# Tradefluenza - Trading Platform & Community

## Overview

Tradefluenza is a comprehensive trading platform and community that provides transparent information about proprietary trading firms, brokers, trading events, and mentorship services. The platform serves as a centralized hub for traders to discover, compare, and engage with trading-related services while building a community around trading education and experiences.

## System Architecture

The application follows a full-stack TypeScript architecture with a modern React frontend and Node.js/Express backend:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: Tanstack React Query for server state
- **UI Components**: Radix UI primitives with Tailwind CSS styling
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom design system

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Authentication**: Passport.js with session-based auth
- **Database ORM**: Drizzle ORM with type-safe queries
- **Real-time**: WebSocket integration for live updates

### Database Architecture
- **Database**: PostgreSQL (Neon serverless)
- **Schema Management**: Drizzle Kit for migrations
- **Connection Pool**: Optimized with connection limits for performance

## Key Components

### 1. Prop Firm Management System
- Comprehensive prop firm comparison and filtering
- Dynamic pricing and account size calculations
- Review and rating system for user feedback
- Promotion and coupon code management

### 2. Broker Comparison Platform
- Multi-criteria broker evaluation system
- Regulatory compliance tracking
- User reviews and ratings
- Detailed broker profiles with pros/cons

### 3. Events & Community Platform
- Trading event management and registration
- Event reviews and feedback system
- Speaker and agenda management
- Premium event handling with payments

### 4. Mentorship Platform
- Mentor discovery and booking system
- Session management and scheduling
- Review system for mentor services
- Specialization-based filtering

### 5. Social Trading Features
- User profiles with trading experience
- Follow/unfollow functionality
- Trade post sharing and commenting
- Trading floor for community discussions

### 6. Admin Dashboard
- Purchase statistics management
- Content management system
- Analytics and reporting tools
- User management capabilities

## Data Flow

### Client-Side Data Flow
1. **Query Management**: React Query handles all server state with optimized caching
2. **Form Handling**: React Hook Form with Zod validation for type safety
3. **Authentication**: Context-based auth state management with session persistence
4. **Real-time Updates**: WebSocket connections for live data updates

### Server-Side Data Flow
1. **Request Processing**: Express middleware chain for request handling
2. **Authentication**: Session-based auth with PostgreSQL session store
3. **Database Operations**: Drizzle ORM for type-safe database interactions
4. **Response Formatting**: Consistent API response structure

### Database Schema Design
- **Users**: Core user management with trading profiles
- **Prop Firms**: Comprehensive prop firm data with pricing tiers
- **Brokers**: Broker information with regulatory details
- **Events**: Event management with registration and reviews
- **Mentors**: Mentor profiles with booking and review systems
- **Social Features**: Posts, comments, likes, and follows

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Type-safe database ORM
- **express**: Web application framework
- **passport**: Authentication middleware
- **ws**: WebSocket implementation
- **zod**: Runtime type validation

### UI & Styling
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe styling variants
- **lucide-react**: Modern icon library

### Development Tools
- **typescript**: Type system
- **vite**: Build tool and dev server
- **tsx**: TypeScript execution
- **esbuild**: Fast JavaScript bundler

## Deployment Strategy

### Development Environment
- **Platform**: Replit with Node.js 20
- **Database**: PostgreSQL 16 module
- **Development Server**: Vite dev server on port 5000
- **Hot Reload**: Enabled for both client and server code

### Production Build Process
1. **Client Build**: Vite builds optimized React application
2. **Server Build**: esbuild bundles Node.js server code
3. **Static Assets**: Served from Express for production
4. **Database Migrations**: Drizzle Kit manages schema updates

### Performance Optimizations
- **Memory Management**: Periodic cleanup and garbage collection
- **Lazy Loading**: Code splitting for major components
- **Image Optimization**: Lazy loading and compression
- **Query Optimization**: React Query with optimized cache settings
- **Bundle Splitting**: Separate chunks for better loading performance

### Monitoring & Analytics
- **Google Analytics**: Integrated tracking for user behavior
- **Performance Monitoring**: Memory usage and render time tracking
- **Error Handling**: Comprehensive error boundaries and logging

## Changelog

- June 19, 2025: Added "Know The Propfirm" video section with YouTube integration and mobile-optimized UI
- June 19, 2025: Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.