import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { storage } from "./storage";
import { 
  propFirmFilterSchema, 
  propFirmSortSchema, 
  insertReviewSchema,
  brokerFilterSchema,
  brokerSortSchema,
  insertBrokerReviewSchema,
  insertPromotionEntrySchema,
  promotionEntries,
  events,
  eventRegistrations,
  eventReviews,
  insertEventReviewSchema,
  users,
  // Trading firms schema
  tradingFirms,
  // Social media schema imports
  updateUserProfileSchema,
  tradePosts,
  postComments,
  postLikes,
  userFollows,
  tradingFloor,
  insertTradePostSchema,
  updateTradePostSchema,
  insertCommentSchema,
  updateCommentSchema,
  updateTradingFloorSchema,
  // Testimonials schema
  testimonials,
  insertTestimonialSchema,
  // Lucky offer schema
  luckyOfferEntries,
  insertLuckyOfferEntrySchema,
  // Forms schema
  forms,
  formFields,
  formSubmissions,
  insertFormSchema,
  insertFormFieldSchema,
  insertFormSubmissionSchema,
  updateFormSchema
} from "@shared/schema";
import { z } from "zod";
import { eq, desc, and, asc, avg, count, gt, gte, ilike, inArray, lt, lte, or, sql } from "drizzle-orm";
import { db } from "./db";
import { setupAuth } from "./auth";
import * as mentorRoutes from "./routes/mentors";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Trading Firms API endpoint
  app.get("/api/trading-firms", async (_req: Request, res: Response) => {
    try {
      const firms = await db.select().from(tradingFirms).orderBy(asc(tradingFirms.position));
      res.json(firms);
    } catch (error) {
      console.error("Error fetching trading firms:", error);
      res.status(500).json({ error: "Failed to fetch trading firms" });
    }
  });
  
  // Mentor routes
  app.get("/api/mentors", mentorRoutes.getMentors);
  app.get("/api/mentors/:id", mentorRoutes.getMentorById);
  app.get("/api/mentors/:id/reviews", mentorRoutes.getMentorReviews);
  app.post("/api/mentors/:id/reviews", mentorRoutes.createMentorReview);
  app.post("/api/mentor-reviews", mentorRoutes.createMentorReview);
  app.post("/api/mentors/:id/book", mentorRoutes.bookMentorSession);
  app.get("/api/user/mentor-sessions", mentorRoutes.getUserSessions);
  app.get("/api/mentor/sessions", mentorRoutes.getMentorSessions);
  app.patch("/api/mentor-sessions/:id/status", mentorRoutes.updateSessionStatus);
  
  // put application routes here
  // prefix all routes with /api

  // Get prop firms with account size and optional filters
  app.get("/api/prop-firms", async (req: Request, res: Response) => {
    try {
      // Parse account size from query params (0 to return all prop firms)
      const accountSizeSchema = z.object({
        accountSize: z.coerce.number().default(0)
      });
      
      const { accountSize } = accountSizeSchema.parse(req.query);
      
      // Manually create filter from query parameters to handle the string values
      const filter: any = {};
      
      // Extract filter parameters
      if (req.query.programType && req.query.programType !== 'any') {
        filter.programType = req.query.programType as string;
      }
      
      if (req.query.profitTarget && req.query.profitTarget !== 'any') {
        filter.profitTarget = req.query.profitTarget as string;
      }
      
      if (req.query.dailyLoss && req.query.dailyLoss !== 'any') {
        filter.dailyLoss = req.query.dailyLoss as string;
      }
      
      if (req.query.maxLoss && req.query.maxLoss !== 'any') {
        filter.maxLoss = req.query.maxLoss as string;
      }
      
      if (req.query.profitSplit && req.query.profitSplit !== 'any') {
        filter.profitSplit = req.query.profitSplit as string;
      }
      
      if (req.query.payoutFrequency && req.query.payoutFrequency !== 'any') {
        filter.payoutFrequency = req.query.payoutFrequency as string;
      }
      
      // Parse sort options from query params
      const sortParams = propFirmSortSchema.safeParse(req.query);
      const sort = sortParams.success ? sortParams.data : undefined;
      
      // Log received filter parameters for debugging
      console.log("Received filter parameters:", req.query);
      console.log("Parsed filter:", Object.keys(filter).length ? filter : undefined);

      const propFirms = await storage.getPropFirms(
        accountSize, 
        Object.keys(filter).length ? filter : undefined, 
        sort
      );
      
      // Log the number of firms after filtering
      console.log(`Filter result: Found ${propFirms.length} firms matching criteria`);
      
      res.json(propFirms);
    } catch (error) {
      console.error("Error fetching prop firms:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request parameters", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to fetch prop firms" });
    }
  });
  
  // Get all prop firm ratings (for the quiz)
  app.get("/api/prop-firms/ratings", async (_req: Request, res: Response) => {
    try {
      const allFirms = await storage.getAllPropFirms();
      const ratingsPromises = allFirms.map(async (firm) => {
        const averageRating = await storage.getAverageRatingByPropFirm(firm.id);
        return { propFirmId: firm.id, averageRating };
      });
      
      const ratings = await Promise.all(ratingsPromises);
      res.json(ratings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ratings" });
    }
  });

  // Get all account sizes
  app.get("/api/prop-firms/account-sizes", async (_req: Request, res: Response) => {
    try {
      // Get all prop firms to extract the available account sizes
      const allPropFirms = await storage.getAllPropFirms();
      
      // Extract unique account sizes from all prop firms
      const accountSizesSet = new Set<number>();
      
      allPropFirms.forEach(firm => {
        if (firm.accountSizes && Array.isArray(firm.accountSizes)) {
          firm.accountSizes.forEach(size => {
            accountSizesSet.add(size);
          });
        }
      });
      
      // Convert to array and sort
      const allAccountSizes = Array.from(accountSizesSet).sort((a, b) => a - b);
      
      // Return the dynamically generated set of account sizes
      res.json(allAccountSizes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch account sizes" });
    }
  });
  
  // Get all available filter options for the search bar
  app.get("/api/prop-firms/filter-options", async (_req: Request, res: Response) => {
    try {
      // Get all prop firms to extract the available filter options
      const allPropFirms = await storage.getAllPropFirms();
      
      // Extract unique values for each filter
      const programTypes = new Set<string>();
      const profitTargets = new Set<number>();
      const dailyLosses = new Set<number>();
      const maxLosses = new Set<number>();
      const profitSplits = new Set<number>();
      const payoutFrequencies = new Set<string>();
      
      // For debugging
      console.log("Number of firms found:", allPropFirms.length);
      if (allPropFirms.length > 0) {
        console.log("First firm sample:", JSON.stringify(allPropFirms[0], null, 2));
      }
      
      allPropFirms.forEach(firm => {
        try {
          if (firm.programType) programTypes.add(firm.programType);
          
          // Handle profitTargets which can be either an array of numbers or a string
          if (firm.profitTargets) {
            // If it's an array, add each target to the set
            if (Array.isArray(firm.profitTargets)) {
              firm.profitTargets.forEach(target => {
                profitTargets.add(target);
              });
            } 
            // If it's a string, try to extract numeric values with regex
            else if (typeof firm.profitTargets === 'string') {
              const regex = /(\d+)%/g;
              let match;
              while ((match = regex.exec(firm.profitTargets)) !== null) {
                if (match && match[1]) {
                  profitTargets.add(parseInt(match[1]));
                }
              }
            }
          }
          
          if (firm.dailyLoss) {
            // If dailyLoss is already a number, add it directly
            if (typeof firm.dailyLoss === 'number') {
              dailyLosses.add(firm.dailyLoss);
            }
            // If it's a string, extract percentage value (e.g., "4%" becomes 4)
            else if (typeof firm.dailyLoss === 'string') {
              const match = firm.dailyLoss.match(/(\d+)%/);
              if (match && match[1]) {
                dailyLosses.add(parseInt(match[1]));
              }
            }
          }
          
          if (firm.maxLoss) {
            // If maxLoss is already a number, add it directly
            if (typeof firm.maxLoss === 'number') {
              maxLosses.add(firm.maxLoss);
            }
            // If it's a string, extract percentage value (e.g., "8%" becomes 8)
            else if (typeof firm.maxLoss === 'string') {
              const match = firm.maxLoss.match(/(\d+)%/);
              if (match && match[1]) {
                maxLosses.add(parseInt(match[1]));
              }
            }
          }
          
          if (firm.profitSplit) profitSplits.add(firm.profitSplit);
          if (firm.payoutFrequency) payoutFrequencies.add(firm.payoutFrequency);
        } catch (err) {
          console.error("Error processing firm:", err);
        }
      });
      
      // If we don't have any values, provide some defaults
      if (profitTargets.size === 0) profitTargets.add(5).add(8).add(10);
      if (dailyLosses.size === 0) dailyLosses.add(2).add(3).add(4).add(5);
      if (maxLosses.size === 0) maxLosses.add(5).add(8).add(10);
      if (profitSplits.size === 0) profitSplits.add(50).add(70).add(80).add(90);
      if (payoutFrequencies.size === 0) payoutFrequencies.add("Weekly").add("Bi-weekly").add("Monthly");
      if (programTypes.size === 0) programTypes.add("One-Phase").add("Two-Phase").add("Three-Phase");
      
      // Convert to sorted arrays
      const filterOptions = {
        programTypes: Array.from(programTypes).sort(),
        profitTargets: Array.from(profitTargets).sort((a, b) => a - b),
        dailyLosses: Array.from(dailyLosses).sort((a, b) => a - b),
        maxLosses: Array.from(maxLosses).sort((a, b) => a - b),
        profitSplits: Array.from(profitSplits).sort((a, b) => a - b),
        payoutFrequencies: Array.from(payoutFrequencies).sort()
      };
      
      console.log("Filter options:", filterOptions);
      
      // Return the filter options
      res.json(filterOptions);
    } catch (error) {
      console.error("Error in filter options endpoint:", error);
      res.status(500).json({ message: "Failed to fetch filter options" });
    }
  });

  // Get a single prop firm by ID with consolidated info when multiple versions exist
  app.get("/api/prop-firms/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Get the requested prop firm
      const propFirm = await storage.getPropFirmById(id);
      
      if (!propFirm) {
        res.status(404).json({ message: "Prop firm not found" });
        return;
      }
      
      // For Blueberry Funded or other firms that might have multiple entries,
      // get all versions to consolidate account sizes and pricing
      if (propFirm.name === "Blueberry Funded") {
        const allFirms = await storage.getPropFirmsByName(propFirm.name);
        
        // Consolidate account sizes and pricing
        if (allFirms && allFirms.length > 0) {
          // Create a set for unique account sizes
          const accountSizesSet = new Set<number>();
          const pricingMap = new Map<number, number>();
          
          // Process all firms with the same name
          allFirms.forEach(firm => {
            // Add account sizes
            if (firm.accountSizes && Array.isArray(firm.accountSizes)) {
              firm.accountSizes.forEach(size => {
                accountSizesSet.add(size);
              });
            }
            
            // Add pricing entries
            if (firm.pricing && Array.isArray(firm.pricing)) {
              firm.pricing.forEach(price => {
                if (price.accountSize && price.price) {
                  pricingMap.set(price.accountSize, price.price);
                }
              });
            }
          });
          
          // Convert sets and maps back to arrays
          propFirm.accountSizes = Array.from(accountSizesSet).sort((a, b) => a - b);
          
          // Create consolidated pricing array with different program types
          const programTypes = ["Two-Phase", "One-Phase", "Express", "Rapid"];
          propFirm.pricing = Array.from(pricingMap.entries()).map(([accountSize, price], index) => {
            // For Blueberry Funded, let's add some variety in program types
            // Smaller accounts get faster programs, larger accounts get more phases
            let programType;
            if (accountSize <= 10000) {
              programType = accountSize === 5000 ? "Express" : "Rapid";
            } else if (accountSize <= 50000) {
              programType = "One-Phase";
            } else {
              programType = "Two-Phase";
            }
            
            return {
              accountSize,
              price,
              programType
            };
          }).sort((a, b) => a.accountSize - b.accountSize);
        }
      }
      
      res.json(propFirm);
    } catch (error) {
      console.error("Error fetching prop firm:", error);
      res.status(500).json({ message: "Failed to fetch prop firm" });
    }
  });

  // Update prop firm tags
  app.patch("/api/prop-firms/:id/tags", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Validate tags
      const tagSchema = z.object({
        tags: z.array(z.string())
      });
      
      const { tags } = tagSchema.parse(req.body);
      
      // Check if prop firm exists
      const propFirm = await storage.getPropFirmById(id);
      
      if (!propFirm) {
        res.status(404).json({ message: "Prop firm not found" });
        return;
      }
      
      // Update the tags
      const updatedPropFirm = await storage.updatePropFirm(id, { tags });
      
      if (!updatedPropFirm) {
        res.status(500).json({ message: "Failed to update prop firm tags" });
        return;
      }
      
      res.json(updatedPropFirm);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request body", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to update prop firm tags" });
    }
  });

  // Get reviews for a prop firm
  app.get("/api/prop-firms/:id/reviews", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if prop firm exists
      const propFirm = await storage.getPropFirmById(id);
      
      if (!propFirm) {
        res.status(404).json({ message: "Prop firm not found" });
        return;
      }
      
      const reviews = await storage.getReviewsByPropFirm(id);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  // Get average rating for a prop firm
  app.get("/api/prop-firms/:id/rating", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if prop firm exists
      const propFirm = await storage.getPropFirmById(id);
      
      if (!propFirm) {
        res.status(404).json({ message: "Prop firm not found" });
        return;
      }
      
      const averageRating = await storage.getAverageRatingByPropFirm(id);
      res.json({ propFirmId: id, averageRating });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch average rating" });
    }
  });
  


  // Add a review for a prop firm
  app.post("/api/reviews", async (req: Request, res: Response) => {
    try {
      console.log("Received review submission:", req.body);
      
      // Create a review schema with validation
      const reviewWithValidation = insertReviewSchema.extend({
        rating: z.coerce.number().min(1).max(5),
        title: z.string().min(5).max(100),
        content: z.string().min(10),
      });
      
      // Parse and validate the request body
      const parsedData = reviewWithValidation.parse(req.body);
      console.log("Parsed review data:", parsedData);
      
      // Note: We don't need to convert the rating here since numeric 
      // type in PostgreSQL can accept JavaScript numbers
      
      // Validate that the prop firm exists
      const propFirm = await storage.getPropFirmById(parsedData.propFirmId);
      
      if (!propFirm) {
        res.status(404).json({ message: "Prop firm not found" });
        return;
      }
      
      // Create the review
      const newReview = await storage.createReview(parsedData);
      console.log("Created review:", newReview);
      res.status(201).json(newReview);
    } catch (error) {
      console.error("Error creating review:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid review data", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Get a single review by ID
  app.get("/api/reviews/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      const review = await storage.getReviewById(id);
      
      if (!review) {
        res.status(404).json({ message: "Review not found" });
        return;
      }
      
      res.json(review);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch review" });
    }
  });

  // Update a review
  app.patch("/api/reviews/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if review exists
      const existingReview = await storage.getReviewById(id);
      
      if (!existingReview) {
        res.status(404).json({ message: "Review not found" });
        return;
      }
      
      // Create a partial schema for update validation
      const updateSchema = insertReviewSchema.partial().extend({
        rating: z.coerce.number().min(1).max(5).optional(),
        title: z.string().min(5).max(100).optional(),
        content: z.string().min(10).optional(),
      });
      
      const parsedData = updateSchema.parse(req.body);
      
      // Note: No need to convert the rating - numeric column in PostgreSQL can handle JS numbers
      const updatedReview = await storage.updateReview(id, parsedData);
      
      res.json(updatedReview);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid review data", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to update review" });
    }
  });

  // Delete a review
  app.delete("/api/reviews/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if review exists
      const existingReview = await storage.getReviewById(id);
      
      if (!existingReview) {
        res.status(404).json({ message: "Review not found" });
        return;
      }
      
      const success = await storage.deleteReview(id);
      
      if (success) {
        res.status(204).end();
      } else {
        res.status(500).json({ message: "Failed to delete review" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete review" });
    }
  });

  // BROKER ROUTES
  
  // Get all brokers with optional filters
  app.get("/api/brokers", async (req: Request, res: Response) => {
    try {
      // Parse filter options from query params
      const filterParams = brokerFilterSchema.safeParse(req.query);
      const filter = filterParams.success ? filterParams.data : undefined;
      
      // Parse sort options from query params
      const sortParams = brokerSortSchema.safeParse(req.query);
      const sort = sortParams.success ? sortParams.data : undefined;

      const brokers = await storage.getBrokers(filter, sort);
      res.json(brokers);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request parameters", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to fetch brokers" });
    }
  });

  // Get a single broker by ID
  app.get("/api/brokers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      const broker = await storage.getBrokerById(id);
      
      if (!broker) {
        res.status(404).json({ message: "Broker not found" });
        return;
      }
      
      res.json(broker);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch broker" });
    }
  });

  // Update broker tags
  app.patch("/api/brokers/:id/tags", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Validate tags
      const tagSchema = z.object({
        tags: z.array(z.string())
      });
      
      const { tags } = tagSchema.parse(req.body);
      
      // Check if broker exists
      const broker = await storage.getBrokerById(id);
      
      if (!broker) {
        res.status(404).json({ message: "Broker not found" });
        return;
      }
      
      // Update the tags
      const updatedBroker = await storage.updateBroker(id, { tags });
      
      if (!updatedBroker) {
        res.status(500).json({ message: "Failed to update broker tags" });
        return;
      }
      
      res.json(updatedBroker);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request body", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to update broker tags" });
    }
  });

  // Get reviews for a broker
  app.get("/api/brokers/:id/reviews", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if broker exists
      const broker = await storage.getBrokerById(id);
      
      if (!broker) {
        res.status(404).json({ message: "Broker not found" });
        return;
      }
      
      const reviews = await storage.getReviewsByBroker(id);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  // Get average rating for a broker
  app.get("/api/brokers/:id/rating", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if broker exists
      const broker = await storage.getBrokerById(id);
      
      if (!broker) {
        res.status(404).json({ message: "Broker not found" });
        return;
      }
      
      const averageRating = await storage.getAverageRatingByBroker(id);
      res.json({ brokerId: id, averageRating });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch average rating" });
    }
  });

  // Add a review for a broker
  app.post("/api/broker-reviews", async (req: Request, res: Response) => {
    try {
      console.log("Received broker review submission:", req.body);
      
      // Create a review schema with validation
      const reviewWithValidation = insertBrokerReviewSchema.extend({
        rating: z.coerce.number().min(1).max(5),
        title: z.string().min(5).max(100),
        content: z.string().min(10),
      });
      
      // Parse and validate the request body
      const parsedData = reviewWithValidation.parse(req.body);
      
      // Validate that the broker exists
      const broker = await storage.getBrokerById(parsedData.brokerId);
      
      if (!broker) {
        res.status(404).json({ message: "Broker not found" });
        return;
      }
      
      // Create the review
      const newReview = await storage.createBrokerReview(parsedData);
      res.status(201).json(newReview);
    } catch (error) {
      console.error("Error creating broker review:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid review data", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Get a single broker review by ID
  app.get("/api/broker-reviews/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      const review = await storage.getBrokerReviewById(id);
      
      if (!review) {
        res.status(404).json({ message: "Review not found" });
        return;
      }
      
      res.json(review);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch review" });
    }
  });

  // Update a broker review
  app.patch("/api/broker-reviews/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if review exists
      const existingReview = await storage.getBrokerReviewById(id);
      
      if (!existingReview) {
        res.status(404).json({ message: "Review not found" });
        return;
      }
      
      // Create a partial schema for update validation
      const updateSchema = insertBrokerReviewSchema.partial().extend({
        rating: z.coerce.number().min(1).max(5).optional(),
        title: z.string().min(5).max(100).optional(),
        content: z.string().min(10).optional(),
      });
      
      const parsedData = updateSchema.parse(req.body);
      const updatedReview = await storage.updateBrokerReview(id, parsedData);
      
      res.json(updatedReview);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid review data", errors: error.errors });
        return;
      }
      
      res.status(500).json({ message: "Failed to update review" });
    }
  });

  // Delete a broker review
  app.delete("/api/broker-reviews/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        res.status(400).json({ message: "Invalid ID format" });
        return;
      }
      
      // Check if review exists
      const existingReview = await storage.getBrokerReviewById(id);
      
      if (!existingReview) {
        res.status(404).json({ message: "Review not found" });
        return;
      }
      
      const success = await storage.deleteBrokerReview(id);
      
      if (success) {
        res.status(204).end();
      } else {
        res.status(500).json({ message: "Failed to delete review" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete review" });
    }
  });

  // Update prop firm position
  app.patch("/api/prop-firms/:id/position", async (req: Request, res: Response) => {
    try {
      // Ensure user is authenticated
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const positionSchema = z.object({
        position: z.number().int().min(1)
      });
      
      const { position } = positionSchema.parse(req.body);
      const updated = await storage.updatePropFirm(id, { position });
      
      if (!updated) {
        return res.status(404).json({ message: "Prop firm not found" });
      }
      
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ message: "Failed to update position" });
    }
  });

  // Update broker position
  app.patch("/api/brokers/:id/position", async (req: Request, res: Response) => {
    try {
      // Ensure user is authenticated
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const positionSchema = z.object({
        position: z.number().int().min(1)
      });
      
      const { position } = positionSchema.parse(req.body);
      const updated = await storage.updateBroker(id, { position });
      
      if (!updated) {
        return res.status(404).json({ message: "Broker not found" });
      }
      
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ message: "Failed to update position" });
    }
  });


  
  // Generic promotion entry endpoint
  app.post("/api/promotions/entry", async (req: Request, res: Response) => {
    try {
      const { email, phoneNumber, promotionType } = req.body;
      
      if (!email || !phoneNumber) {
        return res.status(400).json({ message: "Email and phone number are required" });
      }
      
      // Create a validation schema for the entry
      const entryWithValidation = insertPromotionEntrySchema.extend({
        email: z.string().email("Please provide a valid email address"),
        phoneNumber: z.string().min(5, "Please provide a valid phone number")
      });
      
      // Validate the entry data
      const validatedData = entryWithValidation.parse({
        email,
        phoneNumber,
        promotionType: promotionType || "generic"
      });
      
      // Save to database
      const newEntry = await db.insert(promotionEntries).values(validatedData).returning();
      
      // Log the entry for monitoring
      console.log(`New ${promotionType} promotion entry created:`, { 
        id: newEntry[0].id, 
        email, 
        promotionType 
      });
      
      // Return success without actual coupon code (will be emailed)
      res.status(201).json({ 
        success: true,
        message: "Entry submitted successfully. Your coupon code will be sent via email."
      });
    } catch (error) {
      console.error("Error creating promotion entry:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create promotion entry" });
    }
  });
  
  // Free account promotion entry endpoint
  app.post("/api/promotions/free-account-entry", async (req: Request, res: Response) => {
    try {
      const { email, phoneNumber } = req.body;
      
      if (!email || !phoneNumber) {
        return res.status(400).json({ message: "Email and phone number are required" });
      }
      
      // Create a validation schema for the entry with the schema from shared/schema.ts
      const entryWithValidation = insertPromotionEntrySchema.extend({
        email: z.string().email("Please provide a valid email address"),
        phoneNumber: z.string().min(5, "Please provide a valid phone number")
      });
      
      // Validate the entry data
      const validatedData = entryWithValidation.parse({
        email,
        phoneNumber,
        promotionType: "free_account" // Set default type for free account entries
      });
      
      // Store the entry in the database
      console.log("Free account entry received:", { email, phoneNumber });
      const entry = await storage.createPromotionEntry(validatedData);
      
      res.status(201).json({ 
        success: true,
        message: "Entry submitted successfully",
        entry
      });
    } catch (error) {
      console.error("Error submitting promotion entry:", error);
      res.status(500).json({ message: "Failed to submit entry" });
    }
  });
  
  // Lucky Offer Form submission
  app.post("/api/lucky-offer", async (req: Request, res: Response) => {
    try {
      console.log("Lucky offer request received:", req.body);
      const { email, propFirmId, propFirmName } = req.body;
      
      // Validate the input
      const validatedData = insertLuckyOfferEntrySchema.parse({
        email,
        propFirmId,
        propFirmName
      });
      
      console.log("Validated data:", validatedData);
      
      // Store the entry in the database
      const entry = await db.insert(luckyOfferEntries).values(validatedData).returning();
      
      console.log("Entry created:", entry[0]);
      
      res.status(201).json({
        success: true,
        message: "Lucky offer entry submitted successfully!",
        entry: entry[0]
      });
    } catch (error) {
      console.error("Error submitting lucky offer entry:", error);
      res.status(500).json({ 
        success: false,
        message: error instanceof Error ? error.message : "Failed to submit lucky offer entry" 
      });
    }
  });

  // Prop Firm Rules API with filtering
  app.get("/api/prop-firm-rules", async (req: Request, res: Response) => {
    try {
      const { search, category, minRating } = req.query;
      
      // Use the database storage method to get prop firm rules
      const propFirmRules = await storage.searchPropFirmRules(
        search as string,
        category as string,
        minRating ? parseFloat(minRating as string) : undefined
      );

      console.log(`Prop firm rules query: search="${search}", category="${category}", minRating="${minRating}"`);
      console.log(`Returning ${propFirmRules.length} filtered rules`);
      
      res.json(propFirmRules);
    } catch (error) {
      console.error("Error fetching prop firm rules:", error);
      res.status(500).json({ error: "Failed to fetch prop firm rules" });
    }
  });
  
  // API endpoint for purchasing statistics
  app.get("/api/stats/purchases", async (_req: Request, res: Response) => {
    try {
      // Fetch the purchase stats from the database
      let stats = await storage.getPurchaseStats();
      
      // If no stats exist yet, create initial stats
      if (!stats) {
        stats = await storage.createInitialPurchaseStats({
          totalPurchases: 18427,
          thisMonth: 742,
          thisWeek: 187,
          today: 34
        });
      }
      
      // Add the breakdown by account size (this could be moved to the database schema in the future)
      const statsWithSizeBreakdown = {
        ...stats,
        bySize: {
          small: Math.floor(stats.totalPurchases * 0.34),  // Small accounts (under $10K)
          medium: Math.floor(stats.totalPurchases * 0.47), // Medium accounts ($10K-$50K) 
          large: Math.floor(stats.totalPurchases * 0.19)   // Large accounts ($50K+)
        }
      };
      
      res.json(statsWithSizeBreakdown);
    } catch (error) {
      console.error("Error fetching purchase statistics:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });
  
  // ADMIN ROUTES
  
  // Update purchase statistics
  app.post("/api/admin/stats/purchases", async (req: Request, res: Response) => {
    try {
      // Check authentication - only admin users should be able to update stats
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Validate the request body
      const statsSchema = z.object({
        totalPurchases: z.number().optional(),
        thisMonth: z.number().optional(),
        thisWeek: z.number().optional(),
        today: z.number().optional()
      });
      
      const parsedData = statsSchema.parse(req.body);
      
      // Update the stats
      const updatedStats = await storage.updatePurchaseStats(parsedData);
      
      if (!updatedStats) {
        return res.status(500).json({ message: "Failed to update purchase statistics" });
      }
      
      res.json(updatedStats);
    } catch (error) {
      console.error("Error updating purchase statistics:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to update purchase statistics" });
    }
  });

  // Resolution Center endpoints
  app.post("/api/support/tickets", async (req: Request, res: Response) => {
    try {
      // Validate the request body using insertSupportTicketSchema
      const supportTicketSchema = z.object({
        name: z.string().min(2),
        email: z.string().email(),
        phoneNumber: z.string().min(5),
        entityType: z.enum(["PropFirm", "Broker"]),
        entityId: z.number().int().positive(),
        category: z.string(),
        description: z.string().min(10)
      });
      
      const ticketData = supportTicketSchema.parse(req.body);
      const newTicket = await storage.createSupportTicket(ticketData);
      res.status(201).json(newTicket);
    } catch (error) {
      console.error("Error creating support ticket:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create support ticket" });
    }
  });

  app.get("/api/support/tickets", async (req: Request, res: Response) => {
    try {
      // Authentication check for viewing tickets (could be removed if tickets should be public)
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const tickets = await storage.getSupportTickets();
      res.status(200).json(tickets);
    } catch (error) {
      console.error("Error fetching support tickets:", error);
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  app.get("/api/support/tickets/:id", async (req: Request, res: Response) => {
    try {
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getSupportTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      res.status(200).json(ticket);
    } catch (error) {
      console.error("Error fetching support ticket:", error);
      res.status(500).json({ message: "Failed to fetch support ticket" });
    }
  });

  app.post("/api/support/tickets/:id/comments", async (req: Request, res: Response) => {
    try {
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getSupportTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      const commentSchema = z.object({
        message: z.string().min(1),
        isFromStaff: z.boolean().optional()
      });
      
      const { message, isFromStaff = false } = commentSchema.parse(req.body);
      
      const commentData = {
        ticketId,
        message,
        isFromStaff: isFromStaff && req.isAuthenticated() // Only allow staff comments if authenticated
      };
      
      const newComment = await storage.createSupportTicketComment(commentData);
      res.status(201).json(newComment);
    } catch (error) {
      console.error("Error creating ticket comment:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create ticket comment" });
    }
  });

  app.patch("/api/support/tickets/:id/status", async (req: Request, res: Response) => {
    try {
      // Authentication check - only staff can update ticket status
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getSupportTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      const statusSchema = z.object({
        status: z.enum(["Open", "In Progress", "Resolved", "Closed"])
      });
      
      const { status } = statusSchema.parse(req.body);
      
      const updatedTicket = await storage.updateSupportTicketStatus(ticketId, status);
      res.status(200).json(updatedTicket);
    } catch (error) {
      console.error("Error updating ticket status:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid status", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to update ticket status" });
    }
  });
  
  // Update prop firm discount percentage
  app.patch("/api/prop-firms/:id/discount", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Validate the discount percentage
      const discountSchema = z.object({
        discountPercentage: z.number().min(0).max(100)
      });
      
      const { discountPercentage } = discountSchema.parse(req.body);
      
      // Check if prop firm exists
      const propFirm = await storage.getPropFirmById(id);
      
      if (!propFirm) {
        return res.status(404).json({ message: "Prop firm not found" });
      }
      
      // Update the discount percentage
      const updatedPropFirm = await storage.updatePropFirmDiscountPercentage(id, discountPercentage);
      
      if (!updatedPropFirm) {
        return res.status(500).json({ message: "Failed to update discount percentage" });
      }
      
      res.json(updatedPropFirm);
    } catch (error) {
      console.error("Error updating prop firm discount:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid discount percentage", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to update discount percentage" });
    }
  });
  
  // Events API Endpoints
  
  // Get all events (with optional featured filter)
  app.get("/api/events", async (req: Request, res: Response) => {
    try {
      const { featured, limit } = req.query;
      let query = db.select().from(events);
      
      // Filter for featured events only if requested
      if (featured === 'true') {
        query = query.where(eq(events.featured, true));
      }
      
      // Apply limit if provided
      if (limit) {
        const limitNum = parseInt(limit as string);
        if (!isNaN(limitNum)) {
          query = query.limit(limitNum);
        }
      }
      
      // Order by date_created (newest first)
      query = query.orderBy(desc(events.dateCreated));
      
      const eventsList = await query;
      res.json(eventsList);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Get a specific event by ID
  app.get("/api/events/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const event = await db.select().from(events).where(eq(events.id, id)).limit(1);
      
      if (!event || event.length === 0) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event[0]);
    } catch (error) {
      console.error("Error fetching event:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Create a new event (admin only)
  app.post("/api/events", async (req: Request, res: Response) => {
    try {
      // For demo purposes, we're allowing event creation without authentication
      // In a production environment, you would want to authenticate the user here
      
      // Perform validation (in a real app you would use Zod here)
      if (!req.body.title || !req.body.description || !req.body.fullDescription || !req.body.date || !req.body.location || !req.body.type) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const newEvent = await db.insert(events).values(req.body).returning();
      
      // Broadcast event creation to all WebSocket clients
      (app as any).broadcastUpdate('event_created', newEvent[0]);
      
      res.status(201).json(newEvent[0]);
    } catch (error) {
      console.error("Error creating event:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Update an event (admin only)
  app.patch("/api/events/:id", async (req: Request, res: Response) => {
    try {
      // For demo purposes, we're allowing event updates without authentication
      // In a production environment, you would want to authenticate the user here
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Add dateUpdated field to the update
      const updateData = {
        ...req.body,
        dateUpdated: new Date()
      };
      
      const [updatedEvent] = await db
        .update(events)
        .set(updateData)
        .where(eq(events.id, id))
        .returning();
      
      if (!updatedEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Broadcast event update to all WebSocket clients
      (app as any).broadcastUpdate('event_updated', updatedEvent);
      
      res.json(updatedEvent);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Delete an event (admin only)
  app.delete("/api/events/:id", async (req: Request, res: Response) => {
    try {
      // For demo purposes, we're allowing event deletion without authentication
      // In a production environment, you would want to authenticate the user here
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const [deletedEvent] = await db
        .delete(events)
        .where(eq(events.id, id))
        .returning();
      
      if (!deletedEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Broadcast event deletion to all WebSocket clients
      (app as any).broadcastUpdate('event_deleted', { id: id });
      
      res.json({ message: "Event deleted successfully" });
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Register for an event
  app.post("/api/events/:id/register", async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Check if the event exists
      const event = await db.select().from(events).where(eq(events.id, eventId)).limit(1);
      
      if (!event || event.length === 0) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Validate required fields
      if (!req.body.name || !req.body.email) {
        return res.status(400).json({ message: "Name and email are required" });
      }
      
      // Create registration data
      let registrationData: any = {
        eventId,
        name: req.body.name,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        status: 'Confirmed',
      };
      
      // Add userId if user is authenticated
      if (req.isAuthenticated() && req.user) {
        registrationData.userId = req.user.id;
      }
      
      // Handle payment information if it's a premium event
      if (event[0].isPremium) {
        registrationData.paymentStatus = 'Pending';
        registrationData.paymentAmount = event[0].price;
      } else {
        registrationData.paymentStatus = 'Free';
      }
      
      // Save additional form fields if provided
      if (req.body.additionalInfo) {
        registrationData.additionalInfo = req.body.additionalInfo;
      }
      
      // Create registration
      const [registration] = await db
        .insert(eventRegistrations)
        .values(registrationData)
        .returning();
      
      // Update current attendees count
      const [updatedEvent] = await db
        .update(events)
        .set({
          currentAttendees: event[0].currentAttendees + 1
        })
        .where(eq(events.id, eventId))
        .returning();
      
      // Broadcast event update (attendee count changed) to all clients
      if (updatedEvent) {
        (app as any).broadcastUpdate('event_updated', updatedEvent);
      }
      
      res.status(201).json(registration);
    } catch (error) {
      console.error("Error registering for event:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Event Reviews API endpoints
  
  // Get reviews for an event
  app.get("/api/events/:id/reviews", async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Check if the event exists
      const event = await db.select().from(events).where(eq(events.id, eventId)).limit(1);
      
      if (!event || event.length === 0) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      console.log(`Fetching reviews for event ${eventId}`);
      
      // Get reviews with user info
      const reviews = await db
        .select({
          id: eventReviews.id,
          eventId: eventReviews.eventId,
          userId: eventReviews.userId,
          username: users.username,
          rating: eventReviews.rating,
          title: eventReviews.title,
          content: eventReviews.content,
          highlights: eventReviews.highlights,
          improvements: eventReviews.improvements,
          datePosted: eventReviews.datePosted,
          isVerified: eventReviews.isVerified,
          wouldRecommend: eventReviews.wouldRecommend
        })
        .from(eventReviews)
        .leftJoin(users, eq(eventReviews.userId, users.id))
        .where(eq(eventReviews.eventId, eventId))
        .orderBy(desc(eventReviews.datePosted));
      
      console.log(`Found ${reviews.length} reviews for event ${eventId}`);
      
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching event reviews:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Create a review for an event
  app.post("/api/events/:id/reviews", async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Check if the event exists
      const event = await db.select().from(events).where(eq(events.id, eventId)).limit(1);
      
      if (!event || event.length === 0) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Validate the user is authenticated
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "You must be logged in to leave a review" });
      }
      
      // Check if user has already reviewed this event
      const existingReview = await db
        .select()
        .from(eventReviews)
        .where(and(
          eq(eventReviews.eventId, eventId),
          eq(eventReviews.userId, req.user!.id)
        ))
        .limit(1);
      
      if (existingReview.length > 0) {
        return res.status(400).json({ message: "You have already reviewed this event" });
      }
      
      // Validate the request body with zod
      const parsedData = insertEventReviewSchema.safeParse({
        ...req.body,
        eventId,
        userId: req.user!.id
      });
      
      if (!parsedData.success) {
        return res.status(400).json({
          message: "Invalid review data",
          errors: parsedData.error.errors
        });
      }
      
      console.log("Inserting review data:", parsedData.data);
      
      // Create the review
      const [review] = await db
        .insert(eventReviews)
        .values(parsedData.data)
        .returning();
      
      // Broadcast the new review to all WebSocket clients
      (app as any).broadcastUpdate('event_review_added', {
        ...review,
        username: req.user!.username
      });
      
      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating event review:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Update a review (only the author can update their review)
  app.patch("/api/events/reviews/:id", async (req: Request, res: Response) => {
    try {
      const reviewId = parseInt(req.params.id);
      if (isNaN(reviewId)) {
        return res.status(400).json({ message: "Invalid review ID" });
      }
      
      // Validate the user is authenticated
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get the review
      const existingReview = await db
        .select()
        .from(eventReviews)
        .where(eq(eventReviews.id, reviewId))
        .limit(1);
      
      if (!existingReview || existingReview.length === 0) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      // Check if the user is the author of the review
      if (existingReview[0].userId !== req.user!.id) {
        return res.status(403).json({ message: "You can only update your own reviews" });
      }
      
      // Only allow updating certain fields
      const allowedUpdates = {
        rating: req.body.rating,
        title: req.body.title,
        content: req.body.content,
        highlights: req.body.highlights,
        improvements: req.body.improvements,
        wouldRecommend: req.body.wouldRecommend
      };
      
      // Update the review
      const [updatedReview] = await db
        .update(eventReviews)
        .set(allowedUpdates)
        .where(eq(eventReviews.id, reviewId))
        .returning();
      
      // Broadcast the updated review to all WebSocket clients
      (app as any).broadcastUpdate('event_review_updated', {
        ...updatedReview,
        username: req.user!.username
      });
      
      res.json(updatedReview);
    } catch (error) {
      console.error("Error updating event review:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Delete a review (only the author or admin can delete)
  app.delete("/api/events/reviews/:id", async (req: Request, res: Response) => {
    try {
      const reviewId = parseInt(req.params.id);
      if (isNaN(reviewId)) {
        return res.status(400).json({ message: "Invalid review ID" });
      }
      
      // Validate the user is authenticated
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get the review
      const existingReview = await db
        .select()
        .from(eventReviews)
        .where(eq(eventReviews.id, reviewId))
        .limit(1);
      
      if (!existingReview || existingReview.length === 0) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      // Check if the user is the author of the review or an admin
      const isAdmin = req.user!.username === "tradefluenza"; // Simple admin check
      if (existingReview[0].userId !== req.user!.id && !isAdmin) {
        return res.status(403).json({ message: "You can only delete your own reviews" });
      }
      
      // Delete the review
      await db
        .delete(eventReviews)
        .where(eq(eventReviews.id, reviewId));
      
      // Broadcast the review deletion to all WebSocket clients
      (app as any).broadcastUpdate('event_review_deleted', {
        id: reviewId,
        eventId: existingReview[0].eventId
      });
      
      res.json({ message: "Review deleted successfully" });
    } catch (error) {
      console.error("Error deleting event review:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  const httpServer = createServer(app);
  
  // Initialize WebSocket server on a distinct path to avoid conflicts with Vite's HMR
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Connected clients set
  const clients = new Set<WebSocket>();
  
  // WebSocket connection handler
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    clients.add(ws);
    
    // Send initial message to confirm connection
    ws.send(JSON.stringify({ 
      type: 'connection_established',
      data: { message: 'Connected to Tradefluenza real-time updates' },
      timestamp: Date.now()
    }));
    
    // Handle client messages
    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message from client:', data);
        
        // Handle specific message types if needed
        if (data.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
        }
      } catch (err) {
        console.error('Error parsing WebSocket message:', err);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      clients.delete(ws);
    });
    
    // Handle errors
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });
  
  // Helper function to broadcast database updates to all connected clients
  const broadcastUpdate = (type: string, data: any) => {
    const message = JSON.stringify({ type, data, timestamp: Date.now() });
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };
  
  // Listen for database changes and broadcast updates
  // This can be called from any route that modifies data
  // Example usage: After creating/updating an event, call broadcastUpdate('event_updated', eventData)
  
  // Export the broadcastUpdate function for use in routes
  (app as any).broadcastUpdate = broadcastUpdate;

  // -------------------- Social Media Platform Routes --------------------
  
  // Middleware to check if user is authenticated
  const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "You must be logged in to perform this action" });
  };

  // Get user profile
  app.get("/api/social/profile/:username", async (req: Request, res: Response) => {
    try {
      const username = req.params.username;
      
      // Find user by username
      const user = await db.query.users.findFirst({
        where: eq(users.username, username)
      });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove sensitive information
      const { password, ...publicProfile } = user;
      
      // Get user's post count
      const postsCount = await db.select({ count: count() })
        .from(tradePosts)
        .where(eq(tradePosts.userId, user.id));
      
      // Get follower count
      const followersCount = await db.select({ count: count() })
        .from(userFollows)
        .where(eq(userFollows.followingId, user.id));
      
      // Get following count
      const followingCount = await db.select({ count: count() })
        .from(userFollows)
        .where(eq(userFollows.followerId, user.id));
      
      // Check if the current user is following this user
      let isFollowing = false;
      if (req.isAuthenticated() && req.user) {
        const followRecord = await db.select()
          .from(userFollows)
          .where(and(
            eq(userFollows.followerId, req.user.id),
            eq(userFollows.followingId, user.id)
          ));
        isFollowing = followRecord.length > 0;
      }
      
      res.json({
        ...publicProfile,
        postsCount: postsCount[0]?.count || 0,
        followersCount: followersCount[0]?.count || 0,
        followingCount: followingCount[0]?.count || 0,
        isFollowing
      });
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });
  
  // Update user profile
  app.patch("/api/social/profile", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.id;
      const updateData = updateUserProfileSchema.parse(req.body);
      
      await db.update(users)
        .set({
          ...updateData,
          lastActive: new Date()
        })
        .where(eq(users.id, userId));
      
      // Get updated user
      const updatedUser = await db.query.users.findFirst({
        where: eq(users.id, userId)
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found after update" });
      }
      
      // Remove sensitive information
      const { password, ...publicProfile } = updatedUser;
      
      res.json(publicProfile);
    } catch (error) {
      console.error("Error updating user profile:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Get posts feed (public posts from all users)
  app.get("/api/social/posts", async (req: Request, res: Response) => {
    try {
      // Get latest posts
      const posts = await db.select()
        .from(tradePosts)
        .where(and(
          eq(tradePosts.isPublic, true),
          eq(tradePosts.isArchived, false)
        ))
        .orderBy(desc(tradePosts.datePosted))
        .limit(20);
      
      // Get authors for each post
      const postsWithAuthor = await Promise.all(posts.map(async (post) => {
        const author = await db.query.users.findFirst({
          where: eq(users.id, post.userId)
        });
        
        const likesCount = await db.select({ count: count() })
          .from(postLikes)
          .where(eq(postLikes.postId, post.id));
        
        const commentsCount = await db.select({ count: count() })
          .from(postComments)
          .where(eq(postComments.postId, post.id));
        
        // Check if current user has liked the post
        let hasLiked = false;
        if (req.isAuthenticated() && req.user) {
          const like = await db.select()
            .from(postLikes)
            .where(and(
              eq(postLikes.postId, post.id),
              eq(postLikes.userId, req.user.id)
            ));
          hasLiked = like.length > 0;
        }
        
        // Remove sensitive user data
        const { password, ...safeAuthor } = author || {};
        
        return {
          ...post,
          author: safeAuthor,
          likesCount: likesCount[0]?.count || 0,
          commentsCount: commentsCount[0]?.count || 0,
          hasLiked
        };
      }));
      
      res.json(postsWithAuthor);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });
  
  // Get user's posts
  app.get("/api/social/posts/user/:username", async (req: Request, res: Response) => {
    try {
      const username = req.params.username;
      
      // Find user by username
      const user = await db.query.users.findFirst({
        where: eq(users.username, username)
      });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get user's posts
      const posts = await db.select()
        .from(tradePosts)
        .where(and(
          eq(tradePosts.userId, user.id),
          eq(tradePosts.isPublic, true),
          eq(tradePosts.isArchived, false)
        ))
        .orderBy(desc(tradePosts.datePosted));
      
      // Get counts and check if liked
      const postsWithDetails = await Promise.all(posts.map(async (post) => {
        const likesCount = await db.select({ count: count() })
          .from(postLikes)
          .where(eq(postLikes.postId, post.id));
        
        const commentsCount = await db.select({ count: count() })
          .from(postComments)
          .where(eq(postComments.postId, post.id));
        
        // Check if current user has liked the post
        let hasLiked = false;
        if (req.isAuthenticated() && req.user) {
          const like = await db.select()
            .from(postLikes)
            .where(and(
              eq(postLikes.postId, post.id),
              eq(postLikes.userId, req.user.id)
            ));
          hasLiked = like.length > 0;
        }
        
        // Remove sensitive user info
        const { password, ...safeUser } = user;
        
        return {
          ...post,
          author: safeUser,
          likesCount: likesCount[0]?.count || 0,
          commentsCount: commentsCount[0]?.count || 0,
          hasLiked
        };
      }));
      
      res.json(postsWithDetails);
    } catch (error) {
      console.error("Error fetching user posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });
  
  // Get feed of followed users
  app.get("/api/social/feed", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.id;
      
      // Get list of users the current user is following
      const following = await db.select({ followingId: userFollows.followingId })
        .from(userFollows)
        .where(eq(userFollows.followerId, userId));
      
      const followingIds = following.map(f => f.followingId);
      
      // Also include the user's own posts
      followingIds.push(userId);
      
      // Get posts from followed users
      const posts = await db.select()
        .from(tradePosts)
        .where(and(
          inArray(tradePosts.userId, followingIds),
          eq(tradePosts.isPublic, true),
          eq(tradePosts.isArchived, false)
        ))
        .orderBy(desc(tradePosts.datePosted))
        .limit(50);
      
      // Get authors and counts for each post
      const postsWithDetails = await Promise.all(posts.map(async (post) => {
        const author = await db.query.users.findFirst({
          where: eq(users.id, post.userId)
        });
        
        const likesCount = await db.select({ count: count() })
          .from(postLikes)
          .where(eq(postLikes.postId, post.id));
        
        const commentsCount = await db.select({ count: count() })
          .from(postComments)
          .where(eq(postComments.postId, post.id));
        
        // Check if user has liked this post
        const like = await db.select()
          .from(postLikes)
          .where(and(
            eq(postLikes.postId, post.id),
            eq(postLikes.userId, userId)
          ));
        
        // Remove sensitive user info
        const { password, ...safeAuthor } = author || {};
        
        return {
          ...post,
          author: safeAuthor,
          likesCount: likesCount[0]?.count || 0,
          commentsCount: commentsCount[0]?.count || 0,
          hasLiked: like.length > 0
        };
      }));
      
      res.json(postsWithDetails);
    } catch (error) {
      console.error("Error fetching feed:", error);
      res.status(500).json({ message: "Failed to fetch feed" });
    }
  });
  
  // Create a post
  app.post("/api/social/posts", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.id;
      const postData = insertTradePostSchema.parse(req.body);
      
      // Create the post
      const [newPost] = await db.insert(tradePosts)
        .values({
          ...postData,
          userId,
          datePosted: new Date(),
          dateUpdated: new Date()
        })
        .returning();
      
      if (!newPost) {
        return res.status(500).json({ message: "Failed to create post" });
      }
      
      // Get the user info
      const author = await db.query.users.findFirst({
        where: eq(users.id, userId)
      });
      
      // Remove sensitive user info
      const { password, ...safeAuthor } = author || {};
      
      // Broadcast the new post to all connected clients
      broadcastUpdate('new_post', {
        ...newPost,
        author: safeAuthor,
        likesCount: 0,
        commentsCount: 0,
        hasLiked: false
      });
      
      res.status(201).json({
        ...newPost,
        author: safeAuthor,
        likesCount: 0,
        commentsCount: 0,
        hasLiked: false
      });
    } catch (error) {
      console.error("Error creating post:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid post data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create post" });
    }
  });
  
  // Create a post with image
  app.post("/api/social/posts/with-image", isAuthenticated, async (req: Request, res: Response) => {
    try {
      // TODO: Add multer or similar for image upload processing
      // For now, redirect to regular post creation without image
      const userId = req.user!.id;
      
      // Since we're not handling file upload yet, create a regular post
      if (!req.body.title || !req.body.content || !req.body.postType) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const postData = {
        title: req.body.title,
        content: req.body.content,
        postType: req.body.postType,
        isPublic: req.body.isPublic === 'true',
      };
      
      // Validate the data
      const validatedData = insertTradePostSchema.parse(postData);
      
      // Create the post
      const [newPost] = await db.insert(tradePosts)
        .values({
          ...validatedData,
          userId,
          datePosted: new Date(),
          dateUpdated: new Date()
        })
        .returning();
      
      if (!newPost) {
        return res.status(500).json({ message: "Failed to create post" });
      }
      
      // Get the user info
      const author = await db.query.users.findFirst({
        where: eq(users.id, userId)
      });
      
      // Remove sensitive user info
      const { password, ...safeAuthor } = author || {};
      
      // Broadcast the new post to all connected clients
      broadcastUpdate('new_post', {
        ...newPost,
        author: safeAuthor,
        likesCount: 0,
        commentsCount: 0,
        hasLiked: false
      });
      
      res.status(201).json({
        ...newPost,
        author: safeAuthor,
        likesCount: 0,
        commentsCount: 0,
        hasLiked: false
      });
    } catch (error) {
      console.error("Error creating post with image:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid post data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create post with image" });
    }
  });
  
  // Update a post
  app.patch("/api/social/posts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      // Check if the post exists and belongs to the user
      const existingPost = await db.select()
        .from(tradePosts)
        .where(and(
          eq(tradePosts.id, postId),
          eq(tradePosts.userId, userId)
        ));
      
      if (existingPost.length === 0) {
        return res.status(404).json({ message: "Post not found or not authorized to update" });
      }
      
      const updateData = updateTradePostSchema.parse(req.body);
      
      // Update the post
      const [updatedPost] = await db.update(tradePosts)
        .set({
          ...updateData,
          dateUpdated: new Date()
        })
        .where(eq(tradePosts.id, postId))
        .returning();
      
      if (!updatedPost) {
        return res.status(500).json({ message: "Failed to update post" });
      }
      
      // Get like and comment counts
      const likesCount = await db.select({ count: count() })
        .from(postLikes)
        .where(eq(postLikes.postId, postId));
      
      const commentsCount = await db.select({ count: count() })
        .from(postComments)
        .where(eq(postComments.postId, postId));
      
      // Get user info
      const author = await db.query.users.findFirst({
        where: eq(users.id, userId)
      });
      
      // Remove sensitive info
      const { password, ...safeAuthor } = author || {};
      
      // Check if user has liked their own post
      const like = await db.select()
        .from(postLikes)
        .where(and(
          eq(postLikes.postId, postId),
          eq(postLikes.userId, userId)
        ));
      
      const result = {
        ...updatedPost,
        author: safeAuthor,
        likesCount: likesCount[0]?.count || 0,
        commentsCount: commentsCount[0]?.count || 0,
        hasLiked: like.length > 0
      };
      
      // Broadcast the update
      broadcastUpdate('post_updated', result);
      
      res.json(result);
    } catch (error) {
      console.error("Error updating post:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update post" });
    }
  });
  
  // Delete a post (soft delete)
  app.delete("/api/social/posts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      // Check if the post exists and belongs to the user
      const existingPost = await db.select()
        .from(tradePosts)
        .where(and(
          eq(tradePosts.id, postId),
          eq(tradePosts.userId, userId)
        ));
      
      if (existingPost.length === 0) {
        return res.status(404).json({ message: "Post not found or not authorized to delete" });
      }
      
      // Soft delete by archiving
      await db.update(tradePosts)
        .set({
          isArchived: true,
          dateUpdated: new Date()
        })
        .where(eq(tradePosts.id, postId));
      
      // Broadcast the deletion
      broadcastUpdate('post_deleted', { id: postId });
      
      res.json({ message: "Post archived successfully" });
    } catch (error) {
      console.error("Error deleting post:", error);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });
  
  // Get a single post with comments
  app.get("/api/social/posts/:id", async (req: Request, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      // Get the post
      const post = await db.select()
        .from(tradePosts)
        .where(eq(tradePosts.id, postId));
      
      if (post.length === 0) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Get the author
      const author = await db.query.users.findFirst({
        where: eq(users.id, post[0].userId)
      });
      
      // Get comments
      const comments = await db.select()
        .from(postComments)
        .where(eq(postComments.postId, postId))
        .orderBy(asc(postComments.datePosted));
      
      // Get like count
      const likesCount = await db.select({ count: count() })
        .from(postLikes)
        .where(eq(postLikes.postId, postId));
      
      // Check if current user has liked the post
      let hasLiked = false;
      if (req.isAuthenticated() && req.user) {
        const like = await db.select()
          .from(postLikes)
          .where(and(
            eq(postLikes.postId, postId),
            eq(postLikes.userId, req.user.id)
          ));
        hasLiked = like.length > 0;
      }
      
      // Get comment authors
      const commentsWithAuthors = await Promise.all(comments.map(async (comment) => {
        const commentAuthor = await db.query.users.findFirst({
          where: eq(users.id, comment.userId)
        });
        
        // Remove sensitive author info
        const { password, ...safeCommentAuthor } = commentAuthor || {};
        
        return {
          ...comment,
          author: safeCommentAuthor
        };
      }));
      
      // Remove sensitive author info
      const { password, ...safeAuthor } = author || {};
      
      res.json({
        ...post[0],
        author: safeAuthor,
        likesCount: likesCount[0]?.count || 0,
        hasLiked,
        comments: commentsWithAuthors
      });
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });
  
  // Add a comment to a post
  app.post("/api/social/posts/:id/comments", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      // Check if the post exists
      const post = await db.select()
        .from(tradePosts)
        .where(eq(tradePosts.id, postId));
      
      if (post.length === 0) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const commentData = insertCommentSchema.parse({
        ...req.body,
        postId,
        userId
      });
      
      // Create the comment
      const [newComment] = await db.insert(postComments)
        .values({
          ...commentData,
          datePosted: new Date(),
          dateUpdated: new Date()
        })
        .returning();
      
      if (!newComment) {
        return res.status(500).json({ message: "Failed to create comment" });
      }
      
      // Get the author
      const author = await db.query.users.findFirst({
        where: eq(users.id, userId)
      });
      
      // Remove sensitive info
      const { password, ...safeAuthor } = author || {};
      
      const result = {
        ...newComment,
        author: safeAuthor
      };
      
      // Broadcast the new comment
      broadcastUpdate('new_comment', {
        postId,
        comment: result
      });
      
      res.status(201).json(result);
    } catch (error) {
      console.error("Error creating comment:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create comment" });
    }
  });
  
  // Like a post
  app.post("/api/social/posts/:id/like", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      // Check if the post exists
      const post = await db.select()
        .from(tradePosts)
        .where(eq(tradePosts.id, postId));
      
      if (post.length === 0) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check if already liked
      const existingLike = await db.select()
        .from(postLikes)
        .where(and(
          eq(postLikes.postId, postId),
          eq(postLikes.userId, userId)
        ));
      
      if (existingLike.length > 0) {
        return res.status(400).json({ message: "You have already liked this post" });
      }
      
      // Add like
      await db.insert(postLikes)
        .values({
          postId,
          userId,
          dateLiked: new Date()
        });
      
      // Get updated like count
      const likeCount = await db.select({ count: count() })
        .from(postLikes)
        .where(eq(postLikes.postId, postId));
      
      // Broadcast the like
      broadcastUpdate('post_liked', {
        postId,
        userId,
        count: likeCount[0]?.count || 1
      });
      
      res.json({ liked: true, count: likeCount[0]?.count || 1 });
    } catch (error) {
      console.error("Error liking post:", error);
      res.status(500).json({ message: "Failed to like post" });
    }
  });
  
  // Unlike a post
  app.delete("/api/social/posts/:id/like", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      // Remove like
      await db.delete(postLikes)
        .where(and(
          eq(postLikes.postId, postId),
          eq(postLikes.userId, userId)
        ));
      
      // Get updated like count
      const likeCount = await db.select({ count: count() })
        .from(postLikes)
        .where(eq(postLikes.postId, postId));
      
      // Broadcast the unlike
      broadcastUpdate('post_unliked', {
        postId,
        userId,
        count: likeCount[0]?.count || 0
      });
      
      res.json({ liked: false, count: likeCount[0]?.count || 0 });
    } catch (error) {
      console.error("Error unliking post:", error);
      res.status(500).json({ message: "Failed to unlike post" });
    }
  });
  
  // Follow a user
  app.post("/api/social/follow/:username", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const followerId = req.user!.id;
      const username = req.params.username;
      
      // Find user to follow
      const userToFollow = await db.query.users.findFirst({
        where: eq(users.username, username)
      });
      
      if (!userToFollow) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const followingId = userToFollow.id;
      
      // Can't follow yourself
      if (followerId === followingId) {
        return res.status(400).json({ message: "You cannot follow yourself" });
      }
      
      // Check if already following
      const existingFollow = await db.select()
        .from(userFollows)
        .where(and(
          eq(userFollows.followerId, followerId),
          eq(userFollows.followingId, followingId)
        ));
      
      if (existingFollow.length > 0) {
        return res.status(400).json({ message: "Already following this user" });
      }
      
      // Create follow
      await db.insert(userFollows)
        .values({
          followerId,
          followingId,
          dateFollowed: new Date()
        });
      
      // Get updated follower count
      const followerCount = await db.select({ count: count() })
        .from(userFollows)
        .where(eq(userFollows.followingId, followingId));
      
      // Broadcast the follow
      broadcastUpdate('user_followed', {
        followerId,
        followingId,
        followerCount: followerCount[0]?.count || 1
      });
      
      res.json({ following: true, followerCount: followerCount[0]?.count || 1 });
    } catch (error) {
      console.error("Error following user:", error);
      res.status(500).json({ message: "Failed to follow user" });
    }
  });
  
  // Unfollow a user
  app.delete("/api/social/follow/:username", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const followerId = req.user!.id;
      const username = req.params.username;
      
      // Find user to unfollow
      const userToUnfollow = await db.query.users.findFirst({
        where: eq(users.username, username)
      });
      
      if (!userToUnfollow) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const followingId = userToUnfollow.id;
      
      // Delete follow
      await db.delete(userFollows)
        .where(and(
          eq(userFollows.followerId, followerId),
          eq(userFollows.followingId, followingId)
        ));
      
      // Get updated follower count
      const followerCount = await db.select({ count: count() })
        .from(userFollows)
        .where(eq(userFollows.followingId, followingId));
      
      // Broadcast the unfollow
      broadcastUpdate('user_unfollowed', {
        followerId,
        followingId,
        followerCount: followerCount[0]?.count || 0
      });
      
      res.json({ following: false, followerCount: followerCount[0]?.count || 0 });
    } catch (error) {
      console.error("Error unfollowing user:", error);
      res.status(500).json({ message: "Failed to unfollow user" });
    }
  });
  
  // Get trading floor data
  app.get("/api/social/trading-floor", async (_req: Request, res: Response) => {
    try {
      const markets = await db.select()
        .from(tradingFloor)
        .orderBy(desc(tradingFloor.activityLevel));
      
      res.json(markets);
    } catch (error) {
      console.error("Error fetching trading floor data:", error);
      res.status(500).json({ message: "Failed to fetch trading floor data" });
    }
  });
  
  // Testimonials API Endpoints
  
  // In-memory cache for testimonials data with improved structure
  const testimonialsCache = new Map<string, { 
    data: any,
    timestamp: number,
    etag: string,
    lastModified: Date
  }>();
  
  const CACHE_TTL = 10 * 60 * 1000; // 10 minutes cache TTL (extended for better performance)
  
  // Utility function to clear testimonials cache
  const clearTestimonialsCache = () => {
    // Clear all testimonials- prefixed keys at once
    Array.from(testimonialsCache.keys())
      .filter(key => key.startsWith('testimonials-'))
      .forEach(key => testimonialsCache.delete(key));
    console.log('Testimonials list cache cleared');
  };
  
  // Helper function to generate an ETag for cache validation
  const generateETag = (data: any): string => {
    const jsonStr = JSON.stringify(data);
    // Simple hash function for ETag generation
    let hash = 0;
    for (let i = 0; i < jsonStr.length; i++) {
      const char = jsonStr.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return `W/"${hash.toString(16)}"`;
  };
  
  // Get all testimonials or featured testimonials only with pagination - Optimized version
  app.get("/api/testimonials", async (req: Request, res: Response) => {
    try {
      const featuredOnly = req.query.featured === "true";
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      // Create cache key based on normalized query parameters for better cache hits
      const cacheKey = `testimonials-${featuredOnly}-${limit}-${offset}`;
      
      // Check if we have a valid cached response and handle conditional requests
      const cachedData = testimonialsCache.get(cacheKey);
      
      if (cachedData) {
        // Support for If-None-Match (ETag) and If-Modified-Since headers
        const clientETag = req.headers['if-none-match'];
        const ifModifiedSince = req.headers['if-modified-since'] 
          ? new Date(req.headers['if-modified-since'] as string).getTime() 
          : 0;
          
        // If client has valid cache (via ETag or modification date), return 304
        if ((clientETag && clientETag === cachedData.etag) || 
            (ifModifiedSince && cachedData.lastModified.getTime() <= ifModifiedSince)) {
          res.status(304).end();
          return;
        }
        
        // If cache is still valid but client doesn't have it, serve from cache
        if ((Date.now() - cachedData.timestamp) < CACHE_TTL) {
          console.log('Serving testimonials from cache');
          
          // Set cache-related headers
          res.set({
            'Cache-Control': 'public, max-age=600, stale-while-revalidate=60',
            'ETag': cachedData.etag,
            'Last-Modified': cachedData.lastModified.toUTCString()
          });
          
          return res.json(cachedData.data);
        }
      }
      
      console.log('Fetching fresh testimonials data from database');
      
      // Optimize query to use indices created in schema
      let query = db.select().from(testimonials);
      
      // Apply filters efficiently using indexed columns
      if (featuredOnly) {
        query = query.where(eq(testimonials.featured, true));
      }
      
      // Optimize count query by using indexes where possible
      const countQuery = db.select({ count: sql`count(*)` }).from(testimonials);
      if (featuredOnly) {
        countQuery.where(eq(testimonials.featured, true));
      }
      const [{ count }] = await countQuery;
      
      // Apply pagination and use indexes for efficient ordering
      query = query
        .limit(limit)
        .offset(offset)
        .orderBy(asc(testimonials.displayOrder), desc(testimonials.dateAdded));
      
      const results = await query;
      
      // Create optimized response object
      const responseData = {
        data: results,
        pagination: {
          total: Number(count),
          limit,
          offset,
          hasMore: offset + results.length < Number(count)
        },
        meta: {
          cachedAt: new Date().toISOString(),
          source: 'database'
        }
      };
      
      // Generate ETag for this response
      const etag = generateETag(responseData);
      const lastModified = new Date();
      
      // Store enhanced metadata in cache for future requests
      testimonialsCache.set(cacheKey, {
        data: responseData,
        timestamp: Date.now(),
        etag,
        lastModified
      });
      
      // Set comprehensive cache headers for better client and CDN caching
      res.set({
        'Cache-Control': 'public, max-age=600, stale-while-revalidate=60',
        'ETag': etag,
        'Last-Modified': lastModified.toUTCString(),
        'Vary': 'Accept-Encoding'
      });
      
      // Return optimized response
      res.json(responseData);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      res.status(500).json({ 
        message: "Failed to fetch testimonials",
        error: process.env.NODE_ENV === 'development' ? String(error) : undefined
      });
    }
  });
  
  // Get a single testimonial by ID
  app.get("/api/testimonials/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid testimonial ID" });
      }
      
      // Check cache first
      const cacheKey = `testimonial-${id}`;
      const cachedData = testimonialsCache.get(cacheKey);
      
      if (cachedData && (Date.now() - cachedData.timestamp) < CACHE_TTL) {
        console.log(`Serving testimonial ${id} from cache`);
        // Set explicit cache headers
        res.set('Cache-Control', 'public, max-age=300');
        return res.json(cachedData.data);
      }
      
      const [testimonial] = await db
        .select()
        .from(testimonials)
        .where(eq(testimonials.id, id));
      
      if (!testimonial) {
        return res.status(404).json({ message: "Testimonial not found" });
      }
      
      // Store in cache
      testimonialsCache.set(cacheKey, {
        data: testimonial,
        timestamp: Date.now()
      });
      
      // Set cache headers
      res.set('Cache-Control', 'public, max-age=300');
      res.json(testimonial);
    } catch (error) {
      console.error("Error fetching testimonial:", error);
      res.status(500).json({ message: "Failed to fetch testimonial" });
    }
  });
  
  // Admin API endpoint to create a new testimonial (protected by admin role check)
  app.post("/api/testimonials", async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated and has admin role
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = req.user as User;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Insufficient permissions" });
      }
      
      // Validate the request body
      const testimonialData = insertTestimonialSchema.parse(req.body);
      
      // Insert the testimonial
      const [newTestimonial] = await db
        .insert(testimonials)
        .values(testimonialData)
        .returning();
      
      // Clear cache for list endpoints since we have a new testimonial
      clearTestimonialsCache();
      console.log('Cache cleared after creating new testimonial');
      
      res.status(201).json(newTestimonial);
    } catch (error) {
      console.error("Error creating testimonial:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid testimonial data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create testimonial" });
    }
  });
  
  // Admin API endpoint to update a testimonial (protected by admin role check)
  app.put("/api/testimonials/:id", async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated and has admin role
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = req.user as User;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Insufficient permissions" });
      }
      
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid testimonial ID" });
      }
      
      // Validate the request body
      const testimonialData = insertTestimonialSchema.parse(req.body);
      
      // Check if testimonial exists
      const [existingTestimonial] = await db
        .select()
        .from(testimonials)
        .where(eq(testimonials.id, id));
      
      if (!existingTestimonial) {
        return res.status(404).json({ message: "Testimonial not found" });
      }
      
      // Update the testimonial
      const [updatedTestimonial] = await db
        .update(testimonials)
        .set(testimonialData)
        .where(eq(testimonials.id, id))
        .returning();
      
      // Clear individual testimonial cache
      testimonialsCache.delete(`testimonial-${id}`);
      
      // Use utility function to clear list caches
      clearTestimonialsCache();
      
      console.log(`Cache cleared for updated testimonial id: ${id}`);
      res.json(updatedTestimonial);
    } catch (error) {
      console.error("Error updating testimonial:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid testimonial data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to update testimonial" });
    }
  });
  
  // Admin API endpoint to delete a testimonial (protected by admin role check)
  app.delete("/api/testimonials/:id", async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated and has admin role
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = req.user as User;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Insufficient permissions" });
      }
      
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid testimonial ID" });
      }
      
      // Check if testimonial exists
      const [existingTestimonial] = await db
        .select()
        .from(testimonials)
        .where(eq(testimonials.id, id));
      
      if (!existingTestimonial) {
        return res.status(404).json({ message: "Testimonial not found" });
      }
      
      // Delete the testimonial
      await db
        .delete(testimonials)
        .where(eq(testimonials.id, id));
      
      // Clear individual testimonial cache
      testimonialsCache.delete(`testimonial-${id}`);
      
      // Use utility function to clear list caches
      clearTestimonialsCache();
      
      console.log(`Cache cleared for deleted testimonial id: ${id}`);
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting testimonial:", error);
      res.status(500).json({ message: "Failed to delete testimonial" });
    }
  });

  // ==================== FORM MANAGEMENT API ROUTES ====================

  // Get all forms
  app.get("/api/forms", async (req: Request, res: Response) => {
    try {
      const allForms = await db.select().from(forms).orderBy(asc(forms.name));
      res.json(allForms);
    } catch (error) {
      console.error("Error fetching forms:", error);
      res.status(500).json({ message: "Failed to fetch forms" });
    }
  });

  // Get form by ID with fields
  app.get("/api/forms/:id", async (req: Request, res: Response) => {
    try {
      const formId = parseInt(req.params.id);
      if (isNaN(formId)) {
        return res.status(400).json({ message: "Invalid form ID" });
      }

      const form = await db.query.forms.findFirst({
        where: eq(forms.id, formId),
        with: {
          fields: {
            orderBy: asc(formFields.order)
          }
        }
      });

      if (!form) {
        return res.status(404).json({ message: "Form not found" });
      }

      res.json(form);
    } catch (error) {
      console.error("Error fetching form:", error);
      res.status(500).json({ message: "Failed to fetch form" });
    }
  });

  // Create new form
  app.post("/api/forms", async (req: Request, res: Response) => {
    try {
      const validatedData = insertFormSchema.parse(req.body);
      
      const [newForm] = await db
        .insert(forms)
        .values(validatedData)
        .returning();

      res.status(201).json(newForm);
    } catch (error) {
      console.error("Error creating form:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid form data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create form" });
    }
  });

  // Update form
  app.patch("/api/forms/:id", async (req: Request, res: Response) => {
    try {
      const formId = parseInt(req.params.id);
      if (isNaN(formId)) {
        return res.status(400).json({ message: "Invalid form ID" });
      }

      const validatedData = updateFormSchema.parse(req.body);
      
      const [updatedForm] = await db
        .update(forms)
        .set(validatedData)
        .where(eq(forms.id, formId))
        .returning();

      if (!updatedForm) {
        return res.status(404).json({ message: "Form not found" });
      }

      res.json(updatedForm);
    } catch (error) {
      console.error("Error updating form:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid form data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update form" });
    }
  });

  // Delete form
  app.delete("/api/forms/:id", async (req: Request, res: Response) => {
    try {
      const formId = parseInt(req.params.id);
      if (isNaN(formId)) {
        return res.status(400).json({ message: "Invalid form ID" });
      }

      // Delete form fields first (cascade)
      await db.delete(formFields).where(eq(formFields.formId, formId));
      
      // Delete form submissions
      await db.delete(formSubmissions).where(eq(formSubmissions.formId, formId));
      
      // Delete the form
      const [deletedForm] = await db
        .delete(forms)
        .where(eq(forms.id, formId))
        .returning();

      if (!deletedForm) {
        return res.status(404).json({ message: "Form not found" });
      }

      res.json({ message: "Form deleted successfully" });
    } catch (error) {
      console.error("Error deleting form:", error);
      res.status(500).json({ message: "Failed to delete form" });
    }
  });

  // Add field to form
  app.post("/api/forms/:id/fields", async (req: Request, res: Response) => {
    try {
      const formId = parseInt(req.params.id);
      if (isNaN(formId)) {
        return res.status(400).json({ message: "Invalid form ID" });
      }

      // Check if form exists
      const form = await db.select().from(forms).where(eq(forms.id, formId)).limit(1);
      if (!form.length) {
        return res.status(404).json({ message: "Form not found" });
      }

      const validatedData = insertFormFieldSchema.parse({
        ...req.body,
        formId
      });
      
      const [newField] = await db
        .insert(formFields)
        .values(validatedData)
        .returning();

      res.status(201).json(newField);
    } catch (error) {
      console.error("Error adding form field:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid field data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add form field" });
    }
  });

  // Update form field
  app.patch("/api/forms/fields/:id", async (req: Request, res: Response) => {
    try {
      const fieldId = parseInt(req.params.id);
      if (isNaN(fieldId)) {
        return res.status(400).json({ message: "Invalid field ID" });
      }

      const [updatedField] = await db
        .update(formFields)
        .set(req.body)
        .where(eq(formFields.id, fieldId))
        .returning();

      if (!updatedField) {
        return res.status(404).json({ message: "Field not found" });
      }

      res.json(updatedField);
    } catch (error) {
      console.error("Error updating form field:", error);
      res.status(500).json({ message: "Failed to update field" });
    }
  });

  // Delete form field
  app.delete("/api/forms/fields/:id", async (req: Request, res: Response) => {
    try {
      const fieldId = parseInt(req.params.id);
      if (isNaN(fieldId)) {
        return res.status(400).json({ message: "Invalid field ID" });
      }

      const [deletedField] = await db
        .delete(formFields)
        .where(eq(formFields.id, fieldId))
        .returning();

      if (!deletedField) {
        return res.status(404).json({ message: "Field not found" });
      }

      res.json({ message: "Field deleted successfully" });
    } catch (error) {
      console.error("Error deleting form field:", error);
      res.status(500).json({ message: "Failed to delete field" });
    }
  });

  // Submit form
  app.post("/api/forms/:id/submit", async (req: Request, res: Response) => {
    try {
      const formId = parseInt(req.params.id);
      if (isNaN(formId)) {
        return res.status(400).json({ message: "Invalid form ID" });
      }

      // Check if form exists
      const form = await db.select().from(forms).where(eq(forms.id, formId)).limit(1);
      if (!form.length) {
        return res.status(404).json({ message: "Form not found" });
      }

      const validatedData = insertFormSubmissionSchema.parse({
        ...req.body,
        formId
      });
      
      const [newSubmission] = await db
        .insert(formSubmissions)
        .values(validatedData)
        .returning();

      res.status(201).json(newSubmission);
    } catch (error) {
      console.error("Error submitting form:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid submission data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit form" });
    }
  });

  // Get form submissions
  app.get("/api/forms/:id/submissions", async (req: Request, res: Response) => {
    try {
      const formId = parseInt(req.params.id);
      if (isNaN(formId)) {
        return res.status(400).json({ message: "Invalid form ID" });
      }

      const submissions = await db
        .select()
        .from(formSubmissions)
        .where(eq(formSubmissions.formId, formId))
        .orderBy(desc(formSubmissions.submittedAt));

      res.json(submissions);
    } catch (error) {
      console.error("Error fetching form submissions:", error);
      res.status(500).json({ message: "Failed to fetch submissions" });
    }
  });

  // Get forms by language
  app.get("/api/forms/language/:language", async (req: Request, res: Response) => {
    try {
      const language = req.params.language;
      
      const languageForms = await db
        .select()
        .from(forms)
        .where(eq(forms.language, language))
        .orderBy(asc(forms.name));

      res.json(languageForms);
    } catch (error) {
      console.error("Error fetching forms by language:", error);
      res.status(500).json({ message: "Failed to fetch forms" });
    }
  });

  return httpServer;
}
