import { 
  users, type User, type InsertUser,
  propFirms, type PropFirm, type InsertPropFirm, 
  type PropFirmFilter, type PropFirmSort, 
  propFirmRules, type PropFirmRules, type InsertPropFirmRules,
  reviews, type Review, type InsertReview,
  brokers, type Broker, type InsertBroker,
  type BrokerFilter, type BrokerSort,
  brokerReviews, type BrokerReview, type InsertBrokerReview,
  promotionEntries, type PromotionEntry, type InsertPromotionEntry,
  purchaseStats, type PurchaseStats, type InsertPurchaseStats, type UpdatePurchaseStats,
  achievementBadges, type AchievementBadge, type InsertAchievementBadge,
  userAchievements, type UserAchievement, type InsertUserAchievement,
  supportTickets, type SupportTicket, type InsertSupportTicket,
  supportTicketComments, type SupportTicketComment, type InsertSupportTicketComment
} from "@shared/schema";
import { db } from "./db";
import { eq, and, inArray, asc, desc, sql, count, gt, or, ilike, gte } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Prop Firm methods
  getAllPropFirms(): Promise<PropFirm[]>;
  getPropFirmById(id: number): Promise<PropFirm | undefined>;
  getPropFirmsByName(name: string): Promise<PropFirm[]>;
  createPropFirm(propFirm: InsertPropFirm): Promise<PropFirm>;
  updatePropFirm(id: number, propFirm: Partial<InsertPropFirm>): Promise<PropFirm | undefined>;
  updatePropFirmDiscountPercentage(id: number, discountPercentage: number): Promise<PropFirm | undefined>;
  deletePropFirm(id: number): Promise<boolean>;
  
  // Filtered prop firms
  getPropFirms(accountSize: number, filter?: PropFirmFilter, sort?: PropFirmSort): Promise<PropFirm[]>;
  
  // Review methods for prop firms
  getReviewsByPropFirm(propFirmId: number): Promise<Review[]>;
  getReviewById(id: number): Promise<Review | undefined>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: number, review: Partial<InsertReview>): Promise<Review | undefined>;
  deleteReview(id: number): Promise<boolean>;
  getAverageRatingByPropFirm(propFirmId: number): Promise<number>;
  
  // Broker methods
  getAllBrokers(): Promise<Broker[]>;
  getBrokerById(id: number): Promise<Broker | undefined>;
  createBroker(broker: InsertBroker): Promise<Broker>;
  updateBroker(id: number, broker: Partial<InsertBroker>): Promise<Broker | undefined>;
  deleteBroker(id: number): Promise<boolean>;
  
  // Filtered brokers
  getBrokers(filter?: BrokerFilter, sort?: BrokerSort): Promise<Broker[]>;
  
  // Support ticket methods
  createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket>;
  getSupportTickets(): Promise<SupportTicket[]>;
  getSupportTicket(id: number): Promise<SupportTicket | undefined>;
  updateSupportTicketStatus(id: number, status: string): Promise<SupportTicket | undefined>;
  createSupportTicketComment(comment: InsertSupportTicketComment): Promise<SupportTicketComment>;
  
  // Review methods for brokers
  getReviewsByBroker(brokerId: number): Promise<BrokerReview[]>;
  getBrokerReviewById(id: number): Promise<BrokerReview | undefined>;
  createBrokerReview(review: InsertBrokerReview): Promise<BrokerReview>;
  updateBrokerReview(id: number, review: Partial<InsertBrokerReview>): Promise<BrokerReview | undefined>;
  deleteBrokerReview(id: number): Promise<boolean>;
  getAverageRatingByBroker(brokerId: number): Promise<number>;


  
  // Promotion entry methods
  getPromotionEntries(promotionType?: string): Promise<PromotionEntry[]>;
  createPromotionEntry(entry: InsertPromotionEntry): Promise<PromotionEntry>;
  markPromotionEntryAsProcessed(id: number, notes?: string): Promise<boolean>;
  
  // Purchase statistics methods
  getPurchaseStats(): Promise<PurchaseStats | undefined>;
  updatePurchaseStats(stats: UpdatePurchaseStats): Promise<PurchaseStats | undefined>;
  createInitialPurchaseStats(stats: InsertPurchaseStats): Promise<PurchaseStats>;
  
  // Achievement badges methods
  getAllAchievementBadges(): Promise<AchievementBadge[]>;
  getAchievementBadgeById(id: number): Promise<AchievementBadge | undefined>;
  getAchievementBadgesByCategory(category: string): Promise<AchievementBadge[]>;
  createAchievementBadge(badge: InsertAchievementBadge): Promise<AchievementBadge>;
  updateAchievementBadge(id: number, badge: Partial<InsertAchievementBadge>): Promise<AchievementBadge | undefined>;
  deleteAchievementBadge(id: number): Promise<boolean>;
  
  // User achievements methods
  getUserAchievements(userId: number): Promise<(UserAchievement & { badge: AchievementBadge })[]>;
  getUserAchievementById(id: number): Promise<UserAchievement | undefined>;
  createUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement>;
  updateUserAchievement(id: number, achievement: Partial<InsertUserAchievement>): Promise<UserAchievement | undefined>;
  deleteUserAchievement(id: number): Promise<boolean>;
  getFeaturedAchievements(userId: number): Promise<(UserAchievement & { badge: AchievementBadge })[]>;
  
  // Prop Firm Rules methods
  getAllPropFirmRules(): Promise<PropFirmRules[]>;
  getPropFirmRuleById(id: number): Promise<PropFirmRules | undefined>;
  createPropFirmRule(rule: InsertPropFirmRules): Promise<PropFirmRules>;
  updatePropFirmRule(id: number, rule: Partial<InsertPropFirmRules>): Promise<PropFirmRules | undefined>;
  deletePropFirmRule(id: number): Promise<boolean>;
  searchPropFirmRules(search?: string, category?: string, minRating?: number): Promise<PropFirmRules[]>;
  
  // Support ticket methods - already defined above
}

// Database implementation using PostgreSQL
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  


  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllPropFirms(): Promise<PropFirm[]> {
    return await db.select().from(propFirms);
  }

  async getPropFirmById(id: number): Promise<PropFirm | undefined> {
    const [firm] = await db.select().from(propFirms).where(eq(propFirms.id, id));
    return firm;
  }
  
  async getPropFirmsByName(name: string): Promise<PropFirm[]> {
    return await db.select().from(propFirms).where(eq(propFirms.name, name));
  }

  async createPropFirm(insertPropFirm: InsertPropFirm): Promise<PropFirm> {
    const [firm] = await db.insert(propFirms)
      .values(insertPropFirm)
      .returning();
    return firm;
  }

  async updatePropFirm(id: number, update: Partial<InsertPropFirm>): Promise<PropFirm | undefined> {
    const [updated] = await db.update(propFirms)
      .set(update)
      .where(eq(propFirms.id, id))
      .returning();
    return updated;
  }
  
  async updatePropFirmDiscountPercentage(id: number, discountPercentage: number): Promise<PropFirm | undefined> {
    const [updated] = await db.update(propFirms)
      .set({ discountPercentage })
      .where(eq(propFirms.id, id))
      .returning();
    return updated;
  }

  async deletePropFirm(id: number): Promise<boolean> {
    const [deleted] = await db.delete(propFirms)
      .where(eq(propFirms.id, id))
      .returning({ id: propFirms.id });
    return !!deleted;
  }
  
  // Reviews methods
  async getReviewsByPropFirm(propFirmId: number): Promise<Review[]> {
    return await db.select()
      .from(reviews)
      .where(eq(reviews.propFirmId, propFirmId))
      .orderBy(desc(reviews.datePosted));
  }

  async getReviewById(id: number): Promise<Review | undefined> {
    const [review] = await db.select()
      .from(reviews)
      .where(eq(reviews.id, id));
    return review;
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const [review] = await db.insert(reviews)
      .values(insertReview)
      .returning();
    return review;
  }

  async updateReview(id: number, update: Partial<InsertReview>): Promise<Review | undefined> {
    const [updated] = await db.update(reviews)
      .set(update)
      .where(eq(reviews.id, id))
      .returning();
    return updated;
  }

  async deleteReview(id: number): Promise<boolean> {
    const [deleted] = await db.delete(reviews)
      .where(eq(reviews.id, id))
      .returning({ id: reviews.id });
    return !!deleted;
  }

  async getAverageRatingByPropFirm(propFirmId: number): Promise<number> {
    const result = await db.select({
      avgRating: sql`CAST(AVG(${reviews.rating}) AS NUMERIC(10,1))`,
    })
    .from(reviews)
    .where(eq(reviews.propFirmId, propFirmId));
    
    return result[0]?.avgRating || 0;
  }

  // Broker methods
  async getAllBrokers(): Promise<Broker[]> {
    return await db.select().from(brokers);
  }

  async getBrokerById(id: number): Promise<Broker | undefined> {
    const [broker] = await db.select().from(brokers).where(eq(brokers.id, id));
    return broker;
  }

  async createBroker(insertBroker: InsertBroker): Promise<Broker> {
    const [broker] = await db.insert(brokers)
      .values(insertBroker)
      .returning();
    return broker;
  }

  async updateBroker(id: number, update: Partial<InsertBroker>): Promise<Broker | undefined> {
    const [updated] = await db.update(brokers)
      .set(update)
      .where(eq(brokers.id, id))
      .returning();
    return updated;
  }

  async deleteBroker(id: number): Promise<boolean> {
    const [deleted] = await db.delete(brokers)
      .where(eq(brokers.id, id))
      .returning({ id: brokers.id });
    return !!deleted;
  }

  async getBrokers(filter?: BrokerFilter, sort?: BrokerSort): Promise<Broker[]> {
    try {
      // Base query
      let query = db.select().from(brokers);
      
      // We need to apply filters in memory since some fields are arrays
      let brokersList = await query;
      
      // Apply filters
      if (filter) {
        if (filter.country) {
          brokersList = brokersList.filter(broker => broker.country === filter.country);
        }
        
        if (filter.environment) {
          brokersList = brokersList.filter(broker => broker.environment === filter.environment);
        }
        
        if (filter.yearsActive) {
          brokersList = brokersList.filter(broker => broker.yearsActive === filter.yearsActive);
        }
        
        // Apply score range filter
        if (filter.minScore !== undefined || filter.maxScore !== undefined) {
          brokersList = brokersList.filter(broker => {
            const brokerScore = parseFloat(broker.score.toString());
            
            // Apply min score filter if provided
            if (filter.minScore !== undefined && brokerScore < filter.minScore) {
              return false;
            }
            
            // Apply max score filter if provided
            if (filter.maxScore !== undefined && brokerScore > filter.maxScore) {
              return false;
            }
            
            return true;
          });
        }
      }
      
      // Apply sorting
      if (sort?.field) {
        const direction = sort.direction || 'asc';
        
        switch (sort.field) {
          case 'score':
            brokersList.sort((a, b) => {
              const scoreA = parseFloat(a.score.toString());
              const scoreB = parseFloat(b.score.toString());
              return direction === 'asc' 
                ? scoreA - scoreB 
                : scoreB - scoreA;
            });
            break;
          case 'name':
            brokersList.sort((a, b) => {
              return direction === 'asc' 
                ? a.name.localeCompare(b.name) 
                : b.name.localeCompare(a.name);
            });
            break;
          case 'yearsActive':
            brokersList.sort((a, b) => {
              return direction === 'asc' 
                ? a.yearsActive.localeCompare(b.yearsActive) 
                : b.yearsActive.localeCompare(a.yearsActive);
            });
            break;
          default:
            // Default sort by score (high to low)
            brokersList.sort((a, b) => {
              const scoreA = parseFloat(a.score.toString());
              const scoreB = parseFloat(b.score.toString());
              return scoreB - scoreA;
            });
        }
      } else {
        // Default sort by position, then score as a fallback
        brokersList.sort((a, b) => {
          // First sort by position (if available)
          if (a.position !== undefined && b.position !== undefined) {
            return (a.position || 999) - (b.position || 999);
          }
          // Fallback to score sort (high to low)
          const scoreA = parseFloat(a.score.toString());
          const scoreB = parseFloat(b.score.toString());
          return scoreB - scoreA;
        });
      }
      
      return brokersList;
    } catch (error) {
      console.error("Error fetching brokers:", error);
      throw error;
    }
  }
  
  // Broker Review methods
  async getReviewsByBroker(brokerId: number): Promise<BrokerReview[]> {
    return await db.select()
      .from(brokerReviews)
      .where(eq(brokerReviews.brokerId, brokerId))
      .orderBy(desc(brokerReviews.datePosted));
  }

  async getBrokerReviewById(id: number): Promise<BrokerReview | undefined> {
    const [review] = await db.select()
      .from(brokerReviews)
      .where(eq(brokerReviews.id, id));
    return review;
  }

  async createBrokerReview(insertReview: InsertBrokerReview): Promise<BrokerReview> {
    const [review] = await db.insert(brokerReviews)
      .values(insertReview)
      .returning();
    return review;
  }

  async updateBrokerReview(id: number, update: Partial<InsertBrokerReview>): Promise<BrokerReview | undefined> {
    const [updated] = await db.update(brokerReviews)
      .set(update)
      .where(eq(brokerReviews.id, id))
      .returning();
    return updated;
  }

  async deleteBrokerReview(id: number): Promise<boolean> {
    const [deleted] = await db.delete(brokerReviews)
      .where(eq(brokerReviews.id, id))
      .returning({ id: brokerReviews.id });
    return !!deleted;
  }

  async getAverageRatingByBroker(brokerId: number): Promise<number> {
    const result = await db.select({
      avgRating: sql`CAST(AVG(${brokerReviews.rating}) AS NUMERIC(10,1))`,
    })
    .from(brokerReviews)
    .where(eq(brokerReviews.brokerId, brokerId));
    
    return result[0]?.avgRating || 0;
  }
  
  // Promotion entry methods
  async getPromotionEntries(promotionType?: string): Promise<PromotionEntry[]> {
    let query = db.select().from(promotionEntries);
    
    if (promotionType) {
      query = query.where(eq(promotionEntries.promotionType, promotionType));
    }
    
    return await query.orderBy(desc(promotionEntries.dateCreated));
  }
  
  async createPromotionEntry(entry: InsertPromotionEntry): Promise<PromotionEntry> {
    const [promotionEntry] = await db.insert(promotionEntries)
      .values(entry)
      .returning();
    
    return promotionEntry;
  }
  
  async markPromotionEntryAsProcessed(id: number, notes?: string): Promise<boolean> {
    try {
      const updateData: any = { processed: true };
      if (notes) {
        updateData.notes = notes;
      }
      
      await db.update(promotionEntries)
        .set(updateData)
        .where(eq(promotionEntries.id, id));
      
      return true;
    } catch (error) {
      console.error("Error marking promotion entry as processed:", error);
      return false;
    }
  }
  
  // Purchase statistics methods
  async getPurchaseStats(): Promise<PurchaseStats | undefined> {
    try {
      const [stats] = await db.select().from(purchaseStats);
      return stats;
    } catch (error) {
      console.error("Error getting purchase stats:", error);
      return undefined;
    }
  }
  
  async updatePurchaseStats(stats: UpdatePurchaseStats): Promise<PurchaseStats | undefined> {
    try {
      // First check if stats record exists
      const existingStats = await this.getPurchaseStats();
      
      if (!existingStats) {
        // If no stats exist yet, create initial stats
        return await this.createInitialPurchaseStats({
          totalPurchases: stats.totalPurchases || 0,
          thisMonth: stats.thisMonth || 0,
          thisWeek: stats.thisWeek || 0,
          today: stats.today || 0
        });
      }
      
      // Update the existing stats
      const [updated] = await db.update(purchaseStats)
        .set({
          ...stats,
          lastUpdated: new Date()
        })
        .where(eq(purchaseStats.id, existingStats.id))
        .returning();
      
      return updated;
    } catch (error) {
      console.error("Error updating purchase stats:", error);
      return undefined;
    }
  }
  
  async createInitialPurchaseStats(stats: InsertPurchaseStats): Promise<PurchaseStats> {
    const [created] = await db.insert(purchaseStats)
      .values(stats)
      .returning();
    
    return created;
  }
  
  // Achievement badges methods
  async getAllAchievementBadges(): Promise<AchievementBadge[]> {
    return await db.select().from(achievementBadges);
  }
  
  async getAchievementBadgeById(id: number): Promise<AchievementBadge | undefined> {
    const [badge] = await db.select().from(achievementBadges).where(eq(achievementBadges.id, id));
    return badge;
  }
  
  async getAchievementBadgesByCategory(category: string): Promise<AchievementBadge[]> {
    return await db.select()
      .from(achievementBadges)
      .where(eq(achievementBadges.category, category));
  }
  
  async createAchievementBadge(badge: InsertAchievementBadge): Promise<AchievementBadge> {
    const [newBadge] = await db.insert(achievementBadges)
      .values(badge)
      .returning();
    return newBadge;
  }
  
  async updateAchievementBadge(id: number, update: Partial<InsertAchievementBadge>): Promise<AchievementBadge | undefined> {
    const [updated] = await db.update(achievementBadges)
      .set(update)
      .where(eq(achievementBadges.id, id))
      .returning();
    return updated;
  }
  
  async deleteAchievementBadge(id: number): Promise<boolean> {
    const [deleted] = await db.delete(achievementBadges)
      .where(eq(achievementBadges.id, id))
      .returning({ id: achievementBadges.id });
    return !!deleted;
  }
  
  // User achievements methods
  async getUserAchievements(userId: number): Promise<(UserAchievement & { badge: AchievementBadge })[]> {
    return await db.select({
      ...userAchievements,
      badge: achievementBadges
    })
    .from(userAchievements)
    .innerJoin(achievementBadges, eq(userAchievements.badgeId, achievementBadges.id))
    .where(eq(userAchievements.userId, userId));
  }
  
  async getUserAchievementById(id: number): Promise<UserAchievement | undefined> {
    const [achievement] = await db.select()
      .from(userAchievements)
      .where(eq(userAchievements.id, id));
    return achievement;
  }
  
  async createUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement> {
    const [newAchievement] = await db.insert(userAchievements)
      .values(achievement)
      .returning();
    return newAchievement;
  }
  
  async updateUserAchievement(id: number, update: Partial<InsertUserAchievement>): Promise<UserAchievement | undefined> {
    const [updated] = await db.update(userAchievements)
      .set(update)
      .where(eq(userAchievements.id, id))
      .returning();
    return updated;
  }
  
  async deleteUserAchievement(id: number): Promise<boolean> {
    const [deleted] = await db.delete(userAchievements)
      .where(eq(userAchievements.id, id))
      .returning({ id: userAchievements.id });
    return !!deleted;
  }
  
  async getFeaturedAchievements(userId: number): Promise<(UserAchievement & { badge: AchievementBadge })[]> {
    return await db.select({
      ...userAchievements,
      badge: achievementBadges
    })
    .from(userAchievements)
    .innerJoin(achievementBadges, eq(userAchievements.badgeId, achievementBadges.id))
    .where(and(
      eq(userAchievements.userId, userId),
      eq(userAchievements.featured, true)
    ));
  }

  async getPropFirms(accountSize: number, filter?: PropFirmFilter, sort?: PropFirmSort): Promise<PropFirm[]> {
    try {
      // Base query
      let query = db.select().from(propFirms);
      
      // We can't directly filter by values in an array, so we'll have to filter in memory
      let firms = await query;
      
      // If accountSize is 0, return all firms, otherwise filter by account size
      if (accountSize !== 0) {
        firms = firms.filter(firm => firm.accountSizes.includes(accountSize));
      }
      
      // Apply additional filters
      if (filter) {
        if (filter.programType) {
          firms = firms.filter(firm => firm.programType === filter.programType);
        }
        
        if (filter.profitSplit && filter.profitSplit !== 'any') {
          console.log(`Filtering by profit split: ${filter.profitSplit}`);
          const profitSplitValue = parseInt(filter.profitSplit);
          const firmCountBefore = firms.length;
          
          // Show prop firms where the profit split is GREATER than or EQUAL to the selected value
          firms = firms.filter(firm => firm.profitSplit >= profitSplitValue);
          
          console.log(`Profit split filter results: ${firmCountBefore} -> ${firms.length} firms`);
        }
        
        if (filter.payoutFrequency && filter.payoutFrequency !== 'any') {
          console.log(`Filtering by payout frequency: ${filter.payoutFrequency}`);
          const firmCountBefore = firms.length;
          
          firms = firms.filter(firm => firm.payoutFrequency === filter.payoutFrequency);
          
          console.log(`Payout frequency filter results: ${firmCountBefore} -> ${firms.length} firms`);
        }
        
        if (filter.loyaltyProgram !== undefined) {
          firms = firms.filter(firm => firm.loyaltyProgram === filter.loyaltyProgram);
        }
        
        // Apply price range filter
        if (filter.minPrice !== undefined || filter.maxPrice !== undefined) {
          firms = firms.filter(firm => {
            // Find the pricing for the requested account size
            const pricing = firm.pricing.find(p => p.accountSize === accountSize);
            if (!pricing) return false;
            
            // Apply min price filter if provided
            if (filter.minPrice !== undefined && pricing.price < filter.minPrice) {
              return false;
            }
            
            // Apply max price filter if provided
            if (filter.maxPrice !== undefined && pricing.price > filter.maxPrice) {
              return false;
            }
            
            return true;
          });
        }
        
        // Apply profit target filter (less than or equal to logic)
        if (filter.profitTarget !== undefined && filter.profitTarget !== 'any') {
          console.log(`Filtering by profit target: ${filter.profitTarget}`);
          const profitTargetValue = parseInt(filter.profitTarget);
          const firmCountBefore = firms.length;
          
          // Show prop firms where the profit target is LESS than or EQUAL to the selected value
          firms = firms.filter(firm => {
            // If profitTargets is an array, check if ANY value is less than or equal to profitTargetValue
            if (Array.isArray(firm.profitTargets)) {
              // Find the minimum profit target in the array
              const minProfitTarget = Math.min(...firm.profitTargets);
              return minProfitTarget <= profitTargetValue;
            }
            // If it's a string (legacy data), extract all numbers and check if ANY is less than or equal
            if (typeof firm.profitTargets === 'string') {
              const regex = /(\d+)%/g;
              let match;
              let minTarget = Infinity;
              
              while ((match = regex.exec(firm.profitTargets)) !== null) {
                if (match && match[1]) {
                  const targetValue = parseInt(match[1]);
                  minTarget = Math.min(minTarget, targetValue);
                }
              }
              
              return minTarget <= profitTargetValue;
            }
            return false;
          });
          
          console.log(`Profit target filter results: ${firmCountBefore} -> ${firms.length} firms`);
        }
        
        // Apply daily loss filter (less than or equal to logic)
        if (filter.dailyLoss !== undefined && filter.dailyLoss !== 'any') {
          console.log(`Filtering by daily loss: ${filter.dailyLoss}`);
          const dailyLossValue = parseInt(filter.dailyLoss);
          const firmCountBefore = firms.length;
          
          // Show prop firms where the daily loss is LESS than or EQUAL to the selected value
          firms = firms.filter(firm => {
            // If dailyLoss is already a number, compare
            if (typeof firm.dailyLoss === 'number') {
              return firm.dailyLoss <= dailyLossValue;
            }
            // If it's a string (legacy data), extract and compare
            if (typeof firm.dailyLoss === 'string') {
              const match = firm.dailyLoss.match(/(\d+)%?/);
              if (match && match[1]) {
                const dailyLossNum = parseInt(match[1]);
                return dailyLossNum <= dailyLossValue;
              }
            }
            return false;
          });
          
          console.log(`Daily loss filter results: ${firmCountBefore} -> ${firms.length} firms`);
        }
        
        // Apply max loss filter (less than or equal to logic)
        if (filter.maxLoss !== undefined && filter.maxLoss !== 'any') {
          console.log(`Filtering by max loss: ${filter.maxLoss}`);
          const maxLossValue = parseInt(filter.maxLoss);
          const firmCountBefore = firms.length;
          
          // Show prop firms where the max loss is LESS than or EQUAL to the selected value
          firms = firms.filter(firm => {
            // If maxLoss is already a number, compare
            if (typeof firm.maxLoss === 'number') {
              return firm.maxLoss <= maxLossValue;
            }
            // If it's a string (legacy data), extract and compare
            if (typeof firm.maxLoss === 'string') {
              const match = firm.maxLoss.match(/(\d+)%?/);
              if (match && match[1]) {
                const maxLossNum = parseInt(match[1]);
                return maxLossNum <= maxLossValue;
              }
            }
            return false;
          });
          
          console.log(`Max loss filter results: ${firmCountBefore} -> ${firms.length} firms`);
        }
      }
      
      // Apply sorting
      if (sort?.field) {
        const direction = sort.direction || 'asc';
        
        switch (sort.field) {
          case 'profitSplit':
            firms.sort((a, b) => {
              return direction === 'asc' 
                ? a.profitSplit - b.profitSplit 
                : b.profitSplit - a.profitSplit;
            });
            break;
          case 'name':
            firms.sort((a, b) => {
              return direction === 'asc' 
                ? a.name.localeCompare(b.name) 
                : b.name.localeCompare(a.name);
            });
            break;
          case 'price':
            firms.sort((a, b) => {
              const priceA = a.pricing.find(p => p.accountSize === accountSize)?.price || 0;
              const priceB = b.pricing.find(p => p.accountSize === accountSize)?.price || 0;
              return direction === 'asc' ? priceA - priceB : priceB - priceA;
            });
            break;
          default:
            // Default sort by name
            firms.sort((a, b) => a.name.localeCompare(b.name));
        }
      } else {
        // Default sort by position (lowest position number first)
        firms.sort((a, b) => (a.position || 999) - (b.position || 999));
      }
      
      return firms;
    } catch (error) {
      console.error("Error fetching prop firms:", error);
      throw error;
    }
  }

  // Prop Firm Rules methods
  async getAllPropFirmRules(): Promise<PropFirmRules[]> {
    return await db.select().from(propFirmRules);
  }

  async getPropFirmRuleById(id: number): Promise<PropFirmRules | undefined> {
    const [rule] = await db.select().from(propFirmRules).where(eq(propFirmRules.id, id));
    return rule;
  }

  async createPropFirmRule(rule: InsertPropFirmRules): Promise<PropFirmRules> {
    const [newRule] = await db.insert(propFirmRules).values(rule).returning();
    return newRule;
  }

  async updatePropFirmRule(id: number, update: Partial<InsertPropFirmRules>): Promise<PropFirmRules | undefined> {
    const [updated] = await db.update(propFirmRules)
      .set(update)
      .where(eq(propFirmRules.id, id))
      .returning();
    return updated;
  }

  async deletePropFirmRule(id: number): Promise<boolean> {
    const [deleted] = await db.delete(propFirmRules)
      .where(eq(propFirmRules.id, id))
      .returning({ id: propFirmRules.id });
    return !!deleted;
  }

  async searchPropFirmRules(search?: string, category?: string, minRating?: number): Promise<PropFirmRules[]> {
    return await db.select().from(propFirmRules).orderBy(desc(propFirmRules.rating));
  }

  // Support ticket methods (missing from interface)
  async createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket> {
    const [newTicket] = await db.insert(supportTickets).values(ticket).returning();
    return newTicket;
  }

  async getSupportTickets(): Promise<SupportTicket[]> {
    return await db.select().from(supportTickets);
  }

  async getSupportTicket(id: number): Promise<SupportTicket | undefined> {
    const [ticket] = await db.select().from(supportTickets).where(eq(supportTickets.id, id));
    return ticket;
  }

  async updateSupportTicketStatus(id: number, status: string): Promise<SupportTicket | undefined> {
    const [updated] = await db.update(supportTickets)
      .set({ status })
      .where(eq(supportTickets.id, id))
      .returning();
    return updated;
  }

  async createSupportTicketComment(comment: InsertSupportTicketComment): Promise<SupportTicketComment> {
    const [newComment] = await db.insert(supportTicketComments).values(comment).returning();
    return newComment;
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private firms: Map<number, PropFirm>;
  private reviews: Map<number, Review>;
  private brokers: Map<number, Broker>;
  private brokerReviews: Map<number, BrokerReview>;
  private promotionEntries: Map<number, PromotionEntry>;
  private stats: PurchaseStats | undefined;
  private badges: Map<number, AchievementBadge>;
  private userAchievements: Map<number, UserAchievement>;
  
  private currentUserId: number;
  private currentFirmId: number;
  private currentReviewId: number;
  private currentBrokerId: number;
  private currentBrokerReviewId: number;
  private currentPromotionEntryId: number;

  private currentBadgeId: number;
  private currentUserAchievementId: number;
  
  constructor() {
    this.users = new Map();
    this.firms = new Map();
    this.reviews = new Map();
    this.brokers = new Map();
    this.brokerReviews = new Map();
    this.promotionEntries = new Map();
    this.badges = new Map();
    this.userAchievements = new Map();
    this.currentUserId = 1;
    this.currentFirmId = 1;
    this.currentReviewId = 1;
    this.currentBrokerId = 1;
    this.currentBrokerReviewId = 1;
    this.currentPromotionEntryId = 1;
    this.currentBadgeId = 1;
    this.currentUserAchievementId = 1;
    
    // Initialize with sample data
    this.initializePropFirms();
    this.initializeBrokers();
    this.initializeAchievementBadges();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Prop Firm methods
  async getAllPropFirms(): Promise<PropFirm[]> {
    return Array.from(this.firms.values());
  }

  async getPropFirmById(id: number): Promise<PropFirm | undefined> {
    return this.firms.get(id);
  }
  
  async getPropFirmsByName(name: string): Promise<PropFirm[]> {
    return Array.from(this.firms.values()).filter(firm => firm.name === name);
  }

  async createPropFirm(insertPropFirm: InsertPropFirm): Promise<PropFirm> {
    const id = this.currentFirmId++;
    // Make sure all optional fields have proper null values
    const propFirm: PropFirm = { 
      ...insertPropFirm, 
      id,
      established: insertPropFirm.established || null,
      affiliateLink: insertPropFirm.affiliateLink || null,
      logo: insertPropFirm.logo || null
    };
    this.firms.set(id, propFirm);
    return propFirm;
  }

  async updatePropFirm(id: number, update: Partial<InsertPropFirm>): Promise<PropFirm | undefined> {
    const existing = this.firms.get(id);
    if (!existing) return undefined;
    
    const updated: PropFirm = { ...existing, ...update };
    this.firms.set(id, updated);
    return updated;
  }

  async deletePropFirm(id: number): Promise<boolean> {
    return this.firms.delete(id);
  }

  // Review methods
  async getReviewsByPropFirm(propFirmId: number): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.propFirmId === propFirmId)
      .sort((a, b) => new Date(b.datePosted).getTime() - new Date(a.datePosted).getTime());
  }

  async getReviewById(id: number): Promise<Review | undefined> {
    return this.reviews.get(id);
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const now = new Date();
    const review: Review = {
      ...insertReview,
      id,
      datePosted: now,
      isVerified: false
    };
    this.reviews.set(id, review);
    return review;
  }

  async updateReview(id: number, update: Partial<InsertReview>): Promise<Review | undefined> {
    const existing = this.reviews.get(id);
    if (!existing) return undefined;
    
    const updated: Review = { ...existing, ...update };
    this.reviews.set(id, updated);
    return updated;
  }

  async deleteReview(id: number): Promise<boolean> {
    return this.reviews.delete(id);
  }

  async getAverageRatingByPropFirm(propFirmId: number): Promise<number> {
    const firmReviews = Array.from(this.reviews.values())
      .filter(review => review.propFirmId === propFirmId);
    
    if (firmReviews.length === 0) return 0;
    
    const totalRating = firmReviews.reduce((sum, review) => sum + parseFloat(review.rating.toString()), 0);
    return parseFloat((totalRating / firmReviews.length).toFixed(1));
  }

  // Broker methods
  async getAllBrokers(): Promise<Broker[]> {
    return Array.from(this.brokers.values());
  }

  async getBrokerById(id: number): Promise<Broker | undefined> {
    return this.brokers.get(id);
  }

  async createBroker(insertBroker: InsertBroker): Promise<Broker> {
    const id = this.currentBrokerId++;
    // Make sure all optional fields have proper null values
    const broker: Broker = { 
      ...insertBroker, 
      id,
      regulatoryLicenseNumber: insertBroker.regulatoryLicenseNumber || null,
      logoUrl: insertBroker.logoUrl || null,
      websiteUrl: insertBroker.websiteUrl || null,
      description: insertBroker.description || null,
      dateAdded: new Date()
    };
    this.brokers.set(id, broker);
    return broker;
  }

  async updateBroker(id: number, update: Partial<InsertBroker>): Promise<Broker | undefined> {
    const existing = this.brokers.get(id);
    if (!existing) return undefined;
    
    const updated: Broker = { ...existing, ...update };
    this.brokers.set(id, updated);
    return updated;
  }

  async deleteBroker(id: number): Promise<boolean> {
    return this.brokers.delete(id);
  }

  async getBrokers(filter?: BrokerFilter, sort?: BrokerSort): Promise<Broker[]> {
    let brokersList = Array.from(this.brokers.values());
    
    // Apply filters if provided
    if (filter) {
      if (filter.country) {
        brokersList = brokersList.filter(broker => broker.country === filter.country);
      }
      
      if (filter.environment) {
        brokersList = brokersList.filter(broker => broker.environment === filter.environment);
      }
      
      if (filter.yearsActive) {
        brokersList = brokersList.filter(broker => broker.yearsActive === filter.yearsActive);
      }
      
      // Apply score range filter
      if (filter.minScore !== undefined || filter.maxScore !== undefined) {
        brokersList = brokersList.filter(broker => {
          const brokerScore = parseFloat(broker.score.toString());
          
          // Apply min score filter if provided
          if (filter.minScore !== undefined && brokerScore < filter.minScore) {
            return false;
          }
          
          // Apply max score filter if provided
          if (filter.maxScore !== undefined && brokerScore > filter.maxScore) {
            return false;
          }
          
          return true;
        });
      }
    }
    
    // Apply sorting if provided
    if (sort?.field) {
      const direction = sort.direction || 'asc';
      
      switch (sort.field) {
        case 'score':
          brokersList.sort((a, b) => {
            const scoreA = parseFloat(a.score.toString());
            const scoreB = parseFloat(b.score.toString());
            return direction === 'asc' 
              ? scoreA - scoreB 
              : scoreB - scoreA;
          });
          break;
        case 'name':
          brokersList.sort((a, b) => {
            return direction === 'asc' 
              ? a.name.localeCompare(b.name) 
              : b.name.localeCompare(a.name);
          });
          break;
        case 'yearsActive':
          brokersList.sort((a, b) => {
            return direction === 'asc' 
              ? a.yearsActive.localeCompare(b.yearsActive) 
              : b.yearsActive.localeCompare(a.yearsActive);
          });
          break;
        default:
          // Default sort by score (high to low)
          brokersList.sort((a, b) => {
            const scoreA = parseFloat(a.score.toString());
            const scoreB = parseFloat(b.score.toString());
            return scoreB - scoreA;
          });
      }
    } else {
      // Default sort by position, then score as a fallback
      brokersList.sort((a, b) => {
        // First sort by position (if available)
        if (a.position !== undefined && b.position !== undefined) {
          return (a.position || 999) - (b.position || 999);
        }
        // Fallback to score sort (high to low)
        const scoreA = parseFloat(a.score.toString());
        const scoreB = parseFloat(b.score.toString());
        return scoreB - scoreA;
      });
    }
    
    return brokersList;
  }
  
  // Broker Review methods
  async getReviewsByBroker(brokerId: number): Promise<BrokerReview[]> {
    return Array.from(this.brokerReviews.values())
      .filter(review => review.brokerId === brokerId)
      .sort((a, b) => new Date(b.datePosted).getTime() - new Date(a.datePosted).getTime());
  }

  async getBrokerReviewById(id: number): Promise<BrokerReview | undefined> {
    return this.brokerReviews.get(id);
  }

  async createBrokerReview(insertReview: InsertBrokerReview): Promise<BrokerReview> {
    const id = this.currentBrokerReviewId++;
    const now = new Date();
    const review: BrokerReview = {
      ...insertReview,
      id,
      datePosted: now,
      isVerified: false,
      pros: insertReview.pros || null,
      cons: insertReview.cons || null,
      experience: insertReview.experience || null,
      tradingPeriod: insertReview.tradingPeriod || null
    };
    this.brokerReviews.set(id, review);
    return review;
  }

  async updateBrokerReview(id: number, update: Partial<InsertBrokerReview>): Promise<BrokerReview | undefined> {
    const existing = this.brokerReviews.get(id);
    if (!existing) return undefined;
    
    const updated: BrokerReview = { ...existing, ...update };
    this.brokerReviews.set(id, updated);
    return updated;
  }

  async deleteBrokerReview(id: number): Promise<boolean> {
    return this.brokerReviews.delete(id);
  }

  async getAverageRatingByBroker(brokerId: number): Promise<number> {
    const brokerReviews = Array.from(this.brokerReviews.values())
      .filter(review => review.brokerId === brokerId);
    
    if (brokerReviews.length === 0) return 0;
    
    const totalRating = brokerReviews.reduce((sum, review) => sum + parseFloat(review.rating.toString()), 0);
    return parseFloat((totalRating / brokerReviews.length).toFixed(1));
  }
  
  // Promotion entry methods
  async getPromotionEntries(promotionType?: string): Promise<PromotionEntry[]> {
    let entries = Array.from(this.promotionEntries.values());
    
    if (promotionType) {
      entries = entries.filter(entry => entry.promotionType === promotionType);
    }
    
    return entries.sort((a, b) => 
      new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime()
    );
  }
  
  async createPromotionEntry(insertEntry: InsertPromotionEntry): Promise<PromotionEntry> {
    const id = this.currentPromotionEntryId++;
    const now = new Date();
    
    const entry: PromotionEntry = {
      ...insertEntry,
      id,
      dateCreated: now,
      processed: false,
      notes: null
    };
    
    this.promotionEntries.set(id, entry);
    return entry;
  }
  
  async markPromotionEntryAsProcessed(id: number, notes?: string): Promise<boolean> {
    const entry = this.promotionEntries.get(id);
    if (!entry) return false;
    
    const updated = {
      ...entry,
      processed: true,
      notes: notes || entry.notes
    };
    
    this.promotionEntries.set(id, updated);
    return true;
  }
  
  // Purchase statistics methods
  async getPurchaseStats(): Promise<PurchaseStats | undefined> {
    return this.stats;
  }
  
  async updatePurchaseStats(stats: UpdatePurchaseStats): Promise<PurchaseStats | undefined> {
    if (!this.stats) {
      // If no stats exist yet, create initial stats
      return await this.createInitialPurchaseStats({
        totalPurchases: stats.totalPurchases || 0,
        thisMonth: stats.thisMonth || 0,
        thisWeek: stats.thisWeek || 0,
        today: stats.today || 0
      });
    }
    
    // Update the existing stats
    this.stats = {
      ...this.stats,
      ...stats,
      lastUpdated: new Date()
    };
    
    return this.stats;
  }
  
  async createInitialPurchaseStats(stats: InsertPurchaseStats): Promise<PurchaseStats> {
    const now = new Date();
    this.stats = {
      id: 1,
      ...stats,
      lastUpdated: now,
      createdAt: now
    };
    
    return this.stats;
  }

  // Filtered prop firms
  async getPropFirms(accountSize: number, filter?: PropFirmFilter, sort?: PropFirmSort): Promise<PropFirm[]> {
    // If accountSize is 0, return all firms, otherwise filter by account size
    let firms = accountSize === 0 
      ? Array.from(this.firms.values()) 
      : Array.from(this.firms.values()).filter(firm => firm.accountSizes.includes(accountSize));
    
    // Apply filters if provided
    if (filter) {
      if (filter.programType && filter.programType !== 'any') {
        firms = firms.filter(firm => firm.programType === filter.programType);
      }
      
      if (filter.payoutFrequency && filter.payoutFrequency !== 'any') {
        firms = firms.filter(firm => firm.payoutFrequency === filter.payoutFrequency);
      }
      
      if (filter.profitSplit && filter.profitSplit !== 'any') {
        const profitSplit = parseInt(filter.profitSplit);
        firms = firms.filter(firm => firm.profitSplit >= profitSplit);
      }
      
      if (filter.loyaltyProgram !== undefined) {
        firms = firms.filter(firm => firm.loyaltyProgram === filter.loyaltyProgram);
      }
      
      // Apply price range filter
      if (filter.minPrice !== undefined || filter.maxPrice !== undefined) {
        firms = firms.filter(firm => {
          // Find the pricing for the requested account size
          const pricing = firm.pricing.find(p => p.accountSize === accountSize);
          if (!pricing) return false;
          
          // Apply min price filter if provided
          if (filter.minPrice !== undefined && pricing.price < filter.minPrice) {
            return false;
          }
          
          // Apply max price filter if provided
          if (filter.maxPrice !== undefined && pricing.price > filter.maxPrice) {
            return false;
          }
          
          return true;
        });
      }
      
      // Apply new search filters from horizontal search
      if (filter.profitTarget !== undefined && filter.profitTarget !== 'any') {
        console.log(`Filtering by profit target: ${filter.profitTarget}`);
        const profitTargetValue = parseInt(filter.profitTarget);
        const firmCountBefore = firms.length;
        
        // Show prop firms where the profit target is LESS than or EQUAL to the selected value
        firms = firms.filter(firm => {
          // If profitTargets is an array, check if ANY value is less than or equal to profitTargetValue
          if (Array.isArray(firm.profitTargets)) {
            // Find the minimum profit target in the array
            const minProfitTarget = Math.min(...firm.profitTargets);
            return minProfitTarget <= profitTargetValue;
          }
          // If it's a string (legacy data), extract all numbers and check if ANY is less than or equal
          if (typeof firm.profitTargets === 'string') {
            const regex = /(\d+)%/g;
            let match;
            let minTarget = Infinity;
            
            while ((match = regex.exec(firm.profitTargets)) !== null) {
              if (match && match[1]) {
                const targetValue = parseInt(match[1]);
                minTarget = Math.min(minTarget, targetValue);
              }
            }
            
            return minTarget <= profitTargetValue;
          }
          return false;
        });
        
        console.log(`Profit target filter results: ${firmCountBefore} -> ${firms.length} firms`);
      }
      
      if (filter.dailyLoss !== undefined && filter.dailyLoss !== 'any') {
        console.log(`Filtering by daily loss: ${filter.dailyLoss}`);
        const dailyLossValue = parseInt(filter.dailyLoss);
        const firmCountBefore = firms.length;
        
        // Show prop firms where the daily loss is LESS than or EQUAL to the selected value
        firms = firms.filter(firm => {
          // If dailyLoss is already a number, compare
          if (typeof firm.dailyLoss === 'number') {
            return firm.dailyLoss <= dailyLossValue;
          }
          // If it's a string (legacy data), extract and compare
          if (typeof firm.dailyLoss === 'string') {
            const match = firm.dailyLoss.match(/(\d+)%?/);
            if (match && match[1]) {
              const dailyLossNum = parseInt(match[1]);
              return dailyLossNum <= dailyLossValue;
            }
          }
          return false;
        });
        
        console.log(`Daily loss filter results: ${firmCountBefore} -> ${firms.length} firms`);
      }
      
      if (filter.maxLoss !== undefined && filter.maxLoss !== 'any') {
        console.log(`Filtering by max loss: ${filter.maxLoss}`);
        const maxLossValue = parseInt(filter.maxLoss);
        const firmCountBefore = firms.length;
        
        // Show prop firms where the max loss is LESS than or EQUAL to the selected value
        firms = firms.filter(firm => {
          // If maxLoss is already a number, compare
          if (typeof firm.maxLoss === 'number') {
            return firm.maxLoss <= maxLossValue;
          }
          // If it's a string (legacy data), extract and compare
          if (typeof firm.maxLoss === 'string') {
            const match = firm.maxLoss.match(/(\d+)%?/);
            if (match && match[1]) {
              const maxLossNum = parseInt(match[1]);
              return maxLossNum <= maxLossValue;
            }
          }
          return false;
        });
        
        console.log(`Max loss filter results: ${firmCountBefore} -> ${firms.length} firms`);
      }
      
      // Also add additional logging for profit split filter
      if (filter.profitSplit !== undefined && filter.profitSplit !== 'any') {
        console.log(`Filtering by profit split: ${filter.profitSplit}`);
        const profitSplitValue = parseInt(filter.profitSplit);
        const firmCountBefore = firms.length;
        
        firms = firms.filter(firm => {
          const result = firm.profitSplit >= profitSplitValue;
          return result;
        });
        
        console.log(`Profit split filter results: ${firmCountBefore} -> ${firms.length} firms`);
      }
    }
    
    // Apply sorting if provided
    if (sort?.field) {
      const direction = sort.direction || 'asc';
      
      switch (sort.field) {
        case 'profitSplit':
          firms.sort((a, b) => {
            return direction === 'asc' 
              ? a.profitSplit - b.profitSplit 
              : b.profitSplit - a.profitSplit;
          });
          break;
        case 'name':
          firms.sort((a, b) => {
            return direction === 'asc' 
              ? a.name.localeCompare(b.name) 
              : b.name.localeCompare(a.name);
          });
          break;
        case 'price':
          firms.sort((a, b) => {
            const priceA = a.pricing.find(p => p.accountSize === accountSize)?.price || 0;
            const priceB = b.pricing.find(p => p.accountSize === accountSize)?.price || 0;
            return direction === 'asc' ? priceA - priceB : priceB - priceA;
          });
          break;
        default:
          // Default sort by name
          firms.sort((a, b) => a.name.localeCompare(b.name));
      }
    } else {
      // Default sort by name
      firms.sort((a, b) => a.name.localeCompare(b.name));
    }
    
    return firms;
  }

  // Initialize with sample brokers data from CSV
  private initializeBrokers() {
    const sampleBrokers: InsertBroker[] = [
      {
        name: "XM",
        country: "United Kingdom",
        yearsActive: "10–15 years",
        environment: "AAA",
        regulators: ["ASIC (Australia)", "CYSEC (Cyprus)"],
        regulatoryLicenseNumber: "443670",
        score: 9.03,
        logoUrl: "https://example.com/xm-logo.svg",
        websiteUrl: "https://www.xm.com",
        description: "Regulated in Australia, Cyprus, Belize, Seychelles",
        pros: ["Reliable platform", "Multiple regulation", "Good customer support"],
        cons: ["Higher spreads on some instruments"],
        tags: ["Top Rated"],
      },
      {
        name: "Trive",
        country: "Virgin Islands",
        yearsActive: "10–15 years",
        environment: "—",
        regulators: ["ASIC (Australia)", "MFSA (Malta)"],
        regulatoryLicenseNumber: "424122",
        score: 9.02,
        logoUrl: "https://example.com/trive-logo.svg",
        websiteUrl: "https://www.trive.com",
        description: "Regulated in Australia, Malta, South Africa, Virgin Islands",
        pros: ["Low trading fees", "Multiple regulation"],
        cons: ["Withdrawal times can be slow"],
        tags: ["Popular"],
      },
      {
        name: "GO MARKETS",
        country: "Australia",
        yearsActive: "Above 20 years",
        environment: "AA",
        regulators: ["ASIC (Australia)", "CYSEC (Cyprus)"],
        regulatoryLicenseNumber: "254963",
        score: 8.99,
        logoUrl: "https://example.com/gomarkets-logo.svg",
        websiteUrl: "https://www.gomarkets.com",
        description: "Long-established Australian broker with ASIC and CySEC regulation",
        pros: ["Long track record", "Solid regulatory compliance"],
        cons: ["Limited product range"],
        tags: ["Recommended"],
      },
      {
        name: "EC Markets",
        country: "United Kingdom", 
        yearsActive: "10–15 years",
        environment: "C",
        regulators: ["ASIC (Australia)", "FMA (New Zealand)"],
        regulatoryLicenseNumber: "414198",
        score: 9.12,
        logoUrl: "https://example.com/ecmarkets-logo.svg",
        websiteUrl: "https://www.ecmarkets.com",
        description: "Regulated in Australia, New Zealand, UK",
        pros: ["Good execution speed", "Competitive spreads"],
        cons: ["Limited educational resources"],
        tags: ["Top Rated"],
      },
      {
        name: "STARTRADER",
        country: "Seychelles",
        yearsActive: "10–15 years",
        environment: "AA",
        regulators: ["ASIC (Australia)", "FSCA (South Africa - General)"],
        regulatoryLicenseNumber: "421210",
        score: 9.11,
        logoUrl: "https://example.com/startrader-logo.svg",
        websiteUrl: "https://www.startrader.com",
        description: "Regulated in Australia, South Africa",
        pros: ["Fast execution", "Low spreads"],
        cons: ["Limited customer support hours"],
        tags: ["Popular"],
      },
      {
        name: "IC Markets Global",
        country: "Australia",
        yearsActive: "15–20 years",
        environment: "AAA",
        regulators: ["ASIC (Australia)", "CYSEC (Cyprus)"],
        regulatoryLicenseNumber: "335692",
        score: 9.10,
        logoUrl: "https://example.com/icmarkets-logo.svg",
        websiteUrl: "https://www.icmarkets.com",
        description: "Regulated in Australia, Cyprus",
        pros: ["Raw spreads", "Fast execution", "Multiple platform options"],
        cons: ["Complex account structure"],
        tags: ["Top Rated", "Recommended"],
      }
    ];

    // Add brokers to storage
    sampleBrokers.forEach(broker => {
      const id = this.currentBrokerId++;
      this.brokers.set(id, {
        ...broker,
        id,
        regulatoryLicenseNumber: broker.regulatoryLicenseNumber || null,
        logoUrl: broker.logoUrl || null,
        websiteUrl: broker.websiteUrl || null,
        description: broker.description || null,
        dateAdded: new Date()
      });
    });
  }

  // Initialize with prop firms data
  private initializePropFirms() {
    const sampleFirms: InsertPropFirm[] = [
      {
        name: "ATFunded",
        established: "2020",
        accountSize: 25000,
        programType: "Two-Phase",
        profitTargets: "8% (Phase 1), 5% (Phase 2)",
        dailyLoss: "4%",
        maxLoss: "10%",
        profitSplit: 80,
        payoutFrequency: "Bi-weekly",
        loyaltyPoints: true,
        price: 135,
        affiliateLink: "https://atfunded.com/?ref=tradefluenza",
        logo: "https://cdn.com/atfunded-logo.svg",
      },
      {
        name: "Quant Tekel",
        established: "2021",
        accountSize: 25000,
        programType: "Two-Phase",
        profitTargets: "6% (Phase 1), 6% (Phase 2)",
        dailyLoss: "4%",
        maxLoss: "8%",
        profitSplit: 80,
        payoutFrequency: "Bi-weekly",
        loyaltyPoints: true,
        price: 105,
        affiliateLink: "https://quanttekel.com/?ref=tradefluenza",
        logo: "https://cdn.com/quanttekel-logo.svg",
      },
      {
        name: "AquaFunded",
        established: "2022",
        accountSize: 25000,
        programType: "Three-Phase",
        profitTargets: "6% (Phase 1), 6% (Phase 2), 6% (Phase 3)",
        dailyLoss: "4%",
        maxLoss: "8%",
        profitSplit: 90,
        payoutFrequency: "Bi-weekly",
        loyaltyPoints: true,
        price: 157,
        affiliateLink: "https://aquafunded.com/?ref=tradefluenza",
        logo: "https://cdn.com/aquafunded-logo.svg",
      },
      {
        name: "Instant Funding",
        established: "2020",
        accountSize: 25000,
        programType: "One-Phase",
        profitTargets: "10%",
        dailyLoss: "3%",
        maxLoss: "8%",
        profitSplit: 80,
        payoutFrequency: "Bi-weekly",
        loyaltyPoints: true,
        price: 189,
        affiliateLink: "https://instantfunding.com/?ref=tradefluenza",
        logo: "https://cdn.com/instantfunding-logo.svg",
      },
      {
        name: "FundedNext",
        established: "2019",
        accountSize: 25000,
        programType: "Two-Phase",
        profitTargets: "8% (Phase 1), 4% (Phase 2)",
        dailyLoss: "4%",
        maxLoss: "8%",
        profitSplit: 80,
        payoutFrequency: "On Demand",
        loyaltyPoints: true,
        price: 139,
        affiliateLink: "https://fundednext.com/?ref=tradefluenza",
        logo: "https://cdn.com/fundednext-logo.svg",
      },
      {
        name: "City Traders Imperium",
        established: "2018",
        accountSize: 25000,
        programType: "One-Phase",
        profitTargets: "8%",
        dailyLoss: "0%",
        maxLoss: "5%",
        profitSplit: 80,
        payoutFrequency: "On Demand",
        loyaltyPoints: true,
        price: 149,
        affiliateLink: "https://citytraderimperium.com/?ref=tradefluenza",
        logo: "https://cdn.com/cti-logo.svg",
      },
      {
        name: "FXIFY",
        established: "2021",
        accountSize: 25000,
        programType: "One-Phase",
        profitTargets: "5%",
        dailyLoss: "3%",
        maxLoss: "4%",
        profitSplit: 80,
        payoutFrequency: "Weekly",
        loyaltyPoints: true,
        price: 119,
        affiliateLink: "https://fxify.com/?ref=tradefluenza",
        logo: "https://cdn.com/fxify-logo.svg",
      },
      {
        name: "Funding Traders",
        established: "2020",
        accountSize: 25000,
        programType: "One-Phase",
        profitTargets: "10%",
        dailyLoss: "4%",
        maxLoss: "5%",
        profitSplit: 80,
        payoutFrequency: "Weekly",
        loyaltyPoints: true,
        price: 139,
        affiliateLink: "https://fundingtraders.com/?ref=tradefluenza",
        logo: "https://cdn.com/fundingtraders-logo.svg",
      },
      {
        name: "OANDA Prop Trader",
        established: "2015",
        accountSize: 25000,
        programType: "Two-Phase",
        profitTargets: "8% (Phase 1), 5% (Phase 2)",
        dailyLoss: "5%",
        maxLoss: "10%",
        profitSplit: 80,
        payoutFrequency: "Bi-weekly",
        loyaltyPoints: true,
        price: 199,
        affiliateLink: "https://oandaproptrader.com/?ref=tradefluenza",
        logo: "https://cdn.com/oanda-logo.svg",
      },
      {
        name: "CFT",
        established: "2019",
        accountSize: 25000,
        programType: "Two-Phase",
        profitTargets: "8% (Phase 1), 5% (Phase 2)",
        dailyLoss: "5%",
        maxLoss: "10%",
        profitSplit: 0,
        payoutFrequency: "On Demand",
        loyaltyPoints: true,
        price: 195,
        affiliateLink: "https://cft.com/?ref=tradefluenza",
        logo: "https://cdn.com/cft-logo.svg",
      },
      {
        name: "FTMO",
        established: "2018",
        accountSize: 25000,
        programType: "Two-Phase",
        profitTargets: "10% (Phase 1), 5% (Phase 2)",
        dailyLoss: "5%",
        maxLoss: "10%",
        profitSplit: 80,
        payoutFrequency: "Bi-weekly",
        loyaltyPoints: true,
        price: 540,
        affiliateLink: "https://ftmo.com/en/affiliates/?ref=tradefluenza",
        logo: "https://cdn.com/ftmo-logo.svg",
      },
      {
        name: "The Funded Trader",
        established: "2020",
        accountSize: 25000,
        programType: "Two-Phase",
        profitTargets: "8% (Phase 1), 5% (Phase 2)",
        dailyLoss: "4%",
        maxLoss: "8%",
        profitSplit: 85,
        payoutFrequency: "Monthly",
        loyaltyPoints: true,
        price: 499,
        affiliateLink: "https://thefundedtrader.com/ref=tradefluenza",
        logo: "https://cdn.com/tft-logo.svg",
      }
    ];

    sampleFirms.forEach(firm => {
      const id = this.currentFirmId++;
      // Ensure null for optional fields
      this.firms.set(id, { 
        ...firm, 
        id,
        established: firm.established || null,
        affiliateLink: firm.affiliateLink || null,
        logo: firm.logo || null
      });
    });

    // Also add some entries for other account sizes
    [50000, 100000, 200000].forEach(accountSize => {
      sampleFirms.slice(0, 6).forEach(firm => {
        const id = this.currentFirmId++;
        const price = Math.floor(firm.price * (accountSize / 25000) * 0.9); // Scale price, with discount
        this.firms.set(id, { 
          ...firm, 
          id, 
          accountSize, 
          price,
          established: firm.established || null,
          affiliateLink: firm.affiliateLink || null,
          logo: firm.logo || null
        });
      });
    });
  }

  // Purchase statistics methods
  async getPurchaseStats(): Promise<PurchaseStats | undefined> {
    try {
      const [stats] = await db.select().from(purchaseStats);
      return stats;
    } catch (error) {
      console.error("Error getting purchase stats:", error);
      return undefined;
    }
  }
  
  async updatePurchaseStats(stats: UpdatePurchaseStats): Promise<PurchaseStats | undefined> {
    try {
      // First check if stats record exists
      const existingStats = await this.getPurchaseStats();
      
      if (!existingStats) {
        // If no stats exist yet, create initial stats
        return await this.createInitialPurchaseStats({
          totalPurchases: stats.totalPurchases || 0,
          thisMonth: stats.thisMonth || 0,
          thisWeek: stats.thisWeek || 0,
          today: stats.today || 0
        });
      }
      
      // Update the existing stats
      const [updated] = await db.update(purchaseStats)
        .set({
          ...stats,
          lastUpdated: new Date()
        })
        .where(eq(purchaseStats.id, existingStats.id))
        .returning();
      
      return updated;
    } catch (error) {
      console.error("Error updating purchase stats:", error);
      return undefined;
    }
  }
  
  async createInitialPurchaseStats(stats: InsertPurchaseStats): Promise<PurchaseStats> {
    try {
      const [newStats] = await db.insert(purchaseStats)
        .values(stats)
        .returning();
        
      return newStats;
    } catch (error) {
      console.error("Error creating initial purchase stats:", error);
      throw error;
    }
  }

  // Support ticket methods
  async getSupportTickets(): Promise<SupportTicket[]> {
    try {
      return await db.select().from(supportTickets)
        .orderBy(desc(supportTickets.dateCreated));
    } catch (error) {
      console.error("Error getting support tickets:", error);
      return [];
    }
  }

  async getSupportTicket(id: number): Promise<SupportTicket | undefined> {
    try {
      const [ticket] = await db.select().from(supportTickets)
        .where(eq(supportTickets.id, id));
      return ticket;
    } catch (error) {
      console.error("Error getting support ticket:", error);
      return undefined;
    }
  }

  async createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket> {
    try {
      const [newTicket] = await db.insert(supportTickets)
        .values({
          ...ticket,
          status: "Open", // Default status for new tickets
          dateCreated: new Date(),
          dateUpdated: new Date()
        })
        .returning();
      return newTicket;
    } catch (error) {
      console.error("Error creating support ticket:", error);
      throw error;
    }
  }

  async updateSupportTicketStatus(id: number, status: string): Promise<SupportTicket | undefined> {
    try {
      const [updatedTicket] = await db.update(supportTickets)
        .set({ status, dateUpdated: new Date() })
        .where(eq(supportTickets.id, id))
        .returning();
      return updatedTicket;
    } catch (error) {
      console.error("Error updating support ticket status:", error);
      return undefined;
    }
  }

  async createSupportTicketComment(comment: InsertSupportTicketComment): Promise<SupportTicketComment> {
    try {
      const [newComment] = await db.insert(supportTicketComments)
        .values({
          ...comment,
          dateCreated: new Date()
        })
        .returning();
      return newComment;
    } catch (error) {
      console.error("Error creating support ticket comment:", error);
      throw error;
    }
  }
}

// Use the database storage implementation with PostgreSQL
export const storage = new DatabaseStorage();
