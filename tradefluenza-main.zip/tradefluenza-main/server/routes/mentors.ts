import { Request, Response } from "express";
import { db } from "../db";
import { eq, and, desc, sql, inArray, or, like } from "drizzle-orm";
import { mentors, mentorReviews, mentorSessions, insertMentorSchema, insertMentorReviewSchema, insertMentorSessionSchema, users } from "../../shared/schema";
import { z } from "zod";

// Helper to check if user is authenticated
export const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
};

// Get all mentors with optional filtering
export const getMentors = async (req: Request, res: Response) => {
  try {
    const {
      specialization,
      experienceLevel,
      minHourlyRate,
      maxHourlyRate,
      search,
      limit = 20,
      offset = 0
    } = req.query;
    
    let query = db.select().from(mentors);
    
    // Apply filters if provided
    if (specialization && typeof specialization === 'string') {
      query = query.where(eq(mentors.specialization, specialization));
    }
    
    if (experienceLevel && typeof experienceLevel === 'string') {
      query = query.where(eq(mentors.experienceLevel, experienceLevel));
    }
    
    if (minHourlyRate && typeof minHourlyRate === 'string') {
      const minRate = parseInt(minHourlyRate);
      if (!isNaN(minRate)) {
        query = query.where(sql`${mentors.hourlyRate} >= ${minRate}`);
      }
    }
    
    if (maxHourlyRate && typeof maxHourlyRate === 'string') {
      const maxRate = parseInt(maxHourlyRate);
      if (!isNaN(maxRate)) {
        query = query.where(sql`${mentors.hourlyRate} <= ${maxRate}`);
      }
    }
    
    if (search && typeof search === 'string') {
      const searchTerm = `%${search}%`;
      query = query.where(
        or(
          like(mentors.name, searchTerm),
          like(mentors.bio, searchTerm),
          like(mentors.about, searchTerm)
        )
      );
    }
    
    // Apply pagination
    const limitNum = typeof limit === 'string' ? parseInt(limit) : 20;
    const offsetNum = typeof offset === 'string' ? parseInt(offset) : 0;
    
    // Execute the query with pagination
    const results = await query
      .limit(limitNum)
      .offset(offsetNum)
      .orderBy(desc(mentors.isVerified), desc(mentors.id));
    
    // Count total matching records for pagination
    const countQuery = await db
      .select({ count: sql<number>`count(*)` })
      .from(mentors);
      
    const total = countQuery[0].count;
    
    return res.status(200).json({
      data: results,
      pagination: {
        total,
        limit: limitNum,
        offset: offsetNum,
        hasMore: total > offsetNum + limitNum
      }
    });
  } catch (error) {
    console.error("Error fetching mentors:", error);
    return res.status(500).json({ message: "Failed to fetch mentors" });
  }
};

// Get a single mentor by ID
export const getMentorById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ message: "Invalid mentor ID" });
    }
    
    const mentorId = parseInt(id);
    
    const result = await db
      .select()
      .from(mentors)
      .where(eq(mentors.id, mentorId))
      .limit(1);
    
    if (result.length === 0) {
      return res.status(404).json({ message: "Mentor not found" });
    }
    
    return res.status(200).json(result[0]);
  } catch (error) {
    console.error("Error fetching mentor:", error);
    return res.status(500).json({ message: "Failed to fetch mentor" });
  }
};

// Get reviews for a mentor
export const getMentorReviews = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { limit = 10, offset = 0 } = req.query;
    
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ message: "Invalid mentor ID" });
    }
    
    const mentorId = parseInt(id);
    const limitNum = typeof limit === 'string' ? parseInt(limit) : 10;
    const offsetNum = typeof offset === 'string' ? parseInt(offset) : 0;
    
    // Check if mentor exists
    const mentorExists = await db
      .select({ id: mentors.id })
      .from(mentors)
      .where(eq(mentors.id, mentorId))
      .limit(1);
      
    if (mentorExists.length === 0) {
      return res.status(404).json({ message: "Mentor not found" });
    }
    
    // Fetch reviews with user information
    const reviews = await db
      .select({
        id: mentorReviews.id,
        mentorId: mentorReviews.mentorId,
        userId: mentorReviews.userId,
        rating: mentorReviews.rating,
        title: mentorReviews.title,
        content: mentorReviews.content,
        createdAt: mentorReviews.createdAt,
        updatedAt: mentorReviews.updatedAt,
        username: users.username,
        userAvatar: users.avatarUrl
      })
      .from(mentorReviews)
      .innerJoin(users, eq(mentorReviews.userId, users.id))
      .where(eq(mentorReviews.mentorId, mentorId))
      .limit(limitNum)
      .offset(offsetNum)
      .orderBy(desc(mentorReviews.createdAt));
    
    // Count total reviews for pagination
    const countQuery = await db
      .select({ count: sql<number>`count(*)` })
      .from(mentorReviews)
      .where(eq(mentorReviews.mentorId, mentorId));
      
    const total = countQuery[0].count;
    
    return res.status(200).json(reviews);
  } catch (error) {
    console.error("Error fetching mentor reviews:", error);
    return res.status(500).json({ message: "Failed to fetch mentor reviews" });
  }
};

// Create a review for a mentor
export const createMentorReview = async (req: Request, res: Response) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to post a review" });
    }
    
    // Get mentorId from params or request body
    let mentorId: number;
    
    if (req.params.id) {
      if (isNaN(parseInt(req.params.id))) {
        return res.status(400).json({ message: "Invalid mentor ID in URL" });
      }
      mentorId = parseInt(req.params.id);
    } else if (req.body.mentorId) {
      if (isNaN(parseInt(req.body.mentorId.toString()))) {
        return res.status(400).json({ message: "Invalid mentor ID in request body" });
      }
      mentorId = parseInt(req.body.mentorId.toString());
    } else {
      return res.status(400).json({ message: "Mentor ID is required" });
    }
    
    const userId = req.user?.id;
    
    // Check if mentor exists
    const mentorExists = await db
      .select({ id: mentors.id })
      .from(mentors)
      .where(eq(mentors.id, mentorId))
      .limit(1);
      
    if (mentorExists.length === 0) {
      return res.status(404).json({ message: "Mentor not found" });
    }
    
    // Validate the review data
    const reviewSchema = z.object({
      rating: z.number().min(1).max(5),
      title: z.string().min(3).max(100).optional(),
      content: z.string().min(3).max(1000),
      mentorId: z.number().optional()
    });
    
    const validationResult = reviewSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({ 
        message: "Invalid review data",
        errors: validationResult.error.format() 
      });
    }
    
    // Check if user already reviewed this mentor
    const existingReview = await db
      .select({ id: mentorReviews.id })
      .from(mentorReviews)
      .where(
        and(
          eq(mentorReviews.mentorId, mentorId),
          eq(mentorReviews.userId, userId)
        )
      )
      .limit(1);
    
    if (existingReview.length > 0) {
      return res.status(400).json({ message: "You have already reviewed this mentor" });
    }
    
    // Create the review
    const { rating, content, title } = validationResult.data;
    
    const result = await db.insert(mentorReviews).values({
      mentorId,
      userId,
      rating,
      title: title || `Review of mentor ${mentorId}`,
      content
    }).returning();
    
    return res.status(201).json(result[0]);
  } catch (error) {
    console.error("Error creating mentor review:", error);
    return res.status(500).json({ message: "Failed to create mentor review" });
  }
};

// Book a session with a mentor
export const bookMentorSession = async (req: Request, res: Response) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to book a session" });
    }
    
    const { id } = req.params;
    
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ message: "Invalid mentor ID" });
    }
    
    const mentorId = parseInt(id);
    const userId = req.user?.id;
    
    // Check if mentor exists
    const mentorResult = await db
      .select()
      .from(mentors)
      .where(eq(mentors.id, mentorId))
      .limit(1);
      
    if (mentorResult.length === 0) {
      return res.status(404).json({ message: "Mentor not found" });
    }
    
    const mentor = mentorResult[0];
    
    // Validate the booking data
    const bookingSchema = z.object({
      date: z.string().refine(value => !isNaN(Date.parse(value)), {
        message: "Invalid date format"
      }),
      duration: z.number().min(30).max(240),
      topic: z.string().min(3).max(200),
      notes: z.string().max(1000).optional()
    });
    
    const validationResult = bookingSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({ 
        message: "Invalid booking data",
        errors: validationResult.error.format() 
      });
    }
    
    const { date, duration, topic, notes } = validationResult.data;
    
    // Calculate the price based on duration and hourly rate
    const price = Math.round((duration / 60) * mentor.hourlyRate);
    
    // Create the booking
    const result = await db.insert(mentorSessions).values({
      mentorId,
      userId,
      date: new Date(date),
      duration,
      price,
      topic,
      notes: notes || null,
      status: 'pending',
      paymentConfirmed: false
    }).returning();
    
    return res.status(201).json(result[0]);
  } catch (error) {
    console.error("Error booking mentor session:", error);
    return res.status(500).json({ message: "Failed to book mentor session" });
  }
};

// Get user's booked sessions
export const getUserSessions = async (req: Request, res: Response) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.user?.id;
    
    const sessions = await db
      .select({
        session: mentorSessions,
        mentor: {
          id: mentors.id,
          name: mentors.name,
          profileImage: mentors.profileImage
        }
      })
      .from(mentorSessions)
      .innerJoin(mentors, eq(mentorSessions.mentorId, mentors.id))
      .where(eq(mentorSessions.userId, userId))
      .orderBy(desc(mentorSessions.date));
    
    return res.status(200).json(sessions);
  } catch (error) {
    console.error("Error fetching user sessions:", error);
    return res.status(500).json({ message: "Failed to fetch user sessions" });
  }
};

// Get mentor's scheduled sessions
export const getMentorSessions = async (req: Request, res: Response) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.user?.id;
    
    // Check if the user is a mentor
    const mentorResult = await db
      .select()
      .from(mentors)
      .where(eq(mentors.userId, userId))
      .limit(1);
    
    if (mentorResult.length === 0) {
      return res.status(403).json({ message: "You are not registered as a mentor" });
    }
    
    const mentorId = mentorResult[0].id;
    
    const sessions = await db
      .select()
      .from(mentorSessions)
      .where(eq(mentorSessions.mentorId, mentorId))
      .orderBy(desc(mentorSessions.date));
    
    return res.status(200).json(sessions);
  } catch (error) {
    console.error("Error fetching mentor sessions:", error);
    return res.status(500).json({ message: "Failed to fetch mentor sessions" });
  }
};

// Update session status
export const updateSessionStatus = async (req: Request, res: Response) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const { id } = req.params;
    
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ message: "Invalid session ID" });
    }
    
    const sessionId = parseInt(id);
    const userId = req.user?.id;
    
    // Get the session
    const sessionResult = await db
      .select()
      .from(mentorSessions)
      .where(eq(mentorSessions.id, sessionId))
      .limit(1);
    
    if (sessionResult.length === 0) {
      return res.status(404).json({ message: "Session not found" });
    }
    
    const session = sessionResult[0];
    
    // Check if mentor is associated with this session
    const mentorResult = await db
      .select()
      .from(mentors)
      .where(eq(mentors.id, session.mentorId))
      .limit(1);
    
    if (mentorResult.length === 0) {
      return res.status(404).json({ message: "Associated mentor not found" });
    }
    
    const mentor = mentorResult[0];
    
    // Check if user is either the mentor or the session's user
    if (mentor.userId !== userId && session.userId !== userId) {
      return res.status(403).json({ message: "You don't have permission to update this session" });
    }
    
    // Validate the new status
    const statusSchema = z.object({
      status: z.enum(['pending', 'confirmed', 'completed', 'cancelled'])
    });
    
    const validationResult = statusSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({ 
        message: "Invalid status",
        errors: validationResult.error.format() 
      });
    }
    
    const { status } = validationResult.data;
    
    // Update the session status
    const result = await db
      .update(mentorSessions)
      .set({ status })
      .where(eq(mentorSessions.id, sessionId))
      .returning();
    
    return res.status(200).json(result[0]);
  } catch (error) {
    console.error("Error updating session status:", error);
    return res.status(500).json({ message: "Failed to update session status" });
  }
};