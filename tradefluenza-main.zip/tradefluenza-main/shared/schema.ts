import { pgTable, text, serial, integer, boolean, jsonb, timestamp, varchar, numeric, index, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from 'drizzle-orm';

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").unique(),
  displayName: text("display_name"),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  coverImageUrl: text("cover_image_url"),
  tradingExperience: text("trading_experience"),
  accountCreated: timestamp("account_created").defaultNow().notNull(),
  lastActive: timestamp("last_active").defaultNow().notNull(),
  isVerified: boolean("is_verified").default(false),
  role: text("role").default("trader"),
  tradingStyle: text("trading_style"),
  favoriteMarkets: text("favorite_markets").array(),
  preferredTimeframes: text("preferred_timeframes").array(),
  location: text("location"),
  website: text("website"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  displayName: true,
});

// For profile updates
export const updateUserProfileSchema = z.object({
  displayName: z.string().min(1).max(50).optional(),
  bio: z.string().max(500).optional(),
  avatarUrl: z.string().url().optional().nullable(),
  coverImageUrl: z.string().url().optional().nullable(),
  tradingExperience: z.string().optional(),
  tradingStyle: z.string().optional(),
  favoriteMarkets: z.array(z.string()).optional(),
  preferredTimeframes: z.array(z.string()).optional(),
  location: z.string().optional(),
  website: z.string().url().optional().nullable(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateUserProfile = z.infer<typeof updateUserProfileSchema>;
export type User = typeof users.$inferSelect;

// Define available tags for validation
export const propFirmTags = [
  "Most Loved",
  "Growing",
  "New",
  "Top Rated",
  "Popular",
  "Best Value"
] as const;

// Prop Firm Rules Schema - dedicated table for rules management
export const propFirmRules = pgTable("prop_firm_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  logoUrl: text("logoUrl"),
  established: text("established").notNull(),
  rating: numeric("rating", { precision: 2, scale: 1 }).notNull().default("4.5"),
  reviewCount: integer("reviewCount").notNull().default(0),
  newsTrading: jsonb("newsTrading").notNull(),
  copyTrading: jsonb("copyTrading").notNull(),
  expertAdvisors: jsonb("expertAdvisors").notNull(),
  riskManagement: jsonb("riskManagement").notNull(),
  tradingRestrictions: jsonb("tradingRestrictions").notNull(),
  htmltext: text("htmltext"), // Rich HTML content for detailed rule descriptions
  category: text("category").notNull().default("premium"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const insertPropFirmRulesSchema = createInsertSchema(propFirmRules).omit({
  id: true,
  createdAt: true,
  lastUpdated: true,
});

export type InsertPropFirmRules = z.infer<typeof insertPropFirmRulesSchema>;
export type PropFirmRules = typeof propFirmRules.$inferSelect;

// Prop Firm Schema with enhanced support for multiple account sizes and advanced features
export const propFirms = pgTable("prop_firms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  established: text("established").notNull(),
  headquarters: text("headquarters").notNull(),
  websiteUrl: text("website_url").notNull(),
  logoUrl: text("logo_url").notNull(),
  description: text("description").notNull(),
  accountSizes: integer("account_sizes").array().notNull(),
  programType: text("program_type").notNull(),
  profitTargets: integer("profit_targets").array().notNull(),
  dailyLoss: integer("daily_loss").notNull(),
  maxLoss: integer("max_loss").notNull(),
  profitSplit: integer("profit_split").notNull(),
  payoutFrequency: text("payout_frequency").notNull(),
  loyaltyProgram: boolean("loyalty_program").notNull(),
  pricing: jsonb("pricing").notNull().$type<{accountSize: number, price: number, programType?: string}[]>(),
  refundPolicy: text("refund_policy").notNull(),
  tradingPlatforms: text("trading_platforms").array().notNull(),
  instrumentsAllowed: text("instruments_allowed").array().notNull(),
  minimumTradingDays: integer("minimum_trading_days").notNull(),
  timeToFunded: text("time_to_funded").notNull(),
  scaling: jsonb("scaling").notNull().$type<{available: boolean, terms: string}>(),
  pros: text("pros").array().notNull(),
  cons: text("cons").array().notNull(),
  couponCode: text("coupon_code").default("TFL"),
  discountPercentage: integer("discount_percentage").default(15), // Default 15% discount
  tags: text("tags").array().default([]),
  videoUrl: text("video_url"), // YouTube video URL for "Know The Propfirm" section
  dateAdded: timestamp("date_added").notNull().defaultNow(),
  position: integer("position").default(999), // Higher position = lower in the list
});

export const insertPropFirmSchema = createInsertSchema(propFirms).omit({
  id: true,
  dateAdded: true,
});

export type InsertPropFirm = z.infer<typeof insertPropFirmSchema>;
export type PropFirm = typeof propFirms.$inferSelect;

// Define available program types for validation
export const programTypes = [
  "One-Phase",
  "Two-Phase",
  "Three-Phase",
  "Rapid",
  "Express",
  "Instant Funding"
] as const;

// Define available payout frequencies for validation
export const payoutFrequencies = [
  "Bi-weekly",
  "Monthly",
  "On Demand",
  "Weekly"
] as const;

// Filter schema for prop firms
export const propFirmFilterSchema = z.object({
  programType: z.string().optional(), // Allow any string including 'any'
  profitSplit: z.string().optional(), // Using string for frontend compatibility
  payoutFrequency: z.string().optional(), // Allow any string including 'any'
  loyaltyProgram: z.boolean().optional(),
  minPrice: z.coerce.number().optional(), // Minimum price filter
  maxPrice: z.coerce.number().optional(), // Maximum price filter
  
  // New search parameters for the horizontal search bar
  profitTarget: z.string().optional(), // Profit target percentage as string
  dailyLoss: z.string().optional(), // Daily loss limit percentage as string
  maxLoss: z.string().optional(), // Maximum loss percentage as string
});

export type PropFirmFilter = z.infer<typeof propFirmFilterSchema>;

// Sort options and directions
export const sortFields = ["price", "profitSplit", "name"] as const;
export const sortDirections = ["asc", "desc"] as const;

// More structured sort schema
export const propFirmSortSchema = z.object({
  field: z.enum(sortFields).optional(),
  direction: z.enum(sortDirections).optional(),
});

export type PropFirmSort = z.infer<typeof propFirmSortSchema>;

// Reviews schema
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  propFirmId: integer("prop_firm_id").notNull().references(() => propFirms.id),
  userId: integer("user_id").notNull().references(() => users.id),
  rating: numeric("rating").notNull(), // 1-5 rating
  title: varchar("title", { length: 100 }).notNull(),
  content: text("content").notNull(),
  pros: text("pros").array(),
  cons: text("cons").array(),
  datePosted: timestamp("date_posted").notNull().defaultNow(),
  isVerified: boolean("is_verified").default(false),
  experience: text("experience"),
  tradingPeriod: text("trading_period"),
});

// Relations
export const propFirmsRelations = relations(propFirms, ({ many }) => ({
  reviews: many(reviews),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  propFirm: one(propFirms, {
    fields: [reviews.propFirmId],
    references: [propFirms.id],
  }),
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id],
  }),
}));

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  datePosted: true,
  isVerified: true,
}).extend({
  // Ensure rating is handled as a number throughout the system
  rating: z.number().min(1).max(5),
});

export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;

// Define available environment ratings for brokers
export const environmentRatings = [
  "AAA",
  "AA",
  "A",
  "BBB",
  "BB",
  "B",
  "C",
  "—"
] as const;

// Define available years active options
export const yearsActiveOptions = [
  "Less than 5 years",
  "5–10 years",
  "10–15 years",
  "15–20 years",
  "Above 20 years"
] as const;

// Broker Schema
export const brokers = pgTable("brokers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country").notNull(),
  yearsActive: text("years_active").notNull(),
  environment: text("environment").notNull(),
  regulators: text("regulators").array().notNull(),
  regulatoryLicenseNumber: text("regulatory_license_number"),
  score: numeric("score", { precision: 4, scale: 2 }).notNull(),
  logoUrl: text("logo_url"),
  websiteUrl: text("website_url"),
  description: text("description"),
  pros: text("pros").array().default([]),
  cons: text("cons").array().default([]),
  tags: text("tags").array().default([]),
  dateAdded: timestamp("date_added").notNull().defaultNow(),
  position: integer("position").default(999), // Higher position = lower in the list
});

export const insertBrokerSchema = createInsertSchema(brokers).omit({
  id: true,
  dateAdded: true,
});

export type InsertBroker = z.infer<typeof insertBrokerSchema>;
export type Broker = typeof brokers.$inferSelect;

// Define available tags for brokers
export const brokerTags = [
  "Top Rated",
  "Popular",
  "Best Value",
  "Most Regulated",
  "Recommended"
] as const;

// Filter schema for brokers
export const brokerFilterSchema = z.object({
  country: z.string().optional(),
  environment: z.enum(environmentRatings).optional(),
  yearsActive: z.enum(yearsActiveOptions).optional(),
  minScore: z.coerce.number().optional(),
  maxScore: z.coerce.number().optional(),
});

export type BrokerFilter = z.infer<typeof brokerFilterSchema>;

// Broker sort options
export const brokerSortFields = ["score", "name", "yearsActive"] as const;

// Broker sort schema
export const brokerSortSchema = z.object({
  field: z.enum(brokerSortFields).optional(),
  direction: z.enum(sortDirections).optional(),
});

export type BrokerSort = z.infer<typeof brokerSortSchema>;

// Broker reviews schema
export const brokerReviews = pgTable("broker_reviews", {
  id: serial("id").primaryKey(),
  brokerId: integer("broker_id").notNull().references(() => brokers.id),
  userId: integer("user_id").notNull().references(() => users.id),
  rating: numeric("rating").notNull(), // 1-5 rating
  title: varchar("title", { length: 100 }).notNull(),
  content: text("content").notNull(),
  pros: text("pros").array(),
  cons: text("cons").array(),
  datePosted: timestamp("date_posted").notNull().defaultNow(),
  isVerified: boolean("is_verified").default(false),
  experience: text("experience"),
  tradingPeriod: text("trading_period"),
});

// Relations for brokers
export const brokersRelations = relations(brokers, ({ many }) => ({
  reviews: many(brokerReviews),
}));

export const brokerReviewsRelations = relations(brokerReviews, ({ one }) => ({
  broker: one(brokers, {
    fields: [brokerReviews.brokerId],
    references: [brokers.id],
  }),
  user: one(users, {
    fields: [brokerReviews.userId],
    references: [users.id],
  }),
}));

export const insertBrokerReviewSchema = createInsertSchema(brokerReviews).omit({
  id: true,
  datePosted: true,
  isVerified: true,
}).extend({
  // Ensure rating is handled as a number throughout the system
  rating: z.number().min(1).max(5),
});

export type InsertBrokerReview = z.infer<typeof insertBrokerReviewSchema>;
export type BrokerReview = typeof brokerReviews.$inferSelect;



// Promotion entries schema for free account popup submissions
export const promotionEntries = pgTable("promotion_entries", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  phoneNumber: text("phone_number").notNull(),
  promotionType: text("promotion_type").notNull().default("free_account"),
  dateCreated: timestamp("date_created").defaultNow().notNull(),
  processed: boolean("processed").default(false).notNull(),
  notes: text("notes"),
});

export const insertPromotionEntrySchema = createInsertSchema(promotionEntries).omit({
  id: true,
  dateCreated: true,
  processed: true,
  notes: true,
});

export type InsertPromotionEntry = z.infer<typeof insertPromotionEntrySchema>;
export type PromotionEntry = typeof promotionEntries.$inferSelect;

// Purchase statistics schema for the counter on the homepage
export const purchaseStats = pgTable("purchase_stats", {
  id: serial("id").primaryKey(),
  totalPurchases: integer("total_purchases").notNull(),
  thisMonth: integer("this_month").notNull(),
  thisWeek: integer("this_week").notNull(),
  today: integer("today").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertPurchaseStatsSchema = createInsertSchema(purchaseStats).omit({
  id: true,
  lastUpdated: true,
});

export const updatePurchaseStatsSchema = z.object({
  totalPurchases: z.number().int().optional(),
  thisMonth: z.number().int().optional(),
  thisWeek: z.number().int().optional(),
  today: z.number().int().optional(),
});

export type InsertPurchaseStats = z.infer<typeof insertPurchaseStatsSchema>;
export type UpdatePurchaseStats = z.infer<typeof updatePurchaseStatsSchema>;
export type PurchaseStats = typeof purchaseStats.$inferSelect;

// Achievement Badges schema for the gamified team achievements
export const achievementBadges = pgTable("achievement_badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  iconUrl: text("icon_url").notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull(),
  points: integer("points").notNull().default(10),
  requirements: text("requirements").notNull(),
  dateCreated: timestamp("date_created").notNull().defaultNow(),
});

export const insertAchievementBadgeSchema = createInsertSchema(achievementBadges).omit({
  id: true,
  dateCreated: true,
});

export type InsertAchievementBadge = z.infer<typeof insertAchievementBadgeSchema>;
export type AchievementBadge = typeof achievementBadges.$inferSelect;

// Badge categories and difficulties for validation
export const badgeCategories = [
  "Trading Performance",
  "Learning",
  "Community",
  "Consistency",
  "Growth"
] as const;

export const badgeDifficulties = [
  "Beginner",
  "Intermediate",
  "Advanced",
  "Expert",
  "Legendary"
] as const;

// Trading Firm Schema - Separate from Prop Firms
export const tradingFirms = pgTable("trading_firms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rank: numeric("rank", { precision: 3, scale: 1 }).notNull(),
  reviewCount: integer("review_count").default(0),
  country: text("country").notNull(),
  yearsInOperation: integer("years_in_operation").notNull(),
  assets: text("assets").array().notNull(),
  platforms: text("platforms").array().notNull(),
  maxAllocations: integer("max_allocations").notNull(),
  promo: text("promo"),
  promoDiscount: integer("promo_discount"),
  couponCode: text("coupon_code"),
  logoUrl: text("logo_url").notNull(),
  websiteUrl: text("website_url").notNull(),
  favoriteCount: integer("favorite_count").default(0),
  dateAdded: timestamp("date_added").notNull().defaultNow(),
  position: integer("position").default(999),
});

export const insertTradingFirmSchema = createInsertSchema(tradingFirms, {
  id: undefined,
  dateAdded: undefined,
  favoriteCount: undefined,
  reviewCount: undefined,
});

export type InsertTradingFirm = z.infer<typeof insertTradingFirmSchema>;
export type TradingFirm = typeof tradingFirms.$inferSelect;

// User Achievements schema to track which users have earned which badges
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  badgeId: integer("badge_id").notNull().references(() => achievementBadges.id),
  dateEarned: timestamp("date_earned").notNull().defaultNow(),
  progress: integer("progress").notNull().default(100), // Percentage of completion
  featured: boolean("featured").notNull().default(false), // Whether this badge is featured on user's profile
});

// Relations for badges
export const achievementBadgesRelations = relations(achievementBadges, ({ many }) => ({
  userAchievements: many(userAchievements),
}));

export const userAchievementsRelations = relations(userAchievements, ({ one }) => ({
  badge: one(achievementBadges, {
    fields: [userAchievements.badgeId],
    references: [achievementBadges.id],
  }),
  user: one(users, {
    fields: [userAchievements.userId],
    references: [users.id],
  }),
}));

export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
  id: true,
  dateEarned: true,
}).extend({
  progress: z.number().min(0).max(100),
});

export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;

// Resolution Center schema
export const resolutionCategories = [
  "Account Opening",
  "Transaction Issue",
  "Payout Problem",
  "Platform Technical Issue",
  "Account Verification",
  "Challenge Rules",
  "Account Suspension",
  "Other"
] as const;

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phoneNumber: text("phone_number").notNull(),
  entityType: text("entity_type").notNull(), // "PropFirm" or "Broker"
  entityId: integer("entity_id").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  status: text("status").default("Open").notNull(), // Open, In Progress, Resolved, Closed
  dateCreated: timestamp("date_created").defaultNow().notNull(),
  dateUpdated: timestamp("date_updated").defaultNow().notNull(),
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true,
  status: true,
  dateCreated: true,
  dateUpdated: true,
}).extend({
  entityType: z.enum(["PropFirm", "Broker"]),
  category: z.enum(resolutionCategories),
  phoneNumber: z.string().min(5).max(20),
  email: z.string().email(),
});

export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;
export type SupportTicket = typeof supportTickets.$inferSelect;

// Support Ticket Comments
export const supportTicketComments = pgTable("support_ticket_comments", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull().references(() => supportTickets.id),
  message: text("message").notNull(),
  isFromStaff: boolean("is_from_staff").default(false).notNull(),
  dateCreated: timestamp("date_created").defaultNow().notNull(),
});

export const supportTicketsRelations = relations(supportTickets, ({ many }) => ({
  comments: many(supportTicketComments),
}));

export const supportTicketCommentsRelations = relations(supportTicketComments, ({ one }) => ({
  ticket: one(supportTickets, {
    fields: [supportTicketComments.ticketId],
    references: [supportTickets.id],
  }),
}));

export const insertSupportTicketCommentSchema = createInsertSchema(supportTicketComments).omit({
  id: true,
  dateCreated: true,
});

export type InsertSupportTicketComment = z.infer<typeof insertSupportTicketCommentSchema>;
export type SupportTicketComment = typeof supportTicketComments.$inferSelect;

// Event types for categorizing trading events
export const eventTypes = [
  "Meetup",
  "Workshop",
  "Conference",
  "Webinar",
  "Virtual Tour",
  "Training",
  "Networking",
  "Competition"
] as const;

// Events schema for trading meetups, workshops, and other events
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  fullDescription: text("full_description").notNull(),
  date: text("date").notNull(), // Date range as text (e.g., "May 15-16, 2025")
  location: text("location").notNull(),
  locationDetails: text("location_details"), // Additional details about location, directions, etc.
  attendees: text("attendees"), // Expected attendees (e.g., "500+ Traders")
  type: text("type").notNull(), // Type of event (e.g., "Meetup", "Workshop", "Conference")
  imageUrl: text("image_url"), // URL to event banner image
  registrationUrl: text("registration_url"), // External URL for registration if applicable
  speakersList: jsonb("speakers_list").array(), // Array of speakers with name, title, bio, imageUrl
  agenda: jsonb("agenda").array(), // Array of agenda items with time, title, description
  isPremium: boolean("is_premium").default(false), // Whether the event requires payment
  price: numeric("price"), // Price of the event if premium
  maxAttendees: integer("max_attendees"), // Maximum number of attendees
  currentAttendees: integer("current_attendees").default(0), // Current number of registered attendees
  dateCreated: timestamp("date_created").defaultNow().notNull(),
  dateUpdated: timestamp("date_updated").defaultNow().notNull(),
  status: text("status").default("Upcoming").notNull(), // Upcoming, Ongoing, Completed, Cancelled
  bgClass: text("bg_class").default("from-indigo-600 to-blue-600"), // CSS gradient class for styling
  featured: boolean("featured").default(false), // Whether to feature the event on homepage
  organizer: text("organizer").default("Tradefluenza"), // Who is organizing the event
});

// Event registration schema to track registrations
export const eventRegistrations = pgTable("event_registrations", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull().references(() => events.id),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phoneNumber: text("phone_number"),
  registrationDate: timestamp("registration_date").defaultNow().notNull(),
  status: text("status").default("Confirmed").notNull(), // Confirmed, Cancelled, Waitlisted
  notes: text("notes"),
  paymentStatus: text("payment_status"), // Paid, Pending, Free
  paymentAmount: numeric("payment_amount"),
  additionalInfo: jsonb("additional_info"), // Any additional form fields for the event
});

// Relations
// Event reviews schema
export const eventReviews = pgTable("event_reviews", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull().references(() => events.id),
  userId: integer("user_id").notNull().references(() => users.id),
  rating: numeric("rating").notNull(), // 1-5 rating
  title: varchar("title", { length: 100 }).notNull(),
  content: text("content").notNull(),
  highlights: text("highlights").array(),
  improvements: text("improvements").array(),
  datePosted: timestamp("date_posted").notNull().defaultNow(),
  isVerified: boolean("is_verified").default(false),
  wouldRecommend: boolean("would_recommend").default(true),
});

export const eventsRelations = relations(events, ({ many }) => ({
  registrations: many(eventRegistrations),
  reviews: many(eventReviews),
}));

export const eventRegistrationsRelations = relations(eventRegistrations, ({ one }) => ({
  event: one(events, {
    fields: [eventRegistrations.eventId],
    references: [events.id],
  }),
  user: one(users, {
    fields: [eventRegistrations.userId],
    references: [users.id],
  }),
}));

export const eventReviewsRelations = relations(eventReviews, ({ one }) => ({
  event: one(events, {
    fields: [eventReviews.eventId],
    references: [events.id],
  }),
  user: one(users, {
    fields: [eventReviews.userId],
    references: [users.id],
  }),
}));

// For creating new events
export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  dateCreated: true,
  dateUpdated: true,
  currentAttendees: true,
});

// For registering for events
export const insertEventRegistrationSchema = createInsertSchema(eventRegistrations).omit({
  id: true,
  registrationDate: true,
});

// For creating event reviews
export const insertEventReviewSchema = createInsertSchema(eventReviews).omit({
  id: true,
  datePosted: true,
  isVerified: true,
}).extend({
  // Ensure rating is handled as a number throughout the system
  rating: z.number().min(1).max(5),
});

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;
export type InsertEventRegistration = z.infer<typeof insertEventRegistrationSchema>;
export type EventRegistration = typeof eventRegistrations.$inferSelect;
export type InsertEventReview = z.infer<typeof insertEventReviewSchema>;
export type EventReview = typeof eventReviews.$inferSelect;

// Purchase statistics schema is already defined above

// -------------- Social Media Features --------------

// User follows relationship table
export const userFollows = pgTable("user_follows", {
  id: serial("id").primaryKey(),
  followerId: integer("follower_id").notNull().references(() => users.id),
  followingId: integer("following_id").notNull().references(() => users.id),
  dateFollowed: timestamp("date_followed").defaultNow().notNull(),
});

export const userFollowsRelations = relations(userFollows, ({ one }) => ({
  follower: one(users, {
    fields: [userFollows.followerId],
    references: [users.id],
    relationName: "follower_relation"
  }),
  following: one(users, {
    fields: [userFollows.followingId],
    references: [users.id],
    relationName: "following_relation"
  }),
}));

// User relations will be defined after all tables are created

// Trading Post Types
export const postTypes = [
  "trade_idea", 
  "trade_result", 
  "market_analysis", 
  "educational", 
  "question",
  "general"
] as const;

// Trading Posts - the main content of the social platform
export const tradePosts = pgTable("trade_posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  postType: text("post_type").notNull(),
  instrument: text("instrument"),
  timeframe: text("timeframe"),
  direction: text("direction"), // "long" or "short"
  entryPrice: numeric("entry_price"),
  targetPrice: numeric("target_price"),
  stopLoss: numeric("stop_loss"),
  riskReward: numeric("risk_reward"),
  result: numeric("result"), // Percentage or pips
  imageUrls: text("image_urls").array(),
  tags: text("tags").array(),
  datePosted: timestamp("date_posted").defaultNow().notNull(),
  dateUpdated: timestamp("date_updated").defaultNow().notNull(),
  isPublic: boolean("is_public").default(true).notNull(),
  isPinned: boolean("is_pinned").default(false).notNull(),
  isArchived: boolean("is_archived").default(false).notNull(),
});

// Trade post relations - will be defined after all tables are declared

// Post Comments
export const postComments = pgTable("post_comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => tradePosts.id),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  datePosted: timestamp("date_posted").defaultNow().notNull(),
  dateUpdated: timestamp("date_updated").defaultNow().notNull(),
  parentCommentId: integer("parent_comment_id"),
});

// Post Likes
export const postLikes = pgTable("post_likes", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => tradePosts.id),
  userId: integer("user_id").notNull().references(() => users.id),
  dateLiked: timestamp("date_liked").defaultNow().notNull(),
});

// Likes relations
export const postLikesRelations = relations(postLikes, ({ one }) => ({
  post: one(tradePosts, {
    fields: [postLikes.postId],
    references: [tradePosts.id],
  }),
  user: one(users, {
    fields: [postLikes.userId],
    references: [users.id],
  }),
}));

// Trading Floor Status
export const tradingFloor = pgTable("trading_floor", {
  id: serial("id").primaryKey(),
  marketName: text("market_name").notNull().unique(),
  status: text("status").notNull().default("normal"), // "volatile", "trending", "normal", "quiet"
  direction: text("direction"), // "bullish" or "bearish"
  activityLevel: integer("activity_level").notNull().default(50), // 0-100
  importantNews: text("important_news"),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// For creating and updating posts
export const insertTradePostSchema = createInsertSchema(tradePosts).omit({
  id: true,
  userId: true,  // Omit userId since it will be populated from the authenticated session
  datePosted: true,
  dateUpdated: true,
  isPinned: true,
  isArchived: true,
}).extend({
  postType: z.enum(postTypes),
  imageUrls: z.array(z.string().url()).optional(),
});

export const updateTradePostSchema = createInsertSchema(tradePosts).partial().omit({
  id: true,
  userId: true,
  datePosted: true,
}).extend({
  postType: z.enum(postTypes).optional(),
  imageUrls: z.array(z.string().url()).optional(),
});

// For comments
export const insertCommentSchema = createInsertSchema(postComments).omit({
  id: true,
  datePosted: true,
  dateUpdated: true,
});

export const updateCommentSchema = z.object({
  content: z.string().min(1).max(1000),
});

// For trading floor
export const updateTradingFloorSchema = z.object({
  status: z.enum(["volatile", "trending", "normal", "quiet"]).optional(),
  direction: z.enum(["bullish", "bearish"]).optional().nullable(),
  activityLevel: z.number().min(0).max(100).optional(),
  importantNews: z.string().optional().nullable(),
});

// Types 
export type InsertTradePost = z.infer<typeof insertTradePostSchema>;
export type UpdateTradePost = z.infer<typeof updateTradePostSchema>;
export type TradePost = typeof tradePosts.$inferSelect;

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type UpdateComment = z.infer<typeof updateCommentSchema>;
export type PostComment = typeof postComments.$inferSelect;

export type PostLike = typeof postLikes.$inferSelect;
export type UserFollow = typeof userFollows.$inferSelect;

export type TradingFloor = typeof tradingFloor.$inferSelect;
export type UpdateTradingFloor = z.infer<typeof updateTradingFloorSchema>;

// Define all the relations now that all tables are declared
export const usersRelations = relations(users, ({ many }) => ({
  followers: many(userFollows, { relationName: "following_relation" }),
  following: many(userFollows, { relationName: "follower_relation" }),
  posts: many(tradePosts),
  comments: many(postComments),
  likes: many(postLikes),
}));

export const tradePostsRelations = relations(tradePosts, ({ one, many }) => ({
  author: one(users, {
    fields: [tradePosts.userId],
    references: [users.id],
  }),
  comments: many(postComments),
  likes: many(postLikes),
}));

export const postCommentsRelations = relations(postComments, ({ one, many }) => ({
  post: one(tradePosts, {
    fields: [postComments.postId],
    references: [tradePosts.id],
  }),
  author: one(users, {
    fields: [postComments.userId],
    references: [users.id],
  }),
  // Add parent comment relation if parentCommentId exists
  ...(postComments.parentCommentId && {
    parentComment: one(postComments, {
      fields: [postComments.parentCommentId],
      references: [postComments.id],
    })
  }),
  // Add replies relation
  replies: many(postComments, { relationName: "comment_replies" }),
}));

// Testimonials Schema - Optimized with indices for better query performance
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  profileImageUrl: text("profile_image_url").notNull(),
  traderType: text("trader_type").notNull(), // E.g., "Forex & Indices Trader"
  rating: numeric("rating", { precision: 2, scale: 1 }).notNull(), // 1-5 rating
  testimonialText: text("testimonial_text").notNull(),
  tradingSince: text("trading_since").notNull(), // E.g., "2021"
  badgeLabel: text("badge_label").notNull(), // E.g., "Verified Trader"
  badgeColor: text("badge_color").notNull(), // E.g., "indigo", "purple", "emerald"
  featured: boolean("featured").default(false).notNull(), // Add index for featured filter
  displayOrder: integer("display_order").default(999).notNull(), // Add index for sorting
  dateAdded: timestamp("date_added").defaultNow().notNull(), // Add index for date-based queries
}, (table) => {
  return {
    // Create composite index for the most common query patterns
    featuredOrderIdx: index("testimonials_featured_order_idx").on(table.featured, table.displayOrder),
    dateAddedIdx: index("testimonials_date_added_idx").on(table.dateAdded),
    ratingIdx: index("testimonials_rating_idx").on(table.rating),
  };
});

export const insertTestimonialSchema = createInsertSchema(testimonials).omit({
  id: true,
  dateAdded: true,
});

export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

// ============ MENTORS SCHEMA ============

// Define the specialization enum for mentors
export const specializationEnum = pgEnum('mentor_specialization', [
  'forex',
  'futures',
  'stocks',
  'crypto',
  'options',
  'algo_trading',
  'risk_management',
  'psychology'
]);

// Define the experience level enum
export const experienceLevelEnum = pgEnum('experience_level', [
  'beginner_friendly',
  'intermediate',
  'advanced',
  'professional'
]);

// Define the session status enum
export const sessionStatusEnum = pgEnum('session_status', [
  'pending',
  'confirmed',
  'completed',
  'cancelled'
]);

// Mentors table
export const mentors = pgTable('mentors', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  name: text('name').notNull(),
  profileImage: text('profile_image'),
  bio: text('bio').notNull(),
  experience: integer('experience_years').notNull(), // Years of experience
  specialization: specializationEnum('specialization').notNull(),
  experienceLevel: experienceLevelEnum('experience_level').notNull(),
  hourlyRate: integer('hourly_rate').notNull(), // In USD
  isVerified: boolean('is_verified').default(false),
  availability: text('availability').notNull(), // JSON string of available time slots
  languages: text('languages').notNull(), // Comma-separated languages (e.g., "English,Spanish")
  location: text('location'), // Country/region
  socialMedia: text('social_media'), // JSON string of social media links
  credentials: text('credentials'), // JSON string of credentials/certifications
  about: text('about').notNull(), // Detailed description
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Mentor reviews table
export const mentorReviews = pgTable('mentor_reviews', {
  id: serial('id').primaryKey(),
  mentorId: integer('mentor_id').references(() => mentors.id).notNull(),
  userId: integer('user_id').references(() => users.id).notNull(),
  rating: integer('rating').notNull(), // 1-5 stars
  title: text('title'),
  content: text('content').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Booking sessions table
export const mentorSessions = pgTable('mentor_sessions', {
  id: serial('id').primaryKey(),
  mentorId: integer('mentor_id').references(() => mentors.id).notNull(),
  userId: integer('user_id').references(() => users.id).notNull(),
  date: timestamp('date').notNull(),
  duration: integer('duration').notNull(), // In minutes
  price: integer('price').notNull(), // Total price in USD
  topic: text('topic').notNull(),
  notes: text('notes'),
  status: sessionStatusEnum('status').default('pending'),
  paymentConfirmed: boolean('payment_confirmed').default(false),
  meetingLink: text('meeting_link'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Relations
export const mentorsRelations = relations(mentors, ({ one, many }) => ({
  user: one(users, {
    fields: [mentors.userId],
    references: [users.id],
  }),
  reviews: many(mentorReviews),
  sessions: many(mentorSessions),
}));

export const mentorReviewsRelations = relations(mentorReviews, ({ one }) => ({
  mentor: one(mentors, {
    fields: [mentorReviews.mentorId],
    references: [mentors.id],
  }),
  user: one(users, {
    fields: [mentorReviews.userId],
    references: [users.id],
  }),
}));

export const mentorSessionsRelations = relations(mentorSessions, ({ one }) => ({
  mentor: one(mentors, {
    fields: [mentorSessions.mentorId],
    references: [mentors.id],
  }),
  user: one(users, {
    fields: [mentorSessions.userId],
    references: [users.id],
  }),
}));

// Zod schemas for validation
export const insertMentorSchema = createInsertSchema(mentors).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMentorReviewSchema = createInsertSchema(mentorReviews).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMentorSessionSchema = createInsertSchema(mentorSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type Mentor = typeof mentors.$inferSelect;
export type InsertMentor = z.infer<typeof insertMentorSchema>;
export type MentorReview = typeof mentorReviews.$inferSelect;
export type InsertMentorReview = z.infer<typeof insertMentorReviewSchema>;
export type MentorSession = typeof mentorSessions.$inferSelect;
export type InsertMentorSession = z.infer<typeof insertMentorSessionSchema>;

// Lucky Offer Form Schema
export const luckyOfferEntries = pgTable('lucky_offer_entries', {
  id: serial('id').primaryKey(),
  email: text('email').notNull(),
  propFirmId: integer('prop_firm_id').notNull(),
  propFirmName: text('prop_firm_name').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const insertLuckyOfferEntrySchema = createInsertSchema(luckyOfferEntries).omit({
  id: true,
  createdAt: true,
});

export type InsertLuckyOfferEntry = z.infer<typeof insertLuckyOfferEntrySchema>;
export type LuckyOfferEntry = typeof luckyOfferEntries.$inferSelect;

// Forms Schema - Multilingual Form Management System
export const forms = pgTable('forms', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  language: text('language').notNull().default('en'), // ISO 639-1 language code
  description: text('description').notNull(),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => {
  return {
    nameLanguageIdx: index('forms_name_language_idx').on(table.name, table.language),
    languageIdx: index('forms_language_idx').on(table.language),
    activeIdx: index('forms_active_idx').on(table.isActive),
  };
});

// Form Fields Schema - Dynamic fields for each form
export const formFields = pgTable('form_fields', {
  id: serial('id').primaryKey(),
  formId: integer('form_id').references(() => forms.id).notNull(),
  fieldName: text('field_name').notNull(),
  fieldType: text('field_type').notNull(), // text, email, select, checkbox, etc.
  required: boolean('required').notNull().default(false),
  placeholder: text('placeholder'),
  options: text('options'), // For select, checkbox, radio fields
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => {
  return {
    formIdIdx: index('form_fields_form_id_idx').on(table.formId),
  };
});

// Form Submissions Schema - Store form submissions
export const formSubmissions = pgTable('form_submissions', {
  id: serial('id').primaryKey(),
  formId: integer('form_id').references(() => forms.id).notNull(),
  submissionData: jsonb('submission_data').notNull(), // JSON object with submitted data
  submitterEmail: text('submitter_email'),
  submitterIp: text('submitter_ip'),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => {
  return {
    formIdIdx: index('form_submissions_form_id_idx').on(table.formId),
    dateIdx: index('form_submissions_date_idx').on(table.createdAt),
    emailIdx: index('form_submissions_email_idx').on(table.submitterEmail),
  };
});

// Relations
export const formsRelations = relations(forms, ({ many }) => ({
  fields: many(formFields),
  submissions: many(formSubmissions),
}));

export const formFieldsRelations = relations(formFields, ({ one }) => ({
  form: one(forms, {
    fields: [formFields.formId],
    references: [forms.id],
  }),
}));

export const formSubmissionsRelations = relations(formSubmissions, ({ one }) => ({
  form: one(forms, {
    fields: [formSubmissions.formId],
    references: [forms.id],
  }),
}));

// Zod schemas for validation
export const insertFormSchema = createInsertSchema(forms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateFormSchema = insertFormSchema.partial();

export const insertFormFieldSchema = createInsertSchema(formFields).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFormSubmissionSchema = createInsertSchema(formSubmissions).omit({
  id: true,
  createdAt: true,
});

// Types
export type Form = typeof forms.$inferSelect;
export type InsertForm = z.infer<typeof insertFormSchema>;
export type UpdateForm = z.infer<typeof updateFormSchema>;
export type FormField = typeof formFields.$inferSelect;
export type InsertFormField = z.infer<typeof insertFormFieldSchema>;
export type FormSubmission = typeof formSubmissions.$inferSelect;
export type InsertFormSubmission = z.infer<typeof insertFormSubmissionSchema>;
