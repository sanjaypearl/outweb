// Google Analytics gtag type declaration
interface Window {
  dataLayer: any[];
  gtag: (...args: any[]) => void;
}