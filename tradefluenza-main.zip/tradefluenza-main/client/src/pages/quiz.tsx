import React from "react";
import QuizContainer from "@/components/quiz/quiz-container";

export default function Quiz() {
  return (
    <div className="py-6 min-h-screen bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text">
            Find Your Perfect Prop Firm
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Answer a few questions about your trading style and preferences, and we'll match you with 
            the prop firms that are best suited for your needs.
          </p>
        </div>
        
        <QuizContainer />
      </div>
    </div>
  );
}