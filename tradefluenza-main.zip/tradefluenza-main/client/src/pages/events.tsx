import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { 
  Calendar, MapPin, Users, ArrowRight, Filter, Search,
  ChevronLeft, ChevronRight, SlidersHorizontal, X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Helmet } from "react-helmet-async";

// Types for events
interface Event {
  id: number;
  title: string;
  description: string;
  date: string;
  location: string;
  attendees?: string;
  type: string;
  isPremium: boolean;
  price?: number;
  status: string;
  bgClass: string;
  organizer: string;
}

export default function EventsPage() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState('');
  const [eventTypeFilter, setEventTypeFilter] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const itemsPerPage = 9;
  
  // Fetch all events
  const { data: allEvents, isLoading, error } = useQuery<Event[]>({
    queryKey: ['/api/events'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
  
  // Filter and search events
  const filteredEvents = allEvents?.filter(event => {
    // Apply search term filter
    const matchesSearch = searchTerm === '' || 
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Apply event type filter
    const matchesType = eventTypeFilter === null || event.type === eventTypeFilter;
    
    return matchesSearch && matchesType;
  });
  
  // Get unique event types for filter
  const eventTypes = allEvents ? 
    [...new Set(allEvents.map(event => event.type))].sort() : 
    [];
  
  // Pagination
  const totalPages = filteredEvents ? Math.ceil(filteredEvents.length / itemsPerPage) : 0;
  const paginatedEvents = filteredEvents?.slice((page - 1) * itemsPerPage, page * itemsPerPage);
  
  // Clear all filters
  const clearFilters = () => {
    setSearchTerm('');
    setEventTypeFilter(null);
    setPage(1);
  };
  
  // Skeleton loader for events
  const EventSkeleton = () => (
    <Card className="h-full flex flex-col">
      <Skeleton className="h-48 w-full rounded-t-lg" />
      <CardHeader>
        <Skeleton className="h-6 w-24 mb-2" />
        <Skeleton className="h-8 w-full mb-2" />
        <Skeleton className="h-4 w-3/4" />
      </CardHeader>
      <CardContent className="flex-grow">
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-2/3" />
      </CardContent>
      <CardFooter>
        <Skeleton className="h-10 w-full" />
      </CardFooter>
    </Card>
  );
  
  // Render loading state
  if (isLoading) {
    return (
      <div className="container py-10">
        <div className="mb-8">
          <Skeleton className="h-10 w-3/4 max-w-md mb-2" />
          <Skeleton className="h-6 w-1/2 max-w-sm" />
        </div>
        
        <div className="flex items-center justify-between mb-8">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-10 w-36" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <EventSkeleton key={i} />
          ))}
        </div>
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className="container py-10">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2 text-red-500">Error Loading Events</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">{error.message}</p>
          <Button onClick={() => window.location.reload()}>
            Try Again
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>
          Join Now Virtual Trading Webinars & Workshops | Tradefluenza
        </title>
        <meta
          name="description"
          content="Tradefluenza hosts expert-led virtual trading webinars and workshops. Learn strategies, gain insights and connect with traders worldwide."
        />
        <meta
          name="keywords"
          content="virtual trading webinars, trading workshops"
        />
        <link rel="canonical" href="https://tradefluenza.com/events" />
      </Helmet>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        {/* Header */}
        <div className="mb-10 md:mb-12 text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-5 bg-gradient-to-r from-indigo-600 via-purple-600 to-violet-600 text-transparent bg-clip-text">
            Trading Events & Meetups
          </h1>
          <p className="text-gray-600 dark:text-gray-300 text-lg">
            Discover trading meetups, workshops, and educational events to
            connect with fellow traders and enhance your skills.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-200 dark:border-gray-800 p-6 mb-10 shadow-sm">
          <div className="flex flex-col md:flex-row items-stretch justify-between gap-5">
            <div className="relative w-full">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search events by title, description, or location..."
                className="pl-11 py-6 rounded-xl bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 shadow-sm"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setPage(1); // Reset to first page when searching
                }}
              />
              {searchTerm && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7"
                  onClick={() => setSearchTerm("")}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3 mt-2 md:mt-0">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="flex items-center gap-2 min-w-[140px] h-12"
                  >
                    <SlidersHorizontal className="h-4 w-4" />
                    <span>Event Type</span>
                    {eventTypeFilter && (
                      <Badge className="ml-1">{eventTypeFilter}</Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  {eventTypes.map((type) => (
                    <DropdownMenuItem
                      key={type}
                      className="flex items-center justify-between"
                      onClick={() => {
                        setEventTypeFilter(
                          type === eventTypeFilter ? null : type
                        );
                        setPage(1); // Reset to first page when filtering
                      }}
                    >
                      <span>{type}</span>
                      {type === eventTypeFilter && (
                        <Badge className="ml-2">Selected</Badge>
                      )}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {(searchTerm || eventTypeFilter) && (
                <Button variant="ghost" className="h-12" onClick={clearFilters}>
                  <X className="h-4 w-4 mr-2" /> Clear Filters
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Events grid */}
        {filteredEvents?.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-800/50">
            <Filter className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl font-bold mb-2">No Events Found</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Try adjusting your search or filters to find what you're looking
              for.
            </p>
            <Button variant="outline" onClick={clearFilters}>
              Clear All Filters
            </Button>
          </div>
        ) : (
          <>
            {/* Event status tabs */}
            <div className="bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-200 dark:border-gray-800 p-6 mb-8 shadow-sm">
              <Tabs defaultValue="all" className="w-full">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">
                    Browse Events
                  </h2>
                  <TabsList className="bg-gray-100 dark:bg-gray-800 p-1">
                    <TabsTrigger value="all" className="rounded-lg px-4">
                      All Events
                    </TabsTrigger>
                    <TabsTrigger value="upcoming" className="rounded-lg px-4">
                      Upcoming
                    </TabsTrigger>
                    <TabsTrigger value="ongoing" className="rounded-lg px-4">
                      Ongoing
                    </TabsTrigger>
                    <TabsTrigger value="past" className="rounded-lg px-4">
                      Past
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="all" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {paginatedEvents?.map((event) => (
                      <EventCard key={event.id} event={event} />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="upcoming" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {paginatedEvents
                      ?.filter((e) => e.status === "Upcoming")
                      .map((event) => (
                        <EventCard key={event.id} event={event} />
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="ongoing" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {paginatedEvents
                      ?.filter((e) => e.status === "Ongoing")
                      .map((event) => (
                        <EventCard key={event.id} event={event} />
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="past" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {paginatedEvents
                      ?.filter((e) => e.status === "Completed")
                      .map((event) => (
                        <EventCard key={event.id} event={event} />
                      ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center mt-10 gap-1">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>

                {Array.from({ length: totalPages }).map((_, i) => (
                  <Button
                    key={i}
                    variant={page === i + 1 ? "default" : "outline"}
                    size="icon"
                    onClick={() => setPage(i + 1)}
                  >
                    {i + 1}
                  </Button>
                ))}

                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  disabled={page === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
}

// Event card component
function EventCard({ event }: { event: Event }) {
  return (
    <Card className="h-full flex flex-col transition-all duration-300 hover:shadow-xl overflow-hidden group border border-gray-200 dark:border-gray-800 hover:border-primary/30 relative">
      {/* Status indicator */}
      {event.status !== 'Upcoming' && (
        <div className="absolute top-3 right-3 z-20">
          {event.status === 'Ongoing' ? (
            <div className="flex items-center gap-1.5 bg-emerald-500 text-white px-2.5 py-1 rounded-full text-xs font-semibold">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
              <span>Happening Now</span>
            </div>
          ) : (
            <div className="bg-gray-600/80 backdrop-blur-sm text-white px-2.5 py-1 rounded-full text-xs font-semibold">
              Completed
            </div>
          )}
        </div>
      )}
      
      {/* Featured badge */}
      {event.featured && (
        <div className="absolute top-3 left-3 z-20">
          <div className="bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 px-2.5 py-1 rounded-full text-xs font-semibold shadow-md">
            Featured
          </div>
        </div>
      )}
      
      {/* Header image */}
      <div className={`h-52 w-full relative bg-gradient-to-br ${event.bgClass} group-hover:scale-105 transition-transform duration-700`}>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzBoLTZsMyAxMHpNNTQgMjBsLTYgNiA2IDZ6TTYgNGwtNi02aDEyeiIvPjwvZz48L2c+PC9zdmc+')] opacity-20"></div>
        
        {/* Text overlay with gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
        
        <div className="absolute inset-0 p-6 flex flex-col justify-end text-white">
          <div className="space-y-3">
            {/* Meta info */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-white/90">
              <div className="flex items-center gap-1.5 bg-black/30 px-2 py-1 rounded-full backdrop-blur-sm">
                <Calendar className="h-3.5 w-3.5 text-white/90" />
                <span>{event.date}</span>
              </div>
              <div className="flex items-center gap-1.5 bg-black/30 px-2 py-1 rounded-full backdrop-blur-sm">
                <MapPin className="h-3.5 w-3.5 text-white/90" />
                <span>{event.location}</span>
              </div>
            </div>
            
            {/* Event title with hover effect */}
            <h3 className="text-xl font-bold group-hover:text-white transition-colors duration-300 text-white/90 line-clamp-2">
              {event.title}
            </h3>
            
            {/* Price/Attendance badges */}
            <div className="flex items-center gap-2">
              {event.isPremium ? (
                <Badge className="bg-gradient-to-r from-amber-300 to-amber-500 text-amber-950 hover:from-amber-400 hover:to-amber-600 shadow-sm">
                  Premium - ${event.price}
                </Badge>
              ) : (
                <Badge className="bg-gradient-to-r from-emerald-400 to-emerald-600 text-white hover:from-emerald-500 hover:to-emerald-700 shadow-sm">
                  Free Event
                </Badge>
              )}
              
              {event.attendees && (
                <div className="flex items-center text-sm text-white/80 bg-white/10 px-2 py-0.5 rounded-full backdrop-blur-sm">
                  <Users className="h-3 w-3 mr-1" />
                  {event.attendees}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="flex flex-col flex-grow p-4">
        {/* Event type */}
        <div className="mb-3">
          <Badge variant="outline" className="bg-primary/5 hover:bg-primary/10 text-primary border-primary/20">
            {event.type}
          </Badge>
        </div>
        
        {/* Description */}
        <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-3 mb-4 flex-grow">
          {event.description}
        </p>
        
        {/* CTA Button */}
        <div className="mt-auto pt-2">
          <Button 
            asChild 
            variant="default" 
            className="w-full bg-gradient-to-r from-primary to-indigo-600 hover:from-primary/90 hover:to-indigo-700 text-white shadow-md group"
          >
            <Link href={`/events/${event.id}`} className="flex items-center justify-center">
              View Event Details
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>
      </div>
    </Card>
  );
}