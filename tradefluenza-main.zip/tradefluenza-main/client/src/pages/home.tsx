import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, HelpCircle, ChevronLeft, ChevronRight, Tag, Copy, CheckCircle2, Users, Clock, TrendingUp, Award, Crown, Verified, Trophy, Calendar, Check, ThumbsUp, MessageCircle, Share2, BarChart4, DollarSign, Quote, GraduationCap } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { OnboardingWalkthrough, homeSteps, useWalkthrough, WalkthroughButton } from "@/components/onboarding";
import { useEffect, useState, useRef } from "react";
import { Badge } from "@/components/ui/badge";
import { FiStar, FiExternalLink } from "react-icons/fi";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import PurchaseCounter from "@/components/stats/purchase-counter";
import CountUpAnimation from "@/components/animations/count-up-animation";
import MentorsCard from "@/components/home/MentorsCard";
import BlueberryPromoPopup from "@/components/promotions/BlueberryPromoPopup";
import { usePromotionPopup } from "@/hooks/use-promotion-popup";
import LuckyOfferForm from "@/components/lucky-offer-form";
import { Helmet } from "react-helmet-async";
// Testimonials section removed as requested

// Event data type
interface EventData {
  id: number;
  title: string;
  description: string;
  fullDescription: string;
  date: string;
  location: string;
  locationDetails?: string;
  attendees?: string;
  type: string;
  imageUrl?: string;
  speakersList?: {
    name: string;
    title: string;
    bio: string;
  }[];
  isPremium: boolean;
  price?: string | number;
  currentAttendees: number;
  status: string;
  bgClass: string;
  featured: boolean;
}

// Events Showcase Component
const EventsShowcase = () => {
  const { data: events, isLoading, error } = useQuery<EventData[]>({
    queryKey: ['/api/events'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
  
  // Featured and upcoming events
  const featuredEvents = events?.filter(event => 
    (event.featured || event.status === 'Upcoming') && 
    event.type !== 'Virtual Tour'
  ).slice(0, 3);
  
  // Show skeletons while loading
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[1, 2, 3].map(i => (
          <div key={i} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg border border-gray-200 dark:border-gray-700">
            <Skeleton className="h-48 w-full" />
            <div className="p-5">
              <div className="flex items-center mb-4">
                <Skeleton className="h-10 w-10 rounded-full mr-3" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-32 mb-1" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4 mb-5" />
              <div className="flex justify-between items-center">
                <Skeleton className="h-6 w-20" />
                <Skeleton className="h-9 w-24" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center py-12 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-800/50">
        <h3 className="text-xl font-bold mb-2">Unable to load events</h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          We're having trouble fetching the latest events. Please try again later.
        </p>
      </div>
    );
  }
  
  if (!featuredEvents || featuredEvents.length === 0) {
    return (
      <div className="text-center py-12 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-800/50">
        <h3 className="text-xl font-bold mb-2">No Upcoming Events</h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          Check back later for new trading events and opportunities.
        </p>
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {featuredEvents.map(event => (
        <div key={event.id} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg border border-gray-200 dark:border-gray-700 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group">
          <div className="relative h-48 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent z-10"></div>
            
            {event.imageUrl ? (
              <img 
                src={event.imageUrl} 
                alt={event.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
            ) : (
              <div className={`absolute inset-0 bg-gradient-to-br ${event.bgClass || 'from-indigo-600 to-blue-600'}`}></div>
            )}
            
            <div className="absolute bottom-3 left-4 z-20">
              <div className="flex items-center text-white">
                <Calendar className="w-4 h-4 mr-2" />
                <span className="text-sm opacity-90">{event.date}</span>
              </div>
              <h3 className="text-xl font-bold text-white mt-1">{event.title}</h3>
            </div>
            
            {event.featured && (
              <div className="absolute top-3 right-3 z-20">
                <span className="inline-flex items-center justify-center h-6 px-3 rounded-full bg-gradient-to-r from-yellow-400 to-amber-500 text-white text-xs font-bold shadow-lg">
                  Featured
                </span>
              </div>
            )}
            
            {event.isPremium && (
              <div className="absolute top-3 left-3 z-20">
                <span className="inline-flex items-center justify-center h-6 px-3 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold shadow-lg">
                  Premium
                </span>
              </div>
            )}
          </div>
          
          <div className="p-5">
            {/* Speaker info */}
            {event.speakersList && event.speakersList.length > 0 ? (
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full overflow-hidden mr-3 border-2 border-primary bg-primary/10 flex items-center justify-center">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white leading-tight">
                    {event.speakersList.length === 1 
                      ? event.speakersList[0].name 
                      : `${event.speakersList[0].name} + ${event.speakersList.length - 1} more`
                    }
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {event.speakersList.length === 1 
                      ? event.speakersList[0].title 
                      : `Multiple Speakers`
                    }
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full overflow-hidden mr-3 border-2 border-primary bg-primary/10 flex items-center justify-center">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white leading-tight">Tradefluenza Team</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Trading Experts</p>
                </div>
              </div>
            )}
            
            <p className="text-gray-600 dark:text-gray-300 text-sm mb-5 line-clamp-2">
              {event.description}
            </p>
            
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <span className={`inline-flex items-center justify-center h-6 px-3 rounded-full 
                  ${event.type === 'Workshop' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300' : 
                   event.type === 'Conference' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300' :
                   event.type === 'Competition' ? 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300' :
                   event.type === 'Networking' ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300' :
                   'bg-primary/10 text-primary'} 
                   text-xs font-medium`}
                >
                  {event.type}
                </span>
              </div>
              <Link href={`/events/${event.id}`}>
                <Button variant="outline" size="sm" className="hover:bg-primary/10 hover:text-primary">
                  Details <ArrowRight className="ml-1 h-3 w-3" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};


export default function Home() {
  // State for tab selection in the featured section
  const [activeTab, setActiveTab] = useState<'propFirms' | 'brokers'>('propFirms');
  
  // State to track which firm's code was copied
  const [copiedFirmId, setCopiedFirmId] = useState<number | null>(null);
  
  // Promotion popup state
  const { isPopupOpen, setIsPopupOpen } = usePromotionPopup();
  
  // Quiz related state
  const [quizStep, setQuizStep] = useState<number>(1);
  const [quizExperience, setQuizExperience] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [quizAccountSize, setQuizAccountSize] = useState<'5k' | '25k' | '50k' | '100k'>('25k');
  const [quizMarkets, setQuizMarkets] = useState<string[]>(['forex', 'crypto']);
  const [quizFrequency, setQuizFrequency] = useState<'daily' | 'swing' | 'position'>('swing');
  const [quizShowResults, setQuizShowResults] = useState<boolean>(false);
  
  // Toggle function for quiz markets
  const toggleQuizMarket = (market: string) => {
    if (quizMarkets.includes(market)) {
      setQuizMarkets(prev => prev.filter(m => m !== market));
    } else {
      setQuizMarkets(prev => [...prev, market]);
    }
  };
  
  // Function to determine recommended prop firm based on selections
  const getRecommendedPropFirm = () => {
    if (quizExperience === 'beginner') {
      if (quizAccountSize === '5k' || quizAccountSize === '25k') {
        return {
          name: "Blueberry Funded",
          description: "Best for beginners with lower account sizes and excellent support.",
          link: "/prop-firms/28"
        };
      } else {
        return {
          name: "FTMO",
          description: "Great balance of features with extensive educational resources for beginners.",
          link: "/prop-firms/2"
        };
      }
    } else if (quizExperience === 'intermediate') {
      if (quizFrequency === 'daily') {
        return {
          name: "AquaFunded",
          description: "Ideal for active traders with flexible trading conditions and good scaling options.",
          link: "/prop-firms/39"
        };
      } else {
        return {
          name: "The Funded Trader",
          description: "Perfect balance of account size and rules for intermediate traders.",
          link: "/prop-firms/27"
        };
      }
    } else { // advanced
      if (quizMarkets.includes('crypto')) {
        return {
          name: "Blueberry Markets",
          description: "Advanced traders will appreciate the wide range of instruments including crypto.",
          link: "/prop-firms/28"
        };
      } else {
        return {
          name: "FTMO",
          description: "Industry leader with high account sizes and excellent profit splits for experienced traders.",
          link: "/prop-firms/2"
        };
      }
    }
  };
  
  // Fetch all available account sizes
  const { data: accountSizes, isLoading: isSizesLoading } = useQuery<number[]>({
    queryKey: ['/api/prop-firms/account-sizes'],
  });
  
  // Fetch prop firms for featured section
  const { data: propFirms, isLoading: isPropFirmsLoading } = useQuery<any[]>({
    queryKey: ['/api/prop-firms'],
  });
  
  // Fetch brokers for featured section
  const { data: brokers, isLoading: isBrokersLoading } = useQuery<any[]>({
    queryKey: ['/api/brokers'],
  });
  
  // Fetch purchase statistics
  const { data: purchaseStats, isLoading: isStatsLoading } = useQuery<{
    totalPurchases: number;
    thisMonth: number;
    thisWeek: number;
    today: number;
    bySize?: {
      small: number;
      medium: number;
      large: number;
    }
  }>({ 
    queryKey: ['/api/stats/purchases'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });
  
  // Get walkthrough context
  const { activeWalkthrough, startWalkthrough, endWalkthrough } = useWalkthrough();
  
  // Function to copy coupon code to clipboard
  const copyToClipboard = (firmId: number, code: string) => {
    navigator.clipboard.writeText(code).then(() => {
      setCopiedFirmId(firmId);
      setTimeout(() => setCopiedFirmId(null), 2000);
      
      // Track event in Google Analytics
      if (typeof window !== 'undefined' && window.gtag) {
        window.gtag('event', 'copy_coupon', {
          event_category: 'engagement',
          event_label: `${code} - Firm ID ${firmId}`,
        });
      }
    });
  };
  
  // Auto-start the walkthrough for first-time visitors
  useEffect(() => {
    // Check if this is the user's first visit using localStorage
    const isFirstVisit = localStorage.getItem('first_visit') === null;
    if (isFirstVisit) {
      // Set the flag so we don't show it again
      localStorage.setItem('first_visit', 'false');
      // Start the walkthrough after a short delay
      const timer = setTimeout(() => {
        startWalkthrough('new-user');
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [startWalkthrough]);
  
  // Empty useEffect removed

  return (
    <>
      <Helmet>
        <title>
          Explore Now Best Trading Courses & Community | Tradefluenza
        </title>
        <meta
          name="description"
          content="Join the best trading community with Tradefluenza. Learn from top mentors, explore the best trading courses and grow your skills with trusted guidance."
        />
        <meta
          name="keywords"
          content="Best trading community, Best Trading courses"
        />
        <link rel="canonical" href="https://tradefluenza.com/" />
      </Helmet>

      {/* Promotion popup */}
      <BlueberryPromoPopup isOpen={isPopupOpen} onOpenChange={setIsPopupOpen} />

      {/* Walkthrough component */}
      <OnboardingWalkthrough
        isOpen={activeWalkthrough === "new-user"}
        onFinish={endWalkthrough}
        steps={homeSteps}
        name="new-user"
      />

      <section className="py-24 px-4 relative grid-pattern-bg bg-gradient-to-br from-primary/5 via-background to-accent/5 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10"></div>

        {/* Decorative elements */}
        <div className="absolute -left-20 -top-20 w-64 h-64 rounded-full bg-primary/20 blur-3xl"></div>
        <div className="absolute -right-20 -bottom-20 w-64 h-64 rounded-full bg-accent/20 blur-3xl"></div>

        <div className="max-w-7xl mx-auto text-center relative z-10">
          <div className="absolute top-0 right-0">
            <WalkthroughButton type="new-user" />
          </div>

          <div
            className="inline-block mb-3 rounded-full px-3 py-1 text-sm font-medium gradient-primary shadow-lg"
            data-tour="welcome"
          >
            Empowering Traders Worldwide
          </div>
          <h1 className="text-5xl sm:text-6xl font-bold mb-6 gradient-text">
            World's First Verified Trading Ecosystem
          </h1>
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto">
            Access our comprehensive trading platform with social networking,
            events, and detailed comparisons of prop firms and brokers.
          </p>

          <div className="mt-16 relative px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
            {/* Decorative background elements */}
            <div className="absolute -left-64 top-1/2 transform -translate-y-1/2 w-96 h-96 rounded-full bg-blue-500/5 blur-3xl"></div>
            <div className="absolute -right-64 top-1/3 w-96 h-96 rounded-full bg-purple-500/5 blur-3xl"></div>

            {/* Featured cards grid with enhanced styling */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 relative z-10">
              {/* Mentors Card */}
              <MentorsCard />

              {/* Events Card */}
              <Link href="/events" className="group">
                <div className="relative h-full overflow-hidden rounded-xl">
                  {/* Animated background gradient */}
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-fuchsia-100 dark:from-purple-950/40 dark:to-fuchsia-900/30 transition-all duration-500 group-hover:scale-[1.05] group-hover:blur-[1px]"></div>

                  {/* Card content with enhanced glassmorphism effect */}
                  <div className="relative p-8 rounded-xl backdrop-blur-sm border border-purple-200/60 dark:border-purple-800/30 bg-white/50 dark:bg-gray-900/50 h-full flex flex-col">
                    {/* Top colored bar */}
                    <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-purple-400 to-fuchsia-600"></div>

                    {/* Badge in top corner */}
                    <div className="absolute top-4 right-4">
                      <span className="inline-flex items-center rounded-full bg-purple-50 dark:bg-purple-900/30 px-2.5 py-0.5 text-xs font-medium text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800/50">
                        Live
                      </span>
                    </div>

                    {/* Icon with pulse effect */}
                    <div className="relative mb-6">
                      <div className="absolute inset-0 rounded-full bg-purple-500/20 blur-xl animate-pulse"></div>
                      <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-fuchsia-600 flex items-center justify-center text-white shadow-lg transform transition-transform group-hover:rotate-3 group-hover:scale-110">
                        <Calendar className="h-10 w-10" />
                      </div>
                    </div>

                    <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 group-hover:text-purple-600 dark:group-hover:text-purple-400">
                      Events
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                      Join webinars, workshops and trading competitions with
                      expert traders from around the world
                    </p>

                    {/* Stats section */}
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Upcoming
                        </p>
                        <p className="text-xl font-bold text-purple-600 dark:text-purple-400">
                          12
                        </p>
                      </div>
                      <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Attendees
                        </p>
                        <p className="text-xl font-bold text-purple-600 dark:text-purple-400">
                          500+
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-center mt-auto p-3 rounded-lg bg-gradient-to-r from-purple-500 to-fuchsia-600 text-white font-medium group-hover:shadow-lg transition-all duration-300">
                      <span>Explore Events</span>
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </div>
              </Link>

              {/* Prop Firms Card */}
              <Link
                href="/prop-firms"
                data-tour="compare-button"
                className="group"
              >
                <div className="relative h-full overflow-hidden rounded-xl">
                  {/* Animated background gradient */}
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-50 to-orange-100 dark:from-amber-950/40 dark:to-orange-900/30 transition-all duration-500 group-hover:scale-[1.05] group-hover:blur-[1px]"></div>

                  {/* Card content with enhanced glassmorphism effect */}
                  <div className="relative p-8 rounded-xl backdrop-blur-sm border border-amber-200/60 dark:border-amber-800/30 bg-white/50 dark:bg-gray-900/50 h-full flex flex-col">
                    {/* Top colored bar */}
                    <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 to-orange-600"></div>

                    {/* Badge in top corner */}
                    <div className="absolute top-4 right-4">
                      <span className="inline-flex items-center rounded-full bg-amber-50 dark:bg-amber-900/30 px-2.5 py-0.5 text-xs font-medium text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/50">
                        Featured
                      </span>
                    </div>

                    {/* Icon with pulse effect */}
                    <div className="relative mb-6">
                      <div className="absolute inset-0 rounded-full bg-amber-500/20 blur-xl animate-pulse"></div>
                      <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-lg transform transition-transform group-hover:rotate-3 group-hover:scale-110">
                        <DollarSign className="h-10 w-10" />
                      </div>
                    </div>

                    <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 group-hover:text-amber-600 dark:group-hover:text-amber-400">
                      Prop Firms
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                      Find the perfect prop trading firm with the right account
                      size, profit split and trading conditions
                    </p>

                    {/* Stats section */}
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Firms
                        </p>
                        <p className="text-xl font-bold text-amber-600 dark:text-amber-400">
                          45+
                        </p>
                      </div>
                      <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Accounts
                        </p>
                        <p className="text-xl font-bold text-amber-600 dark:text-amber-400">
                          $5K-$300K
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-center mt-auto p-3 rounded-lg bg-gradient-to-r from-amber-500 to-orange-600 text-white font-medium group-hover:shadow-lg transition-all duration-300">
                      <span>Compare Prop Firms</span>
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </div>
              </Link>

              {/* Brokers Card */}
              <Link href="/brokers" className="group">
                <div className="relative h-full overflow-hidden rounded-xl">
                  {/* Animated background gradient */}
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 to-teal-100 dark:from-emerald-950/40 dark:to-teal-900/30 transition-all duration-500 group-hover:scale-[1.05] group-hover:blur-[1px]"></div>

                  {/* Card content with enhanced glassmorphism effect */}
                  <div className="relative p-8 rounded-xl backdrop-blur-sm border border-emerald-200/60 dark:border-emerald-800/30 bg-white/50 dark:bg-gray-900/50 h-full flex flex-col">
                    {/* Top colored bar */}
                    <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-emerald-400 to-teal-600"></div>

                    {/* Badge in top corner */}
                    <div className="absolute top-4 right-4">
                      <span className="inline-flex items-center rounded-full bg-emerald-50 dark:bg-emerald-900/30 px-2.5 py-0.5 text-xs font-medium text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50">
                        Verified
                      </span>
                    </div>

                    {/* Icon with pulse effect */}
                    <div className="relative mb-6">
                      <div className="absolute inset-0 rounded-full bg-emerald-500/20 blur-xl animate-pulse"></div>
                      <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg transform transition-transform group-hover:rotate-3 group-hover:scale-110">
                        <BarChart4 className="h-10 w-10" />
                      </div>
                    </div>

                    <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
                      Brokers
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                      Compare top trading brokers with verified reviews,
                      regulatory information and detailed analysis
                    </p>

                    {/* Stats section */}
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Brokers
                        </p>
                        <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                          25+
                        </p>
                      </div>
                      <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Reviews
                        </p>
                        <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                          1.5K+
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-center mt-auto p-3 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-medium group-hover:shadow-lg transition-all duration-300">
                      <span>Compare Brokers</span>
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          </div>

          {/* Quiz button with enhanced styling and animated arrow */}
          <div className="mt-16 mb-8 flex justify-center">
            <Link href="/quiz" data-tour="quiz-button">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary/50 to-indigo-600/50 rounded-xl blur-lg opacity-50 group-hover:opacity-100 transition-all duration-500"></div>
                <Button
                  size="lg"
                  variant="outline"
                  className="relative px-10 py-6 rounded-xl border-2 border-primary/40 hover:border-primary/90 font-medium text-base backdrop-blur-sm bg-white/30 dark:bg-gray-900/30 text-gray-800 dark:text-white group-hover:shadow-lg transition-all duration-300 group-hover:scale-105"
                >
                  <div className="flex items-center">
                    <span className="gradient-text font-semibold">
                      Find Your Perfect Prop Firm
                    </span>
                    <div className="ml-2 h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center transform group-hover:translate-x-1 transition-transform duration-300">
                      <ArrowRight className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </Button>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Purchase Counter Banner */}
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 py-8 px-4 border-y border-indigo-900/30">
        <div className="max-w-7xl mx-auto">
          {/* Improved counter implementation with glass morphism effect */}
          <div className="relative overflow-hidden rounded-2xl">
            {/* Animated background gradients for vibrant effect */}
            <div className="absolute -inset-[10px] bg-gradient-to-r from-primary/20 via-indigo-500/20 to-purple-500/20 z-0 blur-3xl opacity-70 animate-pulse"></div>
            <div className="absolute -inset-[5px] bg-gradient-to-r from-blue-500/10 via-indigo-500/10 to-purple-500/10 z-0 blur-lg"></div>

            {/* Animated particles in background - subtle floating dots */}
            <div className="absolute inset-0 z-0">
              <div className="absolute h-2 w-2 rounded-full bg-indigo-600/30 top-[20%] left-[10%] animate-float-slow"></div>
              <div className="absolute h-3 w-3 rounded-full bg-purple-600/30 top-[70%] left-[20%] animate-float-medium"></div>
              <div className="absolute h-2 w-2 rounded-full bg-blue-600/30 top-[30%] left-[80%] animate-float-fast"></div>
              <div className="absolute h-4 w-4 rounded-full bg-indigo-600/20 top-[60%] left-[70%] animate-float-slow"></div>
            </div>

            <div className="relative z-10 rounded-2xl border border-slate-700/50 bg-gray-900/90 backdrop-blur-md p-6 shadow-xl">
              <div className="grid grid-cols-1 md:grid-cols-12 items-center gap-8">
                {/* Main counter - spans 5 columns on desktop */}
                <div className="flex items-center md:col-span-5">
                  <div className="rounded-2xl bg-gradient-to-br from-primary to-indigo-600 p-4 mr-5 shadow-lg shadow-indigo-900/30 group transform transition-all duration-300 hover:scale-105 hover:rotate-3">
                    <Users className="h-8 w-8 text-white drop-shadow-md" />
                  </div>

                  <div>
                    <h3 className="text-xl font-bold text-white">
                      Traders Trust Us
                    </h3>
                    <div className="flex items-baseline mt-2">
                      <CountUpAnimation
                        className="text-5xl font-black bg-gradient-to-r from-primary via-indigo-400 to-purple-500 bg-clip-text text-transparent drop-shadow-sm"
                        start={
                          purchaseStats
                            ? purchaseStats.totalPurchases - 10
                            : 18420
                        }
                        end={
                          purchaseStats ? purchaseStats.totalPurchases : 18427
                        }
                        duration={3}
                      />
                      <span className="ml-3 text-sm font-medium text-slate-300">
                        traders purchased
                      </span>
                    </div>
                  </div>
                </div>

                {/* Stats section - spans 7 columns on desktop */}
                <div className="md:col-span-7 grid grid-cols-3 gap-4">
                  <div className="group p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 backdrop-blur-sm hover:bg-slate-800/80 transition-all duration-300 hover:shadow-lg hover:shadow-indigo-900/10 transform hover:-translate-y-1">
                    <div className="flex items-center">
                      <TrendingUp className="h-4 w-4 text-indigo-400 mr-2" />
                      <span className="text-xs uppercase font-semibold text-slate-300 group-hover:text-indigo-300 transition-colors">
                        This Month
                      </span>
                    </div>
                    <div className="mt-2 bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent text-3xl font-bold">
                      <CountUpAnimation
                        start={
                          purchaseStats ? purchaseStats.thisMonth - 5 : 737
                        }
                        end={purchaseStats ? purchaseStats.thisMonth : 742}
                        duration={3}
                      />
                    </div>
                  </div>

                  <div className="group p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 backdrop-blur-sm hover:bg-slate-800/80 transition-all duration-300 hover:shadow-lg hover:shadow-indigo-900/10 transform hover:-translate-y-1">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-indigo-400 mr-2" />
                      <span className="text-xs uppercase font-semibold text-slate-300 group-hover:text-indigo-300 transition-colors">
                        This Week
                      </span>
                    </div>
                    <div className="mt-2 bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent text-3xl font-bold">
                      <CountUpAnimation
                        start={purchaseStats ? purchaseStats.thisWeek - 5 : 182}
                        end={purchaseStats ? purchaseStats.thisWeek : 187}
                        duration={3}
                      />
                    </div>
                  </div>

                  <div className="group p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 backdrop-blur-sm hover:bg-slate-800/80 transition-all duration-300 hover:shadow-lg hover:shadow-indigo-900/10 transform hover:-translate-y-1">
                    <div className="flex items-center">
                      <Award className="h-4 w-4 text-indigo-400 mr-2" />
                      <span className="text-xs uppercase font-semibold text-slate-300 group-hover:text-indigo-300 transition-colors">
                        Today
                      </span>
                    </div>
                    <div className="mt-2 bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent text-3xl font-bold">
                      <CountUpAnimation
                        start={purchaseStats ? purchaseStats.today - 3 : 31}
                        end={purchaseStats ? purchaseStats.today : 34}
                        duration={3}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Enhanced live indicator with pulse effect */}
              <div className="absolute top-5 right-5 flex items-center">
                <div className="relative mr-2">
                  <div className="absolute -inset-1 bg-indigo-500/30 rounded-full blur-sm animate-ping opacity-75"></div>
                  <div className="absolute -inset-1 bg-indigo-500/20 rounded-full blur-md"></div>
                  <div className="h-3 w-3 rounded-full bg-indigo-500 relative animate-pulse"></div>
                </div>
                <span className="text-xs font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent uppercase tracking-wider">
                  Live
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lucky Offer Form Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/10 dark:to-pink-900/10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              🎉 Lucky Offer Alert!
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Use codes from Tradefluenza when buying any prop firm and get
              entered into our lucky draw for exclusive rewards!
            </p>
          </div>

          <LuckyOfferForm />
        </div>
      </section>

      <section className="py-20 px-4 bg-gradient-to-br from-background to-accent/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 gradient-text inline-block">
              Compare Account Sizes
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Select the account size you're interested in to see detailed
              comparisons of all available prop firms offering that capital
              level
            </p>
          </div>

          <div className="p-10 shadow-xl bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-xl border border-gray-700">
            <div className="flex flex-col items-center justify-center">
              <h3 className="text-2xl font-bold gradient-text mb-10">
                Select Account Size
              </h3>

              {isSizesLoading ? (
                <div className="flex justify-center gap-5 w-full max-w-4xl flex-wrap">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Skeleton key={i} className="w-28 h-20 rounded-xl" />
                  ))}
                </div>
              ) : (
                <div className="flex justify-center gap-5 w-full max-w-4xl flex-wrap">
                  {accountSizes &&
                    Array.isArray(accountSizes) &&
                    accountSizes.map((size: number) => {
                      // Determine if this is most popular (for example, 25000)
                      const isPopular = size === 25000;

                      return (
                        <Link
                          key={size}
                          href={`/prop-firms?accountSize=${size}`}
                        >
                          <div
                            className={`py-6 px-2 rounded-xl cursor-pointer transition-all w-28 h-24 flex flex-col items-center justify-center relative shadow-md hover:shadow-lg hover:scale-105 duration-300
                          ${
                            isPopular
                              ? "bg-gradient-to-br from-purple-600 via-fuchsia-500 to-blue-600 text-white font-semibold"
                              : "bg-gradient-to-br from-slate-100 to-zinc-100 text-gray-800 hover:bg-gradient-to-br hover:from-slate-50 hover:to-zinc-50"
                          }`}
                          >
                            {isPopular && (
                              <div className="absolute -top-3 left-0 right-0 flex justify-center">
                                <span className="text-xs font-bold px-3 py-1 bg-primary text-white rounded-full shadow-lg">
                                  POPULAR
                                </span>
                              </div>
                            )}
                            <span className="text-2xl font-bold">
                              ${size >= 1000 ? size / 1000 + "K" : size}
                            </span>
                            <span className="text-xs mt-1 opacity-80">
                              Account Size
                            </span>
                          </div>
                        </Link>
                      );
                    })}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Broker Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-indigo-50 via-violet-50 to-purple-50 dark:from-indigo-950/30 dark:via-violet-950/30 dark:to-purple-950/30">
        <div className="max-w-7xl mx-auto">
          {/* Tab buttons for switching between prop firms and brokers */}
          <div className="flex justify-center mb-10">
            <div className="inline-flex bg-white/5 backdrop-blur-sm shadow-lg rounded-xl overflow-hidden p-1 border border-gray-200 dark:border-gray-800">
              <button
                onClick={() => setActiveTab("propFirms")}
                className={`px-6 py-2 text-sm font-medium rounded-lg transition-all ${
                  activeTab === "propFirms"
                    ? "bg-gradient-to-r from-primary to-indigo-600 text-white shadow-md"
                    : "text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400"
                }`}
              >
                Prop Firms
              </button>
              <button
                onClick={() => setActiveTab("brokers")}
                className={`px-6 py-2 text-sm font-medium rounded-lg transition-all ${
                  activeTab === "brokers"
                    ? "bg-gradient-to-r from-primary to-indigo-600 text-white shadow-md"
                    : "text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400"
                }`}
              >
                Brokers
              </button>
            </div>
          </div>

          <div className="text-center mb-10">
            <h2 className="text-4xl font-bold mb-4 gradient-text inline-block">
              {activeTab === "propFirms"
                ? "Featured Prop Firms"
                : "Featured Brokers"}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              {activeTab === "propFirms"
                ? "Discover top-rated proprietary trading firms with competitive profit splits, favorable terms, and trusted reputation"
                : "Explore regulated brokers with competitive spreads, advanced trading platforms and reliable customer support"}
            </p>
          </div>

          {/* Featured cards grid for prop firms */}
          {activeTab === "propFirms" && (
            <div className="bg-gradient-to-br from-white/80 to-indigo-50/30 dark:from-gray-900/80 dark:to-indigo-950/20 backdrop-blur-sm rounded-2xl border border-gray-200/50 dark:border-gray-800/50 p-8 shadow-md">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">
                  Featured Prop Firms
                </h3>
                <div className="flex gap-3">
                  <Badge className="bg-gradient-to-r from-amber-400 to-amber-600 text-white px-3 py-1 rounded-full shadow-sm">
                    🔥 Top Rated
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                {isPropFirmsLoading
                  ? // Loading skeletons for prop firms
                    Array(3)
                      .fill(0)
                      .map((_, index) => (
                        <div
                          key={index}
                          className="bg-white dark:bg-gray-800/80 p-6 rounded-xl shadow-md border border-gray-100 dark:border-gray-700/50"
                        >
                          <div className="flex justify-between items-start mb-4">
                            <Skeleton className="h-8 w-32" />
                            <Skeleton className="h-6 w-16 rounded-full" />
                          </div>
                          <Skeleton className="h-4 w-full mb-2" />
                          <Skeleton className="h-4 w-3/4 mb-6" />
                          <div className="space-y-3">
                            <Skeleton className="h-5 w-full" />
                            <Skeleton className="h-5 w-full" />
                            <Skeleton className="h-5 w-2/3" />
                          </div>
                          <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700/40">
                            <div className="flex gap-3">
                              <Skeleton className="h-10 w-full rounded-lg" />
                              <Skeleton className="h-10 w-full rounded-lg" />
                            </div>
                          </div>
                        </div>
                      ))
                  : // Actual prop firm cards
                    propFirms?.slice(0, 3).map((firm, index) => (
                      <div
                        key={firm.id}
                        className={`relative overflow-hidden group ${
                          index === 0 ? "lg:col-span-1 lg:row-span-1" : ""
                        }`}
                      >
                        {/* Special labels based on position */}
                        {index === 0 && (
                          <div className="absolute -top-1 -left-1 z-20">
                            <div className="relative">
                              <div className="absolute inset-0 rounded-br-xl bg-gradient-to-r from-rose-500 to-pink-600 blur-sm"></div>
                              <div className="relative bg-gradient-to-r from-rose-500 to-pink-600 text-white px-5 py-2 rounded-br-xl shadow-lg font-semibold flex items-center">
                                <Crown className="h-4 w-4 mr-1.5" /> Most
                                Selling
                              </div>
                            </div>
                          </div>
                        )}

                        {index === 1 && (
                          <div className="absolute -top-1 -left-1 z-20">
                            <div className="relative">
                              <div className="absolute inset-0 rounded-br-xl bg-gradient-to-r from-blue-500 to-indigo-600 blur-sm"></div>
                              <div className="relative bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-5 py-2 rounded-br-xl shadow-lg font-semibold flex items-center">
                                <Award className="h-4 w-4 mr-1.5" /> Popular
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Card highlight border effect */}
                        <div className="absolute inset-0 rounded-xl border-2 border-transparent group-hover:border-indigo-500/20 dark:group-hover:border-indigo-400/20 transition-colors duration-300 pointer-events-none"></div>

                        {/* Animated glow effect on hover */}
                        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-purple-500/20 to-indigo-500/20 opacity-0 group-hover:opacity-100 -z-10 blur-xl transition-opacity duration-700"></div>

                        {/* Tags */}
                        {firm.tags && firm.tags.length > 0 && (
                          <div className="absolute top-12 right-4 flex gap-2 flex-wrap z-10">
                            {firm.tags.map((tag: string, index: number) => (
                              <Badge
                                key={index}
                                className="bg-indigo-500/90 hover:bg-indigo-600 text-white backdrop-blur-md shadow-sm"
                              >
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}

                        {/* Discount badge if available */}
                        {firm.discountPercentage > 0 && firm.discountCode && (
                          <div className="absolute bottom-4 right-4 z-10">
                            <div className="relative">
                              {/* Animated background for the badge */}
                              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 animate-background-pulse blur-sm"></div>

                              <div
                                className="relative bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-3 py-1.5 rounded-full flex items-center shadow-lg cursor-pointer"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  copyToClipboard(firm.id, firm.discountCode);
                                }}
                              >
                                <span className="text-xs font-bold mr-1.5">
                                  {firm.discountPercentage}% OFF
                                </span>
                                <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded mr-1.5">
                                  {firm.discountCode}
                                </span>
                                {copiedFirmId === firm.id ? (
                                  <CheckCircle2 className="h-3.5 w-3.5 text-green-300" />
                                ) : (
                                  <Copy className="h-3.5 w-3.5 cursor-pointer opacity-70 hover:opacity-100" />
                                )}
                              </div>
                            </div>
                          </div>
                        )}

                        <div
                          className={`h-full flex flex-col bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-all duration-300 group-hover:shadow-xl group-hover:translate-y-[-3px] border ${
                            index === 0
                              ? "border-rose-200 dark:border-rose-900/30"
                              : index === 1
                              ? "border-blue-200 dark:border-blue-900/30"
                              : "border-gray-100 dark:border-gray-700/50"
                          }`}
                        >
                          <div className="p-6">
                            <a
                              href={firm.websiteUrl || "#"}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-block relative z-20"
                            >
                              <h3 className="text-xl font-bold text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                                {firm.name}
                              </h3>
                            </a>
                            <div className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-5">
                              Established {firm.established}
                            </div>

                            <div className="space-y-4">
                              {/* Program Type */}
                              <div className="flex items-start text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400 pt-0.5">
                                  Program Type:
                                </div>
                                <div className="flex gap-1.5 flex-wrap">
                                  {firm.pricing && firm.pricing.length > 0 ? (
                                    // Get unique program types from pricing array
                                    Array.from(
                                      new Set(
                                        firm.pricing.map(
                                          (price: any) => price.programType
                                        )
                                      ) as Set<string>
                                    ).map((type, i: number) => (
                                      <Badge
                                        key={i}
                                        variant="outline"
                                        className={`
                                      ${
                                        String(type) === "Express"
                                          ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800/30"
                                          : ""
                                      }
                                      ${
                                        String(type) === "Rapid"
                                          ? "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800/30"
                                          : ""
                                      }
                                      ${
                                        String(type) === "One-Phase"
                                          ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-800/30"
                                          : ""
                                      }
                                      ${
                                        String(type) === "Two-Phase"
                                          ? "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800/30"
                                          : ""
                                      }
                                      ${
                                        ![
                                          "Express",
                                          "Rapid",
                                          "One-Phase",
                                          "Two-Phase",
                                        ].includes(String(type))
                                          ? "bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700"
                                          : ""
                                      }
                                    `}
                                      >
                                        {String(type)}
                                      </Badge>
                                    ))
                                  ) : firm.programType ? (
                                    <Badge
                                      variant="outline"
                                      className={`
                                    ${
                                      firm.programType === "Express"
                                        ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800/30"
                                        : ""
                                    }
                                    ${
                                      firm.programType === "Rapid"
                                        ? "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800/30"
                                        : ""
                                    }
                                    ${
                                      firm.programType === "One-Phase"
                                        ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-800/30"
                                        : ""
                                    }
                                    ${
                                      firm.programType === "Two-Phase"
                                        ? "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800/30"
                                        : ""
                                    }
                                    ${
                                      ![
                                        "Express",
                                        "Rapid",
                                        "One-Phase",
                                        "Two-Phase",
                                      ].includes(firm.programType)
                                        ? "bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700"
                                        : ""
                                    }
                                  `}
                                    >
                                      {firm.programType}
                                    </Badge>
                                  ) : firm.programTypes &&
                                    firm.programTypes.length > 0 ? (
                                    firm.programTypes.map(
                                      (type: string, i: number) => (
                                        <Badge
                                          key={i}
                                          variant="outline"
                                          className="bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700"
                                        >
                                          {type}
                                        </Badge>
                                      )
                                    )
                                  ) : (
                                    <span className="text-gray-500 dark:text-gray-400">
                                      Various
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* Account Sizes */}
                              <div className="flex items-center text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400">
                                  Account Sizes:
                                </div>
                                <div className="font-medium text-gray-800 dark:text-gray-200">
                                  {firm.accountSizes &&
                                  firm.accountSizes.length > 0 ? (
                                    <div className="flex flex-wrap gap-1.5">
                                      {firm.accountSizes.map(
                                        (size: number, i: number) => (
                                          <Badge
                                            key={i}
                                            variant="outline"
                                            className="bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-800/30"
                                          >
                                            $
                                            {size >= 1000
                                              ? size / 1000 + "K"
                                              : size}
                                          </Badge>
                                        )
                                      )}
                                    </div>
                                  ) : firm.minAccountSize &&
                                    firm.maxAccountSize ? (
                                    <>
                                      $
                                      {firm.minAccountSize >= 1000
                                        ? firm.minAccountSize / 1000 + "K"
                                        : firm.minAccountSize}
                                      {" - "}$
                                      {firm.maxAccountSize >= 1000
                                        ? firm.maxAccountSize / 1000 + "K"
                                        : firm.maxAccountSize}
                                    </>
                                  ) : (
                                    "$5K - $300K"
                                  )}
                                </div>
                              </div>

                              {/* Profit Split */}
                              <div className="flex items-center text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400">
                                  Profit Split:
                                </div>
                                <div className="font-medium text-gray-800 dark:text-gray-200">
                                  {firm.profitSplit}%
                                </div>
                              </div>

                              {/* Rating */}
                              <div className="flex items-center text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400">
                                  Rating:
                                </div>
                                <div className="flex items-center">
                                  <div className="flex">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                      <FiStar
                                        key={star}
                                        className={cn(
                                          "h-4 w-4",
                                          star <= (firm.rating || 0)
                                            ? "text-amber-500 fill-amber-500"
                                            : "text-gray-300 dark:text-gray-600"
                                        )}
                                      />
                                    ))}
                                  </div>
                                  <span className="text-sm ml-2 text-gray-500 dark:text-gray-400">
                                    ({firm.reviewCount || 0} reviews)
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="mt-auto p-6 pt-4 border-t border-gray-100 dark:border-gray-700/40">
                            <div className="flex items-center">
                              <Link
                                href={`/prop-firms/${firm.id}`}
                                className="w-full"
                              >
                                <Button
                                  className={`w-full shadow-md ${
                                    index === 0
                                      ? "bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700"
                                      : index === 1
                                      ? "bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700"
                                      : "bg-gradient-to-r from-primary to-indigo-600 hover:from-primary/90 hover:to-indigo-600/90"
                                  } text-white`}
                                >
                                  View Details{" "}
                                  <ArrowRight className="ml-1.5 h-4 w-4" />
                                </Button>
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
              </div>
            </div>
          )}

          {/* Featured cards grid for brokers */}
          {activeTab === "brokers" && (
            <div className="bg-gradient-to-br from-white/80 to-teal-50/30 dark:from-gray-900/80 dark:to-teal-950/20 backdrop-blur-sm rounded-2xl border border-gray-200/50 dark:border-gray-800/50 p-8 shadow-md">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">
                  Featured Brokers
                </h3>
                <div className="flex gap-3">
                  <Badge className="bg-gradient-to-r from-teal-400 to-emerald-600 text-white px-3 py-1 rounded-full shadow-sm">
                    ⭐ Top Recommended
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                {isBrokersLoading
                  ? // Loading skeletons for brokers
                    Array(3)
                      .fill(0)
                      .map((_, index) => (
                        <div
                          key={index}
                          className="bg-white dark:bg-gray-800/80 p-6 rounded-xl shadow-md border border-gray-100 dark:border-gray-700/50"
                        >
                          <div className="flex justify-between items-start mb-4">
                            <Skeleton className="h-8 w-32" />
                            <Skeleton className="h-6 w-16 rounded-full" />
                          </div>
                          <Skeleton className="h-4 w-full mb-2" />
                          <Skeleton className="h-4 w-3/4 mb-6" />
                          <div className="space-y-3">
                            <Skeleton className="h-5 w-full" />
                            <Skeleton className="h-5 w-full" />
                            <Skeleton className="h-5 w-2/3" />
                          </div>
                          <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700/40">
                            <div className="flex gap-3">
                              <Skeleton className="h-10 w-full rounded-lg" />
                              <Skeleton className="h-10 w-full rounded-lg" />
                            </div>
                          </div>
                        </div>
                      ))
                  : // Actual broker cards
                    brokers?.slice(0, 3).map((broker, index) => (
                      <div
                        key={broker.id}
                        className={`relative overflow-hidden group ${
                          index === 0 ? "lg:col-span-1 lg:row-span-1" : ""
                        }`}
                      >
                        {/* Special labels based on position */}
                        {index === 0 && (
                          <div className="absolute -top-1 -left-1 z-20">
                            <div className="relative">
                              <div className="absolute inset-0 rounded-br-xl bg-gradient-to-r from-teal-500 to-emerald-600 blur-sm"></div>
                              <div className="relative bg-gradient-to-r from-teal-500 to-emerald-600 text-white px-5 py-2 rounded-br-xl shadow-lg font-semibold flex items-center">
                                <Trophy className="h-4 w-4 mr-1.5" /> Top Rated
                              </div>
                            </div>
                          </div>
                        )}

                        {index === 1 && (
                          <div className="absolute -top-1 -left-1 z-20">
                            <div className="relative">
                              <div className="absolute inset-0 rounded-br-xl bg-gradient-to-r from-cyan-500 to-teal-600 blur-sm"></div>
                              <div className="relative bg-gradient-to-r from-cyan-500 to-teal-600 text-white px-5 py-2 rounded-br-xl shadow-lg font-semibold flex items-center">
                                <Verified className="h-4 w-4 mr-1.5" /> Most
                                Popular
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Card highlight border effect */}
                        <div className="absolute inset-0 rounded-xl border-2 border-transparent group-hover:border-teal-500/20 dark:group-hover:border-teal-400/20 transition-colors duration-300 pointer-events-none"></div>

                        {/* Animated glow effect on hover */}
                        <div className="absolute inset-0 bg-gradient-to-r from-teal-500/20 via-emerald-500/20 to-cyan-500/20 opacity-0 group-hover:opacity-100 -z-10 blur-xl transition-opacity duration-700"></div>

                        {/* Tags */}
                        {broker.tags && broker.tags.length > 0 && (
                          <div className="absolute top-12 right-4 flex gap-2 flex-wrap z-10">
                            {broker.tags.map((tag: string, index: number) => (
                              <Badge
                                key={index}
                                className="bg-teal-500/90 hover:bg-teal-600 text-white backdrop-blur-md shadow-sm"
                              >
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}

                        <div
                          className={`h-full flex flex-col bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-all duration-300 group-hover:shadow-xl group-hover:translate-y-[-3px] border ${
                            index === 0
                              ? "border-teal-200 dark:border-teal-900/30"
                              : index === 1
                              ? "border-cyan-200 dark:border-cyan-900/30"
                              : "border-gray-100 dark:border-gray-700/50"
                          }`}
                        >
                          <div className="p-6">
                            <Link
                              href={`/brokers/${broker.id}`}
                              className="inline-block relative z-20"
                            >
                              <h3 className="text-xl font-bold text-gray-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                                {broker.name}
                              </h3>
                            </Link>
                            <div className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-5">
                              {broker.country}
                            </div>

                            <div className="space-y-4">
                              {/* Years Active */}
                              <div className="flex items-center text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400">
                                  Years Active:
                                </div>
                                <div className="font-medium text-gray-800 dark:text-gray-200">
                                  {broker.yearsActive}
                                </div>
                              </div>

                              {/* Environment */}
                              <div className="flex items-center text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400">
                                  Environment:
                                </div>
                                <div className="font-medium text-gray-800 dark:text-gray-200">
                                  {broker.environment}
                                </div>
                              </div>

                              {/* Regulators */}
                              <div className="flex items-center text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400">
                                  Regulators:
                                </div>
                                <div className="font-medium text-gray-800 dark:text-gray-200">
                                  {broker.regulators}
                                </div>
                              </div>

                              {/* Score */}
                              <div className="flex items-center text-sm">
                                <div className="w-32 text-gray-600 dark:text-gray-400">
                                  Score:
                                </div>
                                <div className="flex items-center">
                                  <div className="flex">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                      <FiStar
                                        key={star}
                                        className={cn(
                                          "h-4 w-4",
                                          star <= (broker.score || 0)
                                            ? "text-amber-500 fill-amber-500"
                                            : "text-gray-300 dark:text-gray-600"
                                        )}
                                      />
                                    ))}
                                  </div>
                                  <span className="text-sm ml-2 text-gray-500 dark:text-gray-400">
                                    ({broker.reviewCount || 0} reviews)
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="mt-auto p-6 pt-4 border-t border-gray-100 dark:border-gray-700/40">
                            <div className="flex items-center gap-3">
                              <Link
                                href={`/brokers/${broker.id}`}
                                className="flex-1"
                              >
                                <Button
                                  variant="outline"
                                  className="w-full border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700"
                                >
                                  Details
                                </Button>
                              </Link>
                              <a
                                href={broker.websiteUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex-1"
                              >
                                <Button
                                  className={`w-full shadow-md ${
                                    index === 0
                                      ? "bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700"
                                      : index === 1
                                      ? "bg-gradient-to-r from-cyan-500 to-teal-600 hover:from-cyan-600 hover:to-teal-700"
                                      : "bg-gradient-to-r from-primary to-indigo-600 hover:from-primary/90 hover:to-indigo-600/90"
                                  } text-white`}
                                >
                                  Sign Up{" "}
                                  <FiExternalLink className="ml-1.5 h-4 w-4" />
                                </Button>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
              </div>
            </div>
          )}

          <div className="mt-10 text-center">
            <div className="relative">
              {/* Decorative elements */}
              <div className="absolute left-1/4 top-1/2 -translate-y-1/2 w-24 h-24 rounded-full bg-indigo-500/10 blur-2xl opacity-70 -z-10"></div>
              <div className="absolute right-1/4 top-1/2 -translate-y-1/2 w-32 h-32 rounded-full bg-violet-500/10 blur-2xl opacity-70 -z-10"></div>

              <Link
                href={activeTab === "propFirms" ? "/prop-firms" : "/brokers"}
              >
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-primary/50 hover:border-primary text-gray-800 dark:text-gray-200 font-medium px-10 py-6 rounded-xl transition-all hover:scale-105 shadow-md bg-white/70 dark:bg-gray-900/70 backdrop-blur-sm"
                >
                  View All{" "}
                  {activeTab === "propFirms" ? "Prop Firms" : "Brokers"}{" "}
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Upcoming Events Showcase */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="max-w-7xl mx-auto relative">
          {/* Decorative elements */}
          <div className="absolute -left-10 top-20 w-32 h-32 rounded-full bg-primary/20 blur-3xl opacity-50"></div>
          <div className="absolute right-10 bottom-10 w-48 h-48 rounded-full bg-accent/20 blur-3xl opacity-50"></div>

          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold gradient-text mb-4">
              Upcoming Trading Events
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Connect with industry experts, enhance your trading skills, and
              stay ahead of market trends with our exclusive events
            </p>
          </div>

          {/* Events grid with data fetching */}
          <EventsShowcase />

          <div className="mt-12 text-center">
            <Link href="/events">
              <Button className="gradient-primary border-0 font-medium text-base px-8 py-3 rounded-xl transition-all hover:scale-105 shadow-lg">
                View All Events <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section removed as requested */}
    </>
  );
}