import { useState, useMemo } from 'react';
import { useRoute, Link } from 'wouter';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { PropFirm, Review } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Helmet } from "react-helmet-async";
import { 
  FiArrowLeft, 
  FiExternalLink, 
  FiStar, 
  FiCheck, 
  FiX, 
  FiCalendar,
  FiDollarSign, 
  FiClock, 
  FiTarget, 
  FiArrowDown, 
  FiPercent,
  FiGlobe,
  FiBarChart2,
  FiInfo,
  FiPlay,
  FiShield,
  FiUsers
} from 'react-icons/fi';
import { 
  Trophy, 
  ShieldCheck, 
  Building,
  Calendar,
  Clock,
  Flag,
  Scale,
  AlertTriangle,
  Briefcase,
  BarChart3,
  PieChart,
  Percent,
  ListChecks,
  BadgeCheck
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { trackPageView } from '@/lib/analytics';
import ReviewForm from '@/components/prop-firms/review-form';

interface ExternalReview {
  id: number;
  source: string;
  sourceUrl: string;
  rating: number;
  title: string;
  content: string;
  author: string;
  datePosted: string;
  logoUrl?: string;
}

export default function PropFirmDetail() {
  const [, params] = useRoute('/prop-firms/:id');
  const propFirmId = parseInt(params?.id || '0');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Track page view
  trackPageView(`/prop-firms/${propFirmId}`);
    const canonicalUrl = `https://tradefluenza.com/prop-firms/${propFirmId}`;
  // Fetch prop firm data
  const {
    data: propFirm,
    isLoading,
    isError,
    error
  } = useQuery<PropFirm>({
    queryKey: [`/api/prop-firms/${propFirmId}`],
    queryFn: getQueryFn({ on401: "throw" }),
    retry: 1
  });
  
  // Fetch reviews
  const {
    data: reviews,
    isLoading: isReviewsLoading
  } = useQuery<Review[]>({
    queryKey: [`/api/prop-firms/${propFirmId}/reviews`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!propFirmId
  });
  
  // Fetch average rating
  const {
    data: ratingData
  } = useQuery<{ propFirmId: number, averageRating: number }>({
    queryKey: [`/api/prop-firms/${propFirmId}/rating`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!propFirmId
  });

  // Generate pricing table - moved here to avoid conditional hook calling
  const generatePricingTable = () => {
    if (!propFirm?.accountSizes) return [];
    
    return propFirm.accountSizes.map(accountSize => {
      const pricingData = propFirm.pricing?.find(p => p.accountSize === accountSize);
      
      if (pricingData) {
        return {
          accountSize: accountSize,
          price: pricingData.price,
          programType: pricingData.programType || propFirm.programType
        };
      } else {
        let basePrice;
        if (accountSize <= 5000) basePrice = 39;
        else if (accountSize <= 10000) basePrice = 79;
        else if (accountSize <= 25000) basePrice = 149;
        else if (accountSize <= 50000) basePrice = 249;
        else if (accountSize <= 100000) basePrice = 399;
        else if (accountSize <= 200000) basePrice = 599;
        else basePrice = Math.round(accountSize * 0.004);
        
        return {
          accountSize: accountSize,
          price: basePrice,
          programType: propFirm.programType
        };
      }
    }).sort((a, b) => a.accountSize - b.accountSize);
  };

  const pricingTable = generatePricingTable();
    
  // Helper to format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  // Helper to format account size for display
  const formatAccountSize = (size: number) => {
    return size >= 1000 ? `${size/1000}K` : size;
  };
  
  // Show loading state
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          <Link href="/prop-firms">
            <Button variant="ghost" className="mb-6">
              <FiArrowLeft className="mr-2 h-4 w-4" /> Back to Prop Firms
            </Button>
          </Link>
        
          <div className="flex flex-col md:flex-row gap-8">
            {/* Left side - Main content */}
            <div className="flex-1">
              <Skeleton className="h-12 w-2/3 mb-4" />
              <Skeleton className="h-6 w-1/2 mb-8" />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Skeleton className="h-32 rounded-xl" />
                <Skeleton className="h-32 rounded-xl" />
                <Skeleton className="h-32 rounded-xl" />
              </div>
              
              <Skeleton className="h-8 w-40 mb-4" />
              <Skeleton className="h-64 rounded-xl mb-8" />
            </div>
            
            {/* Right side - Sidebar */}
            <div className="w-full md:w-80 lg:w-96">
              <Skeleton className="h-96 rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Show error state
  if (isError || !propFirm) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          <Link href="/prop-firms">
            <Button variant="ghost" className="mb-6">
              <FiArrowLeft className="mr-2 h-4 w-4" /> Back to Prop Firms
            </Button>
          </Link>
          
          <Card className="text-center py-12">
            <CardContent>
              <div className="flex flex-col items-center justify-center">
                <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
                <h2 className="text-2xl font-bold mb-2">Prop Firm Not Found</h2>
                <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
                  We couldn't find the prop firm you're looking for. It may have been removed or there might be an issue with the connection.
                </p>
                <Link href="/prop-firms">
                  <Button>
                    <FiArrowLeft className="mr-2 h-4 w-4" /> Browse All Prop Firms
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <link rel="canonical" href={canonicalUrl} />
      </Helmet>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Back navigation */}
          <Link href="/prop-firms">
            <Button variant="ghost" className="mb-6">
              <FiArrowLeft className="mr-2 h-4 w-4" /> Back to Prop Firms
            </Button>
          </Link>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main content column */}
            <div className="flex-1">
              {/* Header section */}
              <div className="mb-8">
                <div className="flex items-start justify-between flex-wrap gap-4">
                  <div>
                    <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 inline-block text-transparent bg-clip-text mb-1">
                      {propFirm.name}
                    </h1>
                    <p className="text-gray-600 dark:text-gray-400">
                      Established {propFirm.established} •{" "}
                      {propFirm.headquarters}
                    </p>
                  </div>

                  <div className="flex items-center space-x-2">
                    {propFirm.tags &&
                      propFirm.tags.map((tag, index) => (
                        <Badge
                          key={index}
                          className="bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-600 hover:to-violet-600 text-white"
                        >
                          {tag}
                        </Badge>
                      ))}
                  </div>
                </div>

                {/* Rating & Logo row */}
                <div className="flex flex-col sm:flex-row gap-6 mt-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-20 h-20 rounded-lg flex items-center justify-center overflow-hidden bg-white shadow-md">
                      {propFirm.logoUrl ? (
                        <img
                          src={propFirm.logoUrl}
                          alt={`${propFirm.name} logo`}
                          className="w-full h-full object-contain p-2"
                        />
                      ) : (
                        <Building className="h-10 w-10 text-gray-400" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center mb-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <FiStar
                            key={star}
                            className={cn(
                              "h-5 w-5",
                              star <= (ratingData?.averageRating || 0)
                                ? "text-amber-500 fill-amber-500"
                                : "text-gray-300 dark:text-gray-600"
                            )}
                          />
                        ))}
                        <span className="ml-2 text-gray-600 dark:text-gray-400">
                          {ratingData?.averageRating
                            ? Number(ratingData.averageRating).toFixed(1)
                            : "No ratings"}{" "}
                          ({reviews?.length || 0} reviews)
                        </span>
                      </div>

                      <div className="flex items-center space-x-2 mt-2">
                        <a
                          href={propFirm.websiteUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 flex items-center"
                        >
                          <FiGlobe className="mr-1 h-4 w-4" /> Visit Website
                        </a>
                      </div>
                    </div>
                  </div>

                  {/* CTA Button for mobile view */}
                  <div className="sm:hidden flex-1 flex justify-end">
                    <a
                      href={propFirm.websiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full"
                    >
                      <Button
                        size="lg"
                        className="w-full font-semibold text-base bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white"
                      >
                        Buy Now <FiExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </a>
                  </div>
                </div>
              </div>

              {/* Key Statistics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/40 dark:to-purple-950/40 border-none shadow-md">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                          Profit Split
                        </p>
                        <h3 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">
                          {propFirm.profitSplit}%
                        </h3>
                      </div>
                      <div className="h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center">
                        <Percent className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-violet-50 to-fuchsia-50 dark:from-violet-950/40 dark:to-fuchsia-950/40 border-none shadow-md">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                          Payout Frequency
                        </p>
                        <h3 className="text-2xl font-bold text-violet-600 dark:text-violet-400">
                          {propFirm.payoutFrequency}
                        </h3>
                      </div>
                      <div className="h-10 w-10 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-violet-600 dark:text-violet-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/40 dark:to-indigo-950/40 border-none shadow-md">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                          Program Type
                        </p>
                        <h3 className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                          {propFirm.programType}
                        </h3>
                      </div>
                      <div className="h-10 w-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                        <BarChart3 className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Tabs for different sections */}
              <Tabs
                defaultValue="overview"
                className="mb-8"
                onValueChange={setActiveTab}
              >
                <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-8 h-auto">
                  <TabsTrigger
                    value="overview"
                    className="text-xs sm:text-sm p-2 sm:p-3"
                  >
                    Overview
                  </TabsTrigger>
                  <TabsTrigger
                    value="video"
                    className="text-xs sm:text-sm p-2 sm:p-3"
                  >
                    Know Propfirm
                  </TabsTrigger>
                  <TabsTrigger
                    value="pricing"
                    className="text-xs sm:text-sm p-2 sm:p-3"
                  >
                    Pricing
                  </TabsTrigger>
                  <TabsTrigger
                    value="reviews"
                    className="text-xs sm:text-sm p-2 sm:p-3"
                  >
                    Reviews
                  </TabsTrigger>
                </TabsList>

                {/* Overview Tab */}
                <TabsContent value="overview" className="space-y-8">
                  {/* Description */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FiInfo className="mr-2 h-5 w-5 text-indigo-600" />
                        About {propFirm.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">
                        {propFirm.description}
                      </p>
                    </CardContent>
                  </Card>

                  {/* Trading Parameters */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <BarChart3 className="mr-2 h-5 w-5 text-indigo-600" />
                        Trading Parameters
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-10">
                        {/* Profit Target */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center">
                            <FiTarget className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Profit Target
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.profitTargets.map((target, i) => (
                                <span key={i}>
                                  {target}%
                                  {i < propFirm.profitTargets.length - 1
                                    ? ", "
                                    : ""}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Daily Loss Limit */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-rose-100 dark:bg-rose-900/30 flex items-center justify-center">
                            <FiArrowDown className="h-4 w-4 text-rose-600 dark:text-rose-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Daily Loss Limit
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.dailyLoss}%
                            </div>
                          </div>
                        </div>

                        {/* Max Loss Limit */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                            <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Max Loss Limit
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.maxLoss}%
                            </div>
                          </div>
                        </div>

                        {/* Minimum Trading Days */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                            <Calendar className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Min Trading Days
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.minimumTradingDays} days
                            </div>
                          </div>
                        </div>

                        {/* Time to Funded */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                            <Clock className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Time to Funded
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.timeToFunded}
                            </div>
                          </div>
                        </div>

                        {/* Scaling Plan */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                            <PieChart className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Scaling Plan
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.scaling.available ? (
                                <div className="flex items-center">
                                  <span className="mr-1">Available</span>
                                  <Badge
                                    variant="outline"
                                    className="font-normal"
                                  >
                                    {propFirm.scaling.terms}
                                  </Badge>
                                </div>
                              ) : (
                                "Not Available"
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Trading Platforms */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center">
                            <Briefcase className="h-4 w-4 text-teal-600 dark:text-teal-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Trading Platforms
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.tradingPlatforms.join(", ")}
                            </div>
                          </div>
                        </div>

                        {/* Instruments Allowed */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-fuchsia-100 dark:bg-fuchsia-900/30 flex items-center justify-center">
                            <ListChecks className="h-4 w-4 text-fuchsia-600 dark:text-fuchsia-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Instruments Allowed
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.instrumentsAllowed.join(", ")}
                            </div>
                          </div>
                        </div>

                        {/* Refund Policy */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                            <Scale className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Refund Policy
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.refundPolicy}
                            </div>
                          </div>
                        </div>

                        {/* Loyalty Program */}
                        <div className="flex items-start">
                          <div className="mr-3 mt-1 h-8 w-8 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center">
                            <BadgeCheck className="h-4 w-4 text-pink-600 dark:text-pink-400" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                              Loyalty Program
                            </h4>
                            <div className="font-semibold text-gray-900 dark:text-gray-100">
                              {propFirm.loyaltyProgram
                                ? "Available"
                                : "Not Available"}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Pros & Cons */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border border-emerald-100 dark:border-emerald-900/20">
                      <CardHeader>
                        <CardTitle className="flex items-center text-emerald-700 dark:text-emerald-500">
                          <FiCheck className="mr-2 h-5 w-5" />
                          Advantages
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {propFirm.pros.map((pro, index) => (
                            <li key={index} className="flex items-start">
                              <FiCheck className="h-5 w-5 text-emerald-600 mr-2 mt-0.5" />
                              <span className="text-gray-800 dark:text-gray-200">
                                {pro}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-rose-50 to-pink-50 dark:from-rose-950/40 dark:to-pink-950/40 border border-rose-100 dark:border-rose-900/20">
                      <CardHeader>
                        <CardTitle className="flex items-center text-rose-700 dark:text-rose-500">
                          <FiX className="mr-2 h-5 w-5" />
                          Disadvantages
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {propFirm.cons.map((con, index) => (
                            <li key={index} className="flex items-start">
                              <FiX className="h-5 w-5 text-rose-600 mr-2 mt-0.5" />
                              <span className="text-gray-800 dark:text-gray-200">
                                {con}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {/* Pricing Tab */}
                <TabsContent value="pricing">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FiDollarSign className="mr-2 h-5 w-5 text-indigo-600" />
                        Account Sizes & Pricing
                      </CardTitle>
                      <CardDescription>
                        Detailed pricing for all account sizes offered by{" "}
                        {propFirm.name}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                          <thead>
                            <tr className="border-b border-gray-200 dark:border-gray-700">
                              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                                Account Size
                              </th>
                              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                                Price
                              </th>
                              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                                Program Type
                              </th>
                              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                                Profit Target
                              </th>
                              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                                Profit Split
                              </th>
                              <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900 dark:text-gray-100">
                                Action
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {pricingTable &&
                              pricingTable.map((item: any, index: number) => (
                                <tr
                                  key={index}
                                  className={cn(
                                    "border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50",
                                    index % 2 === 0
                                      ? "bg-gray-50/50 dark:bg-gray-900/20"
                                      : ""
                                  )}
                                >
                                  <td className="px-4 py-4 text-sm font-medium text-gray-800 dark:text-gray-200">
                                    ${formatAccountSize(item.accountSize)}
                                  </td>
                                  <td className="px-4 py-4 text-sm text-gray-800 dark:text-gray-200">
                                    <div className="flex items-center">
                                      <span className="font-semibold">
                                        {formatCurrency(item.price)}
                                      </span>
                                      {propFirm.discountPercentage &&
                                        propFirm.discountPercentage > 0 && (
                                          <Badge className="ml-2 bg-gradient-to-r from-indigo-500 to-violet-500 text-white text-xs font-medium">
                                            {propFirm.discountPercentage}% OFF
                                          </Badge>
                                        )}
                                    </div>
                                  </td>
                                  <td className="px-4 py-4 text-sm text-gray-800 dark:text-gray-200">
                                    <Badge
                                      variant="outline"
                                      className={cn(
                                        "bg-white/50 dark:bg-gray-900/50",
                                        {
                                          "border-indigo-400 text-indigo-600 dark:text-indigo-400":
                                            item.programType === "Express",
                                          "border-purple-400 text-purple-600 dark:text-purple-400":
                                            item.programType === "Rapid",
                                          "border-violet-400 text-violet-600 dark:text-violet-400":
                                            item.programType === "One-Phase",
                                          "border-fuchsia-400 text-fuchsia-600 dark:text-fuchsia-400":
                                            item.programType === "Two-Phase",
                                        }
                                      )}
                                    >
                                      {item.programType || propFirm.programType}
                                    </Badge>
                                  </td>
                                  <td className="px-4 py-4 text-sm text-gray-800 dark:text-gray-200">
                                    {propFirm.profitTargets.join(", ")}%
                                  </td>
                                  <td className="px-4 py-4 text-sm text-gray-800 dark:text-gray-200">
                                    {propFirm.profitSplit}%
                                  </td>
                                  <td className="px-4 py-4 text-right">
                                    <a
                                      href={propFirm.websiteUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center justify-center rounded-md text-sm font-medium h-9 px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 dark:bg-indigo-700 dark:hover:bg-indigo-600"
                                    >
                                      Buy Now
                                    </a>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>

                        {propFirm.discountPercentage &&
                          propFirm.discountPercentage > 0 &&
                          propFirm.couponCode && (
                            <div className="mt-6 p-4 bg-gradient-to-r from-indigo-50 to-violet-50 dark:from-indigo-950/30 dark:to-violet-950/30 rounded-lg border border-indigo-100 dark:border-indigo-900/20">
                              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                                <div className="flex items-center">
                                  <div className="mr-3 h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center">
                                    <Percent className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                                  </div>
                                  <div>
                                    <h4 className="font-medium text-gray-900 dark:text-gray-100">
                                      Exclusive Discount
                                    </h4>
                                    <p className="text-sm text-gray-600 dark:text-gray-400">
                                      Use code{" "}
                                      <span className="font-mono font-bold text-indigo-700 dark:text-indigo-400">
                                        {propFirm.couponCode}
                                      </span>{" "}
                                      for {propFirm.discountPercentage}% off
                                      your purchase
                                    </p>
                                  </div>
                                </div>

                                <Button
                                  variant="outline"
                                  className="border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-400"
                                  onClick={() => {
                                    // Copy to clipboard
                                    navigator.clipboard.writeText(
                                      propFirm.couponCode || ""
                                    );
                                    toast({
                                      title: "Copied to clipboard",
                                      description: `Discount code ${propFirm.couponCode} has been copied to your clipboard.`,
                                    });
                                  }}
                                >
                                  Copy Code
                                </Button>
                              </div>
                            </div>
                          )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Know The Propfirm Video Tab */}
                <TabsContent value="video">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FiPlay className="mr-2 h-5 w-5 text-indigo-600" />
                        Know The Propfirm
                      </CardTitle>
                      <CardDescription>
                        Learn more about {propFirm.name} through their official
                        video presentation
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {propFirm.videoUrl ? (
                        <div className="space-y-6">
                          {/* YouTube Video Embed */}
                          <div className="relative aspect-video rounded-lg overflow-hidden shadow-lg bg-gray-100 dark:bg-gray-800">
                            <iframe
                              src={propFirm.videoUrl
                                .replace("watch?v=", "embed/")
                                .replace("youtu.be/", "youtube.com/embed/")}
                              title={`${propFirm.name} Introduction Video`}
                              className="absolute inset-0 w-full h-full"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            />
                          </div>

                          {/* Video Description - Mobile Optimized */}
                          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 rounded-lg p-4 sm:p-6 border border-indigo-100 dark:border-indigo-900/20">
                            <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2 sm:mb-3">
                              About This Video
                            </h3>
                            <p className="text-sm sm:text-base text-gray-700 dark:text-gray-300 leading-relaxed">
                              This official video from {propFirm.name} provides
                              an in-depth look at their trading program,
                              evaluation process, and what makes them unique in
                              the prop trading industry. Learn directly from
                              their team about their approach to funding traders
                              and supporting success.
                            </p>
                          </div>

                          {/* Key Highlights - Mobile Optimized */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 sm:p-4 border border-gray-200 dark:border-gray-700">
                              <div className="flex items-center mb-2">
                                <div className="h-6 w-6 sm:h-8 sm:w-8 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                  <FiTarget className="h-3 w-3 sm:h-4 sm:w-4 text-indigo-600 dark:text-indigo-400" />
                                </div>
                                <h4 className="font-medium text-sm sm:text-base text-gray-900 dark:text-gray-100">
                                  Trading Goals
                                </h4>
                              </div>
                              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                                Learn about their profit targets and evaluation
                                criteria
                              </p>
                            </div>

                            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 sm:p-4 border border-gray-200 dark:border-gray-700">
                              <div className="flex items-center mb-2">
                                <div className="h-6 w-6 sm:h-8 sm:w-8 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                  <FiDollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-purple-600 dark:text-purple-400" />
                                </div>
                                <h4 className="font-medium text-sm sm:text-base text-gray-900 dark:text-gray-100">
                                  Profit Sharing
                                </h4>
                              </div>
                              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                                Understand their {propFirm.profitSplit}% profit
                                split structure
                              </p>
                            </div>

                            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 sm:p-4 border border-gray-200 dark:border-gray-700">
                              <div className="flex items-center mb-2">
                                <div className="h-6 w-6 sm:h-8 sm:w-8 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                  <FiShield className="h-3 w-3 sm:h-4 sm:w-4 text-violet-600 dark:text-violet-400" />
                                </div>
                                <h4 className="font-medium text-sm sm:text-base text-gray-900 dark:text-gray-100">
                                  Risk Management
                                </h4>
                              </div>
                              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                                Discover their risk management rules and
                                guidelines
                              </p>
                            </div>

                            <div className="bg-white dark:bg-gray-800 rounded-lg p-3 sm:p-4 border border-gray-200 dark:border-gray-700">
                              <div className="flex items-center mb-2">
                                <div className="h-6 w-6 sm:h-8 sm:w-8 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mr-2 sm:mr-3 flex-shrink-0">
                                  <FiUsers className="h-3 w-3 sm:h-4 sm:w-4 text-emerald-600 dark:text-emerald-400" />
                                </div>
                                <h4 className="font-medium text-sm sm:text-base text-gray-900 dark:text-gray-100">
                                  Support System
                                </h4>
                              </div>
                              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                                Learn about their trader support and education
                                programs
                              </p>
                            </div>
                          </div>

                          {/* Call to Action - Mobile Optimized */}
                          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg p-4 sm:p-6 text-white">
                            <div className="flex flex-col gap-3 sm:gap-4">
                              <div className="text-center sm:text-left">
                                <h3 className="text-base sm:text-lg font-semibold mb-1 sm:mb-2">
                                  Ready to Get Started?
                                </h3>
                                <p className="text-sm sm:text-base text-indigo-100 leading-relaxed">
                                  Start your trading journey with{" "}
                                  {propFirm.name} today
                                </p>
                              </div>
                              <Button
                                asChild
                                className="bg-white text-indigo-600 hover:bg-gray-100 font-medium px-4 sm:px-6 py-2 sm:py-3 w-full sm:w-auto text-sm sm:text-base"
                              >
                                <a
                                  href={propFirm.websiteUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center justify-center"
                                >
                                  Visit Website
                                  <FiExternalLink className="ml-2 h-3 w-3 sm:h-4 sm:w-4" />
                                </a>
                              </Button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        /* No Video Available - Mobile Optimized */
                        <div className="text-center py-12 sm:py-16 bg-gray-50 dark:bg-gray-800/30 rounded-xl border border-dashed border-gray-200 dark:border-gray-700 mx-2 sm:mx-0">
                          <div className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center">
                            <FiPlay className="h-6 w-6 sm:h-8 sm:w-8 text-indigo-600 dark:text-indigo-400" />
                          </div>
                          <h3 className="text-base sm:text-lg font-medium mb-2 text-gray-900 dark:text-gray-100">
                            Video Coming Soon
                          </h3>
                          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 max-w-sm sm:max-w-md mx-auto px-4 leading-relaxed">
                            {propFirm.name} will be adding their introduction
                            video soon. Check back later or visit their website
                            to learn more.
                          </p>
                          <Button
                            asChild
                            className="mt-4 bg-indigo-600 hover:bg-indigo-700 text-white px-4 sm:px-6 py-2 text-sm sm:text-base w-auto"
                          >
                            <a
                              href={propFirm.websiteUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center justify-center"
                            >
                              Visit Website
                              <FiExternalLink className="ml-2 h-3 w-3 sm:h-4 sm:w-4" />
                            </a>
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Reviews Tab */}
                <TabsContent value="reviews">
                  <div className="space-y-6">
                    {/* Write Review Section */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <FiStar className="mr-2 h-5 w-5 text-indigo-600" />
                          Write a Review
                        </CardTitle>
                        <CardDescription>
                          Share your experience with {propFirm.name} to help
                          other traders
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ReviewForm propFirmId={propFirm.id} />
                      </CardContent>
                    </Card>

                    {/* Existing Reviews Section */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <FiStar className="mr-2 h-5 w-5 text-indigo-600" />
                          Trader Reviews ({reviews?.length || 0})
                        </CardTitle>
                        <CardDescription>
                          Verified reviews from traders who have used{" "}
                          {propFirm.name}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {isReviewsLoading ? (
                          <div className="space-y-4">
                            {Array(3)
                              .fill(0)
                              .map((_, i) => (
                                <div
                                  key={i}
                                  className="border border-gray-200 dark:border-gray-800 rounded-lg p-4"
                                >
                                  <div className="flex justify-between mb-3">
                                    <Skeleton className="h-6 w-32" />
                                    <Skeleton className="h-4 w-24" />
                                  </div>
                                  <Skeleton className="h-4 w-full mb-2" />
                                  <Skeleton className="h-4 w-2/3" />
                                </div>
                              ))}
                          </div>
                        ) : reviews && reviews.length > 0 ? (
                          <div className="space-y-6">
                            {reviews.map((review) => (
                              <div
                                key={review.id}
                                className="border border-gray-200 dark:border-gray-800 rounded-lg p-5"
                              >
                                <div className="flex justify-between items-start mb-3">
                                  <h4 className="font-medium text-lg text-gray-900 dark:text-gray-100">
                                    {review.title}
                                  </h4>
                                  <div className="flex items-center ml-auto">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                      <FiStar
                                        key={star}
                                        className={cn(
                                          "h-4 w-4",
                                          star <= Number(review.rating)
                                            ? "text-amber-500 fill-amber-500"
                                            : "text-gray-300 dark:text-gray-600"
                                        )}
                                      />
                                    ))}
                                    <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                                      {new Date(
                                        review.datePosted
                                      ).toLocaleDateString()}
                                    </span>
                                  </div>
                                </div>

                                <p className="text-gray-700 dark:text-gray-300 mb-4 whitespace-pre-line">
                                  {review.content}
                                </p>

                                {/* Pros & Cons if available */}
                                {((Array.isArray(review.pros) &&
                                  review.pros.length > 0) ||
                                  (Array.isArray(review.cons) &&
                                    review.cons.length > 0)) && (
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                                    {Array.isArray(review.pros) &&
                                      review.pros.length > 0 && (
                                        <div>
                                          <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center">
                                            <FiCheck className="h-4 w-4 text-emerald-600 mr-1" />{" "}
                                            Pros
                                          </h5>
                                          <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1 pl-6 list-disc">
                                            {review.pros.map((pro, idx) => (
                                              <li key={idx}>{pro}</li>
                                            ))}
                                          </ul>
                                        </div>
                                      )}

                                    {Array.isArray(review.cons) &&
                                      review.cons.length > 0 && (
                                        <div>
                                          <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center">
                                            <FiX className="h-4 w-4 text-rose-600 mr-1" />{" "}
                                            Cons
                                          </h5>
                                          <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1 pl-6 list-disc">
                                            {review.cons.map((con, idx) => (
                                              <li key={idx}>{con}</li>
                                            ))}
                                          </ul>
                                        </div>
                                      )}
                                  </div>
                                )}

                                {/* User info */}
                                <div className="flex items-center mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                                  <div className="bg-indigo-100 dark:bg-indigo-900/30 h-8 w-8 rounded-full flex items-center justify-center mr-3">
                                    <span className="text-indigo-600 dark:text-indigo-400 font-medium text-sm">
                                      {review.userId &&
                                        String(review.userId)[0]}
                                    </span>
                                  </div>
                                  <div>
                                    <span className="text-sm text-gray-500 dark:text-gray-400">
                                      User {review.userId}
                                    </span>
                                    {review.isVerified && (
                                      <Badge
                                        variant="outline"
                                        className="ml-2 text-xs border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-900/20 dark:text-emerald-400"
                                      >
                                        <BadgeCheck className="h-3 w-3 mr-1" />{" "}
                                        Verified Trader
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-12 border border-dashed border-gray-200 dark:border-gray-800 rounded-lg">
                            <FiStar className="h-10 w-10 mx-auto text-gray-300 dark:text-gray-600" />
                            <h3 className="mt-4 text-lg font-medium text-gray-900 dark:text-gray-100">
                              No Reviews Yet
                            </h3>
                            <p className="mt-2 text-gray-500 dark:text-gray-400">
                              Be the first to review {propFirm.name}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar column */}
            <div className="w-full lg:w-80 xl:w-96 order-first lg:order-last">
              {/* CTA Card */}
              <div className="sticky top-24">
                <Card className="bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950/40 dark:to-violet-950/40 border-none shadow-lg">
                  <CardHeader>
                    <CardTitle>Ready to Start Trading?</CardTitle>
                    <CardDescription>
                      Get funded with {propFirm.name} and start your trading
                      journey
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Account Sizes Quick View */}
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                          Account Sizes:
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {propFirm.accountSizes.map((size, index) => (
                            <Badge
                              key={index}
                              variant="outline"
                              className="text-gray-800 dark:text-gray-200 border-indigo-200 dark:border-indigo-800 bg-white/80 dark:bg-gray-900/80"
                            >
                              ${formatAccountSize(size)}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Key Features */}
                      <div>
                        <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                          Key Features:
                        </h4>
                        <ul className="space-y-2">
                          <li className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                            <div className="h-5 w-5 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-2">
                              <Percent className="h-3 w-3 text-indigo-600 dark:text-indigo-400" />
                            </div>
                            {propFirm.profitSplit}% Profit Split
                          </li>
                          <li className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                            <div className="h-5 w-5 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-2">
                              <FiTarget className="h-3 w-3 text-indigo-600 dark:text-indigo-400" />
                            </div>
                            {propFirm.profitTargets.join(", ")}% Profit Target
                          </li>
                          <li className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                            <div className="h-5 w-5 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-2">
                              <Clock className="h-3 w-3 text-indigo-600 dark:text-indigo-400" />
                            </div>
                            {propFirm.payoutFrequency} Payouts
                          </li>
                          <li className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                            <div className="h-5 w-5 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-2">
                              <Briefcase className="h-3 w-3 text-indigo-600 dark:text-indigo-400" />
                            </div>
                            {propFirm.tradingPlatforms.join(", ")} Platform
                            {propFirm.tradingPlatforms.length > 1 ? "s" : ""}
                          </li>
                          <li className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                            <div className="h-5 w-5 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-2">
                              <BarChart3 className="h-3 w-3 text-indigo-600 dark:text-indigo-400" />
                            </div>
                            {propFirm.programType} Program
                          </li>
                        </ul>
                      </div>

                      {/* Discount Code If Available */}
                      {propFirm.discountPercentage &&
                        propFirm.discountPercentage > 0 &&
                        propFirm.couponCode && (
                          <div className="bg-white dark:bg-gray-800 rounded-md border border-indigo-200 dark:border-indigo-800/50 p-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-2">
                                  <Percent className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                                </div>
                                <div>
                                  <p className="text-xs text-gray-500 dark:text-gray-400">
                                    Discount Code
                                  </p>
                                  <p className="font-mono font-medium text-sm">
                                    {propFirm.couponCode}
                                  </p>
                                </div>
                              </div>
                              <Badge className="bg-gradient-to-r from-indigo-500 to-violet-500 text-white">
                                {propFirm.discountPercentage}% OFF
                              </Badge>
                            </div>
                          </div>
                        )}

                      {/* Buy Now Button */}
                      <a
                        href={propFirm.websiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full block"
                      >
                        <Button
                          size="lg"
                          className="w-full font-semibold text-base bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white"
                        >
                          Buy Now <FiExternalLink className="ml-2 h-4 w-4" />
                        </Button>
                      </a>

                      <p className="text-xs text-center text-gray-500 dark:text-gray-400">
                        You will be redirected to the official website of{" "}
                        {propFirm.name}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}