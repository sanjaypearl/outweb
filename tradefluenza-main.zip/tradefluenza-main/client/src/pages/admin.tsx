import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PurchaseStatsManager } from "@/components/admin/purchase-stats-manager";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  ArrowLeft,
  Settings,
  TrendingUp,
  Users,
  BarChart,
  BarChartHorizontal,
  LineChart,
  Gauge,
} from "lucide-react";
import AnalyticsSetup from "@/components/analytics/analytics-setup";

export default function AdminPage() {
  const { user, isLoading } = useAuth();

  // Add title to the page
  useEffect(() => {
    document.title = "Admin Dashboard | Tradefluenza";
  }, []);

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-10 w-10 border-4 border-emerald-500 rounded-full border-t-transparent"></div>
      </div>
    );
  }

  // Redirect if not logged in
  if (!user) {
    return <Redirect to="/auth" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50/50 to-white dark:from-slate-950 dark:to-slate-900">
      <div className="container mx-auto py-8 px-4">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <Link href="/">
              <Button variant="outline" size="sm" className="mb-2">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Homepage
              </Button>
            </Link>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage website content and statistics
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-sm text-muted-foreground">
              Logged in as:{" "}
              <span className="font-semibold">{user.username}</span>
            </div>
          </div>
        </div>

        <Tabs defaultValue="purchase-stats" className="max-w-5xl mx-auto">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger
              value="purchase-stats"
              className="flex items-center gap-2"
            >
              <TrendingUp className="h-4 w-4" /> Purchase Stats
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <LineChart className="h-4 w-4" /> Analytics
            </TabsTrigger>
            <TabsTrigger
              value="user-management"
              className="flex items-center gap-2"
            >
              <Users className="h-4 w-4" /> User Management
            </TabsTrigger>
            <TabsTrigger
              value="site-settings"
              className="flex items-center gap-2"
            >
              <Settings className="h-4 w-4" /> Site Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="purchase-stats" className="mt-6">
            <div className="mb-6">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <BarChart className="h-5 w-5 text-emerald-500" />
                Purchase Statistics Management
              </h2>
              <p className="text-muted-foreground text-sm mt-1">
                Update the purchase counter numbers displayed on the homepage
              </p>
            </div>

            <PurchaseStatsManager />
          </TabsContent>

          <TabsContent value="user-management">
            <div className="flex flex-col items-center justify-center p-8 border border-dashed rounded-lg">
              <Users className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">User Management</h3>
              <p className="text-muted-foreground text-center max-w-md">
                User management features coming soon. This section will allow
                you to manage users, roles and permissions.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <div className="mb-6">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <LineChart className="h-5 w-5 text-blue-500" />
                Google Analytics Integration
              </h2>
              <p className="text-muted-foreground text-sm mt-1">
                Set up and configure Google Analytics to track website traffic
                and user behavior
              </p>
            </div>

            <AnalyticsSetup />
          </TabsContent>

          <TabsContent value="site-settings">
            <div className="flex flex-col items-center justify-center p-8 border border-dashed rounded-lg">
              <Settings className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Site Settings</h3>
              <p className="text-muted-foreground text-center max-w-md">
                Site configuration features coming soon. This section will allow
                you to customize the website appearance and behavior.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
