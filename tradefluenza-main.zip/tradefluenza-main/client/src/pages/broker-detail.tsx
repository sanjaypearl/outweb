import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useRoute, Link } from 'wouter';
import { FiExternalLink, FiStar, FiArrowLeft, FiCheck, FiAward, FiFlag, FiClock, FiGlobe, FiLock, FiAlertTriangle, FiEdit } from 'react-icons/fi';
import { Flag } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, getQueryFn } from '@/lib/queryClient';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';

interface Broker {
  id: number;
  name: string;
  country: string;
  yearsActive: string;
  environment: string;
  regulators: string[];
  regulatoryLicenseNumber: string | null;
  score: number;
  logoUrl: string | null;
  websiteUrl: string | null;
  description: string | null;
  pros: string[];
  cons: string[];
  tags: string[];
  dateAdded: string;
  position: number | null;
}

interface BrokerReview {
  id: number;
  brokerId: number;
  userId: number;
  rating: number;
  title: string;
  content: string;
  pros: string[] | null;
  cons: string[] | null;
  experience: string | null;
  tradingPeriod: string | null;
  datePosted: string;
  isVerified: boolean;
}

interface ExternalReview {
  id: number;
  source: string;
  sourceUrl: string;
  rating: number;
  title: string;
  content: string;
  author: string;
  datePosted: string;
  logoUrl?: string;
}

export default function BrokerDetail() {
  const [, params] = useRoute('/brokers/:id');
  const brokerId = parseInt(params?.id || '0');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  
  // External reviews from various trading forums and platforms
  const externalReviews: ExternalReview[] = [
    {
      id: 1,
      source: "ForexPeaceArmy",
      sourceUrl: "https://www.forexpeacearmy.com",
      rating: 4.2,
      title: "Good broker with tight spreads",
      content: "I've been trading with them for over 2 years. They offer tight spreads and reliable execution. Customer service is responsive though sometimes it takes a day to get a reply. Overall a solid choice for serious traders.",
      author: "TradingExpert22",
      datePosted: "2024-12-15",
      logoUrl: "https://www.forexpeacearmy.com/assets/img/logo.svg"
    },
    {
      id: 2,
      source: "TrustPilot",
      sourceUrl: "https://www.trustpilot.com",
      rating: 3.8,
      title: "Decent platform with some issues",
      content: "The trading platform is good and execution is fast. However, withdrawal process could be improved. I had to wait 5 days for my money. Otherwise, no major complaints - spreads are competitive and platform rarely has downtime.",
      author: "JohnTrader",
      datePosted: "2025-01-21",
      logoUrl: "https://cdn.trustpilot.net/brand-assets/1.1.0/logo-white-bg.svg"
    },
    {
      id: 3,
      source: "BabyPips Forum",
      sourceUrl: "https://forums.babypips.com",
      rating: 4.5,
      title: "Great for beginners",
      content: "I'm a new trader and they've been very supportive. Their educational resources are excellent and the customer service team is patient with newbie questions. The demo account is feature-rich and mimics real trading conditions accurately.",
      author: "NewTrader2025",
      datePosted: "2025-02-18",
      logoUrl: "https://forums.babypips.com/uploads/default/original/3X/2/e/2e8bc773cec3ea382991700c4179356c1f5cdf87.png"
    }
  ];

  // Form schema for adding a review
  const reviewSchema = z.object({
    brokerId: z.number(),
    userId: z.number().default(1), // Default user ID for demo
    rating: z.number().min(1).max(5),
    title: z.string().min(5, 'Title must be at least 5 characters').max(100, 'Title must be less than 100 characters'),
    content: z.string().min(10, 'Review must be at least 10 characters'),
    pros: z.array(z.string()).optional().nullable(),
    cons: z.array(z.string()).optional().nullable(),
    experience: z.string().optional().nullable(),
    tradingPeriod: z.string().optional().nullable(),
  });

  // Get current user
  const { data: user } = useQuery<{ id: number, username: string }>({
    queryKey: ['/api/user'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/user', { credentials: 'include' });
        if (response.status === 401) return null;
        if (!response.ok) throw new Error('Failed to fetch user data');
        return response.json();
      } catch (error) {
        console.error('Error fetching user:', error);
        return null;
      }
    },
  });

  // Initialize form with default values
  const form = useForm<z.infer<typeof reviewSchema>>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      brokerId,
      userId: 2, // Default userId that will be updated when user loads
      rating: 3,
      title: '',
      content: '',
      pros: [],
      cons: [],
      experience: null,
      tradingPeriod: null,
    },
  });
  
  // Update form with user ID when user data is loaded
  useEffect(() => {
    if (user?.id) {
      console.log("Setting user ID in form:", user.id);
      form.setValue('userId', user.id);
    }
  }, [user, form]);

  // Fetch broker details
  const { data: broker, isLoading: brokerLoading } = useQuery<Broker>({
    queryKey: [`/api/brokers/${brokerId}`],
    queryFn: async () => {
      const response = await fetch(`/api/brokers/${brokerId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch broker details');
      }
      return response.json();
    },
  });

  // Fetch broker reviews
  const { data: reviews = [], isLoading: reviewsLoading } = useQuery<BrokerReview[]>({
    queryKey: [`/api/brokers/${brokerId}/reviews`],
    queryFn: async () => {
      console.log("Fetching reviews for broker ID:", brokerId);
      try {
        const response = await fetch(`/api/brokers/${brokerId}/reviews`);
        console.log("Reviews response status:", response.status);
        if (!response.ok) {
          console.warn("Failed to fetch reviews:", response.statusText);
          return [];
        }
        const data = await response.json();
        console.log("Fetched reviews:", data);
        return data;
      } catch (error) {
        console.error("Error fetching reviews:", error);
        return [];
      }
    },
    // Force refetch when we navigate to this page and when data changes
    refetchOnMount: true,
    refetchOnWindowFocus: true, // Refetch when window regains focus
    gcTime: 0, // Using gcTime instead of deprecated cacheTime
  });

  // Submit review mutation
  const submitReview = useMutation({
    mutationFn: async (data: z.infer<typeof reviewSchema>) => {
      console.log("Submitting broker review:", data);
      // Try using standard fetch for debugging
      try {
        const response = await fetch('/api/broker-reviews', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(data),
          credentials: 'include'
        });
        
        console.log("Review submission status:", response.status);
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error(`Error response (${response.status}):`, errorText);
          throw new Error(`Server error: ${response.status} - ${errorText || response.statusText}`);
        }
        
        const responseData = await response.json();
        console.log("Review submission response:", responseData);
        return responseData;
      } catch (error) {
        console.error("Review submission error:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log("Review submitted successfully:", data);
      
      // Show success toast
      toast({
        title: 'Review submitted',
        description: 'Your review has been submitted successfully',
      });
      
      // Close dialog and reset form
      setIsReviewDialogOpen(false);
      form.reset();
      
      // Force refetch data by invalidating the relevant queries
      console.log("Invalidating queries to refetch data");
      queryClient.invalidateQueries({ queryKey: [`/api/brokers/${brokerId}/reviews`] });
      queryClient.invalidateQueries({ queryKey: [`/api/brokers/${brokerId}/rating`] });
      
      // Direct refetch to ensure we have the latest data
      setTimeout(() => {
        queryClient.refetchQueries({ queryKey: [`/api/brokers/${brokerId}/reviews`] });
      }, 300);
    },
    onError: (error) => {
      console.error("Error in mutation handler:", error);
      toast({
        title: 'Error',
        description: `Failed to submit review: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Handle review submission
  const onSubmitReview = (data: z.infer<typeof reviewSchema>) => {
    console.log("Form data before submission:", data);
    submitReview.mutate(data);
  };

  // Calculate average rating - safely parse string or number ratings and calculate the average
  const averageRating = reviews.length
    ? (reviews.reduce((acc, review) => {
        // Make sure to safely parse the rating which could be a string or number
        const ratingValue = typeof review.rating === 'string' 
          ? parseFloat(review.rating) 
          : review.rating;
        return acc + ratingValue;
      }, 0) / reviews.length).toFixed(1)
    : 'N/A';

  if (brokerLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid gap-8">
          <Skeleton className="h-8 w-64" />
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-8">
                <Skeleton className="h-32 w-32 rounded-lg" />
                <div className="space-y-3 flex-grow">
                  <Skeleton className="h-8 w-64" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-6 w-full" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!broker) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-4">Broker Not Found</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            The broker you are looking for does not exist or has been removed.
          </p>
          <Link href="/brokers">
            <Button>
              <FiArrowLeft className="mr-2 h-4 w-4" /> Back to Brokers
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back button and header */}
      <div className="flex flex-col gap-2 mb-8">
        <Link href="/brokers">
          <Button variant="ghost" className="mb-2">
            <FiArrowLeft className="mr-2 h-4 w-4" /> Back to Brokers
          </Button>
        </Link>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-500 to-violet-500 inline-block text-transparent bg-clip-text">
          {broker.name}
        </h1>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Broker overview card */}
        <Card className="lg:col-span-2">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-8">
              {/* Logo */}
              <div className="flex-shrink-0">
                <div 
                  className="w-32 h-32 rounded-lg flex items-center justify-center overflow-hidden"
                  style={{
                    background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(139, 92, 246, 0.1))',
                    boxShadow: '0 0 15px rgba(59, 130, 246, 0.15)',
                    border: '1px solid rgba(59, 130, 246, 0.2)'
                  }}
                >
                  {broker.logoUrl ? (
                    <img 
                      src={broker.logoUrl} 
                      alt={`${broker.name} logo`} 
                      className="w-full h-full object-contain p-2" 
                    />
                  ) : (
                    <span className="text-3xl font-bold bg-gradient-to-r from-blue-500 to-violet-500 inline-block text-transparent bg-clip-text">
                      {broker.name.substring(0, 2)}
                    </span>
                  )}
                </div>
              </div>

              {/* Overview info */}
              <div className="space-y-3 flex-grow">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-2xl font-bold">{broker.name}</h2>
                  {broker.tags && broker.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300">
                      {tag}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400">
                  <div className="flex items-center gap-1">
                    <Flag className="h-4 w-4" />
                    <span>{broker.country}</span>
                  </div>
                  <div>Years active: {broker.yearsActive}</div>
                  {broker.environment && broker.environment !== "—" && (
                    <div>Environment: <span className="font-semibold">{broker.environment}</span></div>
                  )}
                  
                  <div className="flex items-center gap-1">
                    <FiAward className="h-4 w-4" />
                    <span>Score: </span>
                    <span className="font-semibold">
                      {typeof broker.score === 'number' 
                        ? broker.score.toFixed(2)
                        : parseFloat(String(broker.score)).toFixed(2)}
                    </span>
                  </div>
                </div>
                
                {broker.description && (
                  <p className="text-gray-700 dark:text-gray-300">{broker.description}</p>
                )}
                
                {broker.regulators && broker.regulators.length > 0 && (
                  <div>
                    <p className="font-semibold text-sm mb-1">Regulated by:</p>
                    <div className="flex flex-wrap gap-2">
                      {broker.regulators.map((regulator, index) => (
                        <Badge key={index} variant="outline" className="bg-gray-50 dark:bg-gray-800">
                          {regulator}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {broker.regulatoryLicenseNumber && (
                  <div className="text-sm">
                    <span className="font-semibold">License number: </span>
                    {broker.regulatoryLicenseNumber}
                  </div>
                )}
                
                {/* Pros & Cons */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  {broker.pros && broker.pros.length > 0 && (
                    <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-md">
                      <h3 className="font-semibold text-green-700 dark:text-green-400 mb-2">Pros</h3>
                      <ul className="space-y-1">
                        {broker.pros.map((pro, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <FiCheck className="h-4 w-4 text-green-600 dark:text-green-400 mt-0.5" />
                            <span>{pro}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {broker.cons && broker.cons.length > 0 && (
                    <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-md">
                      <h3 className="font-semibold text-red-700 dark:text-red-400 mb-2">Cons</h3>
                      <ul className="space-y-1">
                        {broker.cons.map((con, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <span className="text-red-600 dark:text-red-400">•</span>
                            <span>{con}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Action buttons */}
            <div className="flex justify-end mt-6 space-x-3">
              <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">Write a Review</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Review {broker.name}</DialogTitle>
                    <DialogDescription>
                      Share your experience with this broker to help other traders
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmitReview)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="rating"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Rating (1-5)</FormLabel>
                            <FormControl>
                              <RadioGroup
                                defaultValue={field.value?.toString() || "3"}
                                onValueChange={(value) => field.onChange(parseInt(value))}
                                className="flex space-x-2"
                              >
                                {[1, 2, 3, 4, 5].map((value) => (
                                  <FormItem key={value} className="flex items-center space-x-1">
                                    <FormControl>
                                      <RadioGroupItem value={value.toString()} />
                                    </FormControl>
                                    <FormLabel className="font-normal cursor-pointer">
                                      {value}
                                    </FormLabel>
                                  </FormItem>
                                ))}
                              </RadioGroup>
                            </FormControl>
                            <FormDescription className="text-xs text-muted-foreground">
                              Rate your experience with this broker from 1 (worst) to 5 (best)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Summarize your experience" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Review</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Share your experience with this broker" 
                                className="min-h-[120px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end space-x-2">
                        <Button 
                          variant="outline" 
                          type="button"
                          onClick={() => setIsReviewDialogOpen(false)}
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="submit"
                          disabled={submitReview.isPending}
                        >
                          {submitReview.isPending ? 'Submitting...' : 'Submit Review'}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
              
              {broker.websiteUrl && (
                <a href={broker.websiteUrl} target="_blank" rel="noopener noreferrer">
                  <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    <FiExternalLink className="mr-2 h-4 w-4" /> Visit Official Website
                  </Button>
                </a>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Rating card */}
        <Card>
          <CardHeader>
            <CardTitle>Rating & Reviews</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center mb-6 p-4 rounded-xl bg-gradient-to-br from-blue-50/80 to-indigo-50/80 dark:from-blue-900/20 dark:to-indigo-900/20 shadow-inner">
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 inline-block text-transparent bg-clip-text">
                  {averageRating !== 'N/A' ? Number(averageRating).toFixed(1) : averageRating}
                </span>
                <span className="text-lg text-gray-600 dark:text-gray-300">/ 5</span>
              </div>
              <div className="flex text-amber-500 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <FiStar
                    key={star}
                    className={`h-6 w-6 ${
                      averageRating !== 'N/A' 
                      ? star <= Math.floor(Number(averageRating))
                        ? "fill-current" 
                        : star - 0.5 <= Number(averageRating) 
                          ? "fill-current opacity-50" 
                          : ""
                      : ""
                    }`}
                  />
                ))}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300 font-medium">
                Based on user reviews
              </div>
            </div>
            
            <Separator className="my-4" />
            
            <div className="text-sm">
              <div className="flex justify-between mb-1">
                <span>{reviews.length} reviews</span>
                <span>Last review: {reviews.length ? new Date(reviews[0].datePosted).toLocaleDateString() : 'N/A'}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reviews section */}
      <Tabs defaultValue="reviews">
        <TabsList>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="world-say">What World Say</TabsTrigger>
          <TabsTrigger value="details">Additional Details</TabsTrigger>
        </TabsList>
        
        <TabsContent value="reviews" className="mt-4">
          <Card>
            <CardContent className="p-6">
              {reviewsLoading ? (
                <div className="space-y-6">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="border-b pb-6 last:border-0">
                      <div className="flex justify-between mb-2">
                        <Skeleton className="h-6 w-48" />
                        <Skeleton className="h-4 w-20" />
                      </div>
                      <Skeleton className="h-4 w-full my-2" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                    </div>
                  ))}
                </div>
              ) : reviews.length > 0 ? (
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b pb-6 last:border-0 last:pb-0 relative">
                      <div 
                        className="absolute -left-3 top-0 bottom-0 w-1 rounded-full opacity-70"
                        style={{
                          background: 'linear-gradient(to bottom, #3b82f6, #8b5cf6)'
                        }}
                      ></div>
                    
                      <div className="flex justify-between mb-3">
                        <h3 className="font-semibold text-lg bg-gradient-to-r from-blue-600 to-indigo-600 inline-block text-transparent bg-clip-text">{review.title}</h3>
                        <div className="flex text-amber-500 bg-amber-50 dark:bg-amber-900/10 px-2 py-1 rounded-md">
                          {[1, 2, 3, 4, 5].map((star) => {
                            // Parse rating to ensure we handle both number and string types
                            const ratingValue = typeof review.rating === 'string' 
                              ? parseFloat(review.rating) 
                              : review.rating;
                            
                            return (
                              <FiStar
                                key={star}
                                className={star <= ratingValue ? "fill-current h-4 w-4" : "h-4 w-4"}
                              />
                            );
                          })}
                        </div>
                      </div>
                      
                      <p className="text-gray-700 dark:text-gray-300 text-sm mb-3 bg-gray-50 dark:bg-gray-800/50 p-3 rounded-md border-l-2 border-blue-400">{review.content}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        {review.pros && review.pros.length > 0 && (
                          <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/10 dark:to-emerald-900/10 p-3 rounded-md">
                            <h4 className="font-semibold text-green-700 dark:text-green-400 text-xs mb-2">Pros</h4>
                            <ul className="space-y-1.5">
                              {review.pros.map((pro, index) => (
                                <li key={index} className="flex items-start gap-1.5 text-xs">
                                  <div className="flex-shrink-0 mt-0.5 bg-green-200 dark:bg-green-800 rounded-full p-0.5">
                                    <FiCheck className="h-3 w-3 text-green-700 dark:text-green-300" />
                                  </div>
                                  <span className="text-gray-700 dark:text-gray-300">{pro}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {review.cons && review.cons.length > 0 && (
                          <div className="bg-gradient-to-r from-red-50 to-rose-50 dark:from-red-900/10 dark:to-rose-900/10 p-3 rounded-md">
                            <h4 className="font-semibold text-red-700 dark:text-red-400 text-xs mb-2">Cons</h4>
                            <ul className="space-y-1.5">
                              {review.cons.map((con, index) => (
                                <li key={index} className="flex items-start gap-1.5 text-xs">
                                  <div className="flex-shrink-0 mt-0.5 bg-red-200 dark:bg-red-800 rounded-full h-4 w-4 flex items-center justify-center">
                                    <span className="text-red-700 dark:text-red-300 text-[10px]">×</span>
                                  </div>
                                  <span className="text-gray-700 dark:text-gray-300">{con}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex justify-between mt-4 text-xs">
                        <div>
                          {review.isVerified && (
                            <span className="flex items-center bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 px-2 py-1 rounded-full">
                              <FiCheck className="mr-1 h-3 w-3" /> Verified User
                            </span>
                          )}
                        </div>
                        <div className="text-gray-500 dark:text-gray-400 italic">
                          Posted on {new Date(review.datePosted).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 px-6 rounded-xl bg-gradient-to-br from-blue-50/80 to-indigo-50/80 dark:from-blue-900/20 dark:to-indigo-900/20">
                  <h3 className="text-xl font-semibold mb-2 bg-gradient-to-r from-blue-600 to-indigo-600 inline-block text-transparent bg-clip-text">
                    No reviews yet
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300 mb-6 max-w-md mx-auto">
                    Be the first to share your experience with {broker.name} and help other traders make informed decisions
                  </p>
                  <Button 
                    onClick={() => setIsReviewDialogOpen(true)}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-md hover:shadow-lg transition-all"
                  >
                    <FiEdit className="h-4 w-4 mr-2" /> Write a Review
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* What World Say tab */}
        <TabsContent value="world-say" className="mt-4">
          <Card>
            <CardContent className="p-6">
              <div className="mb-4">
                <h3 className="text-xl font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 inline-block text-transparent bg-clip-text">
                  What traders around the world say about {broker.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  Reviews collected from various trading forums and platforms to help you make a better decision.
                </p>
              </div>
              
              <div className="space-y-8">
                {externalReviews.map((review) => (
                  <div 
                    key={review.id} 
                    className="relative bg-gradient-to-br from-white to-gray-50 dark:from-gray-800/50 dark:to-gray-900/80 p-6 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700"
                  >
                    <div className="absolute top-0 left-4 transform -translate-y-1/2 bg-white dark:bg-gray-800 px-3 py-1 rounded-full border border-gray-200 dark:border-gray-700 shadow-sm">
                      <a 
                        href={review.sourceUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2"
                      >
                        {review.logoUrl ? (
                          <img 
                            src={review.logoUrl} 
                            alt={review.source} 
                            className="h-5 w-auto" 
                          />
                        ) : null}
                        <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">{review.source}</span>
                        <FiExternalLink className="h-3 w-3 text-gray-400" />
                      </a>
                    </div>
                    
                    <div className="mt-3">
                      <div className="flex justify-between items-start mb-3">
                        <h4 className="font-semibold text-lg text-gray-900 dark:text-white">{review.title}</h4>
                        <div className="flex text-amber-500 bg-amber-50 dark:bg-amber-900/30 px-2 py-0.5 rounded">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <FiStar
                              key={star}
                              className={star <= review.rating ? "fill-current h-4 w-4" : "h-4 w-4"}
                            />
                          ))}
                          <span className="ml-1 text-xs font-medium text-gray-700 dark:text-gray-300">
                            {review.rating.toFixed(1)}
                          </span>
                        </div>
                      </div>
                      
                      <p className="text-gray-700 dark:text-gray-300 text-sm mb-3 border-l-2 border-blue-400 pl-3 py-1">
                        "{review.content}"
                      </p>
                      
                      <div className="flex justify-between items-center mt-4 text-xs">
                        <div className="font-medium text-indigo-600 dark:text-indigo-400">
                          By {review.author}
                        </div>
                        <div className="text-gray-500 dark:text-gray-400">
                          Posted on {new Date(review.datePosted).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="text-center mt-8">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  These reviews are collected from third-party sources and are provided for informational purposes only.
                </p>
                <Button variant="outline" size="sm" className="gap-1">
                  <FiExternalLink className="h-3 w-3" /> 
                  <span>Find more reviews online</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="details" className="mt-4">
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold mb-4 bg-gradient-to-r from-blue-600 to-indigo-600 inline-block text-transparent bg-clip-text">
                    Broker Information
                  </h3>
                  <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
                    <dl className="space-y-4">
                      <div className="flex items-center border-b border-gray-200 dark:border-gray-700 pb-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center mr-3">
                          <FiFlag className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div>
                          <dt className="text-xs font-medium text-gray-500 dark:text-gray-400">Country</dt>
                          <dd className="font-medium">{broker.country}</dd>
                        </div>
                      </div>
                      
                      <div className="flex items-center border-b border-gray-200 dark:border-gray-700 pb-3">
                        <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-3">
                          <FiClock className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                        </div>
                        <div>
                          <dt className="text-xs font-medium text-gray-500 dark:text-gray-400">Years Active</dt>
                          <dd className="font-medium">{broker.yearsActive}</dd>
                        </div>
                      </div>
                      
                      <div className="flex items-center border-b border-gray-200 dark:border-gray-700 pb-3">
                        <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mr-3">
                          <FiGlobe className="h-5 w-5 text-green-600 dark:text-green-400" />
                        </div>
                        <div>
                          <dt className="text-xs font-medium text-gray-500 dark:text-gray-400">Environment Rating</dt>
                          <dd className="font-medium">{broker.environment || 'Not rated'}</dd>
                        </div>
                      </div>
                      
                      <div className="flex items-center pb-3">
                        <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center mr-3">
                          <FiLock className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                        </div>
                        <div>
                          <dt className="text-xs font-medium text-gray-500 dark:text-gray-400">Regulatory Status</dt>
                          <dd className="font-medium">
                            {broker.regulators?.length ? (
                              <span className="flex items-center text-green-600 dark:text-green-400">
                                <FiCheck className="mr-1 h-4 w-4" /> Regulated
                              </span>
                            ) : (
                              <span className="flex items-center text-red-600 dark:text-red-400">
                                <FiAlertTriangle className="mr-1 h-4 w-4" /> Unregulated
                              </span>
                            )}
                          </dd>
                        </div>
                      </div>
                      
                      {broker.regulatoryLicenseNumber && (
                        <div className="pt-1 pl-13 border-t border-gray-200 dark:border-gray-700">
                          <dt className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">License Number</dt>
                          <dd className="text-sm">{broker.regulatoryLicenseNumber}</dd>
                        </div>
                      )}
                    </dl>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-4 bg-gradient-to-r from-blue-600 to-indigo-600 inline-block text-transparent bg-clip-text">
                    Regulatory Information
                  </h3>
                  
                  <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4">
                    {broker.regulators && broker.regulators.length > 0 ? (
                      <div>
                        <p className="mb-3 text-sm text-gray-700 dark:text-gray-300">
                          {broker.name} is regulated by the following regulatory authorities:
                        </p>
                        
                        <ul className="space-y-3">
                          {broker.regulators.map((regulator, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <div className="mt-0.5 h-5 w-5 rounded-full bg-blue-100 dark:bg-blue-900/30 flex-shrink-0 flex items-center justify-center">
                                <FiCheck className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                              </div>
                              <div>
                                <p className="font-medium">{regulator}</p>
                              </div>
                            </li>
                          ))}
                        </ul>
                        
                        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-md text-xs text-gray-700 dark:text-gray-300">
                          <p className="mb-1"><strong>Why regulation matters:</strong></p>
                          <p>
                            Regulated brokers are required to follow strict guidelines that protect trader funds and ensure
                            fair trading practices. They typically offer segregated accounts, negative balance protection,
                            and maintain minimum capital requirements.
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-6">
                        <FiAlertTriangle className="mx-auto h-10 w-10 text-amber-500 mb-3" />
                        <h4 className="text-lg font-medium mb-2">Unregulated Broker</h4>
                        <p className="text-sm text-gray-700 dark:text-gray-300 max-w-md mx-auto">
                          This broker does not appear to be regulated by any major financial authority.
                          Trading with unregulated brokers may carry additional risks.
                        </p>
                        
                        <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-md text-xs text-gray-700 dark:text-gray-300 text-left">
                          <p className="mb-1"><strong>Risk factors to consider:</strong></p>
                          <ul className="list-disc pl-4 space-y-1">
                            <li>Less oversight and fewer protections for client funds</li>
                            <li>May not adhere to standard market practices</li>
                            <li>Potential for conflicts of interest</li>
                            <li>Limited recourse in case of disputes</li>
                          </ul>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}