import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { FiExternalLink, FiStar, FiAward, FiClock, FiGlobe, FiLock, FiArrowUp, FiRefreshCw, FiInfo, FiShield } from 'react-icons/fi';
import { Flag } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  environmentRatings,
  yearsActiveOptions,
} from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Helmet } from "react-helmet-async";

interface Broker {
  id: number;
  name: string;
  country: string;
  yearsActive: string;
  environment: string;
  regulators: string[];
  regulatoryLicenseNumber: string | null;
  score: number;
  logoUrl: string | null;
  websiteUrl: string | null;
  description: string | null;
  pros: string[];
  cons: string[];
  tags: string[];
  dateAdded: string;
}

interface BrokerRating {
  brokerId: number;
  averageRating: number;
}

export default function Brokers() {
  const { toast } = useToast();
  const [environment, setEnvironment] = useState<string>('');
  const [yearsActive, setYearsActive] = useState<string>('');
  const [country, setCountry] = useState<string>('');
  const [sort, setSort] = useState<{ field: string; direction: 'asc' | 'desc' }>({
    field: 'score',
    direction: 'desc',
  });

  // Fetch brokers with filters
  const { data: brokers, isLoading: brokersLoading } = useQuery<Broker[]>({
    queryKey: ['/api/brokers', environment, yearsActive, country, sort],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      if (environment && environment !== 'all') params.append('environment', environment);
      if (yearsActive && yearsActive !== 'all') params.append('yearsActive', yearsActive);
      if (country && country !== 'all') params.append('country', country);
      if (sort.field) {
        params.append('field', sort.field);
        params.append('direction', sort.direction);
      }
      
      const response = await fetch(`/api/brokers?${params.toString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch brokers');
      }
      return response.json();
    },
  });

  // Fetch ratings for all brokers
  const { data: ratings, isLoading: ratingsLoading } = useQuery<BrokerRating[]>({
    queryKey: ['/api/brokers/ratings'],
    queryFn: async () => {
      // Fetch ratings for each broker
      if (!brokers) return [];
      
      const ratingsPromises = brokers.map(async (broker) => {
        const response = await fetch(`/api/brokers/${broker.id}/rating`);
        if (!response.ok) {
          return { brokerId: broker.id, averageRating: 0 };
        }
        return response.json();
      });
      
      return await Promise.all(ratingsPromises);
    },
    enabled: Boolean(brokers),
  });

  // Get unique countries for filter
  const countries = brokers 
    ? Array.from(new Set(brokers.map(broker => broker.country))).sort() 
    : [];

  // Get rating for a specific broker
  const getRating = (brokerId: number): number => {
    if (!ratings) return 0;
    const brokerRating = ratings.find(rating => rating.brokerId === brokerId);
    return brokerRating ? brokerRating.averageRating : 0;
  };

  const handleSort = (field: string) => {
    if (sort.field === field) {
      // Toggle direction if same field
      setSort({
        field,
        direction: sort.direction === 'asc' ? 'desc' : 'asc',
      });
    } else {
      // Default to descending for new field
      setSort({ field, direction: 'desc' });
    }
  };

  return (
    <>
      <Helmet>
        <title>
          Get Verified Forex Broker & Prop Firm Reviews | Tradefluenza
        </title>
        <meta
          name="description"
          content="Compare verified forex brokers and prop firm reviews on Tradefluenza. Choose reliable platforms with trusted insights to boost your trading success."
        />
        <meta
          name="keywords"
          content="verified forex brokers, prop firm reviews"
        />
        <link rel="canonical" href="https://tradefluenza.com/brokers" />
      </Helmet>
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section with Animated Background */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-700 p-10 mb-8 border border-blue-400/20 dark:border-blue-500/20 shadow-xl">
          {/* Animated particles */}
          <div className="absolute inset-0 overflow-hidden">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className="absolute rounded-full bg-white/10"
                style={{
                  width: `${Math.random() * 30 + 10}px`,
                  height: `${Math.random() * 30 + 10}px`,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animation: `float ${
                    Math.random() * 10 + 10
                  }s linear infinite`,
                  opacity: Math.random() * 0.5 + 0.1,
                }}
              />
            ))}
          </div>

          {/* Content */}
          <div className="relative max-w-3xl mx-auto text-center z-10">
            <h1 className="text-5xl font-extrabold text-white mb-6 [text-shadow:_0_2px_10px_rgba(0,0,0,0.2)]">
              <span className="inline-block bg-clip-text text-transparent bg-gradient-to-r from-blue-100 to-indigo-200">
                Broker Rankings
              </span>
            </h1>
            <p className="text-blue-100 text-xl mb-8 max-w-2xl mx-auto leading-relaxed [text-shadow:_0_1px_2px_rgba(0,0,0,0.2)]">
              Compare the best forex and CFD brokers with detailed metrics,
              ratings, and regulatory information.
            </p>

            {/* Stats cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
              <div className="backdrop-blur-md bg-white/10 rounded-xl p-4 border border-white/20 shadow-lg transition-all duration-300 hover:bg-white/20">
                <div className="text-3xl font-bold text-white mb-1">
                  {brokers?.length || 0}
                </div>
                <div className="text-blue-100">Trusted Brokers</div>
              </div>
              <div className="backdrop-blur-md bg-white/10 rounded-xl p-4 border border-white/20 shadow-lg transition-all duration-300 hover:bg-white/20">
                <div className="text-3xl font-bold text-white mb-1">
                  {brokers?.reduce(
                    (acc, broker) =>
                      broker.regulators?.length ? acc + 1 : acc,
                    0
                  ) || 0}
                </div>
                <div className="text-blue-100">Regulated</div>
              </div>
              <div className="backdrop-blur-md bg-white/10 rounded-xl p-4 border border-white/20 shadow-lg transition-all duration-300 hover:bg-white/20">
                <div className="text-3xl font-bold text-white mb-1">
                  {brokers?.filter((b) => b.score >= 8.5).length || 0}
                </div>
                <div className="text-blue-100">Elite Rating</div>
              </div>
            </div>
          </div>
        </div>

        {/* Custom styles for animations */}
        <style
          dangerouslySetInnerHTML={{
            __html: `
        @keyframes float {
          0% { transform: translateY(0) translateX(0) rotate(0deg); opacity: 0.1; }
          50% { transform: translateY(-40px) translateX(20px) rotate(180deg); opacity: 0.5; }
          100% { transform: translateY(0) translateX(0) rotate(360deg); opacity: 0.1; }
        }
      `,
          }}
        />

        {/* Filters */}
        <div className="relative backdrop-blur-sm bg-white/70 dark:bg-gray-900/70 rounded-2xl p-6 mb-8 border border-gray-200/50 dark:border-gray-700/50 shadow-lg">
          <div className="absolute -top-4 left-8 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm font-semibold py-1 px-4 rounded-full shadow-md">
            Customize Your Search
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 pt-2">
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium">
                <FiGlobe className="h-4 w-4 text-blue-500" />
                <span>Environment</span>
              </label>
              <Select value={environment} onValueChange={setEnvironment}>
                <SelectTrigger className="bg-white/80 dark:bg-gray-800/80 border border-blue-100 dark:border-blue-900/30 focus:ring-blue-500">
                  <SelectValue placeholder="All environments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All environments</SelectItem>
                  {environmentRatings.map((env) => (
                    <SelectItem key={env} value={env}>
                      {env}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium">
                <FiClock className="h-4 w-4 text-indigo-500" />
                <span>Years Active</span>
              </label>
              <Select value={yearsActive} onValueChange={setYearsActive}>
                <SelectTrigger className="bg-white/80 dark:bg-gray-800/80 border border-indigo-100 dark:border-indigo-900/30 focus:ring-indigo-500">
                  <SelectValue placeholder="Any timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any timeframe</SelectItem>
                  {yearsActiveOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium">
                <Flag className="h-4 w-4 text-violet-500" />
                <span>Country</span>
              </label>
              <Select value={country} onValueChange={setCountry}>
                <SelectTrigger className="bg-white/80 dark:bg-gray-800/80 border border-violet-100 dark:border-violet-900/30 focus:ring-violet-500">
                  <SelectValue placeholder="All countries" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All countries</SelectItem>
                  {countries.map((country) => (
                    <SelectItem key={country} value={country}>
                      {country}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium">
                <FiArrowUp className="h-4 w-4 text-purple-500" />
                <span>Sort By</span>
              </label>
              <Select
                value={`${sort.field}-${sort.direction}`}
                onValueChange={(value) => {
                  const [field, direction] = value.split("-") as [
                    string,
                    "asc" | "desc"
                  ];
                  setSort({ field, direction });
                }}
              >
                <SelectTrigger className="bg-white/80 dark:bg-gray-800/80 border border-purple-100 dark:border-purple-900/30 focus:ring-purple-500">
                  <SelectValue placeholder="Score (High to Low)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="score-desc">
                    Score (High to Low)
                  </SelectItem>
                  <SelectItem value="score-asc">Score (Low to High)</SelectItem>
                  <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                  <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                  <SelectItem value="yearsActive-desc">
                    Years Active (Most)
                  </SelectItem>
                  <SelectItem value="yearsActive-asc">
                    Years Active (Least)
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Broker listings */}
        <div className="grid grid-cols-1 gap-6">
          {brokersLoading ? (
            // Loading skeletons
            Array.from({ length: 5 }).map((_, index) => (
              <Card key={index} className="overflow-hidden border-0 shadow-lg">
                <div className="h-24 bg-gradient-to-r from-blue-300/40 to-indigo-300/40 dark:from-blue-700/40 dark:to-indigo-700/40 animate-pulse" />
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6 w-full">
                    <div className="flex-shrink-0 -mt-12 flex items-center justify-center">
                      <Skeleton className="h-16 w-16 rounded-xl shadow-md" />
                    </div>
                    <div className="flex-grow space-y-3 min-w-0">
                      <Skeleton className="h-7 w-48" />
                      <div className="flex gap-3">
                        <Skeleton className="h-5 w-24" />
                        <Skeleton className="h-5 w-28" />
                        <Skeleton className="h-5 w-32" />
                      </div>
                      <div className="flex gap-3">
                        <Skeleton className="h-10 w-32 rounded-md" />
                        <Skeleton className="h-10 w-32 rounded-md" />
                      </div>
                      <Skeleton className="h-5 w-64" />
                    </div>
                    <div className="flex-shrink-0 flex items-center space-x-2">
                      <Skeleton className="h-10 w-28" />
                      <Skeleton className="h-10 w-28" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : brokers && brokers.length > 0 ? (
            brokers.map((broker) => (
              <Card
                key={broker.id}
                className="overflow-hidden group relative shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-md transition-shadow duration-300"
              >
                {/* COMPLETELY REDESIGNED BROKER CARD */}
                <div className="relative">
                  {/* Clean top section with solid color */}
                  <div className="bg-blue-600 h-14 relative">
                    {/* Score badge */}
                    <div className="absolute right-4 top-4 z-10">
                      <div className="bg-gradient-to-r from-amber-500 to-yellow-400 text-white font-bold rounded-full px-2.5 py-1 flex items-center gap-1 shadow-lg">
                        <span>
                          {getRating(broker.id).toString() === "0"
                            ? "0.0"
                            : typeof getRating(broker.id) === "number"
                            ? getRating(broker.id).toFixed(1)
                            : parseFloat(String(getRating(broker.id))).toFixed(
                                1
                              )}
                        </span>
                        <span className="text-xs">/5</span>
                        <FiStar className="h-4 w-4 fill-white" />
                      </div>
                    </div>

                    {/* Tags on top section */}
                    <div className="absolute left-24 top-4 flex flex-wrap gap-1.5 max-w-[50%]">
                      {broker.tags &&
                        broker.tags.map((tag) => (
                          <Badge
                            key={tag}
                            className="bg-white/90 text-blue-700 border-0 text-xs px-2 py-0.5 shadow-sm"
                          >
                            {tag}
                          </Badge>
                        ))}
                      {broker.regulators && broker.regulators.length > 0 && (
                        <Badge className="bg-white/90 text-blue-700 border-0 text-xs px-2 py-0.5 flex items-center gap-1 shadow-sm">
                          <FiLock className="h-3 w-3" /> Regulated
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Logo positioned at the left side */}
                  <div className="absolute left-6 top-6">
                    <div className="w-16 h-16 rounded-lg bg-white border-2 border-white shadow-lg flex items-center justify-center overflow-hidden">
                      {broker.logoUrl ? (
                        <img
                          src={broker.logoUrl}
                          alt={`${broker.name} logo`}
                          className="w-12 h-12 object-contain"
                        />
                      ) : (
                        <span className="text-xl font-bold text-blue-600">
                          {broker.name.substring(0, 2).toUpperCase()}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Main content area */}
                  <div className="px-6 py-6">
                    {/* Broker name and basic info */}
                    <div className="ml-24 mb-5">
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                        {broker.name}
                      </h3>
                      <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm gap-x-5 gap-y-1 flex-wrap mt-2">
                        <div className="flex items-center gap-1.5">
                          <Flag className="h-3.5 w-3.5 text-blue-600" />
                          <span>{broker.country}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <FiClock className="h-3.5 w-3.5 text-blue-600" />
                          <span>
                            {broker.yearsActive.includes("years")
                              ? broker.yearsActive
                              : `Above ${broker.yearsActive} years`}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                      {/* Details - Left side */}
                      <div className="md:col-span-7">
                        <div className="space-y-4">
                          {broker.environment && broker.environment !== "—" && (
                            <div className="text-sm text-gray-600 dark:text-gray-300 flex items-start gap-2.5">
                              <div className="h-7 w-7 rounded-full bg-blue-50 dark:bg-blue-900/30 flex-shrink-0 flex items-center justify-center">
                                <FiGlobe className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                              </div>
                              <div className="pt-0.5">
                                <span className="font-medium text-gray-700 dark:text-gray-300">
                                  Environment:
                                </span>
                                <span className="ml-1">
                                  {broker.environment}
                                </span>
                              </div>
                            </div>
                          )}

                          {broker.regulators &&
                            broker.regulators.length > 0 && (
                              <div>
                                <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 flex items-center gap-2.5">
                                  <div className="h-7 w-7 rounded-full bg-blue-50 dark:bg-blue-900/30 flex-shrink-0 flex items-center justify-center">
                                    <FiLock className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                                  </div>
                                  <span className="pt-0.5">Regulated by:</span>
                                </div>
                                <div className="flex flex-wrap gap-1.5 ml-10">
                                  {broker.regulators.map((regulator) => (
                                    <span
                                      key={regulator}
                                      className="inline-flex items-center bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-md px-2 py-0.5 text-xs"
                                    >
                                      {regulator}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}

                          {broker.description && (
                            <div className="flex gap-2.5">
                              <div className="h-7 w-7 rounded-full bg-blue-50 dark:bg-blue-900/30 flex-shrink-0 flex items-center justify-center mt-0.5">
                                <FiInfo className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 pt-0.5">
                                {broker.description}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Actions - Right side */}
                      <div className="md:col-span-5 flex flex-col justify-center gap-3 mt-2 md:mt-0">
                        <Link href={`/brokers/${broker.id}`} className="w-full">
                          <Button
                            variant="outline"
                            className="w-full border-gray-200 dark:border-gray-700 hover:border-blue-400 hover:text-blue-600 dark:hover:border-blue-500 dark:hover:text-blue-400 transition-colors"
                          >
                            <span className="flex items-center">
                              <FiInfo className="mr-2 h-4 w-4" />
                              See Details
                            </span>
                          </Button>
                        </Link>
                        {broker.websiteUrl && (
                          <a
                            href={broker.websiteUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-full"
                          >
                            <Button className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 transition-all duration-200">
                              <span className="flex items-center">
                                <FiExternalLink className="mr-2 h-4 w-4" />
                                Visit Website
                              </span>
                            </Button>
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <div className="text-center py-16 bg-white/70 dark:bg-gray-900/70 backdrop-blur-sm rounded-2xl border border-gray-200/50 dark:border-gray-700/50 shadow-lg">
              <div className="inline-block p-4 rounded-full bg-blue-50 dark:bg-blue-900/30 mb-5">
                <FiInfo className="h-8 w-8 text-blue-500 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3">No brokers found</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md mx-auto">
                Try adjusting your filter criteria to see more results or reset
                filters to view all brokers.
              </p>
              <Button
                variant="outline"
                className="bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900/20"
                onClick={() => {
                  setEnvironment("");
                  setYearsActive("");
                  setCountry("");
                  setSort({ field: "score", direction: "desc" });
                }}
              >
                <FiRefreshCw className="mr-2 h-4 w-4" />
                Reset All Filters
              </Button>
            </div>
          )}
        </div>

        {/* Custom animation for pulse slow */}
        <style
          dangerouslySetInnerHTML={{
            __html: `
        @keyframes pulse-slow {
          0%, 100% { opacity: 0.7; }
          50% { opacity: 0.9; }
        }
        .animate-pulse-slow {
          animation: pulse-slow 3s ease-in-out infinite;
        }
      `,
          }}
        />

        {/* Floating Action Button */}
        <div className="fixed bottom-8 right-8 z-50">
          <div className="flex flex-col gap-3">
            <Button
              className="rounded-full h-14 w-14 shadow-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 p-0"
              onClick={() => {
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
            >
              <FiArrowUp className="h-6 w-6" />
            </Button>
            <Button
              className="rounded-full h-14 w-14 shadow-lg bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 p-0"
              onClick={() =>
                toast({
                  title: "Coming Soon!",
                  description: "Broker comparison tool will be available soon.",
                })
              }
            >
              <FiRefreshCw className="h-6 w-6" />
            </Button>
            <Button
              className="rounded-full h-14 w-14 shadow-lg bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 p-0"
              onClick={() =>
                toast({
                  title: "Information",
                  description:
                    "These are the top regulated brokers selected by our expert team.",
                })
              }
            >
              <FiInfo className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}