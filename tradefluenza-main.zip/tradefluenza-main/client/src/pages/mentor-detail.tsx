import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookingForm } from "@/components/mentors/BookingForm";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Loader2, Calendar, MessageCircle, Star, ChevronLeft } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";

// Placeholder avatar component
const UserAvatar = ({ name, image }: { name: string; image?: string }) => (
  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
    {image ? (
      <img src={image} alt={name} className="h-full w-full object-cover" />
    ) : (
      <span className="text-lg font-semibold text-gray-500">{name.charAt(0)}</span>
    )}
  </div>
);

// Star rating component
const StarRating = ({ rating }: { rating: number }) => {
  return (
    <div className="flex">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={`h-4 w-4 ${
            star <= rating ? "text-amber-500 fill-amber-500" : "text-gray-300"
          }`}
        />
      ))}
    </div>
  );
};

// Review form component
const ReviewForm = ({ mentorId, onSuccess }: { mentorId: number; onSuccess: () => void }) => {
  const [rating, setRating] = useState(5);
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const reviewMutation = useMutation({
    mutationFn: async (data: {
      title: string;
      content: string;
      rating: number;
      mentorId: number;
    }) => {
      const res = await apiRequest("POST", "/api/mentor-reviews", data);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to submit review");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/mentors/${mentorId}/reviews`] });
      setIsOpen(false);
      setRating(5);
      setContent("");
      setTitle("");
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Error submitting review",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to leave a review",
        variant: "destructive",
      });
      return;
    }

    if (!title.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide a title for your review",
        variant: "destructive",
      });
      return;
    }

    if (!content.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide content for your review",
        variant: "destructive",
      });
      return;
    }

    reviewMutation.mutate({
      title,
      content,
      rating,
      mentorId,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="ml-auto">
          Write a Review
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Write a Review</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="rating">Rating</Label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Button
                  key={star}
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="p-0 h-auto"
                  onClick={() => setRating(star)}
                >
                  <Star
                    className={`h-6 w-6 ${
                      star <= rating ? "text-amber-500 fill-amber-500" : "text-gray-300"
                    }`}
                  />
                </Button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              placeholder="Summarize your experience"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="content">Review</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
              placeholder="Tell others about your experience with this mentor"
              rows={5}
            />
          </div>
          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={reviewMutation.isPending}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700"
            >
              {reviewMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Review"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

// Mentor skills component
const MentorSkills = ({ skills }: { skills: string[] }) => (
  <div className="flex flex-wrap gap-2 mt-4">
    {skills.map((skill) => (
      <Badge key={skill} variant="secondary" className="text-xs py-1">
        {skill}
      </Badge>
    ))}
  </div>
);

// Mentor review component
const MentorReview = ({ review }: { review: any }) => (
  <Card className="p-4 mb-4 hover:shadow-md transition-shadow">
    <div className="flex items-start">
      <UserAvatar name={review.username || "User"} image={review.userAvatar} />
      <div className="ml-3 flex-1">
        <div className="flex justify-between items-center">
          <h4 className="font-medium">{review.username || "User"}</h4>
          <span className="text-gray-500 text-xs">{formatDate(review.createdAt)}</span>
        </div>
        <StarRating rating={review.rating} />
        <h3 className="font-semibold mt-2">{review.title || "Review"}</h3>
        <p className="mt-1 text-gray-700 text-sm">{review.content || review.comment}</p>
      </div>
    </div>
  </Card>
);

// Main mentor detail page component
export default function MentorDetailPage() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [bookingOpen, setBookingOpen] = useState(false);
  const mentorId = parseInt(params.id);
  const [activeTab, setActiveTab] = useState("about");

  // Fetch mentor details
  const {
    data: mentor,
    isLoading,
    error,
  } = useQuery({
    queryKey: [`/api/mentors/${mentorId}`],
    queryFn: async () => {
      const res = await fetch(`/api/mentors/${mentorId}`);
      if (!res.ok) throw new Error("Failed to fetch mentor details");
      return res.json();
    },
  });

  // Fetch mentor reviews
  const {
    data: reviews,
    isLoading: isLoadingReviews,
    refetch: refetchReviews,
  } = useQuery({
    queryKey: [`/api/mentors/${mentorId}/reviews`],
    queryFn: async () => {
      const res = await fetch(`/api/mentors/${mentorId}/reviews`);
      if (!res.ok) throw new Error("Failed to fetch reviews");
      const data = await res.json();
      // Handle both array responses and paginated data responses
      return Array.isArray(data) ? data : (data.data || []);
    },
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md">
          <p>Error: {(error as Error).message}</p>
          <Button 
            variant="outline" 
            className="mt-4" 
            onClick={() => setLocation("/mentors")}
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Mentors
          </Button>
        </div>
      </div>
    );
  }

  if (!mentor) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Button 
        variant="ghost" 
        className="mb-6" 
        onClick={() => setLocation("/mentors")}
      >
        <ChevronLeft className="h-4 w-4 mr-2" />
        Back to Mentors
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column: Mentor profile */}
        <div className="lg:col-span-2">
          <div className="flex flex-col md:flex-row items-start gap-6">
            <div className="relative">
              <img
                src={mentor.profileImage || "https://via.placeholder.com/200"}
                alt={mentor.name}
                className="w-32 h-32 md:w-48 md:h-48 rounded-full object-cover border-4 border-cyan-500"
                onError={(e) => {
                  e.currentTarget.src = `https://via.placeholder.com/200?text=${mentor.name.charAt(0)}`;
                }}
              />
              {mentor.isVerified && (
                <Badge className="absolute bottom-2 right-2 bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-100">
                  Verified
                </Badge>
              )}
            </div>

            <div className="flex-1">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h1 className="text-3xl font-bold">{mentor.name}</h1>
                  <div className="flex items-center mt-2">
                    <StarRating rating={mentor.rating || 5} />
                    <span className="ml-2 text-sm font-medium">
                      {mentor.rating || 5}.0 ({reviews?.length || 0} reviews)
                    </span>
                    <span className="mx-2 text-gray-400">•</span>
                    <span className="text-sm text-gray-600">
                      {mentor.experience} years experience
                    </span>
                  </div>
                  
                  <p className="mt-2 text-lg font-medium text-gray-700">
                    {mentor.location || "Worldwide"} 
                    <span className="mx-2 text-gray-400">•</span>
                    <span className="text-lg font-medium text-cyan-600">${mentor.hourlyRate}/hr</span>
                  </p>
                </div>
                
                <div className="mt-4 md:mt-0 flex flex-col sm:flex-row gap-2">
                  <Button 
                    onClick={() => setBookingOpen(true)}
                    className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700"
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Book Session
                  </Button>
                  
                  <Button variant="outline">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Message
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
            <TabsList className="grid w-full md:w-auto grid-cols-2 md:inline-flex">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="reviews">
                Reviews ({reviews?.length || 0})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="about" className="mt-6">
              <div>
                <h2 className="text-xl font-semibold mb-4">About {mentor.name}</h2>
                <p className="text-gray-700">{mentor.bio}</p>
                
                <h3 className="text-lg font-semibold mt-6 mb-3">Specializations</h3>
                <MentorSkills 
                  skills={[
                    mentor.specialization, 
                    mentor.experienceLevel,
                    mentor.tradingStyle || "Various Trading Styles",
                    ...(mentor.expertise || [])
                  ]} 
                />
                
                <h3 className="text-lg font-semibold mt-6 mb-3">Languages</h3>
                <p className="text-gray-700">{mentor.languages || "English"}</p>
                
                <h3 className="text-lg font-semibold mt-6 mb-3">Education & Certifications</h3>
                <p className="text-gray-700">{mentor.education || "Professional trading experience and certifications"}</p>
                
                <h3 className="text-lg font-semibold mt-6 mb-3">Mentoring Style</h3>
                <p className="text-gray-700">{mentor.mentoringStyle || "Personalized coaching tailored to individual trader needs."}</p>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold">
                  Reviews ({reviews?.length || 0})
                </h2>
                <ReviewForm mentorId={mentorId} onSuccess={refetchReviews} />
              </div>
              
              {isLoadingReviews ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : reviews?.length > 0 ? (
                <div>
                  {reviews.map((review: any) => (
                    <MentorReview key={review.id} review={review} />
                  ))}
                </div>
              ) : (
                <div className="bg-gray-50 dark:bg-gray-800/40 rounded-lg p-6 text-center">
                  <p className="text-gray-500">No reviews yet. Be the first to review!</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Right column: Booking sidebar */}
        <div className="lg:col-span-1">
          <Card className="p-6 sticky top-20">
            <h3 className="text-lg font-semibold mb-4">Book a Session</h3>
            <p className="text-gray-600 mb-6">
              Direct one-on-one mentoring session with {mentor.name}
            </p>
            
            <div className="flex items-center justify-between mb-4">
              <span className="font-medium">Hourly Rate</span>
              <span className="text-xl font-bold text-cyan-600">${mentor.hourlyRate}</span>
            </div>
            
            <Separator className="mb-4" />
            
            <div className="space-y-2 mb-6">
              <div className="flex justify-between">
                <span>Session Types</span>
                <span className="text-gray-600">Starting at 1 hour</span>
              </div>
              <div className="flex justify-between">
                <span>Availability</span>
                <span className="text-gray-600">Book up to 3 weeks in advance</span>
              </div>
              <div className="flex justify-between">
                <span>Languages</span>
                <span className="text-gray-600">{mentor.languages || "English"}</span>
              </div>
            </div>
            
            <Button 
              onClick={() => setBookingOpen(true)}
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Book a Session
            </Button>
            
            <p className="text-xs text-gray-500 mt-4 text-center">
              You won't be charged until after your session is confirmed
            </p>
          </Card>
        </div>
      </div>

      {/* Booking Dialog */}
      <Dialog open={bookingOpen} onOpenChange={setBookingOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Book a Session with {mentor.name}</DialogTitle>
          </DialogHeader>
          <BookingForm
            mentorId={mentorId}
            onClose={() => setBookingOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}