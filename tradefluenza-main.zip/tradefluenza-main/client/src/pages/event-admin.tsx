import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWebsocket } from "@/hooks/use-websocket";
import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar, ClipboardEdit, Trash2, Plus, Loader2, RefreshCw, ExternalLink } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

// Define speaker schema
const speakerSchema = z.object({
  name: z.string().min(2, "Speaker name is required"),
  title: z.string().min(2, "Speaker title is required"),
  bio: z.string().min(10, "Speaker bio is required"),
  imageUrl: z.string().optional()
});

// Define agenda item schema
const agendaItemSchema = z.object({
  time: z.string().min(2, "Time is required"),
  title: z.string().min(2, "Title is required"),
  description: z.string().min(10, "Description is required"),
  speaker: z.string().optional()
});

// Define validation schema
const eventSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  fullDescription: z.string().min(20, "Full description must be at least 20 characters"),
  date: z.string().min(3, "Date is required"),
  location: z.string().min(3, "Location is required"),
  locationDetails: z.string().optional(),
  attendees: z.string().optional(),
  type: z.string().min(1, "Type is required"),
  imageUrl: z.string().optional(),
  registrationUrl: z.string().optional(),
  speakersList: z.array(speakerSchema).optional(),
  agenda: z.array(agendaItemSchema).optional(),
  isPremium: z.boolean().default(false),
  price: z.number().optional(),
  maxAttendees: z.number().optional(),
  status: z.string().min(1, "Status is required"),
  bgClass: z.string().default("from-indigo-600 to-blue-600"),
  featured: z.boolean().default(false),
  organizer: z.string().default("Tradefluenza")
});

type EventFormData = z.infer<typeof eventSchema>;

// Speaker interface
interface Speaker {
  name: string;
  title: string;
  bio: string;
  imageUrl?: string;
}

// Agenda item interface
interface AgendaItem {
  time: string;
  title: string;
  description: string;
  speaker?: string;
}

// Interface for event data
interface Event {
  id: number;
  title: string;
  description: string;
  fullDescription: string;
  date: string;
  location: string;
  locationDetails?: string;
  attendees?: string;
  type: string;
  imageUrl?: string;
  registrationUrl?: string;
  speakersList?: Speaker[];
  agenda?: AgendaItem[];
  isPremium: boolean;
  price?: number;
  maxAttendees?: number;
  currentAttendees: number;
  status: string;
  bgClass: string;
  featured: boolean;
  organizer: string;
}

const EVENT_TYPES = [
  "Meetup",
  "Workshop",
  "Conference",
  "Webinar",
  "Virtual Tour",
  "Training",
  "Networking",
  "Competition"
];

const EVENT_STATUSES = [
  "Upcoming",
  "Ongoing",
  "Completed",
  "Cancelled"
];

const BG_CLASSES = [
  "from-indigo-600 to-blue-600",
  "from-purple-600 to-blue-600",
  "from-pink-600 to-purple-600", 
  "from-red-600 to-orange-600",
  "from-orange-600 to-yellow-600",
  "from-emerald-600 to-teal-600",
  "from-teal-600 to-sky-600",
  "from-fuchsia-600 to-violet-600",
  "from-violet-600 to-indigo-600",
  "from-slate-800 to-slate-600"
];

export default function EventAdmin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { isConnected } = useWebsocket();
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [eventToDelete, setEventToDelete] = useState<Event | null>(null);
  const [speakersList, setSpeakersList] = useState<Speaker[]>([]);
  const [editingSpeaker, setEditingSpeaker] = useState<Speaker | null>(null);
  const [showSpeakerDialog, setShowSpeakerDialog] = useState(false);
  const [agenda, setAgenda] = useState<AgendaItem[]>([]);
  const [editingAgendaItem, setEditingAgendaItem] = useState<AgendaItem | null>(null);
  const [showAgendaDialog, setShowAgendaDialog] = useState(false);
  
  // Fetch events
  const { data: events, isLoading, isError, refetch } = useQuery<Event[]>({
    queryKey: ['/api/events'],
    queryFn: async () => {
      const response = await fetch('/api/events');
      if (!response.ok) {
        throw new Error('Failed to fetch events');
      }
      return response.json();
    }
  });
  
  // Create form
  const createForm = useForm<EventFormData>({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      title: '',
      description: '',
      fullDescription: '',
      date: '',
      location: '',
      type: 'Meetup',
      isPremium: false,
      status: 'Upcoming',
      bgClass: 'from-indigo-600 to-blue-600',
      featured: false,
      organizer: 'Tradefluenza'
    }
  });
  
  // Edit form
  const editForm = useForm<EventFormData>({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      title: '',
      description: '',
      fullDescription: '',
      date: '',
      location: '',
      type: 'Meetup',
      isPremium: false,
      status: 'Upcoming',
      bgClass: 'from-indigo-600 to-blue-600',
      featured: false,
      organizer: 'Tradefluenza'
    }
  });
  
  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (data: EventFormData) => {
      const res = await apiRequest('POST', '/api/events', data);
      if (!res.ok) {
        throw new Error('Failed to create event');
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Event Created',
        description: 'The event was created successfully.',
        variant: 'default',
      });
      setIsCreateDialogOpen(false);
      createForm.reset();
      
      // The WebSocket system will automatically update the UI
      // but we'll also refetch as a fallback
      setTimeout(() => {
        refetch();
      }, 1000);
    },
    onError: (error: Error) => {
      toast({
        title: 'Creation Failed',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
  
  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: EventFormData }) => {
      console.log('Submitting update for event ID:', id, 'with data:', data);
      
      try {
        const res = await apiRequest('PATCH', `/api/events/${id}`, data);
        console.log('Update response status:', res.status);
        
        const responseText = await res.text();
        console.log('Update response text:', responseText);
        
        if (!res.ok) {
          throw new Error(`Failed to update event: ${responseText}`);
        }
        
        // Try to parse the response as JSON if it's not empty
        let jsonData = {};
        if (responseText.trim()) {
          try {
            jsonData = JSON.parse(responseText);
          } catch (e) {
            console.error('Error parsing JSON response:', e);
          }
        }
        
        return jsonData;
      } catch (error) {
        console.error('Error in update mutation:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log('Update successful, response data:', data);
      toast({
        title: 'Event Updated',
        description: 'The event was updated successfully.',
        variant: 'default',
      });
      setIsEditDialogOpen(false);
      setEditingEvent(null);
      
      // The WebSocket system will automatically update the UI
      // but we'll also refetch as a fallback
      setTimeout(() => {
        refetch();
      }, 1000);
    },
    onError: (error: Error) => {
      console.error('Update mutation error callback:', error);
      toast({
        title: 'Update Failed',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
  
  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/events/${id}`);
      if (!res.ok) {
        throw new Error('Failed to delete event');
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Event Deleted',
        description: 'The event was deleted successfully.',
        variant: 'default',
      });
      setEventToDelete(null);
      
      // The WebSocket system will automatically update the UI
      // but we'll also refetch as a fallback
      setTimeout(() => {
        refetch();
      }, 1000);
    },
    onError: (error: Error) => {
      toast({
        title: 'Deletion Failed',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
  
  // Handle create form submission
  const onCreateSubmit = (data: EventFormData) => {
    createMutation.mutate(data);
  };
  
  // Handle edit form submission
  const onEditSubmit = (data: EventFormData) => {
    console.log('Edit form submitted with data:', data);
    
    if (editingEvent) {
      console.log('Editing event ID:', editingEvent.id);
      try {
        updateMutation.mutate({ id: editingEvent.id, data });
      } catch (error) {
        console.error('Error during update mutation:', error);
      }
    } else {
      console.error('No editing event found!');
    }
  };
  
  // Set up editing event
  useEffect(() => {
    if (editingEvent) {
      editForm.reset({
        title: editingEvent.title,
        description: editingEvent.description,
        fullDescription: editingEvent.fullDescription,
        date: editingEvent.date,
        location: editingEvent.location,
        locationDetails: editingEvent.locationDetails || '',
        attendees: editingEvent.attendees || '',
        type: editingEvent.type,
        imageUrl: editingEvent.imageUrl || '',
        registrationUrl: editingEvent.registrationUrl || '',
        speakersList: editingEvent.speakersList || [],
        agenda: editingEvent.agenda || [],
        isPremium: editingEvent.isPremium,
        price: editingEvent.price || undefined,
        maxAttendees: editingEvent.maxAttendees || undefined,
        status: editingEvent.status,
        bgClass: editingEvent.bgClass,
        featured: editingEvent.featured,
        organizer: editingEvent.organizer
      });
    }
  }, [editingEvent, editForm]);
  
  // Render WebSocket status
  const renderWebSocketStatus = () => {
    return (
      <div className="flex items-center gap-2 text-sm font-medium">
        <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
        <span>{isConnected ? 'WebSocket Connected' : 'WebSocket Disconnected'}</span>
      </div>
    );
  };
  
  if (isLoading) {
    return (
      <div className="container py-10 flex flex-col items-center justify-center min-h-[60vh]">
        <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
        <p className="text-lg">Loading events...</p>
      </div>
    );
  }
  
  if (isError) {
    return (
      <div className="container py-10 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-200 p-4 rounded-lg mb-6">
          <p className="text-lg font-medium">Error loading events</p>
          <p>There was a problem fetching the event data. Please try again.</p>
        </div>
        <Button onClick={() => refetch()}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Try Again
        </Button>
      </div>
    );
  }
  
  return (
    <div className="container py-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Event Management</h1>
          <p className="text-muted-foreground">Create, update, and delete events with real-time WebSocket updates</p>
        </div>
        <div className="flex items-center gap-4">
          {renderWebSocketStatus()}
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Create New Event
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {events && events.map((event) => (
          <Card key={event.id} className="overflow-hidden border-2 hover:border-primary/40 transition-colors">
            <CardHeader className={`bg-gradient-to-br ${event.bgClass} text-white p-6`}>
              <div className="flex justify-between items-start mb-2">
                <Badge className="bg-white/20 text-white hover:bg-white/30">{event.type}</Badge>
                <div className="flex gap-2">
                  <Button variant="secondary" size="icon" className="h-8 w-8 rounded-full bg-white/20 hover:bg-white/30 text-white" onClick={() => {
                    setEditingEvent(event);
                    setIsEditDialogOpen(true);
                  }}>
                    <ClipboardEdit className="h-4 w-4" />
                  </Button>
                  <Button variant="destructive" size="icon" className="h-8 w-8 rounded-full bg-white/20 hover:bg-red-500/80 text-white" onClick={() => setEventToDelete(event)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <CardTitle className="text-xl">{event.title}</CardTitle>
              <CardDescription className="text-white/90">{event.description}</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>{event.date}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Badge variant={
                    event.status === 'Upcoming' ? 'default' :
                    event.status === 'Ongoing' ? 'secondary' :
                    event.status === 'Completed' ? 'outline' :
                    'destructive'
                  }>
                    {event.status}
                  </Badge>
                  {event.featured && <Badge variant="outline">Featured</Badge>}
                  {event.isPremium && <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-900/30 dark:text-amber-400 dark:border-amber-800">Premium</Badge>}
                </div>
                {event.currentAttendees > 0 && (
                  <div className="text-sm">
                    <span className="font-medium">Current Attendees:</span> {event.currentAttendees}
                    {event.maxAttendees && <span> / {event.maxAttendees}</span>}
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="border-t p-4 bg-muted/30">
              <Button variant="outline" className="w-full" asChild>
                <a href={`/events/${event.id}`} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Event Page
                </a>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      {/* Create Event Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Event</DialogTitle>
            <DialogDescription>
              Add a new event to the platform. All fields marked with * are required.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-6 py-4">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid grid-cols-5 mb-4">
                <TabsTrigger value="basic">Basic Info</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="speakers">Speakers</TabsTrigger>
                <TabsTrigger value="agenda">Agenda</TabsTrigger>
                <TabsTrigger value="appearance">Appearance</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Title *</Label>
                    <Input 
                      id="title" 
                      placeholder="Event title" 
                      {...createForm.register('title')} 
                      className={createForm.formState.errors.title ? "border-red-500" : ""}
                    />
                    {createForm.formState.errors.title && (
                      <p className="text-red-500 text-xs">{createForm.formState.errors.title.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Event Type *</Label>
                    <Select 
                      defaultValue={createForm.getValues('type')} 
                      onValueChange={(value) => createForm.setValue('type', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {EVENT_TYPES.map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Short Description *</Label>
                  <Textarea 
                    id="description" 
                    placeholder="Brief description of the event" 
                    {...createForm.register('description')} 
                    className={createForm.formState.errors.description ? "border-red-500" : ""}
                  />
                  {createForm.formState.errors.description && (
                    <p className="text-red-500 text-xs">{createForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fullDescription">Full Description *</Label>
                  <Textarea 
                    id="fullDescription" 
                    placeholder="Detailed description with markdown support" 
                    rows={6}
                    {...createForm.register('fullDescription')} 
                    className={createForm.formState.errors.fullDescription ? "border-red-500" : ""}
                  />
                  {createForm.formState.errors.fullDescription && (
                    <p className="text-red-500 text-xs">{createForm.formState.errors.fullDescription.message}</p>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Date *</Label>
                    <Input 
                      id="date" 
                      placeholder="e.g., May 15-16, 2025" 
                      {...createForm.register('date')} 
                      className={createForm.formState.errors.date ? "border-red-500" : ""}
                    />
                    {createForm.formState.errors.date && (
                      <p className="text-red-500 text-xs">{createForm.formState.errors.date.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Location *</Label>
                    <Input 
                      id="location" 
                      placeholder="e.g., New York, Online, etc." 
                      {...createForm.register('location')} 
                      className={createForm.formState.errors.location ? "border-red-500" : ""}
                    />
                    {createForm.formState.errors.location && (
                      <p className="text-red-500 text-xs">{createForm.formState.errors.location.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">Status *</Label>
                    <Select 
                      defaultValue={createForm.getValues('status')} 
                      onValueChange={(value) => createForm.setValue('status', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        {EVENT_STATUSES.map(status => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="organizer">Organizer</Label>
                    <Input 
                      id="organizer" 
                      placeholder="Event organizer" 
                      {...createForm.register('organizer')} 
                    />
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="details" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="locationDetails">Location Details</Label>
                  <Textarea 
                    id="locationDetails" 
                    placeholder="Additional location information" 
                    {...createForm.register('locationDetails')} 
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="attendees">Expected Attendees</Label>
                    <Input 
                      id="attendees" 
                      placeholder="e.g., 500+ Traders" 
                      {...createForm.register('attendees')} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxAttendees">Maximum Attendees</Label>
                    <Input 
                      id="maxAttendees" 
                      type="number" 
                      placeholder="e.g., 200" 
                      {...createForm.register('maxAttendees', { valueAsNumber: true })} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="imageUrl">Image URL</Label>
                    <Input 
                      id="imageUrl" 
                      placeholder="URL to event image" 
                      {...createForm.register('imageUrl')} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="registrationUrl">External Registration URL</Label>
                    <Input 
                      id="registrationUrl" 
                      placeholder="URL for external registration" 
                      {...createForm.register('registrationUrl')} 
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="isPremium">Premium Event</Label>
                      <p className="text-sm text-muted-foreground">Is this a paid event?</p>
                    </div>
                    <Switch 
                      id="isPremium" 
                      checked={createForm.watch('isPremium')}
                      onCheckedChange={(checked) => createForm.setValue('isPremium', checked)}
                    />
                  </div>
                  
                  {createForm.watch('isPremium') && (
                    <div className="space-y-2">
                      <Label htmlFor="price">Price</Label>
                      <Input 
                        id="price" 
                        type="number" 
                        placeholder="e.g., 299.99" 
                        {...createForm.register('price', { valueAsNumber: true })} 
                      />
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="speakers" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-lg font-medium">Speakers</h3>
                    <p className="text-sm text-muted-foreground">Add speakers for this event</p>
                  </div>
                  <Button 
                    type="button" 
                    onClick={() => {
                      setEditingSpeaker(null);
                      setShowSpeakerDialog(true);
                    }}
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Speaker
                  </Button>
                </div>

                {speakersList.length === 0 ? (
                  <div className="p-8 text-center border rounded-md bg-muted/40">
                    <p className="text-muted-foreground">No speakers added yet</p>
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => {
                        setEditingSpeaker(null);
                        setShowSpeakerDialog(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add First Speaker
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {speakersList.map((speaker, index) => (
                      <Card key={index} className="overflow-hidden">
                        <div className="flex items-start p-4">
                          <div className="flex-1">
                            <h4 className="font-semibold">{speaker.name}</h4>
                            <p className="text-sm text-muted-foreground">{speaker.title}</p>
                            <p className="text-sm mt-2">{speaker.bio}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setEditingSpeaker(speaker);
                                setShowSpeakerDialog(true);
                              }}
                            >
                              <ClipboardEdit className="h-4 w-4" />
                            </Button>
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              className="text-destructive hover:text-destructive/80"
                              onClick={() => {
                                setSpeakersList(speakersList.filter((_, i) => i !== index));
                                createForm.setValue('speakersList', 
                                  speakersList.filter((_, i) => i !== index)
                                );
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="agenda" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-lg font-medium">Agenda</h3>
                    <p className="text-sm text-muted-foreground">Add the schedule for this event</p>
                  </div>
                  <Button 
                    type="button" 
                    onClick={() => {
                      setEditingAgendaItem(null);
                      setShowAgendaDialog(true);
                    }}
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Agenda Item
                  </Button>
                </div>

                {agenda.length === 0 ? (
                  <div className="p-8 text-center border rounded-md bg-muted/40">
                    <p className="text-muted-foreground">No agenda items added yet</p>
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => {
                        setEditingAgendaItem(null);
                        setShowAgendaDialog(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add First Agenda Item
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {agenda.map((item, index) => (
                      <Card key={index} className="overflow-hidden">
                        <div className="flex items-start p-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{item.time}</Badge>
                              <h4 className="font-semibold">{item.title}</h4>
                            </div>
                            <p className="text-sm mt-2">{item.description}</p>
                            {item.speaker && (
                              <p className="text-sm mt-1 text-muted-foreground">Speaker: {item.speaker}</p>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setEditingAgendaItem(item);
                                setShowAgendaDialog(true);
                              }}
                            >
                              <ClipboardEdit className="h-4 w-4" />
                            </Button>
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              className="text-destructive hover:text-destructive/80"
                              onClick={() => {
                                setAgenda(agenda.filter((_, i) => i !== index));
                                createForm.setValue('agenda', 
                                  agenda.filter((_, i) => i !== index)
                                );
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="appearance" className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="featured">Featured Event</Label>
                    <p className="text-sm text-muted-foreground">Show this event on the homepage</p>
                  </div>
                  <Switch 
                    id="featured" 
                    checked={createForm.watch('featured')}
                    onCheckedChange={(checked) => createForm.setValue('featured', checked)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Background Color</Label>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    {BG_CLASSES.map((bgClass) => (
                      <div 
                        key={bgClass}
                        onClick={() => createForm.setValue('bgClass', bgClass)}
                        className={`
                          bg-gradient-to-br ${bgClass} h-12 rounded-md cursor-pointer transition-all
                          ${createForm.watch('bgClass') === bgClass ? 'ring-2 ring-primary ring-offset-2' : 'opacity-70 hover:opacity-100'}
                        `}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="mt-6 p-6 bg-gradient-to-br rounded-lg border">
                  <h3 className="text-lg font-semibold mb-2">Preview</h3>
                  <div className={`bg-gradient-to-br ${createForm.watch('bgClass')} text-white p-4 rounded-lg`}>
                    <div className="mb-1">
                      <Badge className="bg-white/20 text-white hover:bg-white/30">
                        {createForm.watch('type')}
                      </Badge>
                    </div>
                    <h4 className="text-xl font-bold">{createForm.watch('title') || 'Event Title'}</h4>
                    <p className="text-white/90 text-sm">
                      {createForm.watch('description') || 'Event description will appear here'}
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsCreateDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>Create Event</>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Edit Event Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Event</DialogTitle>
            <DialogDescription>
              Update the details of this event. All fields marked with * are required.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-6 py-4">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid grid-cols-5 mb-4">
                <TabsTrigger value="basic">Basic Info</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="speakers">Speakers</TabsTrigger>
                <TabsTrigger value="agenda">Agenda</TabsTrigger>
                <TabsTrigger value="appearance">Appearance</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-title">Title *</Label>
                    <Input 
                      id="edit-title" 
                      placeholder="Event title" 
                      {...editForm.register('title')} 
                      className={editForm.formState.errors.title ? "border-red-500" : ""}
                    />
                    {editForm.formState.errors.title && (
                      <p className="text-red-500 text-xs">{editForm.formState.errors.title.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-type">Event Type *</Label>
                    <Select 
                      value={editForm.watch('type')} 
                      onValueChange={(value) => editForm.setValue('type', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {EVENT_TYPES.map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-description">Short Description *</Label>
                  <Textarea 
                    id="edit-description" 
                    placeholder="Brief description of the event" 
                    {...editForm.register('description')} 
                    className={editForm.formState.errors.description ? "border-red-500" : ""}
                  />
                  {editForm.formState.errors.description && (
                    <p className="text-red-500 text-xs">{editForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-fullDescription">Full Description *</Label>
                  <Textarea 
                    id="edit-fullDescription" 
                    placeholder="Detailed description with markdown support" 
                    rows={6}
                    {...editForm.register('fullDescription')} 
                    className={editForm.formState.errors.fullDescription ? "border-red-500" : ""}
                  />
                  {editForm.formState.errors.fullDescription && (
                    <p className="text-red-500 text-xs">{editForm.formState.errors.fullDescription.message}</p>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-date">Date *</Label>
                    <Input 
                      id="edit-date" 
                      placeholder="e.g., May 15-16, 2025" 
                      {...editForm.register('date')} 
                      className={editForm.formState.errors.date ? "border-red-500" : ""}
                    />
                    {editForm.formState.errors.date && (
                      <p className="text-red-500 text-xs">{editForm.formState.errors.date.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-location">Location *</Label>
                    <Input 
                      id="edit-location" 
                      placeholder="e.g., New York, Online, etc." 
                      {...editForm.register('location')} 
                      className={editForm.formState.errors.location ? "border-red-500" : ""}
                    />
                    {editForm.formState.errors.location && (
                      <p className="text-red-500 text-xs">{editForm.formState.errors.location.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-status">Status *</Label>
                    <Select 
                      value={editForm.watch('status')} 
                      onValueChange={(value) => editForm.setValue('status', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        {EVENT_STATUSES.map(status => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-organizer">Organizer</Label>
                    <Input 
                      id="edit-organizer" 
                      placeholder="Event organizer" 
                      {...editForm.register('organizer')} 
                    />
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="details" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-locationDetails">Location Details</Label>
                  <Textarea 
                    id="edit-locationDetails" 
                    placeholder="Additional location information" 
                    {...editForm.register('locationDetails')} 
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-attendees">Expected Attendees</Label>
                    <Input 
                      id="edit-attendees" 
                      placeholder="e.g., 500+ Traders" 
                      {...editForm.register('attendees')} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-maxAttendees">Maximum Attendees</Label>
                    <Input 
                      id="edit-maxAttendees" 
                      type="number" 
                      placeholder="e.g., 200" 
                      {...editForm.register('maxAttendees', { valueAsNumber: true })} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-imageUrl">Image URL</Label>
                    <Input 
                      id="edit-imageUrl" 
                      placeholder="URL to event image" 
                      {...editForm.register('imageUrl')} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-registrationUrl">External Registration URL</Label>
                    <Input 
                      id="edit-registrationUrl" 
                      placeholder="URL for external registration" 
                      {...editForm.register('registrationUrl')} 
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="edit-isPremium">Premium Event</Label>
                      <p className="text-sm text-muted-foreground">Is this a paid event?</p>
                    </div>
                    <Switch 
                      id="edit-isPremium" 
                      checked={editForm.watch('isPremium')}
                      onCheckedChange={(checked) => editForm.setValue('isPremium', checked)}
                    />
                  </div>
                  
                  {editForm.watch('isPremium') && (
                    <div className="space-y-2">
                      <Label htmlFor="edit-price">Price</Label>
                      <Input 
                        id="edit-price" 
                        type="number" 
                        placeholder="e.g., 299.99" 
                        {...editForm.register('price', { valueAsNumber: true })} 
                      />
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="speakers" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-lg font-medium">Speakers</h3>
                    <p className="text-sm text-muted-foreground">Add speakers for this event</p>
                  </div>
                  <Button 
                    type="button" 
                    onClick={() => {
                      setEditingSpeaker(null);
                      setShowSpeakerDialog(true);
                    }}
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Speaker
                  </Button>
                </div>

                {editForm.watch('speakersList')?.length === 0 ? (
                  <div className="p-8 text-center border rounded-md bg-muted/40">
                    <p className="text-muted-foreground">No speakers added yet</p>
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => {
                        setEditingSpeaker(null);
                        setShowSpeakerDialog(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add First Speaker
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {editForm.watch('speakersList')?.map((speaker, index) => (
                      <Card key={index} className="overflow-hidden">
                        <div className="flex items-start p-4">
                          <div className="flex-1">
                            <h4 className="font-semibold">{speaker.name}</h4>
                            <p className="text-sm text-muted-foreground">{speaker.title}</p>
                            <p className="text-sm mt-2">{speaker.bio}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setEditingSpeaker(speaker);
                                setShowSpeakerDialog(true);
                              }}
                            >
                              <ClipboardEdit className="h-4 w-4" />
                            </Button>
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              className="text-destructive hover:text-destructive/80"
                              onClick={() => {
                                const updatedSpeakers = editForm.watch('speakersList')?.filter((_, i) => i !== index) || [];
                                editForm.setValue('speakersList', updatedSpeakers);
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="agenda" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-lg font-medium">Agenda</h3>
                    <p className="text-sm text-muted-foreground">Add the schedule for this event</p>
                  </div>
                  <Button 
                    type="button" 
                    onClick={() => {
                      setEditingAgendaItem(null);
                      setShowAgendaDialog(true);
                    }}
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Agenda Item
                  </Button>
                </div>

                {editForm.watch('agenda')?.length === 0 ? (
                  <div className="p-8 text-center border rounded-md bg-muted/40">
                    <p className="text-muted-foreground">No agenda items added yet</p>
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => {
                        setEditingAgendaItem(null);
                        setShowAgendaDialog(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add First Agenda Item
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {editForm.watch('agenda')?.map((item, index) => (
                      <Card key={index} className="overflow-hidden">
                        <div className="flex items-start p-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{item.time}</Badge>
                              <h4 className="font-semibold">{item.title}</h4>
                            </div>
                            <p className="text-sm mt-2">{item.description}</p>
                            {item.speaker && (
                              <p className="text-sm mt-1 text-muted-foreground">Speaker: {item.speaker}</p>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setEditingAgendaItem(item);
                                setShowAgendaDialog(true);
                              }}
                            >
                              <ClipboardEdit className="h-4 w-4" />
                            </Button>
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="icon"
                              className="text-destructive hover:text-destructive/80"
                              onClick={() => {
                                const updatedAgenda = editForm.watch('agenda')?.filter((_, i) => i !== index) || [];
                                editForm.setValue('agenda', updatedAgenda);
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="appearance" className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="edit-featured">Featured Event</Label>
                    <p className="text-sm text-muted-foreground">Show this event on the homepage</p>
                  </div>
                  <Switch 
                    id="edit-featured" 
                    checked={editForm.watch('featured')}
                    onCheckedChange={(checked) => editForm.setValue('featured', checked)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Background Color</Label>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    {BG_CLASSES.map((bgClass) => (
                      <div 
                        key={bgClass}
                        onClick={() => editForm.setValue('bgClass', bgClass)}
                        className={`
                          bg-gradient-to-br ${bgClass} h-12 rounded-md cursor-pointer transition-all
                          ${editForm.watch('bgClass') === bgClass ? 'ring-2 ring-primary ring-offset-2' : 'opacity-70 hover:opacity-100'}
                        `}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="mt-6 p-6 bg-gradient-to-br rounded-lg border">
                  <h3 className="text-lg font-semibold mb-2">Preview</h3>
                  <div className={`bg-gradient-to-br ${editForm.watch('bgClass')} text-white p-4 rounded-lg`}>
                    <div className="mb-1">
                      <Badge className="bg-white/20 text-white hover:bg-white/30">
                        {editForm.watch('type')}
                      </Badge>
                    </div>
                    <h4 className="text-xl font-bold">{editForm.watch('title') || 'Event Title'}</h4>
                    <p className="text-white/90 text-sm">
                      {editForm.watch('description') || 'Event description will appear here'}
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => {
                  setIsEditDialogOpen(false);
                  setEditingEvent(null);
                }}
              >
                Cancel
              </Button>
              <Button 
                type="button" 
                disabled={updateMutation.isPending}
                onClick={() => {
                  console.log('Save button clicked');
                  const formData = editForm.getValues();
                  console.log('Form data from getValues:', formData);
                  
                  if (editingEvent) {
                    console.log('Manually submitting update for event ID:', editingEvent.id);
                    try {
                      updateMutation.mutate({ id: editingEvent.id, data: formData });
                    } catch (error) {
                      console.error('Error during manual update mutation:', error);
                    }
                  } else {
                    console.error('No editing event found during manual submission!');
                  }
                }}
              >
                {updateMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  <>Save Changes</>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation */}
      <AlertDialog open={!!eventToDelete} onOpenChange={(open) => !open && setEventToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the event "{eventToDelete?.title}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => eventToDelete && deleteMutation.mutate(eventToDelete.id)}
              className="bg-red-600 hover:bg-red-700"
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>Delete</>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Speaker Dialog */}
      <Dialog open={showSpeakerDialog} onOpenChange={setShowSpeakerDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingSpeaker ? 'Edit Speaker' : 'Add Speaker'}</DialogTitle>
            <DialogDescription>
              {editingSpeaker ? 'Update speaker information' : 'Add a new speaker to this event'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="speaker-name">Name *</Label>
              <Input 
                id="speaker-name" 
                placeholder="Speaker's full name"
                value={editingSpeaker?.name || ''}
                onChange={(e) => setEditingSpeaker(prev => ({
                  ...(prev || { name: '', title: '', bio: '' }),
                  name: e.target.value
                }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="speaker-title">Title/Role *</Label>
              <Input 
                id="speaker-title" 
                placeholder="e.g., CEO at XYZ Company"
                value={editingSpeaker?.title || ''}
                onChange={(e) => setEditingSpeaker(prev => ({
                  ...(prev || { name: '', title: '', bio: '' }),
                  title: e.target.value
                }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="speaker-bio">Bio *</Label>
              <Textarea 
                id="speaker-bio" 
                placeholder="Brief biography of the speaker"
                rows={4}
                value={editingSpeaker?.bio || ''}
                onChange={(e) => setEditingSpeaker(prev => ({
                  ...(prev || { name: '', title: '', bio: '' }),
                  bio: e.target.value
                }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="speaker-image">Image URL (Optional)</Label>
              <Input 
                id="speaker-image" 
                placeholder="URL to speaker's photo"
                value={editingSpeaker?.imageUrl || ''}
                onChange={(e) => setEditingSpeaker(prev => ({
                  ...(prev || { name: '', title: '', bio: '' }),
                  imageUrl: e.target.value
                }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowSpeakerDialog(false);
                setEditingSpeaker(null);
              }}
            >
              Cancel
            </Button>
            <Button
              type="button"
              disabled={!editingSpeaker?.name || !editingSpeaker?.title || !editingSpeaker?.bio}
              onClick={() => {
                if (editingSpeaker && editingSpeaker.name && editingSpeaker.title && editingSpeaker.bio) {
                  if (isEditDialogOpen) {
                    // We're in the edit event dialog
                    const currentSpeakers = editForm.watch('speakersList') || [];
                    if (currentSpeakers.some(s => s === editingSpeaker)) {
                      // Update existing speaker
                      editForm.setValue(
                        'speakersList',
                        currentSpeakers.map(s => s === editingSpeaker ? editingSpeaker : s)
                      );
                    } else {
                      // Add new speaker
                      editForm.setValue('speakersList', [...currentSpeakers, editingSpeaker]);
                    }
                  } else {
                    // We're in the create event dialog
                    if (speakersList.some(s => s === editingSpeaker)) {
                      // Update existing speaker
                      setSpeakersList(
                        speakersList.map(s => s === editingSpeaker ? editingSpeaker : s)
                      );
                    } else {
                      // Add new speaker
                      setSpeakersList([...speakersList, editingSpeaker]);
                    }
                    createForm.setValue('speakersList', [...speakersList, editingSpeaker]);
                  }
                  setShowSpeakerDialog(false);
                  setEditingSpeaker(null);
                }
              }}
            >
              {editingSpeaker && speakersList.includes(editingSpeaker) ? 'Update Speaker' : 'Add Speaker'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Agenda Item Dialog */}
      <Dialog open={showAgendaDialog} onOpenChange={setShowAgendaDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingAgendaItem ? 'Edit Agenda Item' : 'Add Agenda Item'}</DialogTitle>
            <DialogDescription>
              {editingAgendaItem ? 'Update schedule item' : 'Add a new item to the event schedule'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="agenda-time">Time *</Label>
              <Input 
                id="agenda-time" 
                placeholder="e.g., 9:00 AM - 10:30 AM"
                value={editingAgendaItem?.time || ''}
                onChange={(e) => setEditingAgendaItem(prev => ({
                  ...(prev || { time: '', title: '', description: '' }),
                  time: e.target.value
                }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="agenda-title">Title *</Label>
              <Input 
                id="agenda-title" 
                placeholder="e.g., Opening Keynote"
                value={editingAgendaItem?.title || ''}
                onChange={(e) => setEditingAgendaItem(prev => ({
                  ...(prev || { time: '', title: '', description: '' }),
                  title: e.target.value
                }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="agenda-description">Description *</Label>
              <Textarea 
                id="agenda-description" 
                placeholder="Description of this agenda item"
                rows={3}
                value={editingAgendaItem?.description || ''}
                onChange={(e) => setEditingAgendaItem(prev => ({
                  ...(prev || { time: '', title: '', description: '' }),
                  description: e.target.value
                }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="agenda-speaker">Speaker (Optional)</Label>
              <Input 
                id="agenda-speaker" 
                placeholder="Name of the speaker"
                value={editingAgendaItem?.speaker || ''}
                onChange={(e) => setEditingAgendaItem(prev => ({
                  ...(prev || { time: '', title: '', description: '' }),
                  speaker: e.target.value
                }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowAgendaDialog(false);
                setEditingAgendaItem(null);
              }}
            >
              Cancel
            </Button>
            <Button
              type="button"
              disabled={!editingAgendaItem?.time || !editingAgendaItem?.title || !editingAgendaItem?.description}
              onClick={() => {
                if (editingAgendaItem && editingAgendaItem.time && editingAgendaItem.title && editingAgendaItem.description) {
                  if (isEditDialogOpen) {
                    // We're in the edit event dialog
                    const currentAgenda = editForm.watch('agenda') || [];
                    if (currentAgenda.some(a => a === editingAgendaItem)) {
                      // Update existing agenda item
                      editForm.setValue(
                        'agenda',
                        currentAgenda.map(a => a === editingAgendaItem ? editingAgendaItem : a)
                      );
                    } else {
                      // Add new agenda item
                      editForm.setValue('agenda', [...currentAgenda, editingAgendaItem]);
                    }
                  } else {
                    // We're in the create event dialog
                    if (agenda.some(a => a === editingAgendaItem)) {
                      // Update existing agenda item
                      setAgenda(
                        agenda.map(a => a === editingAgendaItem ? editingAgendaItem : a)
                      );
                    } else {
                      // Add new agenda item
                      setAgenda([...agenda, editingAgendaItem]);
                    }
                    createForm.setValue('agenda', [...agenda, editingAgendaItem]);
                  }
                  setShowAgendaDialog(false);
                  setEditingAgendaItem(null);
                }
              }}
            >
              {editingAgendaItem && agenda.includes(editingAgendaItem) ? 'Update Item' : 'Add Item'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}