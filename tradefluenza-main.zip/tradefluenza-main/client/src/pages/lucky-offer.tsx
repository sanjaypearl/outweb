import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Gift, Sparkles, Trophy, Star } from 'lucide-react';

const luckyOfferFormSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  fullName: z.string().min(2, 'Full name must be at least 2 characters'),
  phoneNumber: z.string().min(10, 'Phone number must be at least 10 characters'),
  tradeflunezaCode: z.string().min(1, 'Tradefluneza code is required'),
  experienceLevel: z.enum(['beginner', 'intermediate', 'advanced'], {
    required_error: 'Please select your experience level',
  }),
  interestedPropFirms: z.string().optional(),
  additionalNotes: z.string().optional(),
});

type LuckyOfferFormData = z.infer<typeof luckyOfferFormSchema>;

export default function LuckyOfferPage() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<LuckyOfferFormData>({
    resolver: zodResolver(luckyOfferFormSchema),
    defaultValues: {
      email: '',
      fullName: '',
      phoneNumber: '',
      tradeflunezaCode: '',
      experienceLevel: 'beginner',
      interestedPropFirms: '',
      additionalNotes: '',
    },
  });

  const submitLuckyOfferMutation = useMutation({
    mutationFn: async (data: LuckyOfferFormData) => {
      // Create a form submission
      const formData = {
        formId: 1, // This would be the Lucky Offer form ID
        submissionData: {
          email: data.email,
          fullName: data.fullName,
          phoneNumber: data.phoneNumber,
          tradeflunezaCode: data.tradeflunezaCode,
          experienceLevel: data.experienceLevel,
          interestedPropFirms: data.interestedPropFirms,
          additionalNotes: data.additionalNotes,
        },
      };

      return await apiRequest('/api/form-submissions', {
        method: 'POST',
        body: JSON.stringify(formData),
        headers: {
          'Content-Type': 'application/json',
        },
      });
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: 'Success!',
        description: 'Your Lucky Offer application has been submitted successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/form-submissions'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to submit your application. Please try again.',
        variant: 'destructive',
      });
      console.error('Submit error:', error);
    },
  });

  const onSubmit = (data: LuckyOfferFormData) => {
    submitLuckyOfferMutation.mutate(data);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl bg-white/10 backdrop-blur-lg border-white/20 text-white">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-4 rounded-full">
                <Trophy className="h-12 w-12 text-white" />
              </div>
            </div>
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
              Application Submitted!
            </CardTitle>
            <CardDescription className="text-gray-300 text-lg mt-2">
              Thank you for applying for our Lucky Offer program. We'll review your application and contact you within 24-48 hours.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <div className="space-y-4">
              <div className="flex items-center justify-center space-x-2 text-yellow-400">
                <Star className="h-5 w-5" />
                <span>Your application is now in our review queue</span>
                <Star className="h-5 w-5" />
              </div>
              <p className="text-gray-300">
                Keep an eye on your email for updates on your Lucky Offer status.
              </p>
              <Button
                onClick={() => window.location.href = '/'}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-2 px-6 rounded-full"
              >
                Return to Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-4 rounded-full">
              <Gift className="h-12 w-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">
            Lucky Offer Program
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Exclusive opportunities for traders with Tradefluneza codes. Apply now for special offers and premium access.
          </p>
        </div>

        {/* Benefits */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 text-white">
            <CardContent className="p-6 text-center">
              <Sparkles className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Exclusive Access</h3>
              <p className="text-gray-300 text-sm">
                Get priority access to premium prop firms and special trading opportunities.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 text-white">
            <CardContent className="p-6 text-center">
              <Trophy className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Special Offers</h3>
              <p className="text-gray-300 text-sm">
                Unlock discounted rates and bonus features not available to regular users.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 text-white">
            <CardContent className="p-6 text-center">
              <Star className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">VIP Support</h3>
              <p className="text-gray-300 text-sm">
                Receive dedicated support and personalized recommendations from our team.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Form */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-white text-center">
              Apply for Lucky Offer
            </CardTitle>
            <CardDescription className="text-gray-300 text-center">
              Fill out the form below to apply for our exclusive Lucky Offer program.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Full Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your full name"
                            {...field}
                            className="bg-white/20 border-white/30 text-white placeholder:text-gray-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Email Address</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="Enter your email"
                            {...field}
                            className="bg-white/20 border-white/30 text-white placeholder:text-gray-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="phoneNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Phone Number</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your phone number"
                            {...field}
                            className="bg-white/20 border-white/30 text-white placeholder:text-gray-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="tradeflunezaCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Tradefluneza Code</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your Tradefluneza code"
                            {...field}
                            className="bg-white/20 border-white/30 text-white placeholder:text-gray-400"
                          />
                        </FormControl>
                        <FormDescription className="text-gray-400">
                          This code is required to access the Lucky Offer program.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="experienceLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Trading Experience Level</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-white/20 border-white/30 text-white">
                            <SelectValue placeholder="Select your experience level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner (0-1 years)</SelectItem>
                          <SelectItem value="intermediate">Intermediate (1-3 years)</SelectItem>
                          <SelectItem value="advanced">Advanced (3+ years)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="interestedPropFirms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Interested Prop Firms (Optional)</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., FTMO, MyForexFunds, The5ers"
                          {...field}
                          className="bg-white/20 border-white/30 text-white placeholder:text-gray-400"
                        />
                      </FormControl>
                      <FormDescription className="text-gray-400">
                        Let us know which prop firms you're most interested in.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="additionalNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Additional Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Any additional information you'd like to share..."
                          {...field}
                          className="bg-white/20 border-white/30 text-white placeholder:text-gray-400"
                          rows={4}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  disabled={submitLuckyOfferMutation.isPending}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 px-6 rounded-full text-lg"
                >
                  {submitLuckyOfferMutation.isPending ? 'Submitting...' : 'Submit Application'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}