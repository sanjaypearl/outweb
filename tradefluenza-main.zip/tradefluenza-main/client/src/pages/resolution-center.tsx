import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Helmet } from "react-helmet-async";

const supportTicketSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  phoneNumber: z.string().min(5, "Please enter a valid phone number"),
  entityType: z.enum(["PropFirm", "Broker"], {
    required_error: "Please select the entity type",
  }),
  entityId: z.number({
    required_error: "Please select an entity",
  }),
  category: z.string({
    required_error: "Please select a category",
  }),
  description: z.string().min(10, "Description must be at least 10 characters"),
});

type SupportTicketFormData = z.infer<typeof supportTicketSchema>;

const ResolutionCenter = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("submit");
  
  // Fetch prop firms and brokers for the dropdown menu
  const { data: propFirms = [], isLoading: isLoadingPropFirms } = useQuery({
    queryKey: ["/api/prop-firms"],
    queryFn: async () => {
      const response = await fetch("/api/prop-firms");
      return response.json();
    },
  });
  
  const { data: brokers = [], isLoading: isLoadingBrokers } = useQuery({
    queryKey: ["/api/brokers"],
    queryFn: async () => {
      const response = await fetch("/api/brokers");
      return response.json();
    },
  });

  const form = useForm<SupportTicketFormData>({
    resolver: zodResolver(supportTicketSchema),
    defaultValues: {
      name: "",
      email: "",
      phoneNumber: "",
      description: "",
    },
  });

  const submitTicketMutation = useMutation({
    mutationFn: async (data: SupportTicketFormData) => {
      const response = await apiRequest("POST", "/api/support/tickets", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Ticket submitted",
        description: "Your ticket has been submitted successfully.",
      });
      form.reset();
      setActiveTab("success");
      queryClient.invalidateQueries({ queryKey: ["/api/support/tickets"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "There was an error submitting your ticket. Please try again.",
        variant: "destructive",
      });
    },
  });

  const entityOptions = form.watch("entityType");
  
  const onSubmit = (data: SupportTicketFormData) => {
    submitTicketMutation.mutate(data);
  };

  // Resolution categories based on entity type
  const getCategories = (entityType: "PropFirm" | "Broker" | undefined) => {
    if (entityType === "PropFirm") {
      return [
        "Account Access",
        "Payment Issues",
        "Trading Conditions", 
        "Challenge Rules",
        "Payout Problems",
        "Technical Support",
        "Other"
      ];
    } else if (entityType === "Broker") {
      return [
        "Account Issues", 
        "Withdrawal Problems",
        "Trading Conditions",
        "Platform Technical Issues",
        "Regulation Concerns",
        "Customer Service",
        "Other"
      ];
    }
    return [];
  };

  return (
    <>
      <Helmet>
        <link
          rel="canonical"
          href="https://tradefluenza.com/resolution-center"
        />
      </Helmet>
      <div className="container mx-auto py-10">
        <div className="flex flex-col items-center mb-10">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-400 bg-clip-text text-transparent mb-4">
            Resolution Center
          </h1>
          <p className="text-center text-muted-foreground max-w-2xl">
            Having an issue with a Prop Firm or Broker? Our Resolution Center is
            here to help. Submit your concern below and our team will
            investigate and respond promptly.
          </p>
        </div>

        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full max-w-3xl mx-auto"
        >
          <TabsList className="grid w-full grid-cols-1">
            <TabsTrigger value="submit">Submit a Report</TabsTrigger>
            {/* Confirmation tab is programmatically shown after successful submission */}
          </TabsList>

          <TabsContent value="submit">
            <Card className="border-gradient-to-r border-blue-500">
              <CardHeader>
                <CardTitle>Submit a Resolution Request</CardTitle>
                <CardDescription>
                  Fill out the form below with details about your issue
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="space-y-6"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Name</FormLabel>
                            <FormControl>
                              <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input placeholder="you@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="+1 (555) 123-4567" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="entityType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Reporting About</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select entity type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="PropFirm">
                                Prop Firm
                              </SelectItem>
                              <SelectItem value="Broker">Broker</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {entityOptions && (
                      <FormField
                        control={form.control}
                        name="entityId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              {entityOptions === "PropFirm"
                                ? "Prop Firm"
                                : "Broker"}
                            </FormLabel>
                            <Select
                              onValueChange={(value) =>
                                field.onChange(parseInt(value))
                              }
                              defaultValue={field.value?.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue
                                    placeholder={`Select a ${
                                      entityOptions === "PropFirm"
                                        ? "prop firm"
                                        : "broker"
                                    }`}
                                  />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {entityOptions === "PropFirm" &&
                                  propFirms.map((firm: any) => (
                                    <SelectItem
                                      key={firm.id}
                                      value={firm.id.toString()}
                                    >
                                      {firm.name}
                                    </SelectItem>
                                  ))}
                                {entityOptions === "Broker" &&
                                  brokers.map((broker: any) => (
                                    <SelectItem
                                      key={broker.id}
                                      value={broker.id.toString()}
                                    >
                                      {broker.name}
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    {entityOptions && (
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Issue Category</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select an issue category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {getCategories(
                                  entityOptions as "PropFirm" | "Broker"
                                ).map((category) => (
                                  <SelectItem key={category} value={category}>
                                    {category}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Describe your issue</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Please provide details about your issue..."
                              className="min-h-[150px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Include any relevant details that could help us
                            resolve your issue faster.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
                      disabled={submitTicketMutation.isPending}
                    >
                      {submitTicketMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        "Submit Report"
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="success">
            <Card>
              <CardHeader>
                <CardTitle className="text-center text-green-600">
                  Report Submitted Successfully!
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-6">
                  <div className="mx-auto w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-600 w-8 h-8"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>
                  <p className="text-lg text-muted-foreground mb-6">
                    Thank you for submitting your report to our Resolution
                    Center. Our team will review your issue and contact you
                    shortly.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Please keep an eye on your email as we may reach out for
                    additional information.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button
                  variant="outline"
                  onClick={() => setActiveTab("submit")}
                >
                  Submit Another Report
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default ResolutionCenter;