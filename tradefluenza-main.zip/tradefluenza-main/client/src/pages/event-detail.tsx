import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { 
  Calendar, MapPin, Users, ArrowLeft, ExternalLink, 
  Clock, User, Mail, Phone, Check, X, Loader2, AlertCircle,
  Star
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import EventReviewForm from "@/components/events/event-review-form";
import EventReviewsList from "@/components/events/event-reviews-list";

// Define event registration schema
const registrationSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Valid email is required"),
  phoneNumber: z.string().optional(),
  additionalInfo: z.record(z.string()).optional(),
});

type RegistrationData = z.infer<typeof registrationSchema>;

// Define event type
interface Speaker {
  name: string;
  title: string;
  bio: string;
  imageUrl?: string;
}

interface AgendaItem {
  time: string;
  title: string;
  description: string;
  speaker?: string;
}

interface Event {
  id: number;
  title: string;
  description: string;
  fullDescription: string;
  date: string;
  location: string;
  locationDetails?: string;
  attendees?: string;
  type: string;
  imageUrl?: string;
  registrationUrl?: string;
  speakersList?: Speaker[];
  agenda?: AgendaItem[];
  isPremium: boolean;
  price?: number;
  maxAttendees?: number;
  currentAttendees: number;
  status: string;
  bgClass: string;
  featured: boolean;
  organizer: string;
}

export default function EventDetail() {
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("details");
  
  const { data: event, isLoading, error } = useQuery<Event, Error>({
    queryKey: ['/api/events', Number(id)],
    queryFn: async () => {
      const response = await fetch(`/api/events/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch event');
      }
      return response.json();
    },
    enabled: !!id && !isNaN(Number(id)),
  });
  
  // Form setup for registration
  const { register, handleSubmit, formState: { errors }, reset } = useForm<RegistrationData>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      name: user?.username || '',
      email: '',
      phoneNumber: '',
    }
  });
  
  // Mutation for event registration
  const registerMutation = useMutation({
    mutationFn: async (data: RegistrationData) => {
      const res = await apiRequest('POST', `/api/events/${id}/register`, data);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || 'Failed to register for the event');
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Registration Successful",
        description: "You have successfully registered for this event.",
        variant: "default",
      });
      reset();
      // Invalidate event query to refresh attendee count
      queryClient.invalidateQueries({ queryKey: ['/api/events', Number(id)] });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: RegistrationData) => {
    registerMutation.mutate(data);
  };
  
  // Reset form when user changes
  useEffect(() => {
    if (user) {
      reset({
        name: user.username || '',
        email: '',
        phoneNumber: '',
      });
    }
  }, [user, reset]);
  
  // If there's an error fetching the event
  if (error) {
    return (
      <div className="container py-10">
        <div className="flex flex-col items-center justify-center text-center py-12">
          <X className="h-16 w-16 text-red-500 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Failed to load event</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">{error.message}</p>
          <Button variant="outline" onClick={() => setLocation('/events')}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Events
          </Button>
        </div>
      </div>
    );
  }
  
  if (isLoading || !event) {
    return (
      <div className="container py-10">
        <Skeleton className="h-10 w-96 mb-4" />
        <Skeleton className="h-6 w-72 mb-8" />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Skeleton className="h-64 w-full mb-4 rounded-xl" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-3/4 mb-6" />
            
            <Skeleton className="h-8 w-48 mb-2" />
            <Skeleton className="h-24 w-full mb-6" />
          </div>
          
          <div>
            <Skeleton className="h-64 w-full rounded-xl" />
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container py-10 px-4 sm:px-6 max-w-7xl mx-auto">
      <Button variant="outline" className="mb-6 hover:bg-primary/5" onClick={() => setLocation('/events')}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Events
      </Button>
      
      <div className={`bg-gradient-to-br ${event.bgClass} text-white p-6 md:p-8 lg:p-10 rounded-xl mb-8 relative overflow-hidden shadow-md`}>
        {/* Event image background */}
        {event.imageUrl && (
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
            style={{ backgroundImage: `url(${event.imageUrl})` }}
          />
        )}
        {/* Fallback pattern if no image */}
        {!event.imageUrl && (
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzBoLTZsMyAxMHpNNTQgMjBsLTYgNiA2IDZ6TTYgNGwtNi02aDEyeiIvPjwvZz48L2c+PC9zdmc+')] opacity-20"></div>
        )}
        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-black/20"></div>
        
        <div className="relative z-10">
          <Badge className="mb-3 bg-white/20 text-white hover:bg-white/30 px-2.5 py-1 shadow-sm">
            {event.type}
          </Badge>
          
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 leading-tight">{event.title}</h1>
          
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-sm mb-6">
            <div className="flex items-center gap-1.5 bg-black/20 px-2.5 py-1 rounded-full backdrop-blur-sm">
              <Calendar className="h-4 w-4 text-white/90" />
              <span>{event.date}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-black/20 px-2.5 py-1 rounded-full backdrop-blur-sm">
              <MapPin className="h-4 w-4 text-white/90" />
              <span>{event.location}</span>
            </div>
            {event.attendees && (
              <div className="flex items-center gap-1.5 bg-black/20 px-2.5 py-1 rounded-full backdrop-blur-sm">
                <Users className="h-4 w-4 text-white/90" />
                <span>{event.attendees}</span>
              </div>
            )}
            {event.organizer && (
              <div className="flex items-center gap-1.5 bg-black/20 px-2.5 py-1 rounded-full backdrop-blur-sm">
                <User className="h-4 w-4 text-white/90" />
                <span>By: {event.organizer}</span>
              </div>
            )}
          </div>
          
          <p className="text-base sm:text-lg text-white/90 max-w-4xl leading-relaxed">
            {event.description}
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        <div className="lg:col-span-2">
          {/* Featured Image Section */}
          {event.imageUrl && (
            <div className="mb-8 rounded-xl overflow-hidden shadow-lg">
              <img 
                src={event.imageUrl} 
                alt={event.title}
                className="w-full h-64 md:h-80 object-cover"
                loading="lazy"
              />
            </div>
          )}
          
          <Tabs defaultValue="details" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gradient-to-r from-indigo-50 via-purple-50 to-indigo-50 dark:from-indigo-950/30 dark:via-purple-950/30 dark:to-indigo-950/30 border border-indigo-100 dark:border-indigo-800/30 shadow-sm backdrop-blur-sm">
              <TabsTrigger value="details" className="text-base sm:text-sm data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-600 data-[state=active]:text-white">Overview</TabsTrigger>
              <TabsTrigger value="agenda" className="text-base sm:text-sm data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-600 data-[state=active]:text-white">Agenda</TabsTrigger>
              <TabsTrigger value="speakers" className="text-base sm:text-sm data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-600 data-[state=active]:text-white">Speakers</TabsTrigger>
              <TabsTrigger value="reviews" className="text-base sm:text-sm data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-600 data-[state=active]:text-white">
                <div className="flex items-center">
                  <Star className="w-3.5 h-3.5 mr-1.5" />
                  Reviews
                </div>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="details" className="mt-6">
              <div className="prose prose-lg dark:prose-invert max-w-none">
                {event.fullDescription && (
                  <div dangerouslySetInnerHTML={{ __html: event.fullDescription.replace(/\n/g, '<br />') }} />
                )}
                
                {event.locationDetails && (
                  <>
                    <h3 className="text-xl font-bold mt-6 mb-3">Location Details</h3>
                    <p>{event.locationDetails}</p>
                  </>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="agenda" className="mt-6">
              {event.agenda && event.agenda.length > 0 ? (
                <div className="relative">
                  {/* Timeline Track */}
                  <div className="absolute left-0 top-0 bottom-0 w-[2px] bg-gradient-to-b from-primary/80 via-primary/50 to-primary/30 ml-4 md:ml-[68px]"></div>
                  
                  <div className="space-y-10">
                    {event.agenda.map((item, index) => (
                      <div 
                        key={index} 
                        className="relative pl-12 md:pl-[120px] group"
                      >
                        {/* Timeline Node */}
                        <div className="absolute left-[11px] md:left-[61px] top-1 md:top-2 w-7 h-7 rounded-full bg-gradient-to-br from-primary to-indigo-600 shadow-lg flex items-center justify-center z-10 group-hover:scale-110 transition-transform">
                          <div className="w-2 h-2 rounded-full bg-white"></div>
                          <div className="absolute -inset-1 rounded-full bg-primary/20 animate-ping opacity-75"></div>
                        </div>
                        
                        {/* Time Badge */}
                        <div className="hidden md:block absolute left-0 top-1 w-[50px] text-right">
                          <div className="text-sm font-bold text-primary bg-primary/5 rounded-md px-2 py-1 inline-block">
                            {item.time.split(' ')[0]}
                          </div>
                        </div>
                        
                        <div className="bg-gradient-to-r p-0.5 from-primary/20 to-transparent rounded-xl shadow-sm hover:shadow-md transition-shadow">
                          <div className="bg-white dark:bg-gray-800 rounded-[10px]">
                            <div className="p-5">
                              <div className="md:hidden mb-2 text-sm font-semibold text-primary bg-primary/5 px-2 py-1 rounded-md inline-block">
                                {item.time}
                              </div>
                              <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{item.title}</h3>
                              {item.speaker && (
                                <div className="flex items-center text-sm font-medium text-gray-600 dark:text-gray-300 mb-3 bg-gray-100 dark:bg-gray-700/50 rounded-full pl-2 pr-3 py-1 w-fit">
                                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                                    <User className="h-3 w-3 text-primary" />
                                  </div>
                                  {item.speaker}
                                </div>
                              )}
                              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{item.description}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-16 bg-gray-50 dark:bg-gray-800/30 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                    <Clock className="h-8 w-8 text-primary/60" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Agenda Coming Soon</h3>
                  <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                    The event schedule will be published soon. Check back later for the complete agenda.
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="speakers" className="mt-6">
              {event.speakersList && event.speakersList.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {event.speakersList.map((speaker, index) => (
                    <Card key={index} className="overflow-hidden transition-all duration-300 hover:shadow-md hover:border-primary/40 group">
                      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent p-0.5">
                        <CardHeader className="flex flex-row items-center gap-5 pb-2">
                          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-indigo-500/30 p-0.5 shadow-md overflow-hidden">
                            {speaker.imageUrl ? (
                              <img src={speaker.imageUrl} alt={speaker.name} className="w-full h-full object-cover rounded-full" />
                            ) : (
                              <div className="w-full h-full rounded-full bg-white dark:bg-gray-800 flex items-center justify-center">
                                <User className="w-9 h-9 text-primary/60" />
                              </div>
                            )}
                          </div>
                          <div>
                            <CardTitle className="group-hover:text-primary transition-colors">{speaker.name}</CardTitle>
                            <CardDescription className="text-primary/70 font-medium">{speaker.title}</CardDescription>
                          </div>
                        </CardHeader>
                      </div>
                      <CardContent className="pt-4">
                        <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">{speaker.bio}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 bg-gray-50 dark:bg-gray-800/30 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-8 w-8 text-primary/60" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Speaker Information Coming Soon</h3>
                  <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                    Our speaker lineup will be announced shortly. Check back later for updates!
                  </p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-8">
                {/* Reviews Listing */}
                <EventReviewsList 
                  eventId={event.id} 
                  onDeleteReview={() => {
                    queryClient.invalidateQueries({ queryKey: [`/api/events/${event.id}/reviews`] });
                  }} 
                />
                
                {/* Review Submission Form */}
                <div className="mt-10">
                  <Separator className="my-8" />
                  <EventReviewForm 
                    eventId={event.id}
                    onReviewSubmitted={() => {
                      queryClient.invalidateQueries({ queryKey: [`/api/events/${event.id}/reviews`] });
                      toast({
                        title: "Thanks for your feedback!",
                        description: "Your review has been submitted and will help other traders.",
                      });
                    }}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div>
          <Card className="overflow-hidden border-2 hover:border-primary/30 transition-all duration-300 shadow-sm hover:shadow-md sticky top-6">
            <div className="absolute inset-x-0 top-0 h-2 bg-gradient-to-r from-primary to-indigo-600"></div>
            
            <CardHeader className="bg-gradient-to-br from-primary/5 to-indigo-500/5 pb-4">
              <CardTitle className="text-xl flex items-center justify-between">
                <span>Register for this Event</span>
                {event.isPremium && (
                  <Badge className="bg-gradient-to-r from-amber-300 to-amber-500 text-amber-950 ml-2">
                    Premium
                  </Badge>
                )}
              </CardTitle>
              <CardDescription className="flex items-center text-base">
                {event.isPremium ? (
                  <div className="flex items-center">
                    <span className="font-semibold text-primary/90">${event.price}</span>
                    <span className="mx-2">•</span>
                    <span className="text-sm">{event.type} Event</span>
                  </div>
                ) : (
                  <div className="flex items-center">
                    <Badge variant="outline" className="border-green-500 text-green-600 mr-2">
                      Free
                    </Badge>
                    <span className="text-sm">{event.type} Event</span>
                  </div>
                )}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6 space-y-6">
              {/* Upcoming event banner */}
              {event.status === 'Upcoming' && (
                <div className="bg-primary/5 border border-primary/10 rounded-lg p-3 text-center">
                  <p className="text-primary font-medium text-sm">
                    <Calendar className="inline-block mr-1.5 h-4 w-4 relative -top-[1px]" />
                    {event.date}
                  </p>
                </div>
              )}
              
              {/* Attendee progress */}
              {event.maxAttendees && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm font-medium">
                    <span className="text-gray-700 dark:text-gray-300">Spots Remaining</span>
                    <span className="text-primary">
                      {event.maxAttendees - event.currentAttendees} / {event.maxAttendees}
                    </span>
                  </div>
                  
                  <div className="w-full h-2.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-primary to-indigo-600"
                      style={{ width: `${(event.currentAttendees / event.maxAttendees) * 100}%` }}
                    >
                    </div>
                  </div>
                  
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {event.currentAttendees === 0 ? (
                      <span>Be the first to register!</span>
                    ) : event.currentAttendees === 1 ? (
                      <span>1 person has registered so far</span>
                    ) : (
                      <span>{event.currentAttendees} people have registered already</span>
                    )}
                  </p>
                </div>
              )}
              
              {/* Registration form or external registration link */}
              {event.registrationUrl ? (
                <div className="text-center py-2">
                  <p className="mb-4 text-gray-600 dark:text-gray-300 text-sm">Registration is handled on an external site.</p>
                  <Button asChild className="w-full bg-gradient-to-r from-primary to-indigo-600 hover:from-primary/90 hover:to-indigo-500 shadow-md">
                    <a href={event.registrationUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center py-6">
                      Register on External Site
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </a>
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-1.5 flex items-center">
                      <User className="h-3.5 w-3.5 mr-1.5 text-primary/70" />
                      Your Name
                    </label>
                    <div className="relative">
                      <Input
                        id="name"
                        placeholder="Enter your full name"
                        {...register("name")}
                        className={`py-5 pl-3 ${errors.name ? "border-red-500 focus:ring-red-500" : "focus:ring-primary/30 border-gray-200 hover:border-gray-300"}`}
                      />
                      {errors.name && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2">
                          <div className="bg-red-100 dark:bg-red-900/30 rounded-full p-0.5">
                            <X className="h-3.5 w-3.5 text-red-500" />
                          </div>
                        </div>
                      )}
                    </div>
                    {errors.name && (
                      <p className="text-xs text-red-500 mt-1.5 flex items-start">
                        <span className="bg-red-100 dark:bg-red-900/30 p-0.5 rounded-full mr-1.5 mt-0.5 flex-shrink-0">
                          <AlertCircle className="h-3 w-3" />
                        </span>
                        <span>{errors.name.message}</span>
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1.5 flex items-center">
                      <Mail className="h-3.5 w-3.5 mr-1.5 text-primary/70" />
                      Email Address
                    </label>
                    <div className="relative">
                      <Input
                        id="email"
                        type="email"
                        placeholder="you@example.com"
                        {...register("email")}
                        className={`py-5 pl-3 ${errors.email ? "border-red-500 focus:ring-red-500" : "focus:ring-primary/30 border-gray-200 hover:border-gray-300"}`}
                      />
                      {errors.email && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2">
                          <div className="bg-red-100 dark:bg-red-900/30 rounded-full p-0.5">
                            <X className="h-3.5 w-3.5 text-red-500" />
                          </div>
                        </div>
                      )}
                    </div>
                    {errors.email && (
                      <p className="text-xs text-red-500 mt-1.5 flex items-start">
                        <span className="bg-red-100 dark:bg-red-900/30 p-0.5 rounded-full mr-1.5 mt-0.5 flex-shrink-0">
                          <AlertCircle className="h-3 w-3" />
                        </span>
                        <span>{errors.email.message}</span>
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="phoneNumber" className="block text-sm font-medium mb-1.5 flex items-center">
                      <Phone className="h-3.5 w-3.5 mr-1.5 text-primary/70" />
                      Phone Number <span className="text-xs text-gray-500 ml-1">(optional)</span>
                    </label>
                    <div className="relative">
                      <Input
                        id="phoneNumber"
                        placeholder="+1 (123) 456-7890"
                        {...register("phoneNumber")}
                        className="py-5 pl-3 focus:ring-primary/30 border-gray-200 hover:border-gray-300"
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1.5 flex items-start">
                      <span className="bg-gray-100 dark:bg-gray-700/50 p-0.5 rounded-full mr-1.5 mt-0.5 flex-shrink-0">
                        <AlertCircle className="h-3 w-3 text-gray-400" />
                      </span>
                      <span>We'll only contact you with important event updates</span>
                    </p>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className={`w-full py-6 mt-4 shadow-md text-base font-medium ${event.status !== 'Upcoming' 
                      ? 'bg-gray-400 hover:bg-gray-500'
                      : 'bg-gradient-to-r from-primary to-indigo-600 hover:from-primary/90 hover:to-indigo-500'
                    }`}
                    disabled={registerMutation.isPending || event.status !== 'Upcoming'}
                  >
                    {registerMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Processing Registration...
                      </>
                    ) : event.status !== 'Upcoming' ? (
                      'Registration Closed'
                    ) : (
                      'Secure Your Spot Now'
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
            
            <CardFooter className="flex flex-col px-6 py-5 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800/50 dark:to-gray-800/70 border-t border-gray-200 dark:border-gray-700/30">
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-3">
                <div className="flex items-start">
                  <div className="rounded-full bg-green-100 dark:bg-green-900/30 p-1 text-green-600 mr-3 mt-0.5">
                    <Check className="h-3 w-3" />
                  </div>
                  <span>Confirmation details will be sent to your email</span>
                </div>
                {!event.isPremium && (
                  <div className="flex items-start">
                    <div className="rounded-full bg-green-100 dark:bg-green-900/30 p-1 text-green-600 mr-3 mt-0.5">
                      <Check className="h-3 w-3" />
                    </div>
                    <span>This event is completely free to attend</span>
                  </div>
                )}
                <div className="flex items-start">
                  <div className="rounded-full bg-green-100 dark:bg-green-900/30 p-1 text-green-600 mr-3 mt-0.5">
                    <Check className="h-3 w-3" />
                  </div>
                  <span>You can cancel your registration anytime</span>
                </div>
                {event.status === 'Upcoming' && (
                  <div className="flex items-start">
                    <div className="rounded-full bg-green-100 dark:bg-green-900/30 p-1 text-green-600 mr-3 mt-0.5">
                      <Check className="h-3 w-3" />
                    </div>
                    <span>Event reminders will be sent before the date</span>
                  </div>
                )}
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}