import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  GraduationCap, 
  Calendar, 
  Star, 
  Clock, 
  Globe, 
  MessageCircle,
  Video,
  Users,
  Verified,
  CreditCard,
  Search,
  Filter,
  ChevronDown,
  BarChart4
} from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMentors, useMentor, useMentorReviews, useBookSession, useSubmitReview } from "@/hooks/use-mentors";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FiStar } from "react-icons/fi";

// For demonstration purposes - this would come from the database
const sampleMentors = [
  {
    id: 1,
    name: "Alex Chen",
    profileImage: "https://randomuser.me/api/portraits/men/32.jpg",
    specialization: "forex",
    experienceLevel: "professional",
    hourlyRate: 85,
    experience: 8,
    bio: "Professional Forex trader with 8+ years of experience. Specialized in swing trading major pairs.",
    rating: 4.9,
    reviewCount: 124,
    languages: "English, Mandarin",
    isVerified: true,
    studentCount: 235
  },
  {
    id: 2,
    name: "Sarah Johnson",
    profileImage: "https://randomuser.me/api/portraits/women/44.jpg",
    specialization: "stocks",
    experienceLevel: "advanced",
    hourlyRate: 75,
    experience: 6,
    bio: "Stock market analyst and day trader. Focus on technical analysis and momentum strategies.",
    rating: 4.7,
    reviewCount: 89,
    languages: "English",
    isVerified: true,
    studentCount: 167
  },
  {
    id: 3,
    name: "Michael Rodriguez",
    profileImage: "https://randomuser.me/api/portraits/men/67.jpg",
    specialization: "futures",
    experienceLevel: "professional",
    hourlyRate: 95,
    experience: 12,
    bio: "E-mini S&P 500 futures trader with experience in market profile and order flow analysis.",
    rating: 4.8,
    reviewCount: 218,
    languages: "English, Spanish",
    isVerified: true,
    studentCount: 312
  },
  {
    id: 4,
    name: "Emma Wilson",
    profileImage: "https://randomuser.me/api/portraits/women/22.jpg",
    specialization: "crypto",
    experienceLevel: "intermediate",
    hourlyRate: 65,
    experience: 4,
    bio: "Cryptocurrency trader and blockchain enthusiast. Specializing in altcoin trading strategies.",
    rating: 4.5,
    reviewCount: 56,
    languages: "English",
    isVerified: true,
    studentCount: 94
  }
];

// For demo purposes only - this would be loaded from the database
const sampleReviews = [
  {
    id: 1,
    userId: 2,
    mentorId: 1,
    userName: "David Williams",
    userImage: "https://randomuser.me/api/portraits/men/41.jpg",
    rating: 5,
    comment: "Alex completely transformed my trading. His detailed analysis of my trading patterns helped me eliminate bad habits and focus on high probability setups. Worth every penny.",
    date: "2 weeks ago"
  },
  {
    id: 2,
    userId: 3,
    mentorId: 1,
    userName: "Jessica Kim",
    userImage: "https://randomuser.me/api/portraits/women/63.jpg",
    rating: 4,
    comment: "Very knowledgeable about forex market dynamics. Helped me develop a better risk management system. Would recommend for intermediate traders looking to improve.",
    date: "1 month ago"
  }
];

// Component for the booking form dialog
const BookingForm = ({ mentor, onClose }: { mentor: any, onClose: () => void }) => {
  const { user } = useAuth();
  const [duration, setDuration] = useState("60");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [topic, setTopic] = useState("");
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  
  // Use the book session mutation
  const bookSession = useBookSession();
  
  const calculatePrice = () => {
    return (parseInt(duration) / 60) * mentor.hourlyRate;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to book a session",
        variant: "destructive"
      });
      return;
    }
    
    try {
      // Combine date and time
      const dateTimeStr = `${date}T${time}:00`;
      const dateTime = new Date(dateTimeStr);
      
      if (isNaN(dateTime.getTime())) {
        toast({
          title: "Invalid date or time",
          description: "Please select a valid date and time",
          variant: "destructive"
        });
        return;
      }
      
      // Book the session through the API
      await bookSession.mutateAsync({
        mentorId: mentor.id,
        date: dateTimeStr,
        duration: parseInt(duration),
        topic,
        notes: notes || undefined
      });
      
      onClose();
    } catch (error) {
      console.error("Error booking session:", error);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex items-center border-b border-gray-200 dark:border-gray-700 pb-4 mb-4">
        <img 
          src={mentor.profileImage} 
          alt={mentor.name} 
          className="h-16 w-16 rounded-full object-cover border-2 border-cyan-500"
        />
        <div className="ml-4">
          <div className="flex items-center">
            <h3 className="text-xl font-bold">{mentor.name}</h3>
            {mentor.isVerified && (
              <Badge className="ml-2 bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-100">
                <Verified className="h-3 w-3 mr-1" /> Verified
              </Badge>
            )}
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            ${mentor.hourlyRate}/hour • {mentor.specialization} specialist
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="date">Date</Label>
          <Input 
            id="date" 
            type="date" 
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            min={new Date().toISOString().split('T')[0]}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="time">Time</Label>
          <Input 
            id="time" 
            type="time" 
            value={time}
            onChange={(e) => setTime(e.target.value)}
            required
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="duration">Session Duration</Label>
        <Select 
          value={duration} 
          onValueChange={setDuration}
        >
          <SelectTrigger id="duration">
            <SelectValue placeholder="Select duration" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="30">30 minutes</SelectItem>
            <SelectItem value="60">1 hour</SelectItem>
            <SelectItem value="90">1.5 hours</SelectItem>
            <SelectItem value="120">2 hours</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="topic">What would you like to focus on?</Label>
        <Input 
          id="topic" 
          placeholder="e.g., Strategy review, Technical analysis, Risk management"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="notes">Additional notes (optional)</Label>
        <Textarea 
          id="notes" 
          placeholder="Any specific questions or topics you'd like to cover"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
        />
      </div>
      
      <div className="rounded-lg bg-cyan-50 dark:bg-cyan-900/30 p-4 mt-6">
        <div className="flex justify-between items-center">
          <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
            {parseInt(duration)} minutes at ${mentor.hourlyRate}/hour
          </div>
          <div className="text-xl font-bold">${calculatePrice()}</div>
        </div>
      </div>
      
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button 
          type="submit" 
          className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700"
        >
          <CreditCard className="h-4 w-4 mr-2" />
          Book & Pay
        </Button>
      </DialogFooter>
    </form>
  );
};

// Component for mentor card
const MentorCard = ({ mentor }: { mentor: any }) => {
  const [showBookingForm, setShowBookingForm] = useState(false);
  
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg border border-gray-200 dark:border-gray-800">
      <div className="relative p-6">
        {mentor.isVerified && (
          <Badge className="absolute right-4 top-4 bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-100">
            <Verified className="h-3 w-3 mr-1" /> Verified
          </Badge>
        )}
        
        <div className="flex items-start">
          <img 
            src={mentor.profileImage} 
            alt={mentor.name} 
            className="h-20 w-20 rounded-full object-cover border-2 border-cyan-500"
          />
          <div className="ml-4">
            <h3 className="text-xl font-bold">{mentor.name}</h3>
            <div className="flex items-center mt-1">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <FiStar 
                    key={star} 
                    className={`${star <= Math.floor(mentor.rating) ? "text-amber-500 fill-amber-500" : "text-gray-300"} h-4 w-4`} 
                  />
                ))}
              </div>
              <span className="ml-2 text-sm font-medium">{mentor.rating}</span>
              <span className="mx-1 text-gray-400">•</span>
              <span className="text-sm text-gray-600 dark:text-gray-400">{mentor.reviewCount} reviews</span>
            </div>
            <div className="flex flex-wrap mt-2 gap-2">
              <Badge variant="outline" className="bg-white dark:bg-gray-800">
                ${mentor.hourlyRate}/hr
              </Badge>
              <Badge variant="outline" className="capitalize bg-white dark:bg-gray-800">
                {mentor.specialization}
              </Badge>
              <Badge variant="outline" className="capitalize bg-white dark:bg-gray-800">
                {mentor.experienceLevel.replace('_', ' ')}
              </Badge>
            </div>
          </div>
        </div>
        
        <p className="mt-4 text-gray-600 dark:text-gray-400">
          {mentor.bio}
        </p>
        
        <div className="grid grid-cols-3 gap-2 mt-4">
          <div className="flex items-center">
            <Clock className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm">{mentor.experience} years</span>
          </div>
          <div className="flex items-center">
            <Globe className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm">{mentor.languages}</span>
          </div>
          <div className="flex items-center">
            <Users className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm">{mentor.studentCount} students</span>
          </div>
        </div>
        
        <div className="mt-6 flex space-x-3">
          <Dialog open={showBookingForm} onOpenChange={setShowBookingForm}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700 flex-1">
                <Calendar className="h-4 w-4 mr-2" />
                Book Session
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Book a Session</DialogTitle>
                <DialogDescription>
                  Schedule a one-on-one mentoring session with {mentor.name}.
                </DialogDescription>
              </DialogHeader>
              <BookingForm mentor={mentor} onClose={() => setShowBookingForm(false)} />
            </DialogContent>
          </Dialog>
          
          <Button variant="outline">
            <MessageCircle className="h-4 w-4 mr-2" />
            Message
          </Button>
        </div>
      </div>
    </Card>
  );
};

// Component for submitting reviews
const ReviewForm = ({ mentorId, onClose }: { mentorId: number, onClose: () => void }) => {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const { toast } = useToast();
  const submitReview = useSubmitReview();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await submitReview.mutateAsync({
        mentorId,
        rating,
        comment
      });
      
      onClose();
    } catch (error) {
      console.error("Error submitting review:", error);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="rating">Rating</Label>
        <div className="flex items-center space-x-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setRating(star)}
              className="focus:outline-none"
            >
              <FiStar 
                className={`h-6 w-6 ${star <= rating ? "text-amber-500 fill-amber-500" : "text-gray-300"}`} 
              />
            </button>
          ))}
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="comment">Your review</Label>
        <Textarea 
          id="comment"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Share your experience with this mentor..."
          rows={5}
          required
        />
      </div>
      
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button 
          type="submit" 
          className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700"
          disabled={submitReview.isPending}
        >
          {submitReview.isPending ? "Submitting..." : "Submit Review"}
        </Button>
      </DialogFooter>
    </form>
  );
};

// Component for showing mentor details with reviews
const MentorDetails = ({ mentor: initialMentor, onBack }: { mentor: any, onBack: () => void }) => {
  const [showReviewForm, setShowReviewForm] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Use the API hooks to fetch real data
  const { data: mentorData, isLoading: isMentorLoading } = useMentor(initialMentor?.id || null);
  const { data: reviewsData, isLoading: isReviewsLoading } = useMentorReviews(initialMentor?.id);
  
  // Combine initial data with API data
  const mentor = {
    ...initialMentor,
    ...mentorData,
    reviews: reviewsData?.data || []
  };
  
  const handleOpenReviewForm = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to submit a review",
        variant: "destructive"
      });
      return;
    }
    setShowReviewForm(true);
  };
  
  return (
    <div className="space-y-8">
      <Button variant="outline" onClick={onBack} className="mb-4">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to mentors
      </Button>
      
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-md p-8 border border-gray-200 dark:border-gray-800">
        <div className="flex flex-col md:flex-row md:items-start">
          <div className="md:w-1/3 flex flex-col items-center text-center mb-6 md:mb-0">
            <img 
              src={mentor.profileImage} 
              alt={mentor.name} 
              className="h-32 w-32 rounded-full object-cover border-3 border-cyan-500"
            />
            <h2 className="mt-4 text-2xl font-bold">{mentor.name}</h2>
            <div className="flex items-center mt-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <FiStar 
                    key={star} 
                    className={`${star <= Math.floor(mentor.rating) ? "text-amber-500 fill-amber-500" : "text-gray-300"} h-4 w-4`} 
                  />
                ))}
              </div>
              <span className="ml-2 text-sm font-medium">{mentor.rating}</span>
              <span className="mx-1 text-gray-400">•</span>
              <span className="text-sm text-gray-600 dark:text-gray-400">{mentor.reviewCount} reviews</span>
            </div>
            
            <div className="flex flex-wrap justify-center mt-3 gap-2">
              <Badge variant="outline" className="bg-white dark:bg-gray-800 capitalize">
                {mentor.specialization}
              </Badge>
              <Badge variant="outline" className="capitalize bg-white dark:bg-gray-800">
                {mentor.experienceLevel.replace('_', ' ')}
              </Badge>
            </div>
            
            <div className="mt-6 grid grid-cols-2 gap-4 w-full">
              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg text-center">
                <div className="text-lg font-bold">{mentor.experience}</div>
                <div className="text-xs text-gray-500">Years Exp.</div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg text-center">
                <div className="text-lg font-bold">{mentor.studentCount}</div>
                <div className="text-xs text-gray-500">Students</div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg text-center">
                <div className="text-lg font-bold">${mentor.hourlyRate}</div>
                <div className="text-xs text-gray-500">Hourly Rate</div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg text-center">
                <div className="text-lg font-bold">{mentor.languages}</div>
                <div className="text-xs text-gray-500">Languages</div>
              </div>
            </div>
            
            <div className="mt-6 w-full space-y-3">
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700">
                    <Calendar className="h-4 w-4 mr-2" />
                    Book a Session
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Book a Session</DialogTitle>
                    <DialogDescription>
                      Schedule a one-on-one mentoring session with {mentor.name}.
                    </DialogDescription>
                  </DialogHeader>
                  <BookingForm mentor={mentor} onClose={() => {}} />
                </DialogContent>
              </Dialog>
              
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={handleOpenReviewForm}
              >
                <Star className="h-4 w-4 mr-2" />
                Leave a Review
              </Button>
              
              <Dialog open={showReviewForm} onOpenChange={setShowReviewForm}>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Submit a Review</DialogTitle>
                    <DialogDescription>
                      Share your experience with {mentor.name} to help other traders.
                    </DialogDescription>
                  </DialogHeader>
                  <ReviewForm mentorId={mentor.id} onClose={() => setShowReviewForm(false)} />
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          <div className="md:w-2/3 md:pl-8 md:border-l md:border-gray-200 dark:md:border-gray-800">
            <h3 className="text-xl font-bold mb-4">About</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {mentor.bio}
              <br/><br/>
              With {mentor.experience} years of trading experience, I've helped over {mentor.studentCount} traders 
              improve their strategies and achieve consistent results. My teaching approach combines technical analysis, 
              risk management, and trading psychology to develop well-rounded traders.
              <br/><br/>
              I specialize in {mentor.specialization} trading with particular expertise in trend identification, 
              market structure analysis, and developing personalized trading systems that match your goals and personality.
            </p>
            
            <h3 className="text-xl font-bold mb-4">Session Types</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center mb-2">
                  <Video className="h-5 w-5 text-cyan-500 mr-2" />
                  <h4 className="font-bold">1:1 Coaching</h4>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Personalized mentoring sessions focused on your specific trading challenges
                </p>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center mb-2">
                  <BarChart4 className="h-5 w-5 text-cyan-500 mr-2" />
                  <h4 className="font-bold">Trade Review</h4>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Detailed analysis of your recent trades to identify patterns and improvements
                </p>
              </div>
            </div>
            
            <h3 className="text-xl font-bold mb-4">Reviews</h3>
            <div className="space-y-6">
              {/* Use the actual reviews from API */}
              {mentor.reviews && mentor.reviews.length > 0 ? (
                mentor.reviews.map((review: {
                  id: number;
                  userName?: string;
                  rating: number;
                  comment: string;
                  createdAt: string;
                }) => (
                  <div key={review.id} className="border-b border-gray-200 dark:border-gray-800 pb-6 last:border-0">
                    <div className="flex items-center mb-2">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-400 to-cyan-500 flex items-center justify-center text-white font-bold mr-3">
                        {review.userName ? review.userName.charAt(0).toUpperCase() : "U"}
                      </div>
                      <div>
                        <div className="font-medium">{review.userName || "Anonymous User"}</div>
                        <div className="text-sm text-gray-500">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="flex mb-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <FiStar 
                          key={star} 
                          className={`${star <= review.rating ? "text-amber-500 fill-amber-500" : "text-gray-300"} h-4 w-4`} 
                        />
                      ))}
                    </div>
                    <p className="text-gray-600 dark:text-gray-400">{review.comment}</p>
                  </div>
                ))
              ) : (
                <div className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <p className="text-gray-500">No reviews yet. Be the first to leave a review!</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface MentorsPageProps {
  selectedMentorId?: number;
}

export default function MentorsPage({ selectedMentorId }: MentorsPageProps) {
  const [filter, setFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMentor, setSelectedMentor] = useState<number | null>(selectedMentorId || null);
  const { user } = useAuth();
  
  // Use the mentors hook with filters
  const { data: mentorsData, isLoading, error } = useMentors({
    specialization: filter !== 'all' ? filter : undefined,
    search: searchQuery.trim() !== "" ? searchQuery : undefined,
    limit: 20,
    offset: 0
  });
  
  // Get the selected mentor data if we have an ID
  const { data: selectedMentorData } = useMentor(selectedMentor);
  
  // For now, still use the sample data until API is fully implemented
  const filteredMentors = mentorsData?.data || sampleMentors;
  
  // If a mentor is selected, show their detailed profile
  if (selectedMentor !== null) {
    // Use the selected mentor data from API if available, otherwise fall back to sample data
    const mentor = selectedMentorData || 
                  filteredMentors.find(m => m.id === selectedMentor) || 
                  sampleMentors.find(m => m.id === selectedMentor);
    
    if (mentor) {
      return <MentorDetails mentor={mentor} onBack={() => setSelectedMentor(null)} />;
    }
  }
  
  return (
    <div className="bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-gray-900 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="ghost" className="mr-4 hover:bg-transparent p-0">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold gradient-text">Verified Trading Mentors</h1>
        </div>
        
        <div className="bg-white dark:bg-gray-900 rounded-xl shadow-xl border border-gray-200 dark:border-gray-800 p-8 mb-8">
          <div className="text-center mb-10">
            <div className="flex items-center justify-center mb-4">
              <GraduationCap className="h-10 w-10 text-cyan-500 mr-3" />
              <h2 className="text-2xl md:text-3xl font-bold">Learn from Professional Traders</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Book one-on-one sessions with Tradefluenza-verified professional traders. Get personalized mentorship, 
              trading strategy reviews, and accelerate your journey to becoming a profitable trader.
            </p>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div className="inline-flex p-1 bg-gray-100 dark:bg-gray-800 rounded-xl">
              <button 
                onClick={() => setFilter("all")}
                className={`px-4 py-2 rounded-lg text-sm font-medium ${filter === "all" ? "bg-white dark:bg-gray-700 shadow-sm" : "text-gray-600 dark:text-gray-400"}`}
              >
                All Mentors
              </button>
              <button 
                onClick={() => setFilter("forex")}
                className={`px-4 py-2 rounded-lg text-sm font-medium ${filter === "forex" ? "bg-white dark:bg-gray-700 shadow-sm" : "text-gray-600 dark:text-gray-400"}`}
              >
                Forex
              </button>
              <button 
                onClick={() => setFilter("futures")}
                className={`px-4 py-2 rounded-lg text-sm font-medium ${filter === "futures" ? "bg-white dark:bg-gray-700 shadow-sm" : "text-gray-600 dark:text-gray-400"}`}
              >
                Futures
              </button>
              <button 
                onClick={() => setFilter("stocks")}
                className={`px-4 py-2 rounded-lg text-sm font-medium ${filter === "stocks" ? "bg-white dark:bg-gray-700 shadow-sm" : "text-gray-600 dark:text-gray-400"}`}
              >
                Stocks
              </button>
              <button 
                onClick={() => setFilter("crypto")}
                className={`px-4 py-2 rounded-lg text-sm font-medium ${filter === "crypto" ? "bg-white dark:bg-gray-700 shadow-sm" : "text-gray-600 dark:text-gray-400"}`}
              >
                Crypto
              </button>
            </div>
            
            <div className="relative w-full md:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Search by name or specialty..." 
                className="pl-10 w-full md:w-[300px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredMentors.length > 0 ? (
              filteredMentors.map((mentor) => (
                <div 
                  key={mentor.id} 
                  onClick={() => setSelectedMentor(mentor.id)}
                  className="cursor-pointer"
                >
                  <MentorCard mentor={mentor} />
                </div>
              ))
            ) : (
              <div className="col-span-2 text-center p-16 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                <Search className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-bold mb-2">No mentors found</h3>
                <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                  We couldn't find any mentors matching your search criteria. Try adjusting your filters or search query.
                </p>
              </div>
            )}
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-900 rounded-xl shadow-xl border border-gray-200 dark:border-gray-800 p-8">
          <h2 className="text-2xl font-bold mb-6">How It Works</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 rounded-xl">
              <div className="w-16 h-16 rounded-full bg-cyan-100 dark:bg-cyan-900/50 flex items-center justify-center mb-4">
                <GraduationCap className="h-8 w-8 text-cyan-600 dark:text-cyan-400" />
              </div>
              <h3 className="text-lg font-bold mb-2">Find Your Mentor</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Browse our directory of verified trading mentors with proven track records
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 rounded-xl">
              <div className="w-16 h-16 rounded-full bg-cyan-100 dark:bg-cyan-900/50 flex items-center justify-center mb-4">
                <Calendar className="h-8 w-8 text-cyan-600 dark:text-cyan-400" />
              </div>
              <h3 className="text-lg font-bold mb-2">Book a Session</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Schedule a one-on-one session at your preferred date and time
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 rounded-xl">
              <div className="w-16 h-16 rounded-full bg-cyan-100 dark:bg-cyan-900/50 flex items-center justify-center mb-4">
                <Star className="h-8 w-8 text-cyan-600 dark:text-cyan-400" />
              </div>
              <h3 className="text-lg font-bold mb-2">Leave Feedback</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Share your experience and help other traders find the right mentor
              </p>
            </div>
          </div>
        </div>
        
        {!user && (
          <div className="mt-8 p-6 bg-gradient-to-r from-cyan-500/10 to-blue-600/10 rounded-xl border border-cyan-200 dark:border-cyan-900 text-center">
            <h3 className="text-xl font-bold mb-2">Ready to book a session?</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Sign in or create an account to book a session with our verified mentors.
            </p>
            <Link href="/auth">
              <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700">
                Sign In / Register
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}