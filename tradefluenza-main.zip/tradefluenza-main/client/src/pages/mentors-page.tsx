import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  GraduationCap, 
  Search,
  Filter,
  ChevronDown,
  BarChart4,
  Loader2
} from "lucide-react";
import { useMentors } from "@/hooks/use-mentors";
import { MentorCard } from "@/components/mentors/MentorCard";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet-async";

export default function MentorsPage() {
  const [filters, setFilters] = useState({
    specialization: "",
    experienceLevel: "",
    minHourlyRate: 0,
    maxHourlyRate: 1000,
    search: ""
  });
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  // Fetch mentors with current filters
  const { data, isLoading, error } = useMentors(filters);
  
  // Function to update filters
  const updateFilter = (key: string, value: string | number) => {
    // If the value is "all", treat it as empty string for API filtering
    const actualValue = value === "all" ? "" : value;
    setFilters(prev => ({ ...prev, [key]: actualValue }));
  };
  
  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  // Handle search form submission
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateFilter("search", searchQuery);
  };
  
  // Specialization options
  const specializationOptions = [
    { value: "all", label: "All Specializations" },
    { value: "forex", label: "Forex" },
    { value: "stocks", label: "Stocks" },
    { value: "crypto", label: "Cryptocurrency" },
    { value: "futures", label: "Futures" },
    { value: "options", label: "Options" },
    { value: "day_trading", label: "Day Trading" },
    { value: "swing_trading", label: "Swing Trading" },
    { value: "technical_analysis", label: "Technical Analysis" },
    { value: "fundamental_analysis", label: "Fundamental Analysis" },
    { value: "risk_management", label: "Risk Management" },
  ];
  
  // Experience level options
  const experienceLevelOptions = [
    { value: "all", label: "All Experience Levels" },
    { value: "beginner", label: "Beginner" },
    { value: "intermediate", label: "Intermediate" },
    { value: "advanced", label: "Advanced" },
    { value: "professional", label: "Professional" },
    { value: "expert", label: "Expert" },
  ];

  return (
    <>
      <Helmet>
        <title>Get to Know Trusted Trading Mentor Reviews | Tradefluenza</title>
        <meta
          name="description"
          content="Find the best trusted trading mentor reviews with Tradefluenza. Discover expert guidance and mentorship to accelerate your trading success."
        />
        <meta
          name="keywords"
          content="trusted trading mentor reviews, expert trading mentorship"
        />
        <link rel="canonical" href="https://tradefluenza.com/mentors" />
      </Helmet>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="mb-4 md:mb-0">
            <h1 className="text-3xl font-bold flex items-center">
              <GraduationCap className="h-8 w-8 mr-2 text-cyan-500" />
              Trading Mentors
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Connect with experienced traders for personalized mentoring
              sessions
            </p>
          </div>

          <form onSubmit={handleSearchSubmit} className="flex w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search mentors..."
                className="pl-10 pr-4"
                value={searchQuery}
                onChange={handleSearchChange}
              />
            </div>
            <Button
              type="submit"
              className="ml-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white"
            >
              Search
            </Button>
          </form>
        </div>

        <div className="bg-gray-50 dark:bg-gray-800/40 p-4 rounded-lg mb-8">
          <div className="flex flex-col md:flex-row items-center gap-4">
            <div className="flex items-center">
              <Filter className="h-4 w-4 mr-2 text-gray-500" />
              <span className="text-sm font-medium">Filters:</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 flex-1">
              <Select
                value={filters.specialization || "all"}
                onValueChange={(value) => updateFilter("specialization", value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Specialization" />
                </SelectTrigger>
                <SelectContent>
                  {specializationOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={filters.experienceLevel || "all"}
                onValueChange={(value) =>
                  updateFilter("experienceLevel", value)
                }
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Experience Level" />
                </SelectTrigger>
                <SelectContent>
                  {experienceLevelOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={`${filters.minHourlyRate}-${filters.maxHourlyRate}`}
                onValueChange={(value) => {
                  const [min, max] = value.split("-").map(Number);
                  setFilters((prev) => ({
                    ...prev,
                    minHourlyRate: min,
                    maxHourlyRate: max,
                  }));
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Hourly Rate" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0-1000">All Rates</SelectItem>
                  <SelectItem value="0-50">Under $50/hour</SelectItem>
                  <SelectItem value="50-100">$50 - $100/hour</SelectItem>
                  <SelectItem value="100-200">$100 - $200/hour</SelectItem>
                  <SelectItem value="200-1000">$200+/hour</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              variant="outline"
              className="whitespace-nowrap"
              onClick={() =>
                setFilters({
                  specialization: "",
                  experienceLevel: "",
                  minHourlyRate: 0,
                  maxHourlyRate: 1000,
                  search: "",
                })
              }
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-cyan-500" />
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500">
              Error loading mentors. Please try again.
            </p>
          </div>
        ) : data?.data.length === 0 ? (
          <div className="text-center py-12">
            <BarChart4 className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold">No mentors found</h3>
            <p className="text-gray-500 mt-2">
              Try adjusting your filters or search query
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {data?.data.map((mentor) => (
                <MentorCard key={mentor.id} mentor={mentor} />
              ))}
            </div>

            {data?.pagination.hasMore && (
              <div className="flex justify-center mt-8">
                <Button
                  variant="outline"
                  onClick={() =>
                    toast({
                      title: "Coming soon",
                      description:
                        "Load more functionality will be available soon",
                    })
                  }
                  className="flex items-center"
                >
                  Load More <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
}