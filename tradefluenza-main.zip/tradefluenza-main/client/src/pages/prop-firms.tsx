import { useState, useEffect, useMemo, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import AccountSizeSelector from "@/components/prop-firms/account-size-selector";
import ComparisonTable from "@/components/prop-firms/comparison-table";
import ComparisonCard from "@/components/prop-firms/comparison-card";
import TradingFirmCard from "@/components/prop-firms/trading-firm-card";
import Pagination from "@/components/prop-firms/pagination";
import HorizontalSearch from "@/components/prop-firms/horizontal-search";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet-async";
import { 
  ArrowRight, 
  Trash, 
  BarChart2, 
  Star,
  ChevronDown,
  Globe,
  Clock,
  Server
} from "lucide-react";
import { PropFirm, TradingFirm } from "@shared/schema";

export default function PropFirms() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const { toast } = useToast();
  const params = new URLSearchParams(search);
  
  // Get account size from URL parameters, now showing all account sizes by default
  const defaultAccountSize = parseInt(params.get("accountSize") || "0");
  
  // Get filter params from URL
  const defaultProgramType = params.get("programType") || undefined;
  const defaultProfitTarget = params.get("profitTarget") ? parseInt(params.get("profitTarget")!) : undefined;
  const defaultDailyLoss = params.get("dailyLoss") ? parseInt(params.get("dailyLoss")!) : undefined;
  const defaultMaxLoss = params.get("maxLoss") ? parseInt(params.get("maxLoss")!) : undefined;
  const defaultProfitSplit = params.get("profitSplit") ? parseInt(params.get("profitSplit")!) : undefined;
  
  // State for current filters and pagination
  const [accountSize, setAccountSize] = useState<number>(defaultAccountSize);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  
  // State for view mode and pagination
  const [viewMode, setViewMode] = useState<'challenges' | 'firms'>('firms');
  
  // Fetch account sizes
  const { data: accountSizes = [] } = useQuery<number[]>({
    queryKey: ['/api/prop-firms/account-sizes']
  });
  
  // Build query parameters from the URL filters
  const buildQueryParams = () => {
    const queryParams = new URLSearchParams();
    queryParams.append("accountSize", accountSize.toString());
    
    // Add filters from the URL parameters (from search)
    if (defaultProgramType) {
      queryParams.append("programType", defaultProgramType);
    }
    
    if (defaultProfitTarget) {
      queryParams.append("profitTarget", defaultProfitTarget.toString());
    }
    
    if (defaultDailyLoss) {
      queryParams.append("dailyLoss", defaultDailyLoss.toString());
    }
    
    if (defaultMaxLoss) {
      queryParams.append("maxLoss", defaultMaxLoss.toString());
    }
    
    if (defaultProfitSplit) {
      queryParams.append("profitSplit", defaultProfitSplit.toString());
    }
    
    return queryParams.toString();
  };
  
  // Fetch prop firms data
  const { data: propFirms = [], isLoading: isLoadingPropFirms } = useQuery<PropFirm[]>({
    queryKey: [`/api/prop-firms?${buildQueryParams()}`]
  });
  
  // Fetch trading firms data (used in the "firms" view)
  const { data: tradingFirms = [], isLoading: isLoadingTradingFirms } = useQuery<TradingFirm[]>({
    queryKey: ['/api/trading-firms'],
    enabled: viewMode === 'firms'
  });
  
  // Combined loading state
  const isLoading = isLoadingPropFirms || (viewMode === 'firms' && isLoadingTradingFirms);
  
  // Update URL when account size changes, preserving the filter params from the URL
  useEffect(() => {
    const queryParams = new URLSearchParams();
    
    // Add account size and preserve filters from URL
    queryParams.set("accountSize", accountSize.toString());
    
    if (defaultProgramType) {
      queryParams.set("programType", defaultProgramType);
    }
    
    if (defaultProfitTarget) {
      queryParams.set("profitTarget", defaultProfitTarget.toString());
    }
    
    if (defaultDailyLoss) {
      queryParams.set("dailyLoss", defaultDailyLoss.toString());
    }
    
    if (defaultMaxLoss) {
      queryParams.set("maxLoss", defaultMaxLoss.toString());
    }
    
    if (defaultProfitSplit) {
      queryParams.set("profitSplit", defaultProfitSplit.toString());
    }
    
    // Update URL without navigating (replace current history entry)
    setLocation(`/prop-firms?${queryParams.toString()}`, { replace: true });
  }, [
    accountSize,
    defaultProgramType,
    defaultProfitTarget,
    defaultDailyLoss,
    defaultMaxLoss,
    defaultProfitSplit,
    setLocation
  ]);
  
  // Reset pagination when account size changes
  useEffect(() => {
    setCurrentPage(1);
  }, [accountSize]);
  
  // Calculate pagination values based on the active view
  const displayItems = viewMode === 'firms' ? tradingFirms : propFirms;
  const totalItems = displayItems.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const paginatedItems = displayItems.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  // Handle account size change
  const handleAccountSizeChange = (size: number) => {
    setAccountSize(size);
  };
  
  return (
    <>
      <Helmet>
        <title>
          Discover Now Best Prop Firm for Forex Traders | Tradefluenza
        </title>
        <meta
          name="description"
          content="Tradefluenza is the best platform to compare trading firms. Find the Best Prop Firm for Forex Traders and make the right choice for your trading journey."
        />
        <meta
          name="keywords"
          content="best platform to compare trading firms, Best Prop Firm for Forex Traders"
        />
        <link rel="canonical" href="https://tradefluenza.com/prop-firms" />
      </Helmet>
      <div className="bg-gradient-to-br from-background via-gray-50/80 to-accent/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Page Header */}
          <div className="mb-12 text-center">
            <div className="inline-block mb-3 rounded-full px-3 py-1 text-sm font-medium gradient-primary shadow-lg">
              Compare and Choose
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold gradient-text mb-4">
              Compare Prop Trading Firms
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Find the best ${(accountSize / 1000).toLocaleString()}K funded
              account that matches your trading style and preferences
            </p>
          </div>

          {/* Account Size Selector */}
          <AccountSizeSelector
            accountSizes={accountSizes}
            currentSize={accountSize}
            onChange={handleAccountSizeChange}
          />

          {/* Horizontal Search Bar */}
          <HorizontalSearch
            defaultProgramType={defaultProgramType}
            defaultProfitTarget={defaultProfitTarget}
            defaultDailyLoss={defaultDailyLoss}
            defaultMaxLoss={defaultMaxLoss}
            defaultProfitSplit={defaultProfitSplit}
            accountSize={accountSize}
          />

          {/* Space between filters and content */}
          <div className="mb-8"></div>

          {/* View Mode Toggle */}
          <div className="flex justify-center mb-8">
            <div className="bg-black rounded-full p-1 flex">
              <button
                className={`py-2 px-8 rounded-full text-center font-medium transition-all ${
                  viewMode === "firms" ? "bg-white text-black" : "text-white"
                }`}
                onClick={() => setViewMode("firms")}
              >
                Firms
              </button>
              <button
                className={`py-2 px-8 rounded-full text-center font-medium transition-all ${
                  viewMode === "challenges"
                    ? "bg-white text-black"
                    : "text-white"
                }`}
                onClick={() => setViewMode("challenges")}
              >
                Challenges
              </button>
            </div>
          </div>

          {/* Loading state */}
          {isLoading && (
            <div className="bg-white p-16 my-10 text-center rounded-2xl shadow-xl border border-gray-100 overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 opacity-50"></div>
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 animate-gradient-x"></div>
              <div className="inline-flex flex-col items-center relative z-10">
                <div className="w-20 h-20 mb-6 relative">
                  <div className="absolute inset-0 rounded-full border-t-3 border-l-3 border-r-3 border-transparent border-primary animate-spin"></div>
                  <div
                    className="absolute inset-2 rounded-full border-b-3 border-indigo-500/70 animate-spin"
                    style={{
                      animationDirection: "reverse",
                      animationDuration: "1.5s",
                    }}
                  ></div>
                  <div
                    className="absolute inset-4 rounded-full border-l-3 border-purple-500/60 animate-spin"
                    style={{ animationDuration: "2s" }}
                  ></div>
                  <div className="absolute inset-6 rounded-full bg-gradient-to-r from-blue-500 to-indigo-500 opacity-20 animate-pulse"></div>
                </div>
                <h3 className="text-xl font-bold mb-2 text-gray-800">
                  Loading Data
                </h3>
                <p className="text-gray-600">
                  Fetching the latest prop firm information for you...
                </p>
              </div>
            </div>
          )}

          {/* Empty state */}
          {!isLoading &&
            propFirms.length === 0 &&
            viewMode === "challenges" && (
              <div className="bg-white p-16 my-10 text-center rounded-2xl shadow-xl border border-gray-100 overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-br from-red-50 via-orange-50 to-amber-50 opacity-50"></div>
                <div className="relative z-10">
                  <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-red-500 to-amber-500 flex items-center justify-center shadow-lg">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-12 w-12 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold mb-3 bg-gradient-to-r from-red-600 via-orange-500 to-amber-600 text-transparent bg-clip-text">
                    No Results Found
                  </h3>
                  <p className="text-gray-700 mb-8 max-w-md mx-auto">
                    No prop firms match your current filter criteria. Try
                    adjusting your filters or clearing them to see all available
                    options.
                  </p>
                  <button
                    onClick={() => {
                      // Return to the homepage to reset filters
                      setLocation("/");
                    }}
                    className="bg-gradient-to-r from-red-500 to-amber-500 hover:from-red-600 hover:to-amber-600 px-8 py-3 rounded-lg font-semibold text-white shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
                  >
                    Back to Homepage
                  </button>
                </div>
              </div>
            )}

          {/* Challenges View */}
          {!isLoading && propFirms.length > 0 && viewMode === "challenges" && (
            <>
              {/* Challenges Table - Desktop View */}
              <div className="hidden lg:block">
                <div className="relative">
                  <ComparisonTable propFirms={paginatedItems} />
                </div>
              </div>

              {/* Challenges Cards - Mobile View */}
              <div className="lg:hidden space-y-6">
                {paginatedItems.map((firm) => (
                  <div key={firm.id} className="relative">
                    <ComparisonCard firm={firm} />
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Firms View */}
          {!isLoading && viewMode === "firms" && tradingFirms.length > 0 && (
            <div>
              {/* Desktop View */}
              <div className="hidden lg:block rounded-xl overflow-hidden shadow-xl bg-gradient-to-r from-indigo-950 via-purple-950 to-indigo-950 text-white mb-6">
                {/* Header with count */}
                <div className="flex items-center py-6 px-8 bg-gradient-to-r from-indigo-900/80 to-purple-900/80">
                  <h2 className="text-xl font-semibold bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent">
                    Top-Rated Trading Firms{" "}
                    <span className="ml-2 text-lg bg-gradient-to-r from-indigo-400 to-purple-300 bg-clip-text">
                      ({tradingFirms.length})
                    </span>
                  </h2>
                </div>

                {/* Table */}
                <table className="w-full border-collapse">
                  {/* Table Header */}
                  <thead>
                    <tr className="border-b border-indigo-800/50 bg-gradient-to-r from-indigo-900/70 via-purple-900/70 to-indigo-900/70 text-xs uppercase text-indigo-200">
                      <th className="py-4 px-3 text-left w-[17%]">Firm</th>
                      <th className="py-4 px-2 text-center">
                        <div className="flex items-center justify-center">
                          Rank <ChevronDown className="h-3 w-3 ml-1" />
                        </div>
                      </th>
                      <th className="py-4 px-2 text-center">
                        <div className="flex items-center justify-center">
                          Reviews <ChevronDown className="h-3 w-3 ml-1" />
                        </div>
                      </th>
                      <th className="py-4 px-2 text-center">
                        <div className="flex items-center justify-center">
                          Country <ChevronDown className="h-3 w-3 ml-1" />
                        </div>
                      </th>
                      <th className="py-4 px-2 text-center">
                        <div className="flex items-center justify-center">
                          Years <ChevronDown className="h-3 w-3 ml-1" />
                        </div>
                      </th>
                      <th className="py-4 px-2 text-center w-[16%]">Assets</th>
                      <th className="py-4 px-2 text-center">Platforms</th>
                      <th className="py-4 px-2 text-center">Promo</th>
                      <th className="py-4 px-2 text-center w-[10%]">Actions</th>
                    </tr>
                  </thead>

                  {/* Table Body */}
                  <tbody>
                    {tradingFirms.map((firm) => (
                      <tr
                        key={firm.id}
                        className="border-b border-indigo-800/30 hover:bg-gradient-to-r hover:from-indigo-900/50 hover:to-purple-900/50 transition-all duration-200"
                      >
                        {/* Firm */}
                        <td className="py-4 px-3">
                          <div className="flex items-center space-x-3">
                            <div className="h-14 w-14 flex items-center justify-center bg-purple-600 rounded-lg shadow-lg flex-shrink-0">
                              {firm.logoUrl ? (
                                <img
                                  src={firm.logoUrl}
                                  alt={firm.name}
                                  className="h-8 w-8 object-contain"
                                />
                              ) : (
                                <span className="text-2xl font-bold text-white">
                                  {firm.name.charAt(0)}
                                </span>
                              )}
                            </div>
                            <div className="flex flex-col">
                              <div className="font-semibold text-white">
                                {firm.name}
                              </div>
                              <div className="flex items-center mt-1">
                                <div className="w-2 h-2 rounded-full bg-indigo-400 mr-2"></div>
                                <span className="text-xs text-indigo-300">
                                  Est. {firm.yearsInOperation}
                                </span>
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Rank */}
                        <td className="py-4 px-2 text-center">
                          <div className="flex justify-center">
                            <div className="bg-gradient-to-r from-indigo-900/80 to-purple-800/80 text-white py-1 px-3 rounded-full text-sm border border-indigo-700/30">
                              {firm.rank || "–"}
                            </div>
                          </div>
                        </td>

                        {/* Reviews */}
                        <td className="py-4 px-2 text-center">
                          <div className="flex justify-center">
                            <div className="bg-gradient-to-r from-indigo-800/60 to-purple-800/60 rounded-full h-8 w-8 flex items-center justify-center border border-indigo-700/30 text-white">
                              {firm.reviewCount || 0}
                            </div>
                          </div>
                        </td>

                        {/* Country */}
                        <td className="py-4 px-2 text-center">
                          <div className="flex items-center justify-center">
                            <Globe className="h-4 w-4 text-indigo-400 mr-1 flex-shrink-0" />
                            <span className="text-white">
                              {firm.country || "–"}
                            </span>
                          </div>
                        </td>

                        {/* Years in Operation */}
                        <td className="py-4 px-2 text-center">
                          <div className="flex items-center justify-center">
                            <Clock className="h-4 w-4 mr-1 text-indigo-400 flex-shrink-0" />
                            <span className="text-white">
                              {firm.yearsInOperation || "–"} years
                            </span>
                          </div>
                        </td>

                        {/* Assets */}
                        <td className="py-4 px-2 text-center">
                          <div className="flex flex-wrap gap-1 justify-center">
                            {firm.assets &&
                              firm.assets
                                .slice(0, 3)
                                .map((asset: string, index: number) => (
                                  <span
                                    key={index}
                                    className="inline-block px-2 py-1 text-xs bg-indigo-700 rounded text-white font-medium"
                                  >
                                    {asset}
                                  </span>
                                ))}
                          </div>
                        </td>

                        {/* Platforms */}
                        <td className="py-4 px-2 text-center">
                          <div className="flex gap-1 justify-center">
                            {firm.platforms &&
                              firm.platforms.map(
                                (platform: string, index: number) => (
                                  <span
                                    key={index}
                                    className="h-7 w-7 bg-purple-700 rounded-full flex items-center justify-center text-xs text-white font-medium"
                                  >
                                    {platform === "MT4"
                                      ? "M4"
                                      : platform === "MT5"
                                      ? "M5"
                                      : platform.charAt(0)}
                                  </span>
                                )
                              )}
                          </div>
                        </td>

                        {/* Promo */}
                        <td className="py-4 px-2 text-center">
                          {firm.promoDiscount ? (
                            <div
                              className="rounded-lg overflow-hidden shadow-lg flex cursor-pointer group relative transition-all duration-200 mx-auto inline-block"
                              onClick={() => {
                                if (firm.couponCode) {
                                  navigator.clipboard.writeText(
                                    firm.couponCode
                                  );
                                  toast({
                                    title: "Code copied!",
                                    description: `${firm.couponCode} has been copied to clipboard`,
                                    variant: "default",
                                  });
                                }
                              }}
                              title="Click to copy code"
                            >
                              <div className="bg-purple-600 h-full flex items-center justify-center px-2 py-1">
                                <div className="text-white font-bold text-sm whitespace-nowrap">
                                  {firm.promoDiscount}%&nbsp;OFF
                                </div>
                              </div>
                              <div className="bg-black h-full flex items-center justify-center px-2 py-1 group-hover:bg-gray-900 transition-colors">
                                <div className="text-white text-xs font-semibold flex items-center whitespace-nowrap">
                                  {firm.couponCode || "CODE"}
                                  <svg
                                    className="h-3 w-3 ml-1 text-white opacity-70 group-hover:opacity-100"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                  >
                                    <rect
                                      x="9"
                                      y="9"
                                      width="13"
                                      height="13"
                                      rx="2"
                                      ry="2"
                                    ></rect>
                                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                                  </svg>
                                </div>
                              </div>
                            </div>
                          ) : firm.promo ? (
                            <div className="rounded-lg bg-gradient-to-r from-blue-700 to-indigo-700 text-white py-2 px-3 text-xs font-medium inline-flex items-center justify-center">
                              {firm.promo}
                            </div>
                          ) : (
                            <div className="text-white text-sm">No Promo</div>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="py-4 px-2 text-center">
                          <button
                            onClick={() =>
                              window.open(firm.websiteUrl, "_blank")
                            }
                            className="inline-flex items-center justify-center px-3 h-8 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium rounded-md transition-all duration-200 shadow-md hover:shadow-lg text-sm"
                          >
                            Visit{" "}
                            <ArrowRight className="ml-1 h-3.5 w-3.5 flex-shrink-0" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile View */}
              <div className="lg:hidden">
                <div className="rounded-xl overflow-hidden shadow-xl bg-gradient-to-r from-indigo-950 via-purple-950 to-indigo-950 text-white mb-6">
                  <div className="flex items-center justify-between py-4 px-6 bg-gradient-to-r from-indigo-900/80 to-purple-900/80">
                    <h2 className="text-lg font-semibold bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent">
                      Trading Firms
                    </h2>
                    <span className="px-3 py-1 rounded-full bg-indigo-800/70 text-indigo-200 text-sm">
                      {tradingFirms.length} firms
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {tradingFirms.map((firm) => (
                    <TradingFirmCard key={firm.id} firm={firm} />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Empty state for Trading Firms */}
          {!isLoading && tradingFirms.length === 0 && viewMode === "firms" && (
            <div className="bg-white p-16 my-10 text-center rounded-2xl shadow-xl border border-gray-100 overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 opacity-50"></div>
              <div className="relative z-10">
                <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center shadow-lg">
                  <Server className="h-12 w-12 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3 bg-gradient-to-r from-indigo-600 via-blue-500 to-purple-600 text-transparent bg-clip-text">
                  No Trading Firms Found
                </h3>
                <p className="text-gray-700 mb-8 max-w-md mx-auto">
                  We're currently adding more trading firms to our database.
                  Check back soon for more options!
                </p>
              </div>
            </div>
          )}

          {/* Pagination */}
          {!isLoading && displayItems.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              totalItems={totalItems}
              itemsPerPage={itemsPerPage}
            />
          )}
        </div>
      </div>
    </>
  );
}