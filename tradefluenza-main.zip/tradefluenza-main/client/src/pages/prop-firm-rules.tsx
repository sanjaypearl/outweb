import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Filter,
  Search,
  BookOpen,
  AlertTriangle,
  Copy,
  TrendingUp,
  Users,
  Calendar,
  Shield,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { FiStar } from "react-icons/fi";
import { Helmet } from "react-helmet-async";

interface PropFirmRule {
  id: number;
  name: string;
  established: string;
  rating: string;
  reviewCount: number;
  logoUrl?: string;
  htmltext?: string; // Rich HTML content for detailed rule descriptions
  newsTrading: any; // JSON field, can be object or string
  copyTrading: any; // JSON field, can be object or string
  expertAdvisors: any; // JSON field, can be object or string
  riskManagement: any; // JSON field, can be object or string
  tradingRestrictions: any; // JSON field, can be object or string
  category: string;
}

const PropFirmRules = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  // Fetch prop firm rules with filtering
  const { data: propFirmRules, isLoading } = useQuery<PropFirmRule[]>({
    queryKey: ["/api/prop-firm-rules", searchTerm, activeTab],
  });

  const filteredRules = propFirmRules || [];

  const totalRules = filteredRules.length;

  if (isLoading) {
    return (
      <>
        <Helmet>
        <link rel="canonical" href="https://tradefluenza.com/prop-firm-rules" />
      </Helmet>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <Skeleton className="h-10 w-64 mx-auto mb-4" />
            <Skeleton className="h-6 w-96 mx-auto mb-8" />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="bg-white dark:bg-gray-800">
                <CardHeader>
                  <Skeleton className="h-6 w-32 mb-2" />
                  <Skeleton className="h-4 w-24" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <link rel="canonical" href="https://tradefluenza.com/prop-firm-rules" />
      </Helmet>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="p-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl">
                <BookOpen className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
                Prop Firm Rules
              </h1>
            </div>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-4xl mx-auto">
              In the prop trading industry, rules can vary significantly from
              one firm to another based on their risk management policies. This
              section provides key rules for each firm and highlights any
              significant rule changes along with the specific dates of those
              changes.
            </p>
          </div>

          {/* Controls */}
          <div className="flex flex-col lg:flex-row gap-4 mb-8">
            {/* Filter and Tabs */}
            <div className="flex items-center gap-4">
              <Button variant="outline" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Filter
              </Button>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="all">Key Rules</TabsTrigger>
                  <TabsTrigger value="changes">Rule Changes</TabsTrigger>
                  <TabsTrigger value="eas">
                    EAs, Copy Trading, and Platforms
                  </TabsTrigger>
                  <TabsTrigger value="risk">Risk Management</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Search */}
            <div className="relative lg:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Rules Count */}
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Rules <span className="text-purple-600">{totalRules}</span>
            </h2>
          </div>

          {/* Rules Grid */}
          <div className="grid grid-cols-1 gap-6">
            {filteredRules.map((firm) => (
              <Card
                key={firm.id}
                className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-shadow"
              >
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {/* Logo */}
                      <div className="w-16 h-16 rounded-lg bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center text-white font-bold text-lg">
                        {firm.logoUrl ? (
                          <img
                            src={firm.logoUrl}
                            alt={firm.name}
                            className="w-full h-full object-cover rounded-lg"
                          />
                        ) : (
                          firm.name.charAt(0)
                        )}
                      </div>

                      {/* Firm Info */}
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                          {firm.name}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                          <Calendar className="h-4 w-4" />
                          <span>{firm.established}</span>
                        </div>
                      </div>
                    </div>

                    {/* Rating */}
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <span className="text-lg font-bold text-gray-900 dark:text-white">
                          {firm.rating}
                        </span>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <FiStar
                              key={star}
                              className={`h-4 w-4 ${
                                star <= parseFloat(firm.rating)
                                  ? "text-yellow-400 fill-current"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {firm.reviewCount}
                      </span>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="pt-0">
                  {/* HTML Content Display */}
                  {firm.htmltext && (
                    <div
                      className="prose prose-sm max-w-none dark:prose-invert"
                      dangerouslySetInnerHTML={{ __html: firm.htmltext }}
                    />
                  )}

                  {/* Fallback to old structure if no HTML content */}
                  {!firm.htmltext && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {/* News Trading */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="h-5 w-5 text-blue-500" />
                          <h4 className="font-semibold text-gray-900 dark:text-white">
                            News Trading
                          </h4>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                            <div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {typeof firm.newsTrading === "object"
                                  ? JSON.stringify(firm.newsTrading)
                                  : firm.newsTrading}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Copy Trading */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Copy className="h-5 w-5 text-purple-500" />
                          <h4 className="font-semibold text-gray-900 dark:text-white">
                            Copy Trading
                          </h4>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                            <div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {typeof firm.copyTrading === "object"
                                  ? JSON.stringify(firm.copyTrading)
                                  : firm.copyTrading}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Expert Advisors */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Shield className="h-5 w-5 text-green-500" />
                          <h4 className="font-semibold text-gray-900 dark:text-white">
                            Expert Advisors (EAs)
                          </h4>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {typeof firm.expertAdvisors === "object"
                                ? JSON.stringify(firm.expertAdvisors)
                                : firm.expertAdvisors}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Risk Management - Always show if no HTML content */}
                  {!firm.htmltext && (
                    <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <AlertTriangle className="h-5 w-5 text-orange-500" />
                            <h4 className="font-semibold text-gray-900 dark:text-white">
                              Risk Management
                            </h4>
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-start gap-2">
                              <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {typeof firm.riskManagement === "object"
                                  ? JSON.stringify(firm.riskManagement)
                                  : firm.riskManagement}
                              </p>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <AlertTriangle className="h-5 w-5 text-red-500" />
                            <h4 className="font-semibold text-gray-900 dark:text-white">
                              Trading Restrictions
                            </h4>
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-start gap-2">
                              <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {typeof firm.tradingRestrictions === "object"
                                  ? JSON.stringify(firm.tradingRestrictions)
                                  : firm.tradingRestrictions}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* No Results */}
          {filteredRules.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 mb-4">
                <Search className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                No rules found
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Try adjusting your search or filter criteria
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default PropFirmRules;
