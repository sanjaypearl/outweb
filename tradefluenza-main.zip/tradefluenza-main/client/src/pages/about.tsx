import { FiUsers, FiTrendingUp, FiAward, FiShield, FiLayers, FiCheckCircle, FiArrowRight } from 'react-icons/fi';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'wouter';
import { Helmet } from "react-helmet-async";

// Team member images
import rishavImage from '../assets/rishav_Negi.jpeg';
import bobbyImage from '../assets/Bobby_Arya.jpeg';
import raviImage from '../assets/ravi_verma.jpeg';
import virajImage from '../assets/viraj_CHAUDHARY.jpg';
import aamirImage from '../assets/aamir.jpeg';
import snehaImage from '../assets/sneha.jpg';
import akashImage from '../assets/akash.jpg';

export default function AboutPage() {
  return (
    <>
      <Helmet>
        <link rel="canonical" href="https://tradefluenza.com/about"/>
      </Helmet>
      <div className="container mx-auto px-4 py-12">
        {/* Hero section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-indigo-600 inline-block text-transparent bg-clip-text">
            About Tradefluenza
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Empowering traders with data-driven insights and transparent
            information about prop firms and brokers.
          </p>
        </div>

        {/* Mission section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              At Tradefluenza, we believe that every trader deserves access to
              accurate, unbiased information to make informed decisions. Our
              mission is to bring transparency to the world of prop trading and
              brokerage services.
            </p>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              We meticulously research and analyze prop firms and brokers,
              providing comprehensive data and genuine user reviews to help
              traders find the perfect partners for their trading journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <Link href="/prop-firms">
                <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                  Explore Prop Firms <FiArrowRight className="ml-2" />
                </Button>
              </Link>
              <Link href="/brokers">
                <Button variant="outline">Compare Brokers</Button>
              </Link>
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 p-8 rounded-2xl border border-blue-100 dark:border-blue-800">
            <div className="grid grid-cols-2 gap-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full bg-blue-100 dark:bg-blue-800/50 flex items-center justify-center mb-3">
                  <FiUsers className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="font-semibold mb-1">Community</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Building a community of informed traders
                </p>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full bg-indigo-100 dark:bg-indigo-800/50 flex items-center justify-center mb-3">
                  <FiTrendingUp className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
                </div>
                <h3 className="font-semibold mb-1">Growth</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Helping traders grow and succeed
                </p>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full bg-blue-100 dark:bg-blue-800/50 flex items-center justify-center mb-3">
                  <FiAward className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="font-semibold mb-1">Excellence</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Promoting high standards in trading
                </p>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full bg-indigo-100 dark:bg-indigo-800/50 flex items-center justify-center mb-3">
                  <FiShield className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
                </div>
                <h3 className="font-semibold mb-1">Transparency</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Providing honest, unbiased information
                </p>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-16" />

        {/* What We Do section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">What We Do</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-blue-100 dark:border-blue-800">
              <CardContent className="p-6">
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-800/50 flex items-center justify-center mb-4">
                  <FiLayers className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3">
                  Comprehensive Analysis
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  We thoroughly research and analyze each prop firm and broker,
                  presenting detailed information on account types, trading
                  conditions, fees, and more.
                </p>
              </CardContent>
            </Card>
            <Card className="border-indigo-100 dark:border-indigo-800">
              <CardContent className="p-6">
                <div className="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-800/50 flex items-center justify-center mb-4">
                  <FiCheckCircle className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Verified Reviews</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  We collect and verify user reviews to provide real-world
                  perspectives on the services offered by prop firms and
                  brokers, helping you make informed decisions.
                </p>
              </CardContent>
            </Card>
            <Card className="border-blue-100 dark:border-blue-800">
              <CardContent className="p-6">
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-800/50 flex items-center justify-center mb-4">
                  <FiTrendingUp className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3">
                  Educational Resources
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  We provide educational content and guidance to help traders
                  understand the nuances of prop trading and make the most of
                  their trading opportunities.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Team section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-4">Our Team</h2>
          <p className="text-center text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-12">
            Tradefluenza is built by a team of passionate traders and financial
            experts dedicated to bringing transparency to the prop trading
            industry.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-800 dark:to-indigo-800 mx-auto mb-4 flex items-center justify-center overflow-hidden">
                <img
                  src={rishavImage}
                  alt="Rishav Negi"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Rishav Negi</h3>
              <p className="text-indigo-600 dark:text-indigo-400 mb-3">
                Co-Founder
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm max-w-xs mx-auto">
                Experienced trader with a vision to bring transparency to the
                prop trading industry through data-driven insights.
              </p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-800 dark:to-indigo-800 mx-auto mb-4 flex items-center justify-center overflow-hidden">
                <img
                  src={virajImage}
                  alt="Viraj Chaudhary"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Viraj Chaudhary</h3>
              <p className="text-indigo-600 dark:text-indigo-400 mb-3">
                Co-Founder
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm max-w-xs mx-auto">
                Serial Entrepreneur with a vision of building world's first
                verified and transparent community with mentors.
              </p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-800 dark:to-indigo-800 mx-auto mb-4 flex items-center justify-center overflow-hidden">
                <img
                  src={bobbyImage}
                  alt="Bobby Arya"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Bobby Arya</h3>
              <p className="text-indigo-600 dark:text-indigo-400 mb-3">
                Co-Founder
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm max-w-xs mx-auto">
                Trading strategist with extensive knowledge of prop firm
                challenges and success factors.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mt-8">
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-800 dark:to-indigo-800 mx-auto mb-4 flex items-center justify-center overflow-hidden">
                <img
                  src={aamirImage}
                  alt="Aamir Ansari"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Aamir Ansari</h3>
              <p className="text-indigo-600 dark:text-indigo-400 mb-3">
                Co-Founder
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm max-w-xs mx-auto">
                Technology innovator focused on creating intuitive trading tools
                and platform comparisons.
              </p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-800 dark:to-indigo-800 mx-auto mb-4 flex items-center justify-center overflow-hidden">
                <img
                  src={akashImage}
                  alt="Akash Verma"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Akash Verma</h3>
              <p className="text-indigo-600 dark:text-indigo-400 mb-3">
                Founding Team & Team Lead
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm max-w-xs mx-auto">
                Trading specialist with expertise in developing strategic
                trading approaches and leading team initiatives.
              </p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-800 dark:to-indigo-800 mx-auto mb-4 flex items-center justify-center overflow-hidden">
                <img
                  src={raviImage}
                  alt="Ravi Verma"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Ravi Verma</h3>
              <p className="text-indigo-600 dark:text-indigo-400 mb-3">
                Tech Strategy
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm max-w-xs mx-auto">
                Technology strategist leading platform development and
                innovation to enhance the user experience.
              </p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-800 dark:to-indigo-800 mx-auto mb-4 flex items-center justify-center overflow-hidden">
                <img
                  src={snehaImage}
                  alt="Sneha"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Sneha</h3>
              <p className="text-indigo-600 dark:text-indigo-400 mb-3">
                Founder's Office
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm max-w-xs mx-auto">
                Operations specialist coordinating team efforts and ensuring
                smooth functioning of all platform services.
              </p>
            </div>
          </div>
        </div>

        {/* Contact section */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Get in Touch</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-8">
            Have questions or suggestions? We'd love to hear from you. Contact
            our team for more information about our services or to provide
            feedback.
          </p>
          <Link href="/contact">
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
              Contact Us
            </Button>
          </Link>
        </div>
      </div>
    </>
  );
}