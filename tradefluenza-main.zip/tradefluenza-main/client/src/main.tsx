import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { suppressResizeObserverErrors } from "./lib/suppress-resize-observer-errors";
import { initializePerformanceOptimizations } from "./lib/preload";
import { performMemoryCleanup } from "./lib/memory-cleanup";
import { HelmetProvider } from "react-helmet-async";

// Suppress harmless ResizeObserver errors that come from Shadcn UI components
suppressResizeObserverErrors();

// Initialize performance optimizations
initializePerformanceOptimizations();

// Setup periodic memory cleanup to reduce RAM usage
if (typeof window !== 'undefined') {
  setInterval(() => {
    performMemoryCleanup();
  }, 5 * 60 * 1000); // Clean up every 5 minutes
}

// Create root with a callback that measures initial render performance
const root = createRoot(document.getElementById("root")!);

// Performance measurement for development mode only
if (process.env.NODE_ENV === 'development') {
  const startTime = performance.now();
  root.render(
    <HelmetProvider>
      <App />
    </HelmetProvider>
  );
  
  // Log render time once the component has mounted
  setTimeout(() => {
    const endTime = performance.now();
    console.log(`Initial render took ${Math.round(endTime - startTime)}ms`);
  }, 0);
} else {
  // In production, just render without the performance logging
  root.render(
    <HelmetProvider>
      <App />
    </HelmetProvider>
  );
}
