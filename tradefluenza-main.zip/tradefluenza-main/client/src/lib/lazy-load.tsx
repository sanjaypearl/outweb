import { lazy, Suspense, ComponentType } from "react";
import { Loader2 } from "lucide-react";

/**
 * Function to lazily load components only when they're needed
 * This reduces initial bundle size and improves performance
 */
export function lazyLoad<T extends ComponentType<any>>(
  importFunc: () => Promise<{ default: T }>,
  fallback: React.ReactNode = <LoadingFallback />
) {
  const LazyComponent = lazy(importFunc);

  return (props: React.ComponentProps<T>) => (
    <Suspense fallback={fallback}>
      <LazyComponent {...props} />
    </Suspense>
  );
}

/**
 * Default loading spinner to show while lazily loaded components are loading
 */
export function LoadingFallback() {
  return (
    <div className="flex items-center justify-center p-8 min-h-[200px]">
      <Loader2 className="h-8 w-8 animate-spin text-primary/70" />
    </div>
  );
}

/**
 * Predefined lazy-loaded components for performance optimization
 */

// Core pages that can be lazy loaded
export const LazyPropFirms = lazyLoad(() => import("@/pages/prop-firms"));
export const LazyPropFirmDetail = lazyLoad(
  () => import("@/pages/prop-firm-detail")
);
export const LazyBrokerDetail = lazyLoad(() => import("@/pages/broker-detail"));
export const LazyMentorsPage = lazyLoad(() => import("@/pages/mentors-page"));
export const LazyMentorDetail = lazyLoad(() => import("@/pages/mentor-detail"));
export const LazyQuiz = lazyLoad(() => import("@/pages/quiz"));
export const LazyEventsPage = lazyLoad(() => import("@/pages/events"));
export const LazyEventDetail = lazyLoad(() => import("@/pages/event-detail"));
