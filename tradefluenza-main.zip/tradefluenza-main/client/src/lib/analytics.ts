// Google Analytics utility functions
import { useEffect } from 'react';
import { useLocation } from 'wouter';

// React hook to initialize analytics and track page views
export const useAnalytics = (): void => {
  const [location] = useLocation();
  
  // Track page views when location changes
  useEffect(() => {
    trackPageView(location);
  }, [location]);
};

// Track page views
export const trackPageView = (path: string): void => {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    window.gtag('config', 'G-FCTC2LSV40', {
      page_path: path,
    });
  }
};

// Track events
export const trackEvent = (
  action: string,
  category: string, 
  label?: string, 
  value?: number
): void => {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
};

// Custom events
export const trackBuyNowClick = (firmName: string, accountSize: number): void => {
  trackEvent('buy_now_click', 'purchase', firmName, accountSize);
};

export const trackCouponCopy = (couponCode: string, firmName: string): void => {
  trackEvent('copy_coupon', 'engagement', `${couponCode} - ${firmName}`);
};

export const trackFilterApply = (filterType: string, filterValue: string): void => {
  trackEvent('apply_filter', 'filter', `${filterType}: ${filterValue}`);
};