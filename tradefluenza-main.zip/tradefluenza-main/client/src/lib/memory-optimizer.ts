/**
 * Memory optimization utilities to reduce RAM usage
 */

// WeakMap for caching to allow garbage collection
const componentCache = new WeakMap();

// Optimize React Query cache size
export const queryClientConfig = {
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
      refetchOnWindowFocus: false,
      retry: 1, // Reduce retry attempts to save memory
    },
  },
};

// Cleanup function for unused data
export function cleanupUnusedData() {
  // Force garbage collection if available
  if (typeof window !== 'undefined' && (window as any).gc) {
    (window as any).gc();
  }
}

// Optimized image loading
export function optimizeImageLoading(img: HTMLImageElement) {
  img.loading = 'lazy';
  img.decoding = 'async';
}

// Remove unused event listeners
export function cleanupEventListeners() {
  const elements = document.querySelectorAll('[data-cleanup-listeners]');
  elements.forEach(element => {
    const clonedElement = element.cloneNode(true);
    element.parentNode?.replaceChild(clonedElement, element);
  });
}