/**
 * Performance optimization utilities to reduce RAM usage and improve performance
 */

// Debounce function to limit expensive operations
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

// Throttle function to limit function calls
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

// Memory cleanup for large objects
export function cleanupMemory() {
  if (typeof window !== 'undefined' && window.gc) {
    window.gc();
  }
}

// Image lazy loading with intersection observer
export function createImageObserver(callback: (entry: IntersectionObserverEntry) => void) {
  return new IntersectionObserver(
    (entries) => {
      entries.forEach(callback);
    },
    {
      rootMargin: '50px',
      threshold: 0.1
    }
  );
}

// Reduce bundle size by removing unused console logs in production
export const log = process.env.NODE_ENV === 'development' 
  ? console.log 
  : () => {};

export const warn = process.env.NODE_ENV === 'development' 
  ? console.warn 
  : () => {};