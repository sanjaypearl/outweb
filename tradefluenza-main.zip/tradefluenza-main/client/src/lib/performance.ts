/**
 * Performance utility functions to optimize the website
 */

/**
 * Debounce function to limit how often a function can be called
 * Useful for search inputs, window resize handlers, etc.
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout> | null = null;
  
  return function(...args: Parameters<T>) {
    const later = () => {
      timeout = null;
      func(...args);
    };
    
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Throttle function to ensure a function is not called more than once
 * in the specified time period
 * Useful for scroll handlers, mouse move events, etc.
 */
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle = false;
  
  return function(...args: Parameters<T>) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limit);
    }
  };
}

/**
 * Memoize function results to avoid expensive recalculations
 */
export function memoize<T extends (...args: any[]) => any>(
  func: T
): (...args: Parameters<T>) => ReturnType<T> {
  const cache = new Map<string, ReturnType<T>>();
  
  return function(...args: Parameters<T>): ReturnType<T> {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      return cache.get(key) as ReturnType<T>;
    }
    
    const result = func(...args);
    cache.set(key, result);
    return result;
  };
}

/**
 * Function to optimize images by creating appropriate srcset
 * @param baseUrl The base URL of the image
 * @param sizes Array of sizes to generate
 * @returns A srcset string for responsive images
 */
export function generateSrcSet(baseUrl: string, sizes: number[] = [300, 600, 900, 1200]): string {
  const extension = baseUrl.split('.').pop() || '';
  const basePath = baseUrl.substring(0, baseUrl.lastIndexOf('.'));
  
  return sizes
    .map(size => `${basePath}-${size}.${extension} ${size}w`)
    .join(', ');
}

/**
 * Preload critical resources
 * @param urls Array of resource URLs to preload
 */
export function preloadResources(urls: string[]): void {
  if (typeof window === 'undefined') return;
  
  urls.forEach(url => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.href = url;
    link.as = url.endsWith('.js') ? 'script' : 
               url.endsWith('.css') ? 'style' : 
               url.match(/\.(jpe?g|png|gif|svg|webp)$/i) ? 'image' : 
               'fetch';
    document.head.appendChild(link);
  });
}