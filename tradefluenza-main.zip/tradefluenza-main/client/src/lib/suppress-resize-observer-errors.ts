/**
 * This utility suppresses harmless ResizeObserver errors
 * by catching them and preventing them from appearing in the console.
 * These errors occur during normal operation of Shadcn UI components
 * that use resize observers internally.
 */

export function suppressResizeObserverErrors() {
  // Store the original error handler
  const originalOnError = window.onerror;

  // Create a custom error handler
  window.onerror = function(msg, source, lineNo, columnNo, error) {
    // Check if the error is a ResizeObserver loop error
    if (msg.toString().includes('ResizeObserver loop')) {
      // It's a ResizeObserver error - suppress it
      return true;
    }
    
    // For all other errors, use the original handler
    if (originalOnError) {
      return originalOnError(msg, source, lineNo, columnNo, error);
    }
    
    // If no original handler, let the error pass through
    return false;
  };
}