import { memo, useMemo, useCallback } from 'react';

/**
 * Higher-order component for memoizing expensive components
 */
export function withMemoization<T extends {}>(Component: React.ComponentType<T>) {
  return memo(Component);
}

/**
 * Custom hook for memoizing expensive calculations
 */
export function useMemoizedCalculation<T>(
  calculation: () => T,
  dependencies: React.DependencyList
): T {
  return useMemo(calculation, dependencies);
}

/**
 * Custom hook for memoizing callback functions
 */
export function useMemoizedCallback<T extends (...args: any[]) => any>(
  callback: T,
  dependencies: React.DependencyList
): T {
  return useCallback(callback, dependencies);
}

/**
 * Optimize large lists with virtual scrolling-like behavior
 */
export function useOptimizedList<T>(
  items: T[],
  itemsPerPage: number = 10,
  currentPage: number = 1
) {
  return useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return items.slice(startIndex, endIndex);
  }, [items, itemsPerPage, currentPage]);
}