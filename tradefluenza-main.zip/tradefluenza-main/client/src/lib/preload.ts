/**
 * Utility for preloading critical assets to improve perceived performance
 */

/**
 * Preload critical CSS files
 */
export function preloadCriticalCSS() {
  const criticalStylesheets = [
    '/src/index.css'
  ];
  
  criticalStylesheets.forEach(href => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'style';
    link.href = href;
    document.head.appendChild(link);
  });
}

/**
 * Preload critical images for faster rendering
 */
export function preloadCriticalImages() {
  const criticalImages = [
    // Logo and essential UI elements
    '/src/assets/logo.png',
    
    // Homepage hero images
    '/src/assets/hero-bg.jpg',
  ];
  
  criticalImages.forEach(src => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = src;
    document.head.appendChild(link);
  });
}

/**
 * Register a service worker for caching assets (if supported)
 */
export function registerServiceWorker() {
  if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js')
        .catch(error => {
          console.error('ServiceWorker registration failed:', error);
        });
    });
  }
}

/**
 * Initialize all performance optimizations
 */
export function initializePerformanceOptimizations() {
  // These can be conditionally enabled based on browser capabilities
  // and user preferences
  
  if (typeof window !== 'undefined') {
    // Only run in browser environment
    preloadCriticalCSS();
    preloadCriticalImages();
    
    // Optional service worker registration
    // Uncomment when ready to implement proper caching strategy
    // registerServiceWorker();
  }
}