/**
 * Memory cleanup utilities for optimal RAM usage
 */

// Clean up WebSocket connections and event listeners
export function cleanupWebSocketConnections() {
  const connections = (window as any).__websocketConnections || [];
  connections.forEach((ws: WebSocket) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.close();
    }
  });
  (window as any).__websocketConnections = [];
}

// Clean up React Query cache periodically
export function cleanupQueryCache(queryClient: any) {
  queryClient.clear();
  queryClient.invalidateQueries();
}

// Remove unused DOM elements
export function cleanupDOMElements() {
  // Remove any orphaned elements
  const orphans = document.querySelectorAll('[data-removed="true"]');
  orphans.forEach(element => element.remove());
  
  // Clean up any hidden elements that might be taking up memory
  const hiddenElements = document.querySelectorAll('.hidden:not([data-keep])');
  hiddenElements.forEach(element => {
    if (!element.hasAttribute('data-keep')) {
      element.remove();
    }
  });
}

// Optimize images for memory usage
export function optimizeImageMemory() {
  const images = document.querySelectorAll('img');
  images.forEach(img => {
    // Set proper loading attributes
    img.loading = 'lazy';
    img.decoding = 'async';
    
    // Remove large images that are not visible
    if (img.offsetHeight === 0 && img.offsetWidth === 0) {
      img.src = '';
    }
  });
}

// Global memory cleanup function
export function performMemoryCleanup(queryClient?: any) {
  cleanupDOMElements();
  optimizeImageMemory();
  
  if (queryClient) {
    cleanupQueryCache(queryClient);
  }
  
  // Force garbage collection if available
  if (typeof window !== 'undefined' && (window as any).gc) {
    (window as any).gc();
  }
}