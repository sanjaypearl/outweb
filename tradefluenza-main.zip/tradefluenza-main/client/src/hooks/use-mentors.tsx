import { useQuery, useMutation } from "@tanstack/react-query";
import { Mentor, MentorReview, MentorSession } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Types for API responses
type MentorsResponse = {
  data: Mentor[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
    hasMore: boolean;
  };
};

type MentorReviewsResponse = {
  data: MentorReview[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
    hasMore: boolean;
  };
};

// Hook for fetching all mentors with filters
export function useMentors(options?: {
  specialization?: string;
  experienceLevel?: string;
  minHourlyRate?: number;
  maxHourlyRate?: number;
  search?: string;
  limit?: number;
  offset?: number;
}) {
  return useQuery<MentorsResponse>({
    queryKey: ["/api/mentors", options],
    enabled: true,
  });
}

// Hook for fetching a single mentor by ID
export function useMentor(id: number | null) {
  return useQuery<Mentor>({
    queryKey: ["/api/mentors", id],
    enabled: !!id,
  });
}

// Hook for fetching mentor reviews
export function useMentorReviews(mentorId: number, limit = 10, offset = 0) {
  return useQuery<MentorReviewsResponse>({
    queryKey: ["/api/mentors", mentorId, "reviews", { limit, offset }],
    enabled: !!mentorId,
  });
}

// Hook for fetching user's booked sessions
export function useUserSessions() {
  return useQuery<MentorSession[]>({
    queryKey: ["/api/user/mentor-sessions"],
  });
}

// Hook for submitting a mentor review
export function useSubmitReview() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({
      mentorId,
      rating,
      comment,
    }: {
      mentorId: number;
      rating: number;
      comment: string;
    }) => {
      const res = await apiRequest("POST", `/api/mentors/${mentorId}/reviews`, {
        rating,
        comment,
      });
      
      return await res.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate mentor reviews query
      queryClient.invalidateQueries({
        queryKey: ["/api/mentors", variables.mentorId, "reviews"],
      });
      
      toast({
        title: "Review submitted",
        description: "Your review has been successfully submitted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error submitting review",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Hook for booking a mentor session
export function useBookSession() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({
      mentorId,
      date,
      duration,
      topic,
      notes,
    }: {
      mentorId: number;
      date: string;
      duration: number;
      topic: string;
      notes?: string;
    }) => {
      const res = await apiRequest("POST", `/api/mentors/${mentorId}/book`, {
        date,
        duration,
        topic,
        notes,
      });
      
      return await res.json();
    },
    onSuccess: () => {
      // Invalidate user sessions query
      queryClient.invalidateQueries({
        queryKey: ["/api/user/mentor-sessions"],
      });
      
      toast({
        title: "Session booked",
        description: "Your session has been successfully booked.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error booking session",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Hook for updating a session status
export function useUpdateSessionStatus() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({
      sessionId,
      status,
    }: {
      sessionId: number;
      status: "pending" | "confirmed" | "completed" | "cancelled";
    }) => {
      const res = await apiRequest("PATCH", `/api/mentor-sessions/${sessionId}/status`, {
        status,
      });
      
      return await res.json();
    },
    onSuccess: () => {
      // Invalidate sessions queries
      queryClient.invalidateQueries({
        queryKey: ["/api/user/mentor-sessions"],
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/mentor/sessions"],
      });
      
      toast({
        title: "Session updated",
        description: "The session status has been updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating session",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}