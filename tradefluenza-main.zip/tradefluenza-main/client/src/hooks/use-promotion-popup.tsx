import { useState, useEffect } from 'react';

export function usePromotionPopup() {
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  // Custom setter that also updates localStorage when popup is closed
  const handleSetIsPopupOpen = (value: boolean) => {
    setIsPopupOpen(value);
    
    // If user is closing the popup, store that in localStorage permanently
    if (value === false) {
      localStorage.setItem('promo_popup_dismissed', 'true');
    }
  };

  useEffect(() => {
    // Check if user has previously dismissed the popup
    const hasUserDismissed = localStorage.getItem('promo_popup_dismissed');
    
    // Only show popup if user hasn't dismissed it before
    if (!hasUserDismissed) {
      // Show popup after 5 seconds (5000ms) of page load
      const timer = setTimeout(() => {
        setIsPopupOpen(true);
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, []);

  return {
    isPopupOpen,
    setIsPopupOpen: handleSetIsPopupOpen
  };
}