import { useState, useEffect, useCallback, useRef } from 'react';
import { queryClient } from '@/lib/queryClient';

type WebSocketMessage = {
  type: string;
  data: any;
  timestamp: number;
};

export function useWebsocket() {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);

  // Connect to the WebSocket server
  const connect = useCallback(() => {
    try {
      // Close any existing connection
      if (socketRef.current) {
        socketRef.current.close();
      }

      // Create WebSocket connection using the correct protocol based on whether we're using HTTPS or HTTP
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      if (process.env.NODE_ENV === 'development') {
        console.log(`Connecting to WebSocket at ${wsUrl}`);
      }
      const socket = new WebSocket(wsUrl);
      socketRef.current = socket;

      // Connection opened
      socket.addEventListener('open', () => {
        if (process.env.NODE_ENV === 'development') {
          console.log('WebSocket connection established');
        }
        setIsConnected(true);
        
        // Clear any reconnect timeout
        if (reconnectTimeoutRef.current) {
          window.clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      });

      // Listen for messages
      socket.addEventListener('message', (event) => {
        try {
          const message = JSON.parse(event.data) as WebSocketMessage;
          if (process.env.NODE_ENV === 'development') {
            console.log('WebSocket message received:', message);
          }
          setLastMessage(message);
          
          // Handle different message types
          handleWebSocketMessage(message);
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
        }
      });

      // Connection closed
      socket.addEventListener('close', () => {
        console.log('WebSocket connection closed');
        setIsConnected(false);
        
        // Attempt to reconnect after a delay
        if (!reconnectTimeoutRef.current) {
          reconnectTimeoutRef.current = window.setTimeout(() => {
            console.log('Attempting to reconnect WebSocket...');
            connect();
          }, 3000);
        }
      });

      // Connection error
      socket.addEventListener('error', (error) => {
        console.error('WebSocket error:', error);
        setIsConnected(false);
      });

    } catch (error) {
      console.error('Failed to establish WebSocket connection:', error);
      setIsConnected(false);
    }
  }, []);

  // Handle WebSocket messages and update the UI accordingly
  const handleWebSocketMessage = useCallback((message: WebSocketMessage) => {
    switch (message.type) {
      case 'connection_established':
        console.log('WebSocket connection established:', message.data.message);
        break;
        
      case 'event_created':
        // Invalidate the events list query to fetch fresh data
        queryClient.invalidateQueries({ queryKey: ['/api/events'] });
        break;
        
      case 'event_updated':
        // Update both the event list and the specific event detail
        queryClient.invalidateQueries({ queryKey: ['/api/events'] });
        queryClient.invalidateQueries({ queryKey: ['/api/events', message.data.id] });
        break;
        
      case 'event_deleted':
        // Update the events list
        queryClient.invalidateQueries({ queryKey: ['/api/events'] });
        break;
        
      case 'pong':
        // Handle ping response
        console.log('Ping response received:', message.timestamp);
        break;
        
      default:
        console.log('Unhandled WebSocket message type:', message.type);
    }
  }, []);

  // Send a ping message to keep the connection alive
  const ping = useCallback(() => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'ping', timestamp: Date.now() }));
    }
  }, []);

  // Connect on component mount, disconnect on unmount
  useEffect(() => {
    connect();
    
    // Set up keep-alive ping
    const pingInterval = setInterval(ping, 30000); // 30 seconds
    
    return () => {
      // Clean up
      clearInterval(pingInterval);
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [connect, ping]);

  return { isConnected, lastMessage };
}