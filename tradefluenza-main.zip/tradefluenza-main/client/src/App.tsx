import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Brokers from "@/pages/brokers";
import AboutPage from "@/pages/about";
import ContactPage from "@/pages/contact";
import AuthPage from "@/pages/auth-page";
import AdminPage from "@/pages/admin";
import ResolutionCenter from "@/pages/resolution-center";
import EventAdmin from "@/pages/event-admin";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { RedirectHandler } from "@/components/redirect-handler";

// Import lazy-loaded components for better performance
import {
  LazyPropFirms,
  LazyPropFirmDetail,
  LazyBrokerDetail,
  LazyQuiz,
  LazyEventsPage,
  LazyEventDetail,
  LazyMentorsPage,
  LazyMentorDetail
} from "@/lib/lazy-load";
import PropFirmRules from "@/pages/prop-firm-rules";
import LuckyOfferPage from "@/pages/lucky-offer";

import { WalkthroughProvider } from "@/components/onboarding";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { useAnalytics } from "@/lib/analytics";
import { useWebsocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

function Router() {
  // Initialize Google Analytics tracking
  useAnalytics();
  
  // Initialize WebSocket connection for real-time updates
  const { isConnected } = useWebsocket();
  
  // Log connection status only in development environment
  if (process.env.NODE_ENV === 'development') {
    useEffect(() => {
      console.log('WebSocket connection status:', isConnected ? 'Connected' : 'Disconnected');
    }, [isConnected]);
  }
  
  // Get auth context for profile redirection
  const { user } = useAuth();
  
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/prop-firms" component={LazyPropFirms} />
      <Route path="/prop-firms/:id" component={LazyPropFirmDetail} />
      <Route path="/prop-firm-rules" component={PropFirmRules} />
      <Route path="/lucky-offer" component={LuckyOfferPage} />
      <Route path="/brokers" component={Brokers} />
      <Route path="/brokers/:id" component={LazyBrokerDetail} />
      <Route path="/about" component={AboutPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/quiz" component={LazyQuiz} />
      <Route path="/resolution-center" component={ResolutionCenter} />
      <Route path="/events" component={LazyEventsPage} />
      <Route path="/events/:id" component={LazyEventDetail} />
      <Route path="/mentors" component={LazyMentorsPage} />
      <Route path="/mentors/:id" component={LazyMentorDetail} />
      <Route path="/auth" component={AuthPage} />
      
      {/* Admin Routes */}
      <Route path="/admin" component={() =>
        <AdminPage />
      } />
      <Route path="/event-admin" component={() =>
        <EventAdmin />
      } />
      
      {/* Redirect profile to auth page since social media is removed */}
      <Route path="/profile" component={AuthPage} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // One-time initialization of Google Analytics
  useEffect(() => {
    // Check if Google Analytics is loaded (no verbose logging to reduce console noise)
    if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
      // Send a test event
      window.gtag('event', 'ga_test', {
        event_category: 'testing',
        event_label: 'GA initialization test',
      });
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <WalkthroughProvider>
            <div className="flex flex-col min-h-screen">
              <Header />
              <main className="flex-grow">
                <Toaster />
                <Router />
              </main>
              <Footer />
            </div>
          </WalkthroughProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
