import { Step } from 'react-joyride';

// Home page walkthrough steps
export const homeSteps: Step[] = [
  {
    target: '[data-tour="welcome"]',
    content: 'Welcome to Tradefluenza! This walkthrough will help you understand how to use our platform to find the perfect prop trading firm for your needs.',
    placement: 'bottom',
    disableBeacon: true,
  },
  {
    target: '[data-tour="compare-button"]',
    content: 'Click here to compare all prop firms side by side, filtering by account size, program type, profit split, and more.',
    placement: 'bottom',
  },
  {
    target: '[data-tour="quiz-button"]',
    content: 'Not sure which prop firm is right for you? Take our personalized quiz to get recommendations based on your trading style and preferences.',
    placement: 'bottom',
  },
];

// Prop firms page walkthrough steps
export const propFirmsSteps: Step[] = [
  {
    target: 'body',
    content: 'This page shows all available prop firms. You can filter and sort them based on your preferences.',
    placement: 'center',
    disableBeacon: true,
  },
  {
    target: '.filters-container',
    content: 'Use these filters to narrow down prop firms based on program type, profit split, and payout frequency.',
    placement: 'bottom',
  },
  {
    target: '.account-size-selector',
    content: 'Select an account size to see which firms offer that capital amount.',
    placement: 'bottom',
  },
  {
    target: '.prop-firm-card',
    content: 'Each card shows key information about a prop firm. Click on a card to see more details.',
    placement: 'right',
  },
];

// Prop firm detail page walkthrough steps
export const propFirmDetailSteps: Step[] = [
  {
    target: '.prop-firm-header',
    content: 'Here you can see detailed information about this specific prop firm.',
    placement: 'bottom',
    disableBeacon: true,
  },
  {
    target: '.prop-firm-stats',
    content: 'These statistics show the key metrics for this prop firm, including profit targets, loss limits, and more.',
    placement: 'left',
  },
  {
    target: '.prop-firm-reviews',
    content: 'Read reviews from traders who have used this prop firm, or leave your own review to help others.',
    placement: 'top',
  },
  {
    target: '.buy-now-button',
    content: 'Ready to sign up? Click here to visit the prop firm\'s website and create your funded account.',
    placement: 'left',
  },
];

// Quiz page walkthrough steps
export const quizSteps: Step[] = [
  {
    target: '.quiz-container',
    content: 'This quiz will help you find the perfect prop firm based on your trading style, experience level, and preferences.',
    placement: 'center',
    disableBeacon: true,
  },
  {
    target: '.quiz-experience',
    content: 'Tell us about your trading experience so we can recommend appropriate prop firms.',
    placement: 'bottom',
  },
  {
    target: '.quiz-trading-style',
    content: 'Select your trading style(s) to help us match you with compatible prop firms.',
    placement: 'bottom',
  },
  {
    target: '.quiz-account-size',
    content: 'Choose your preferred account size based on your budget and trading goals.',
    placement: 'bottom',
  },
];