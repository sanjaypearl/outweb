import React, { useState, useEffect } from 'react';
import Joyride, { CallBackProps, STATUS, Step, TooltipRenderProps } from 'react-joyride';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

// Custom tooltip component for our walkthroughs
const Tooltip = ({
  continuous,
  index,
  step,
  backProps,
  closeProps,
  primaryProps,
  skipProps,
  size,
  isLastStep
}: TooltipRenderProps) => (
  <div className="p-5 max-w-md rounded-xl bg-white shadow-lg border border-gray-200 relative">
    <button
      {...closeProps}
      className="absolute top-3 right-3 text-gray-400 hover:text-gray-600"
    >
      <X size={18} />
    </button>
    
    <div className="mb-5">
      <div className="text-lg font-medium text-gray-900 mb-2">
        Step {index + 1} of {size}
      </div>
      <div className="text-gray-700">{step.content}</div>
    </div>
    
    <div className="flex justify-between">
      {index > 0 && (
        <Button
          {...backProps}
          variant="outline" 
          size="sm"
        >
          Back
        </Button>
      )}
      
      <div className="flex-1" />
      
      {!isLastStep && (
        <Button
          {...skipProps}
          variant="ghost" 
          size="sm"
          className="mr-2"
        >
          Skip
        </Button>
      )}
      
      <Button
        {...primaryProps}
        variant="default"
        size="sm"
        className="bg-gradient-to-r from-primary to-indigo-600 border-0"
      >
        {isLastStep ? 'Finish' : 'Next'}
      </Button>
    </div>
  </div>
);

// Define walkthrough types
export type WalkthroughType = 'new-user' | 'prop-firms' | 'comparison' | 'quiz';

// Utility functions to track walkthrough completion
export const isWalkthroughCompleted = (name: string): boolean => {
  return localStorage.getItem(`walkthrough-${name}-completed`) === 'true';
};

export const markWalkthroughCompleted = (name: string): void => {
  localStorage.setItem(`walkthrough-${name}-completed`, 'true');
};

interface OnboardingWalkthroughProps {
  isOpen?: boolean;
  onFinish?: () => void;
  steps: Step[];
  name: string; // Add a unique name for the walkthrough to remember completion in localStorage
}

export default function OnboardingWalkthrough({
  isOpen = false, 
  onFinish,
  steps,
  name,
}: OnboardingWalkthroughProps) {
  const [run, setRun] = useState(isOpen);
  const [stepIndex, setStepIndex] = useState(0);
  
  useEffect(() => {
    setRun(isOpen);
  }, [isOpen]);
  
  const handleJoyrideCallback = (data: CallBackProps) => {
    const { action, index, status, type } = data;

    if (status === STATUS.FINISHED || status === STATUS.SKIPPED) {
      // Mark this walkthrough as completed
      markWalkthroughCompleted(name);
      setRun(false);
      if (onFinish) onFinish();
    } else if (type === 'step:after' && action === 'next') {
      // Update the step index
      setStepIndex(index + 1);
    } else if (type === 'step:after' && action === 'prev') {
      // Update the step index
      setStepIndex(index - 1);
    }
  };

  return (
    <Joyride
      callback={handleJoyrideCallback}
      continuous
      hideCloseButton
      run={run}
      scrollToFirstStep
      showProgress
      showSkipButton
      stepIndex={stepIndex}
      steps={steps}
      styles={{
        options: {
          primaryColor: '#6d28d9', // purple-700
          zIndex: 10000,
        },
        spotlight: {
          borderRadius: '8px',
          boxShadow: '0 0 0 999em rgba(0, 0, 0, 0.85)',
        },
      }}
      tooltipComponent={Tooltip}
      disableScrolling={false}
    />
  );
}