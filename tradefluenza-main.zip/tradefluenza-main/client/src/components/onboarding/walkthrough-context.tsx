import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useLocation } from 'wouter';
import { WalkthroughType, isWalkthroughCompleted } from './walkthrough';

interface WalkthroughContextType {
  activeWalkthrough: WalkthroughType | null;
  startWalkthrough: (type: WalkthroughType) => void;
  endWalkthrough: () => void;
  showWalkthroughButton: (type: WalkthroughType) => boolean;
}

// Create the context with a default value
const WalkthroughContext = createContext<WalkthroughContextType>({
  activeWalkthrough: null,
  startWalkthrough: () => {},
  endWalkthrough: () => {},
  showWalkthroughButton: () => false,
});

// Hook to use the walkthrough context
export const useWalkthrough = () => useContext(WalkthroughContext);

// Provider component to wrap the app
export const WalkthroughProvider = ({ children }: { children: ReactNode }) => {
  const [location] = useLocation();
  const [activeWalkthrough, setActiveWalkthrough] = useState<WalkthroughType | null>(null);
  
  // Reset walkthrough when location changes
  useEffect(() => {
    setActiveWalkthrough(null);
  }, [location]);
  
  // Function to start a walkthrough
  const startWalkthrough = (type: WalkthroughType) => {
    setActiveWalkthrough(type);
  };
  
  // Function to end a walkthrough
  const endWalkthrough = () => {
    setActiveWalkthrough(null);
  };
  
  // Function to determine if we should show the walkthrough button
  const showWalkthroughButton = (type: WalkthroughType) => {
    // Logic to determine if we should show the walkthrough button
    // We might not want to show it on certain pages, or if the user has already completed it
    return !isWalkthroughCompleted(type);
  };
  
  return (
    <WalkthroughContext.Provider
      value={{
        activeWalkthrough,
        startWalkthrough,
        endWalkthrough,
        showWalkthroughButton,
      }}
    >
      {children}
    </WalkthroughContext.Provider>
  );
};