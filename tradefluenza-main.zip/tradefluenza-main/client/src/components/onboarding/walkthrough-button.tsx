import React from 'react';
import { Button } from '@/components/ui/button';
import { HelpCircle } from 'lucide-react';
import { useWalkthrough } from './walkthrough-context';
import { WalkthroughType } from './walkthrough';

interface WalkthroughButtonProps {
  type: WalkthroughType;
  className?: string;
}

export default function WalkthroughButton({ type, className = '' }: WalkthroughButtonProps) {
  const { startWalkthrough, showWalkthroughButton } = useWalkthrough();
  
  if (!showWalkthroughButton(type)) {
    return null;
  }
  
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => startWalkthrough(type)}
      className={`bg-gradient-to-r from-primary/10 to-indigo-500/10 border border-primary/20 hover:bg-gradient-to-r hover:from-primary/20 hover:to-indigo-500/20 shadow-sm ${className}`}
    >
      <HelpCircle className="mr-2 h-4 w-4" />
      Take a Tour
    </Button>
  );
}