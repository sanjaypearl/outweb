import React from "react";
import { Slider } from "@/components/ui/slider";
import { Shield, ShieldAlert, ShieldCheck } from "lucide-react";

interface QuizRiskToleranceStepProps {
  value: number;
  onChange: (value: number) => void;
}

// Risk tolerance descriptions
const riskLevels = [
  {
    value: 1,
    label: "Very Conservative",
    icon: ShieldCheck,
    description: "I prefer very strict rules and maximum security, even if it means slower growth.",
    details: "Firms with relaxed drawdown limits, longer evaluation periods, high profit splits."
  },
  {
    value: 2,
    label: "Conservative",
    icon: ShieldCheck,
    description: "I prefer clear rules and good security, with modest growth targets.",
    details: "Firms with balanced drawdown limits and reasonable profit targets."
  },
  {
    value: 3,
    label: "Moderate",
    icon: Shield,
    description: "I balance risk and reward equally in my trading decisions.",
    details: "Firms with standard industry rules and average profit targets."
  },
  {
    value: 4,
    label: "Aggressive",
    icon: ShieldAlert,
    description: "I'm comfortable with higher risk for potentially higher rewards.",
    details: "Firms with slightly higher profit targets and tighter evaluation periods."
  },
  {
    value: 5,
    label: "Very Aggressive",
    icon: ShieldAlert,
    description: "I seek maximum growth and can handle significant volatility.",
    details: "Firms with high profit targets, shorter evaluation periods, and strict rules."
  }
];

export default function QuizRiskToleranceStep({ value, onChange }: QuizRiskToleranceStepProps) {
  // Get current risk level
  const currentRiskLevel = riskLevels.find(level => level.value === value) || riskLevels[2];
  const Icon = currentRiskLevel.icon;
  
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">What's your risk tolerance?</h2>
      <p className="text-gray-600 mb-6">
        Different prop firms have different risk management rules. Some have strict daily drawdown limits,
        while others are more flexible but might have stricter overall account drawdown limits.
      </p>
      
      <div className="flex flex-col items-center mb-8">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 ${
          value <= 2 ? "bg-green-100" : value === 3 ? "bg-blue-100" : "bg-amber-100"
        }`}>
          <Icon className={`w-8 h-8 ${
            value <= 2 ? "text-green-600" : value === 3 ? "text-blue-600" : "text-amber-600"
          }`} />
        </div>
        
        <h3 className="text-lg font-medium">{currentRiskLevel.label}</h3>
        <p className="text-center text-gray-600 mb-4">{currentRiskLevel.description}</p>
        
        <div className={`text-sm p-3 rounded-md text-center max-w-md mb-6 ${
          value <= 2 ? "bg-green-50 text-green-700" : 
          value === 3 ? "bg-blue-50 text-blue-700" : 
          "bg-amber-50 text-amber-700"
        }`}>
          We'll match you with: {currentRiskLevel.details}
        </div>
        
        <Slider
          value={[value]}
          min={1}
          max={5}
          step={1}
          onValueChange={(values) => onChange(values[0])}
          className="w-full max-w-md"
        />
        
        <div className="flex justify-between w-full max-w-md mt-2 text-xs text-gray-500">
          <span>Very Conservative</span>
          <span className="ml-auto">Very Aggressive</span>
        </div>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg border">
        <h3 className="font-medium mb-2">What This Means</h3>
        <p className="text-sm text-gray-600">
          Your risk tolerance helps us match you with prop firms that have compatible trading rules.
          Conservative options typically have more relaxed drawdown limits but may have lower profit
          splits, while aggressive options often have higher profit potential but stricter rules.
        </p>
      </div>
    </div>
  );
}