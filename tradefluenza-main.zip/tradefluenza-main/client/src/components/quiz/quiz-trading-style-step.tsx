import React from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";

interface QuizTradingStyleStepProps {
  values: string[];
  timeframe: string;
  onStyleChange: (values: string[]) => void;
  onTimeframeChange: (value: string) => void;
}

// Define trading styles
const tradingStyles = [
  {
    id: "swing",
    label: "Swing Trading",
    description: "I hold positions for several days to weeks to capitalize on expected price movements."
  },
  {
    id: "day",
    label: "Day Trading",
    description: "I open and close positions within the same trading day."
  },
  {
    id: "scalping",
    label: "Scalping",
    description: "I make numerous trades daily, aiming for small profits on each trade."
  },
  {
    id: "position",
    label: "Position Trading",
    description: "I hold positions for weeks to months, focusing on long-term trends."
  },
  {
    id: "automated",
    label: "Automated/Algo Trading",
    description: "I use automated systems or algorithms to execute trades."
  },
  {
    id: "news",
    label: "News Trading",
    description: "I trade based on news events and economic announcements."
  }
];

// Define timeframes
const timeframes = [
  {
    id: "short",
    label: "Short-term",
    description: "I want to qualify as quickly as possible (within 1 month)."
  },
  {
    id: "medium",
    label: "Medium-term",
    description: "I'm comfortable with a 1-3 month evaluation period."
  },
  {
    id: "long",
    label: "Long-term", 
    description: "I prefer a longer evaluation (3+ months) with more relaxed rules."
  }
];

export default function QuizTradingStyleStep({ 
  values, 
  timeframe,
  onStyleChange, 
  onTimeframeChange 
}: QuizTradingStyleStepProps) {
  const handleStyleToggle = (id: string) => {
    if (values.includes(id)) {
      onStyleChange(values.filter(v => v !== id));
    } else {
      onStyleChange([...values, id]);
    }
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">What's your trading style?</h2>
      <p className="text-gray-600 mb-6">
        Select all that apply. This helps us recommend prop firms that are compatible with your trading approach.
      </p>
      
      <div className="space-y-3 mb-8">
        {tradingStyles.map((style) => (
          <div
            key={style.id}
            className={`flex items-start space-x-3 border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors ${
              values.includes(style.id) ? "border-primary bg-primary/5" : "border-gray-200"
            }`}
            onClick={() => handleStyleToggle(style.id)}
          >
            <Checkbox 
              id={style.id} 
              checked={values.includes(style.id)}
              onCheckedChange={() => handleStyleToggle(style.id)}
              className="mt-1"
            />
            <div className="flex-1">
              <Label
                htmlFor={style.id}
                className="text-base font-medium block mb-1 cursor-pointer"
              >
                {style.label}
              </Label>
              <p className="text-gray-600 text-sm">{style.description}</p>
            </div>
          </div>
        ))}
      </div>
      
      <Separator className="my-6" />
      
      <h2 className="text-xl font-semibold mb-4">Preferred evaluation timeframe</h2>
      <p className="text-gray-600 mb-6">
        How quickly do you want to pass the evaluation and start trading a funded account?
      </p>
      
      <RadioGroup
        value={timeframe}
        onValueChange={onTimeframeChange}
        className="space-y-4"
      >
        {timeframes.map((option) => (
          <div
            key={option.id}
            className={`flex items-start space-x-3 border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors ${
              timeframe === option.id ? "border-primary bg-primary/5" : "border-gray-200"
            }`}
            onClick={() => onTimeframeChange(option.id)}
          >
            <RadioGroupItem value={option.id} id={`timeframe-${option.id}`} className="mt-1" />
            <div className="flex-1">
              <Label
                htmlFor={`timeframe-${option.id}`}
                className="text-base font-medium block mb-1 cursor-pointer"
              >
                {option.label}
              </Label>
              <p className="text-gray-600 text-sm">{option.description}</p>
            </div>
          </div>
        ))}
      </RadioGroup>
    </div>
  );
}