import React from "react";
import { Slider } from "@/components/ui/slider";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface QuizBudgetStepProps {
  value: number;
  onChange: (value: number) => void;
}

// Common account sizes
const accountSizes = [
  {
    value: 5000,
    label: "$5,000",
    price: "Low cost (typically $50-$150)",
    description: "Good for beginners or testing a strategy"
  },
  {
    value: 10000,
    label: "$10,000",
    price: "Moderate cost (typically $100-$300)",
    description: "Popular choice for newer traders"
  },
  {
    value: 25000,
    label: "$25,000",
    price: "Medium cost (typically $200-$500)",
    description: "Balanced option for most traders"
  },
  {
    value: 50000,
    label: "$50,000",
    price: "Higher cost (typically $400-$800)",
    description: "For experienced traders with proven strategies"
  },
  {
    value: 100000,
    label: "$100,000",
    price: "Premium cost (typically $800-$1,500)",
    description: "For professional traders seeking larger capital"
  },
  {
    value: 200000,
    label: "$200,000",
    price: "High premium (typically $1,500+)",
    description: "For elite traders with consistent performance"
  }
];

export default function QuizBudgetStep({ value, onChange }: QuizBudgetStepProps) {
  // Find the closest account size
  const currentAccountSize = accountSizes.find(size => size.value === value) || accountSizes[2];

  // Format value as currency
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">What account size are you looking for?</h2>
      <p className="text-gray-600 mb-6">
        The account size affects both the cost of the challenge and the potential profit you can make.
        Larger accounts typically have higher evaluation fees but offer greater earning potential.
      </p>
      
      <div className="mb-10">
        <p className="text-lg font-medium text-center mb-1">
          {currentAccountSize.label}
        </p>
        <p className="text-sm text-center text-gray-500 mb-6">
          {currentAccountSize.price}
        </p>
        
        <Slider
          defaultValue={[value]}
          min={5000}
          max={200000}
          step={5000}
          onValueChange={(values) => onChange(values[0])}
          className="my-6"
        />
        
        <div className="flex justify-between text-xs text-gray-500">
          <span>$5K</span>
          <span>$50K</span>
          <span>$100K</span>
          <span>$200K</span>
        </div>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
        <h3 className="font-medium mb-3">Common Account Sizes</h3>
        <RadioGroup
          value={value.toString()}
          onValueChange={(val) => onChange(parseInt(val))}
          className="grid grid-cols-1 md:grid-cols-2 gap-3"
        >
          {accountSizes.map((size) => (
            <div
              key={size.value}
              className={`flex items-start space-x-2 border rounded-lg p-3 cursor-pointer hover:border-primary transition-colors ${
                value === size.value ? "border-primary bg-primary/5" : "border-gray-200 bg-white"
              }`}
              onClick={() => onChange(size.value)}
            >
              <RadioGroupItem 
                value={size.value.toString()} 
                id={`size-${size.value}`} 
                className="mt-1" 
              />
              <div className="flex-1">
                <Label
                  htmlFor={`size-${size.value}`}
                  className="text-base font-medium block cursor-pointer"
                >
                  {size.label}
                </Label>
                <p className="text-gray-600 text-xs">{size.description}</p>
              </div>
            </div>
          ))}
        </RadioGroup>
      </div>
    </div>
  );
}