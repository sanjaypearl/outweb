import React from "react";
import { Lightbulb } from "lucide-react";

export default function QuizIntro() {
  return (
    <div className="text-center">
      <div className="w-16 h-16 bg-gradient-to-br from-indigo-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
        <Lightbulb className="w-8 h-8 text-white" />
      </div>
      
      <h2 className="text-2xl font-bold mb-4">Find Your Perfect Prop Firm</h2>
      
      <p className="text-gray-600 mb-6">
        Not sure which prop firm is right for you? Answer a few questions about your trading style, 
        budget, and preferences, and we'll match you with the prop firms that best suit your needs.
      </p>
      
      <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-left">
        <h3 className="text-blue-800 font-medium mb-2">Why Take This Quiz?</h3>
        <ul className="space-y-2 text-blue-700">
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Save time comparing dozens of different prop firms</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Get personalized recommendations based on your trading style</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Find firms that match your budget and risk tolerance</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">•</span>
            <span>Discover prop firms you might have overlooked</span>
          </li>
        </ul>
      </div>
    </div>
  );
}