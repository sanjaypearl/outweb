import React, { useEffect, useState } from "react";
import { Trophy, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import StarRating from "@/components/prop-firms/star-rating";
import { QuizPreferences } from "./quiz-container";
import { PropFirm } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Link } from "wouter";

interface QuizResultsProps {
  preferences: QuizPreferences;
  propFirms: PropFirm[];
  isLoading: boolean;
  onViewAll: () => void;
}

interface ScoredPropFirm extends PropFirm {
  matchScore: number;
  matchReason: string[];
}

export default function QuizResults({ 
  preferences, 
  propFirms,
  isLoading, 
  onViewAll 
}: QuizResultsProps) {
  const [rankedFirms, setRankedFirms] = useState<ScoredPropFirm[]>([]);
  const [isCalculating, setIsCalculating] = useState(true);

  // Fetch ratings for prop firms
  const { data: ratingData } = useQuery({
    queryKey: ['/api/prop-firms/ratings'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !isLoading && propFirms.length > 0,
  });

  // Calculate firm matches based on user preferences
  useEffect(() => {
    if (isLoading || propFirms.length === 0) return;

    setIsCalculating(true);
    
    // Simulate a brief calculation delay for user experience
    const timer = setTimeout(() => {
      const scored = calculatePropFirmScores(propFirms, preferences);
      setRankedFirms(scored);
      setIsCalculating(false);
    }, 1200);
    
    return () => clearTimeout(timer);
  }, [propFirms, preferences, isLoading]);

  // The main scoring algorithm
  const calculatePropFirmScores = (firms: PropFirm[], prefs: QuizPreferences): ScoredPropFirm[] => {
    const scoredFirms = firms.map(firm => {
      let score = 0;
      const reasons: string[] = [];

      // 1. Account size match (highest weight)
      const targetAccountSize = prefs.accountSize;
      if (firm.accountSizes.includes(targetAccountSize)) {
        score += 35;
        reasons.push(`Offers your preferred account size ($${targetAccountSize.toLocaleString()})`);
      } else {
        // Find closest account size
        const closestSize = firm.accountSizes.reduce((prev, curr) => {
          return (Math.abs(curr - targetAccountSize) < Math.abs(prev - targetAccountSize) ? curr : prev);
        }, firm.accountSizes[0]);
        
        // Score based on how close the available size is to the target
        const sizeDifference = Math.abs(closestSize - targetAccountSize);
        const sizeRatio = 1 - (sizeDifference / targetAccountSize);
        const sizeScore = Math.round(25 * Math.max(sizeRatio, 0));
        score += sizeScore;
        
        if (sizeScore > 10) {
          reasons.push(`Offers a similar account size ($${closestSize.toLocaleString()})`);
        }
      }

      // 2. Trading style compatibility
      const { tradingStyles, timeframe } = prefs;
      
      // Day trading and scalping prefer firms with no minimum trading days
      if ((tradingStyles.includes('day') || tradingStyles.includes('scalping')) && 
          !firm.minimumTradingDays) {
        score += 15;
        reasons.push('No minimum trading days requirement');
      }
      
      // Swing and position traders prefer longer evaluation periods
      if ((tradingStyles.includes('swing') || tradingStyles.includes('position')) && 
          timeframe === 'medium' || timeframe === 'long') {
        score += 15;
        reasons.push('Suitable for swing/position trading');
      }
      
      // 3. Experience level match
      const { experienceLevel } = prefs;
      
      if (experienceLevel === 'beginner' && 
          (firm.profitTargets[0] <= 8 || firm.minimumTradingDays === null)) {
        score += 15;
        reasons.push('Good for beginners with reasonable targets');
      }
      
      if (experienceLevel === 'advanced' || experienceLevel === 'professional') {
        if (firm.scaling && firm.scaling.available) {
          score += 20;
          reasons.push('Offers account scaling for growth');
        }
        
        if (firm.profitSplit >= 80) {
          score += 15;
          reasons.push(`High profit split (${firm.profitSplit}%)`);
        }
      }
      
      // 4. Risk tolerance match
      const { riskTolerance } = prefs;
      
      // Conservative traders (1-2) prefer firms with relaxed rules
      if (riskTolerance <= 2) {
        if (firm.dailyLoss >= 5) {
          score += 15;
          reasons.push(`Higher daily drawdown limit (${firm.dailyLoss}%)`);
        }
        
        if (firm.maxLoss >= 10) {
          score += 10;
          reasons.push(`Higher maximum drawdown limit (${firm.maxLoss}%)`);
        }
      }
      
      // Aggressive traders (4-5) prefer firms with higher profit potential
      if (riskTolerance >= 4) {
        if (firm.profitTargets[0] <= 8) {
          score += 20;
          reasons.push(`Achievable profit target (${firm.profitTargets[0]}%)`);
        }
        
        if (firm.profitSplit >= 80) {
          score += 15;
          reasons.push(`High profit split (${firm.profitSplit}%)`);
        }
      }
      
      // 5. Timeframe preference match
      if (timeframe === 'short' && firm.profitTargets[0] <= 10) {
        score += 10;
        reasons.push('Suitable for short-term qualification');
      } else if (timeframe === 'medium') {
        score += 5;
      } else if (timeframe === 'long' && firm.profitTargets.length > 1) {
        score += 10;
        reasons.push('Multi-phase evaluation for long-term traders');
      }
      
      // 6. Additional nice-to-have features
      if (firm.loyaltyProgram) {
        score += 5;
        reasons.push('Offers loyalty/reward program');
      }
      
      if (firm.payoutFrequency === 'Bi-weekly' || firm.payoutFrequency === 'Weekly') {
        score += 5;
        reasons.push(`Frequent payouts (${firm.payoutFrequency})`);
      }
      
      // Limit to top 3 reasons
      const limitedReasons = reasons.slice(0, 3);
      
      return {
        ...firm,
        matchScore: Math.min(score, 100), // Cap at 100
        matchReason: limitedReasons
      };
    });
    
    // Sort by score (descending)
    return scoredFirms.sort((a, b) => b.matchScore - a.matchScore);
  };

  // Get the top 3 matches
  const topMatches = rankedFirms.slice(0, 3);

  // Get average rating for a prop firm
  const getAverageRating = (propFirmId: number) => {
    if (!ratingData || !Array.isArray(ratingData)) return 0;
    const rating = ratingData.find((r: {propFirmId: number, averageRating: number | string}) => 
      r.propFirmId === propFirmId
    );
    return rating ? Number(rating.averageRating) : 0;
  };

  // Loading state
  if (isLoading || isCalculating) {
    return (
      <div className="text-center">
        <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Loader2 className="w-10 h-10 text-purple-600 animate-spin" />
        </div>
        
        <h2 className="text-2xl font-bold mb-4">Finding Your Matches</h2>
        <p className="text-gray-600 mb-8">
          We're analyzing {propFirms.length} prop firms to find your perfect match...
        </p>
        
        <div className="space-y-4 max-w-md mx-auto">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <Trophy className="w-10 h-10 text-white" />
        </div>
        
        <h2 className="text-2xl font-bold mb-2">Your Top Matches</h2>
        <p className="text-gray-600">
          Based on your preferences, here are the prop firms that best match your trading style.
        </p>
      </div>
      
      {topMatches.length > 0 ? (
        <div className="space-y-6">
          {topMatches.map((firm, index) => (
            <Card key={firm.id} className={`overflow-hidden border-2 ${
              index === 0 ? 'border-yellow-400 shadow-md' : 'border-gray-200'
            }`}>
              {index === 0 && (
                <div className="bg-yellow-400 text-yellow-900 text-xs font-medium py-1 text-center">
                  TOP MATCH
                </div>
              )}
              
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold">{firm.name}</h3>
                    <div className="flex items-center mt-1">
                      <StarRating rating={getAverageRating(firm.id)} size="sm" />
                      <Badge 
                        variant="outline" 
                        className="ml-2 bg-green-50 text-green-700 border-green-200"
                      >
                        {firm.matchScore}% Match
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Starting from</p>
                    <p className="text-lg font-semibold">
                      ${firm.pricing.find(p => p.accountSize === preferences.accountSize)?.price || 
                         firm.pricing[0].price}
                    </p>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pb-4">
                <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                  <div>
                    <p className="text-gray-500">Account Size</p>
                    <p className="font-medium">${preferences.accountSize.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Profit Split</p>
                    <p className="font-medium">{firm.profitSplit}%</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Profit Target</p>
                    <p className="font-medium">{firm.profitTargets[0]}%</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Max Loss</p>
                    <p className="font-medium">{firm.maxLoss}%</p>
                  </div>
                </div>
                
                <h4 className="font-medium text-sm mb-2">Why it's a match:</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  {firm.matchReason.map((reason, i) => (
                    <li key={i} className="flex items-start">
                      <span className="text-green-500 mr-2">✓</span>
                      <span>{reason}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              
              <CardFooter className="border-t pt-4 pb-4 flex justify-between">
                <Link href={`/prop-firms/${firm.id}`}>
                  <Button variant="outline">View Details</Button>
                </Link>
                <a href={firm.websiteUrl} target="_blank" rel="noopener noreferrer">
                  <Button>
                    Buy Now <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </a>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center p-8 border rounded-lg bg-gray-50">
          <p className="text-gray-600 mb-4">
            We couldn't find any matches based on your preferences. Try adjusting your criteria.
          </p>
          <Button onClick={onViewAll}>View All Prop Firms</Button>
        </div>
      )}
      
      <div className="mt-8 text-center">
        <Button 
          variant="outline"
          onClick={onViewAll}
          className="mx-auto"
        >
          View All Prop Firms
        </Button>
      </div>
    </div>
  );
}