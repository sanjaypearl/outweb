import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import QuizIntro from "./quiz-intro";
import QuizExperienceStep from "./quiz-experience-step";
import QuizTradingStyleStep from "./quiz-trading-style-step";
import QuizBudgetStep from "./quiz-budget-step";
import QuizRiskToleranceStep from "./quiz-risk-tolerance-step";
import QuizResults from "./quiz-results";
import { PropFirm } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

// Define the quiz steps
const STEPS = [
  "intro",
  "experience",
  "tradingStyle",
  "budget",
  "riskTolerance",
  "results"
];

export interface QuizPreferences {
  experienceLevel: string;
  tradingStyles: string[];
  accountSize: number;
  timeframe: string;
  riskTolerance: number;
}

export default function QuizContainer() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [preferences, setPreferences] = useState<QuizPreferences>({
    experienceLevel: "",
    tradingStyles: [],
    accountSize: 25000,
    timeframe: "",
    riskTolerance: 3
  });
  
  // Fetch all prop firms for matching in the results
  const { data: propFirms, isLoading } = useQuery({
    queryKey: ['/api/prop-firms'],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });
  
  // Progress calculation
  const progress = Math.round((currentStep / (STEPS.length - 1)) * 100);
  
  // Handle next step
  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };
  
  // Handle previous step
  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };
  
  // Handle preference updates
  const updatePreferences = (update: Partial<QuizPreferences>) => {
    setPreferences({ ...preferences, ...update });
  };
  
  // Render current step
  const renderStep = () => {
    switch (STEPS[currentStep]) {
      case "intro":
        return <QuizIntro />;
      case "experience":
        return (
          <QuizExperienceStep 
            value={preferences.experienceLevel} 
            onChange={(value: string) => updatePreferences({ experienceLevel: value })}
          />
        );
      case "tradingStyle":
        return (
          <QuizTradingStyleStep 
            values={preferences.tradingStyles}
            timeframe={preferences.timeframe}
            onStyleChange={(values: string[]) => updatePreferences({ tradingStyles: values })}
            onTimeframeChange={(value: string) => updatePreferences({ timeframe: value })}
          />
        );
      case "budget":
        return (
          <QuizBudgetStep 
            value={preferences.accountSize}
            onChange={(value: number) => updatePreferences({ accountSize: value })}
          />
        );
      case "riskTolerance":
        return (
          <QuizRiskToleranceStep 
            value={preferences.riskTolerance}
            onChange={(value: number) => updatePreferences({ riskTolerance: value })}
          />
        );
      case "results":
        return (
          <QuizResults 
            preferences={preferences}
            propFirms={propFirms || []}
            isLoading={isLoading}
            onViewAll={() => setLocation("/prop-firms")}
          />
        );
      default:
        return <QuizIntro />;
    }
  };
  
  return (
    <div className="container max-w-3xl mx-auto py-10">
      <Card className="border-2 shadow-md">
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl bg-gradient-to-r from-indigo-500 to-purple-700 text-transparent bg-clip-text">
            Prop Firm Matcher
          </CardTitle>
          <CardDescription>
            Find your perfect trading partner in just a few steps
          </CardDescription>
          <Progress value={progress} className="h-2 mt-2" />
        </CardHeader>
        
        <CardContent className="pt-6">
          {renderStep()}
        </CardContent>
        
        <CardFooter className="flex justify-between border-t p-6">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 0}
          >
            Previous
          </Button>
          
          {currentStep < STEPS.length - 1 ? (
            <Button onClick={handleNext}>
              {currentStep === 0 ? "Start Quiz" : "Next"}
            </Button>
          ) : (
            <Button onClick={() => setLocation("/prop-firms")}>
              Browse All Prop Firms
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}