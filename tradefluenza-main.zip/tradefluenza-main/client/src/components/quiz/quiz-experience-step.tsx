import React from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface QuizExperienceStepProps {
  value: string;
  onChange: (value: string) => void;
}

// Define experience levels
const experienceLevels = [
  {
    id: "beginner",
    title: "Beginner",
    description: "I'm new to trading or have less than 1 year of experience.",
  },
  {
    id: "intermediate",
    title: "Intermediate",
    description: "I've been trading for 1-3 years and understand basic strategies.",
  },
  {
    id: "advanced",
    title: "Advanced",
    description: "I've been trading for 3+ years and have a consistent strategy.",
  },
  {
    id: "professional",
    title: "Professional",
    description: "I have 5+ years of experience and trade as my primary source of income.",
  },
];

export default function QuizExperienceStep({ value, onChange }: QuizExperienceStepProps) {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">What is your trading experience?</h2>
      <p className="text-gray-600 mb-6">
        This helps us recommend prop firms that match your experience level. Some firms are better suited for beginners, while others cater to more experienced traders.
      </p>
      
      <RadioGroup
        value={value}
        onValueChange={onChange}
        className="space-y-4"
      >
        {experienceLevels.map((level) => (
          <div
            key={level.id}
            className={`flex items-start space-x-3 border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors ${
              value === level.id ? "border-primary bg-primary/5" : "border-gray-200"
            }`}
            onClick={() => onChange(level.id)}
          >
            <RadioGroupItem value={level.id} id={level.id} className="mt-1" />
            <div className="flex-1">
              <Label
                htmlFor={level.id}
                className="text-base font-medium block mb-1 cursor-pointer"
              >
                {level.title}
              </Label>
              <p className="text-gray-600 text-sm">{level.description}</p>
            </div>
          </div>
        ))}
      </RadioGroup>
    </div>
  );
}