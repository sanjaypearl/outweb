import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { EventReview } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { StarRating } from "@/components/ui/star-rating";
import { ThumbsUp, MoreVertical, Calendar, CheckCircle2, Pencil, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";

interface EventReviewsListProps {
  eventId: number;
  onDeleteReview?: () => void;
}

export default function EventReviewsList({ eventId, onDeleteReview }: EventReviewsListProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isDeleteLoading, setIsDeleteLoading] = useState(false);

  // Fetch reviews for the event
  const {
    data: reviews,
    isLoading,
    isError,
    refetch,
  } = useQuery<(EventReview & { username: string })[]>({
    queryKey: [`/api/events/${eventId}/reviews`],
    retry: 1,
  });

  // Calculate average rating
  const averageRating = reviews?.length
    ? reviews.reduce((sum, review) => sum + Number(review.rating), 0) / reviews.length
    : 0;

  // Delete a review
  const handleDeleteReview = async (reviewId: number) => {
    if (!confirm("Are you sure you want to delete this review?")) return;

    setIsDeleteLoading(true);
    try {
      const response = await fetch(`/api/events/reviews/${reviewId}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to delete review");
      }

      toast({
        title: "Review deleted",
        description: "Your review has been deleted successfully.",
      });

      refetch();
      if (onDeleteReview) onDeleteReview();
    } catch (error: any) {
      toast({
        title: "Failed to delete review",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsDeleteLoading(false);
    }
  };

  // Format username initials for avatar
  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-1/3" />
        <div className="space-y-8">
          {[1, 2].map((i) => (
            <Card key={i} className="border border-primary/10">
              <CardHeader className="pb-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div>
                      <Skeleton className="h-5 w-24" />
                      <Skeleton className="h-4 w-32 mt-1" />
                    </div>
                  </div>
                  <Skeleton className="h-6 w-20" />
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full mt-1" />
                <Skeleton className="h-4 w-full mt-1" />
                <Skeleton className="h-4 w-3/4 mt-1" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <Alert variant="destructive" className="my-4">
        <AlertDescription>
          Failed to load reviews. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  // Show message if no reviews
  if (!reviews?.length) {
    return (
      <Card className="border border-primary/10 bg-card/50">
        <CardContent className="pt-6 pb-4 text-center">
          <p className="text-muted-foreground mb-2">No reviews yet</p>
          <p className="text-sm">Be the first to share your experience!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-semibold mb-1">Reviews</h3>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-lg">
                {averageRating.toFixed(1)}
              </span>
              <StarRating
                value={averageRating}
                readOnly
                size={18}
              />
            </div>
            <span className="text-muted-foreground">
              {reviews.length} {reviews.length === 1 ? "review" : "reviews"}
            </span>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {reviews.map((review) => (
          <Card key={review.id} className="border border-primary/10 hover:border-primary/20 transition-colors">
            <CardHeader className="pb-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-gradient-to-br from-primary/80 to-primary">
                      {getInitials(review.username)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium">{review.username}</h4>
                    <div className="flex items-center gap-2 text-muted-foreground text-sm">
                      <Calendar size={12} />
                      <span>
                        {formatDistanceToNow(new Date(review.datePosted), {
                          addSuffix: true,
                        })}
                      </span>
                      {review.isVerified && (
                        <>
                          <span>•</span>
                          <span className="flex items-center text-green-500">
                            <CheckCircle2 size={12} className="mr-1" />
                            Verified Attendee
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StarRating
                    value={Number(review.rating)}
                    readOnly
                    size={16}
                  />
                  {(user?.id === review.userId || user?.username === "tradefluenza") && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical size={16} />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {user?.id === review.userId && (
                          <DropdownMenuItem disabled>
                            <Pencil size={14} className="mr-2" />
                            Edit Review
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => handleDeleteReview(review.id)}
                          disabled={isDeleteLoading}
                        >
                          <Trash2 size={14} className="mr-2" />
                          Delete Review
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="pb-3">
              <h5 className="font-medium text-lg mb-2">{review.title}</h5>
              <p className="text-muted-foreground whitespace-pre-line">{review.content}</p>

              {(review.highlights?.length || review.improvements?.length) && (
                <div className="mt-4 space-y-3">
                  {review.highlights?.length > 0 && (
                    <div>
                      <h6 className="text-sm font-medium mb-2">Highlights</h6>
                      <div className="flex flex-wrap gap-2">
                        {review.highlights.map((highlight, i) => (
                          <Badge
                            key={i}
                            className="px-3 py-1 bg-primary/20 text-primary-foreground"
                          >
                            {highlight}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {review.improvements?.length > 0 && (
                    <div>
                      <h6 className="text-sm font-medium mb-2">Suggestions for improvement</h6>
                      <div className="flex flex-wrap gap-2">
                        {review.improvements.map((improvement, i) => (
                          <Badge
                            key={i}
                            className="px-3 py-1 bg-secondary/30 text-secondary-foreground"
                          >
                            {improvement}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
            <CardFooter>
              <div className="w-full flex justify-between items-center">
                <div className="flex items-center text-sm text-muted-foreground">
                  {review.wouldRecommend !== undefined && (
                    <span>
                      {review.wouldRecommend ? "Recommends this event" : "Doesn't recommend this event"}
                    </span>
                  )}
                </div>
                <Button variant="ghost" size="sm" className="gap-1 opacity-0">
                  <ThumbsUp size={14} />
                  <span>Helpful</span>
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}