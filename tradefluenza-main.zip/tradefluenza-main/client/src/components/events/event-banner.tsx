import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Calendar, MapPin, ArrowRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { trackEvent } from '@/lib/analytics';

// Event interface
interface Event {
  id: number;
  title: string;
  description: string;
  date: string;
  location: string;
  type: string;
  isPremium: boolean;
  status: string;
  bgClass: string;
  imageUrl?: string;
}

export function EventBanner() {
  // Using the imported trackEvent function directly - no need for hook
  
  // Fetch featured events
  const { data: events, isLoading, error } = useQuery<Event[]>({
    queryKey: ['/api/events', { featured: true }],
    queryFn: async () => {
      const response = await fetch('/api/events?featured=true&limit=3');
      if (!response.ok) {
        throw new Error('Failed to fetch events');
      }
      return response.json();
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Add event tracking for clicks
  const handleEventClick = (eventId: number, eventTitle: string) => {
    trackEvent('event_card_click', 'events', eventTitle, eventId);
  };
  
  // If there are no events, don't render the section
  if (!isLoading && (!events || events.length === 0)) {
    return null;
  }
  
  // Handle errors
  if (error) {
    console.error('Error loading events:', error);
    return null;
  }
  
  // Skeleton loading state
  if (isLoading) {
    return (
      <div className="bg-gray-50 dark:bg-gray-900/50 py-14">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Skeleton className="h-8 w-64 mx-auto mb-4" />
            <Skeleton className="h-4 w-96 mx-auto max-w-full" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-xl overflow-hidden shadow-md">
                <Skeleton className="h-48 w-full" />
                <div className="p-5">
                  <Skeleton className="h-4 w-16 mb-3" />
                  <Skeleton className="h-6 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <Skeleton className="h-10 w-full" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-50 dark:bg-gray-900/50 py-14">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-violet-600 text-transparent bg-clip-text">
            Upcoming Trading Events
          </h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Join our trading community in educational workshops, networking meetups, and online trading sessions
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {events?.slice(0, 3).map((event) => (
            <div 
              key={event.id}
              className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md transition-all duration-300 hover:shadow-lg border border-gray-100 dark:border-gray-700 h-full flex flex-col group"
            >
              {/* Event header with gradient background */}
              <div className={`p-6 ${event.bgClass} text-white relative flex flex-col`}>
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzBoLTZsMyAxMHpNNTQgMjBsLTYgNiA2IDZ6TTYgNGwtNi02aDEyeiIvPjwvZz48L2c+PC9zdmc+')] opacity-20"></div>
                
                <Badge className="self-start z-10 bg-white/20 text-white hover:bg-white/30">
                  {event.type}
                </Badge>
                
                <h3 className="text-xl font-semibold mt-4 mb-1 z-10 line-clamp-2">{event.title}</h3>
                
                <div className="flex items-center text-sm text-white/80 mt-3 z-10">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>{event.date}</span>
                </div>
                
                <div className="flex items-center text-sm text-white/80 mt-1 z-10">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>{event.location}</span>
                </div>
              </div>
              
              <div className="p-6 flex-grow">
                <p className="text-gray-600 dark:text-gray-300 line-clamp-3">
                  {event.description}
                </p>
              </div>
              
              <div className="p-6 pt-0">
                <Button
                  asChild
                  className="w-full group-hover:translate-y-0 group-hover:shadow-md"
                  onClick={() => handleEventClick(event.id, event.title)}
                >
                  <Link href={`/events/${event.id}`}>
                    View Details <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-10 text-center">
          <Button 
            variant="outline" 
            asChild
            className="px-6"
            onClick={() => trackEvent('view_all_events_click', 'events')}
          >
            <Link href="/events" className="inline-flex items-center">
              View All Events
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}