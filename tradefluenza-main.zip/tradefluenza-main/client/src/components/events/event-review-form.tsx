import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { StarRating } from "@/components/ui/star-rating";
import { Switch } from "@/components/ui/switch";
import { PlusCircle, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";

// Form validation schema
const reviewFormSchema = z.object({
  rating: z.number().min(1).max(5),
  title: z.string().min(5, "Title must be at least 5 characters").max(100, "Title must be less than 100 characters"),
  content: z.string().min(20, "Review must be at least 20 characters"),
  highlights: z.array(z.string()).optional(),
  improvements: z.array(z.string()).optional(),
  wouldRecommend: z.boolean().default(true),
});

type ReviewFormValues = z.infer<typeof reviewFormSchema>;

interface EventReviewFormProps {
  eventId: number;
  onReviewSubmitted: () => void;
}

export default function EventReviewForm({ eventId, onReviewSubmitted }: EventReviewFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [newHighlight, setNewHighlight] = useState("");
  const [newImprovement, setNewImprovement] = useState("");

  const form = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      rating: 5,
      title: "",
      content: "",
      highlights: [],
      improvements: [],
      wouldRecommend: true,
    },
  });

  // Add a highlight
  const handleAddHighlight = () => {
    if (newHighlight.trim() === "") return;
    
    const currentHighlights = form.getValues("highlights") || [];
    form.setValue("highlights", [...currentHighlights, newHighlight.trim()]);
    setNewHighlight("");
  };

  // Remove a highlight
  const handleRemoveHighlight = (index: number) => {
    const currentHighlights = form.getValues("highlights") || [];
    form.setValue(
      "highlights",
      currentHighlights.filter((_, i) => i !== index)
    );
  };

  // Add a suggestion for improvement
  const handleAddImprovement = () => {
    if (newImprovement.trim() === "") return;
    
    const currentImprovements = form.getValues("improvements") || [];
    form.setValue("improvements", [...currentImprovements, newImprovement.trim()]);
    setNewImprovement("");
  };

  // Remove a suggestion for improvement
  const handleRemoveImprovement = (index: number) => {
    const currentImprovements = form.getValues("improvements") || [];
    form.setValue(
      "improvements",
      currentImprovements.filter((_, i) => i !== index)
    );
  };

  // Submit review mutation
  const submitReviewMutation = useMutation({
    mutationFn: async (data: ReviewFormValues) => {
      const response = await apiRequest("POST", `/api/events/${eventId}/reviews`, data);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit review");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Review submitted",
        description: "Your review has been submitted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/events/${eventId}/reviews`] });
      form.reset();
      onReviewSubmitted();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit review",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (data: ReviewFormValues) => {
    submitReviewMutation.mutate(data);
  };

  // If user is not authenticated, show login prompt
  if (!user) {
    return (
      <Card className="mb-8 border border-primary/10 bg-card/50">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">Write a Review</CardTitle>
          <CardDescription>
            Share your experience with other traders
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-6">
            <p className="text-center text-muted-foreground mb-4">
              Please sign in to leave a review for this event.
            </p>
            <Button variant="default" asChild>
              <a href="/auth">Sign In</a>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-8 border border-primary/10 bg-card/50">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Write a Review</CardTitle>
        <CardDescription>
          Share your experience with other traders
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="rating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rating</FormLabel>
                  <FormControl>
                    <StarRating
                      value={field.value}
                      onChange={field.onChange}
                      maxStars={5}
                      size={28}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Review Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Summarize your experience" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Review</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Share details of your experience at this event"
                      className="min-h-32"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Separator className="my-6" />

            <div className="space-y-4">
              <FormLabel>What did you like?</FormLabel>
              <div className="flex flex-wrap gap-2 mb-4">
                {form.watch("highlights")?.map((highlight, index) => (
                  <Badge
                    key={index}
                    className="px-3 py-1 bg-primary/20 hover:bg-primary/30 text-primary-foreground"
                  >
                    {highlight}
                    <button
                      type="button"
                      onClick={() => handleRemoveHighlight(index)}
                      className="ml-2 text-primary-foreground/70 hover:text-primary-foreground"
                    >
                      <Trash2 size={14} />
                    </button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Add a highlight (e.g., 'Great speakers')"
                  value={newHighlight}
                  onChange={(e) => setNewHighlight(e.target.value)}
                  className="flex-grow"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleAddHighlight}
                >
                  <PlusCircle size={16} className="mr-1" /> Add
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <FormLabel>What could be improved?</FormLabel>
              <div className="flex flex-wrap gap-2 mb-4">
                {form.watch("improvements")?.map((improvement, index) => (
                  <Badge
                    key={index}
                    className="px-3 py-1 bg-secondary/30 hover:bg-secondary/40 text-secondary-foreground"
                  >
                    {improvement}
                    <button
                      type="button"
                      onClick={() => handleRemoveImprovement(index)}
                      className="ml-2 text-secondary-foreground/70 hover:text-secondary-foreground"
                    >
                      <Trash2 size={14} />
                    </button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Add a suggestion (e.g., 'More Q&A time')"
                  value={newImprovement}
                  onChange={(e) => setNewImprovement(e.target.value)}
                  className="flex-grow"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleAddImprovement}
                >
                  <PlusCircle size={16} className="mr-1" /> Add
                </Button>
              </div>
            </div>

            <FormField
              control={form.control}
              name="wouldRecommend"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Recommend this event?</FormLabel>
                    <FormDescription>
                      Would you recommend this event to fellow traders?
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <div className="pt-4 pb-2 text-right">
              <Button
                type="submit"
                className="w-full sm:w-auto"
                disabled={submitReviewMutation.isPending}
              >
                {submitReviewMutation.isPending ? "Submitting..." : "Submit Review"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}