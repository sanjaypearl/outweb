import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Gift, Sparkles, Trophy, CheckCircle2, Mail } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";

// Form schema
const luckyOfferFormSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  propFirmId: z.string().min(1, "Please select a prop firm"),
  propFirmName: z.string().min(1, "Prop firm name is required")
});

type LuckyOfferFormData = z.infer<typeof luckyOfferFormSchema>;

export default function LuckyOfferForm() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  // Fetch prop firms for dropdown
  const { data: propFirms, isLoading: isPropFirmsLoading } = useQuery<any[]>({
    queryKey: ['/api/prop-firms'],
  });

  const form = useForm<LuckyOfferFormData>({
    resolver: zodResolver(luckyOfferFormSchema),
    defaultValues: {
      email: "",
      propFirmId: "",
      propFirmName: ""
    }
  });

  const submitMutation = useMutation({
    mutationFn: async (data: LuckyOfferFormData) => {
      const response = await apiRequest(
        'POST',
        '/api/lucky-offer',
        {
          email: data.email,
          propFirmId: parseInt(data.propFirmId),
          propFirmName: data.propFirmName
        }
      );
      return response.json();
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: "Success!",
        description: "Your lucky offer entry has been submitted successfully!",
      });
    },
    onError: (error) => {
      console.error("Lucky offer submission error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit your entry. Please try again.",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: LuckyOfferFormData) => {
    submitMutation.mutate(data);
  };

  const handlePropFirmChange = (value: string) => {
    const selectedFirm = propFirms?.find(firm => firm.id.toString() === value);
    form.setValue('propFirmId', value);
    form.setValue('propFirmName', selectedFirm?.name || '');
  };

  if (isSubmitted) {
    return (
      <Card className="w-full max-w-2xl mx-auto bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/40 mb-6">
              <CheckCircle2 className="w-10 h-10 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-2xl font-bold text-green-800 dark:text-green-300 mb-2">
              Entry Submitted Successfully!
            </h3>
            <p className="text-green-600 dark:text-green-400 mb-4">
              Thank you for participating in our lucky offer! We'll contact you soon with further details.
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-green-700 dark:text-green-300">
              <Mail className="w-4 h-4" />
              <span>Check your email for confirmation</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-2xl mx-auto bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border-purple-200 dark:border-purple-800">
      <CardHeader className="text-center pb-4">
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="relative">
            <Gift className="w-8 h-8 text-purple-600 dark:text-purple-400" />
            <Sparkles className="w-4 h-4 text-yellow-500 absolute -top-1 -right-1 animate-pulse" />
          </div>
          <Trophy className="w-8 h-8 text-yellow-500" />
        </div>
        <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          🎉 Lucky Offer Alert!
        </CardTitle>
        <CardDescription className="text-lg">
          <span className="font-semibold text-purple-700 dark:text-purple-300">
            Use codes from Tradefluenza
          </span>
          <br />
          Buy any prop firm and claim your lucky reward!
        </CardDescription>
      </CardHeader>
      
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Email Address
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="email"
                      placeholder="Enter your email address"
                      {...field}
                      className="border-purple-200 dark:border-purple-800 focus:border-purple-400 dark:focus:border-purple-600"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="propFirmId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Which Prop Firm Did You Buy?
                  </FormLabel>
                  <Select onValueChange={handlePropFirmChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="border-purple-200 dark:border-purple-800 focus:border-purple-400 dark:focus:border-purple-600">
                        <SelectValue placeholder="Select the prop firm you purchased" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {isPropFirmsLoading ? (
                        <div className="p-2">
                          <Skeleton className="h-4 w-32" />
                        </div>
                      ) : (
                        propFirms?.map((firm) => (
                          <SelectItem key={firm.id} value={firm.id.toString()}>
                            {firm.name}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 rounded-lg p-4 border border-purple-200 dark:border-purple-800">
              <h4 className="font-semibold text-purple-800 dark:text-purple-300 mb-2">
                📋 How it works:
              </h4>
              <ul className="text-sm text-purple-700 dark:text-purple-400 space-y-1">
                <li>• Use promo codes from Tradefluenza when purchasing</li>
                <li>• Submit your email and prop firm details</li>
                <li>• Get entered into our lucky draw</li>
                <li>• Win exclusive rewards and bonuses!</li>
              </ul>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium py-3 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Submitting...
                </>
              ) : (
                <>
                  <Gift className="w-5 h-5 mr-2" />
                  Submit My Entry
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}