import { Link } from "wouter";
import { 
  TwitterIcon, 
  FacebookIcon, 
  InstagramIcon, 
  LinkedinIcon,
  Mail,
  Globe,
  TrendingUp,
  BarChart3,
  Users,
  ChevronRight,
  ExternalLink
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

export default function Footer() {
  const [accountSizes, setAccountSizes] = useState<number[]>([]);
  
  useEffect(() => {
    async function fetchAccountSizes() {
      try {
        const response = await fetch('/api/prop-firms/account-sizes');
        if (response.ok) {
          const sizes = await response.json();
          setAccountSizes(sizes);
        }
      } catch (error) {
        console.error('Error fetching account sizes:', error);
      }
    }
    
    fetchAccountSizes();
  }, []);
  
  const formatAccountSize = (size: number) => {
    return size >= 1000 ? `$${size/1000}K` : `$${size}`;
  };
  
  return (
    <footer className="mt-16">
      {/* Newsletter section */}
      <div className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern-bg opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-4">Stay Updated</h2>
              <p className="text-gray-300 mb-6 max-w-lg">
                Get the latest news on prop trading firms, exclusive comparisons, and trading tips delivered to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <input 
                  type="email" 
                  placeholder="Enter your email" 
                  className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-3 rounded-lg w-full sm:w-auto sm:flex-1 focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <Button className="bg-gradient-to-r from-primary to-blue-700 hover:from-primary/90 hover:to-blue-600 text-white font-medium py-3 px-6">
                  Subscribe
                </Button>
              </div>
            </div>
            <div className="hidden lg:flex justify-end">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 w-full max-w-md">
                <div className="flex items-center mb-4">
                  <TrendingUp className="h-8 w-8 text-primary mr-3" />
                  <h3 className="text-xl font-bold text-white">Trading Quiz</h3>
                </div>
                <p className="text-gray-300 mb-6">
                  Find the perfect prop firm for your trading style, experience level, and budget in just a few clicks.
                </p>
                <Link href="/quiz">
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white font-medium flex items-center justify-center">
                    Take the Quiz
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main footer content */}
      <div className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            <div className="lg:col-span-2">
              <Link href="/">
                <h2 className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-500 text-transparent bg-clip-text inline-block mb-4">
                  Tradefluenza
                </h2>
              </Link>
              <p className="text-gray-400 text-sm mb-6 max-w-md">
                The ultimate resource for traders looking to compare and choose the best proprietary trading firms based on real data and community feedback.
              </p>
              {/* Social media links removed as requested */}
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4 border-b border-gray-800 pb-2">Explore</h3>
              <ul className="space-y-3 text-gray-400 text-sm">
                <li>
                  <Link href="/" className="hover:text-primary flex items-center">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    <span>Home</span>
                  </Link>
                </li>
                <li>
                  <Link href="/prop-firms" className="hover:text-primary flex items-center">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    <span>Prop Firms</span>
                  </Link>
                </li>
                <li>
                  <Link href="/quiz" className="hover:text-primary flex items-center">
                    <Globe className="h-4 w-4 mr-2" />
                    <span>Find Your Match</span>
                  </Link>
                </li>
                <li>
                  <Link href="/prop-firm-comparison" className="hover:text-primary flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    <span>Compare</span>
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4 border-b border-gray-800 pb-2">Account Sizes</h3>
              <ul className="space-y-3 text-gray-400 text-sm">
                {accountSizes.slice(0, 5).map((size) => (
                  <li key={size}>
                    <Link 
                      href={`/prop-firms?accountSize=${size}`} 
                      className="hover:text-primary flex items-center"
                    >
                      <ChevronRight className="h-4 w-4 mr-1" />
                      <span>{formatAccountSize(size)} Accounts</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4 border-b border-gray-800 pb-2">Support</h3>
              <ul className="space-y-3 text-gray-400 text-sm">
                <li>
                  <a href="#" className="hover:text-primary flex items-center">
                    <Mail className="h-4 w-4 mr-2" />
                    <span>Contact Us</span>
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary flex items-center">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    <span>Privacy Policy</span>
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary flex items-center">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    <span>Terms of Service</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">
              © {new Date().getFullYear()} Tradefluenza. All rights reserved.
            </p>
            <div className="mt-4 md:mt-0">
              <p className="text-xs text-gray-500">
                Traders' choices matter. Helping you find the perfect prop firm since 2023.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
