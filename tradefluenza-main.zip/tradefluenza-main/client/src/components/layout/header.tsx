import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, ChevronDown, Search, TrendingUp, BarChart3, Users, BookOpen, Building, UserCircle, LogOut, Settings, LifeBuoy, Calendar } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  // Detect scroll for transparent/solid header transition
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const navigation = [
    { name: "Home", href: "/" },
    { name: "Prop Firms", href: "/prop-firms" },
    { name: "Prop Firm Rules", href: "/prop-firm-rules" },
    { name: "Brokers", href: "/brokers" },
    { name: "Events", href: "/events" },
    { name: "About", href: "/about" },
    { name: "Resolution Center", href: "/resolution-center" },
  ];
  
  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-blue-700 text-transparent bg-clip-text cursor-pointer">
                Tradefluenza
              </h1>
            </Link>
          </div>
          
          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <Link 
                key={item.name}
                href={item.href}
                className={`
                  relative py-2 px-1 text-sm font-medium transition-all duration-200
                  ${location === item.href 
                    ? "text-primary" 
                    : "text-gray-600 hover:text-primary"}
                `}
              >
                <span className="relative z-10">{item.name}</span>
                
                {/* Active underline indicator */}
                {location === item.href && (
                  <span className="absolute bottom-0 left-0 w-full h-0.5 bg-primary rounded-full"></span>
                )}
              </Link>
            ))}
          </nav>
          
          {/* Right side actions */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Find Match button */}
            <Link href="/quiz">
              <button className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                Find Match
              </button>
            </Link>
            
            {/* Authentication */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <div className="flex h-full w-full items-center justify-center rounded-full bg-gradient-to-br from-primary to-blue-600 text-white">
                      {user.username.charAt(0).toUpperCase()}
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.username}</p>
                      <p className="text-xs leading-none text-muted-foreground">Member</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="w-full cursor-pointer">
                      <UserCircle className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/admin" className="w-full cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Admin Dashboard</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="cursor-pointer text-red-600 focus:text-red-600"
                    onClick={() => logoutMutation.mutate()}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-3">
                <Link href="/auth">
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary/5 text-sm h-9">
                    Log in
                  </Button>
                </Link>
                <Link href="/auth?register=true">
                  <Button className="bg-primary hover:bg-primary/90 text-white text-sm h-9">
                    Sign up
                  </Button>
                </Link>
              </div>
            )}
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              className="text-gray-700 hover:text-primary p-2 rounded-md transition-all duration-200 hover:bg-gray-100"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
            >
              {isOpen ? 
                <X className="h-6 w-6" /> : 
                <Menu className="h-6 w-6" />
              }
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden absolute w-full bg-white/95 backdrop-blur-sm shadow-lg border-b border-gray-200/40 animate-in slide-in-from-top duration-300 z-50">
          <div className="px-4 py-4 space-y-3">
            {navigation.map((item) => (
              <Link 
                key={item.name} 
                href={item.href}
                className={`
                  flex items-center py-3 px-4 rounded-lg transition-all duration-200
                  ${location === item.href 
                    ? "bg-gradient-to-r from-primary/10 to-blue-500/10 text-primary font-medium" 
                    : "text-gray-700 hover:bg-gray-50 hover:text-primary hover:translate-x-1"}
                `}
                onClick={() => setIsOpen(false)}
              >
                {item.name === "Home" && <TrendingUp className="mr-3 h-5 w-5" />}
                {item.name === "Prop Firms" && <BarChart3 className="mr-3 h-5 w-5" />}
                {item.name === "Brokers" && <Building className="mr-3 h-5 w-5" />}
                {item.name === "Events" && <Calendar className="mr-3 h-5 w-5" />}
                {item.name === "About" && <BookOpen className="mr-3 h-5 w-5" />}
                {item.name === "Resolution Center" && <LifeBuoy className="mr-3 h-5 w-5" />}
                {item.name}
              </Link>
            ))}
            
            {/* Mobile CTA */}
            <Link href="/quiz">
              <button 
                className="w-full mt-4 text-center bg-gradient-to-r from-primary to-blue-700 text-white py-3 px-5 rounded-lg shadow-md font-medium hover:shadow-lg transition-all duration-300 active:translate-y-0.5"
                onClick={() => setIsOpen(false)}
              >
                Find Your Perfect Prop Firm
              </button>
            </Link>
            

            
            {/* Mobile Authentication */}
            {user ? (
              <div className="mt-4 border-t border-gray-100 pt-4">
                <Link 
                  href="/profile"
                  className="flex items-center py-3 px-4 rounded-lg transition-all duration-200 text-gray-700 hover:bg-gray-50"
                  onClick={() => setIsOpen(false)}
                >
                  <UserCircle className="mr-3 h-5 w-5" />
                  Profile
                </Link>
                <Link 
                  href="/admin"
                  className="flex items-center py-3 px-4 rounded-lg transition-all duration-200 text-gray-700 hover:bg-gray-50"
                  onClick={() => setIsOpen(false)}
                >
                  <Settings className="mr-3 h-5 w-5" />
                  Admin Dashboard
                </Link>
                <button
                  className="flex items-center w-full py-3 px-4 rounded-lg transition-all duration-200 text-red-600 hover:bg-red-50"
                  onClick={() => {
                    logoutMutation.mutate();
                    setIsOpen(false);
                  }}
                >
                  <LogOut className="mr-3 h-5 w-5" />
                  Log out
                </button>
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Link href="/auth" onClick={() => setIsOpen(false)}>
                  <button className="w-full py-2 px-4 border border-primary text-primary rounded-lg hover:bg-primary/5 transition-colors">
                    Log in
                  </button>
                </Link>
                <Link href="/auth?register=true" onClick={() => setIsOpen(false)}>
                  <button className="w-full py-2 px-4 bg-gradient-to-r from-primary to-blue-700 text-white rounded-lg shadow-sm hover:shadow-md transition-all">
                    Sign up
                  </button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
