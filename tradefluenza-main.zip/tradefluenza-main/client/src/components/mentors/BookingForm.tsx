import React, { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface BookingFormProps {
  mentorId: number;
  onClose: () => void;
}

export const BookingForm: React.FC<BookingFormProps> = ({ mentorId, onClose }) => {
  const [date, setDate] = useState<Date>();
  const [time, setTime] = useState<string>("");
  const [sessionType, setSessionType] = useState<string>("one_hour");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!date || !time) {
      toast({
        title: "Missing information",
        description: "Please select both a date and time for your session.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Get duration from session type
    const getDuration = () => {
      switch (sessionType) {
        case "one_hour": return 60;
        case "two_hour": return 120;
        case "portfolio_review": return 90;
        default: return 60;
      }
    };
    
    // Convert time string to Date object with the selected date
    const sessionDate = new Date(date);
    const [hours, minutes] = time.split(':');
    const isPM = time.includes('PM');
    let hourValue = parseInt(hours);
    if (isPM && hourValue !== 12) hourValue += 12;
    if (!isPM && hourValue === 12) hourValue = 0;
    sessionDate.setHours(hourValue, parseInt(minutes) || 0);
    
    try {
      // Prepare booking data
      const bookingData = {
        date: sessionDate.toISOString(),
        duration: getDuration(),
        topic: `${sessionType.replace('_', ' ')} session`,
        notes: "Booking made through the website."
      };
      
      // Send booking request to API
      const response = await fetch(`/api/mentors/${mentorId}/book`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookingData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to book session");
      }
      
      toast({
        title: "Session Booked!",
        description: `Your session has been scheduled for ${format(date, "MMMM d, yyyy")} at ${time}.`,
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Booking failed",
        description: error instanceof Error ? error.message : "There was an error booking your session. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // List of available time slots
  const timeSlots = [
    "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
    "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"
  ];
  
  // Session types with duration and descriptions
  const sessionTypes = [
    { value: "one_hour", label: "1 Hour Session", description: "Standard mentoring session" },
    { value: "two_hour", label: "2 Hour Session", description: "Extended strategy review" },
    { value: "portfolio_review", label: "Portfolio Review", description: "In-depth analysis of your trades" },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4 pt-4">
      <div className="space-y-2">
        <Label htmlFor="date">Select Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal",
                !date && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date ? format(date, "PPP") : <span>Pick a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              initialFocus
              disabled={(date) => date < new Date()}
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="space-y-2">
        <Label htmlFor="time">Select Time</Label>
        <Select value={time} onValueChange={setTime}>
          <SelectTrigger>
            <SelectValue placeholder="Select time slot" />
          </SelectTrigger>
          <SelectContent>
            {timeSlots.map((slot) => (
              <SelectItem key={slot} value={slot}>
                {slot}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="sessionType">Session Type</Label>
        <Select value={sessionType} onValueChange={setSessionType}>
          <SelectTrigger>
            <SelectValue placeholder="Select session type" />
          </SelectTrigger>
          <SelectContent>
            {sessionTypes.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label} - {type.description}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="pt-4 flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button 
          type="submit" 
          disabled={isSubmitting}
          className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700"
        >
          {isSubmitting ? "Booking..." : "Book Session"}
        </Button>
      </div>
    </form>
  );
};