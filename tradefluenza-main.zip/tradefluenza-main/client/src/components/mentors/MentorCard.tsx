import React, { useState } from "react";
import { FiStar } from "react-icons/fi";
import { Award, Calendar, Clock, Globe, Info, MapPin, MessageCircle, Tag, Users } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { BookingForm } from "./BookingForm";
import { useLocation } from "wouter";

// Custom icon for verified badge
const Verified = () => (
  <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7.5 0.875C5.84899 0.875 4.26398 1.50089 3.08059 2.6114C1.8972 3.72191 1.25 5.2076 1.25 6.75C1.25 8.2924 1.8972 9.77809 3.08059 10.8886C4.26398 11.9991 5.84899 12.625 7.5 12.625C9.15101 12.625 10.736 11.9991 11.9194 10.8886C13.1028 9.77809 13.75 8.2924 13.75 6.75C13.75 5.2076 13.1028 3.72191 11.9194 2.6114C10.736 1.50089 9.15101 0.875 7.5 0.875ZM10.3594 5.79687L7.10938 9.04687C7.03603 9.12028 6.94874 9.17939 6.85256 9.22089C6.75638 9.26238 6.65311 9.28545 6.54844 9.28879C6.44377 9.29214 6.33908 9.27568 6.24017 9.24042C6.14126 9.20517 6.04996 9.15178 5.97156 9.08281L3.66406 7.08281C3.50926 6.94504 3.41953 6.75669 3.41342 6.55783C3.40731 6.35896 3.48523 6.16547 3.63089 6.01981C3.77655 5.87415 3.97005 5.79623 4.16891 5.80234C4.36778 5.80845 4.55613 5.89818 4.69389 6.05297L6.51562 7.63359L9.30625 4.84297C9.37863 4.76983 9.46504 4.71076 9.56036 4.66919C9.65568 4.62761 9.75811 4.60438 9.86204 4.60079C9.96597 4.5972 10.0698 4.61333 10.1682 4.64829C10.2665 4.68324 10.3574 4.73635 10.4353 4.80512C10.5132 4.87389 10.5764 4.95711 10.6215 5.04999C10.6665 5.14286 10.6925 5.24391 10.6981 5.34761C10.7037 5.45132 10.6888 5.55508 10.6543 5.65352C10.6199 5.75195 10.5665 5.84136 10.4969 5.91719L10.3594 5.79687Z" fill="currentColor"/>
  </svg>
);

// Utility function to format specialization and experience levels
const formatString = (str: string) => {
  return str.replace(/_/g, ' ').split(' ').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
};

interface MentorCardProps {
  mentor: {
    id: number;
    name: string;
    profileImage?: string;
    bio: string;
    experience: number;
    specialization: string;
    experienceLevel: string;
    hourlyRate: number;
    isVerified?: boolean;
    languages?: string;
    location?: string;
  };
}

export const MentorCard: React.FC<MentorCardProps> = ({ mentor }) => {
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [, navigate] = useLocation();

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg border border-gray-200 dark:border-gray-800">
      <div className="relative p-6">
        {mentor.isVerified && (
          <Badge className="absolute right-4 top-4 bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-100">
            <Verified /> <span className="ml-1">Verified</span>
          </Badge>
        )}
        
        <div className="flex items-start">
          <img 
            src={mentor.profileImage || 'https://via.placeholder.com/150'}
            alt={mentor.name} 
            className="h-20 w-20 rounded-full object-cover border-2 border-cyan-500"
            onError={(e) => {
              e.currentTarget.src = 'https://via.placeholder.com/150?text=' + mentor.name.charAt(0);
            }}
          />
          <div className="ml-4">
            <h3 className="text-xl font-bold">{mentor.name}</h3>
            <div className="flex items-center mt-1">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <FiStar 
                    key={star} 
                    className="text-amber-500 fill-amber-500 h-4 w-4" 
                  />
                ))}
              </div>
              <span className="ml-2 text-sm font-medium">5.0</span>
              <span className="mx-1 text-gray-400">•</span>
              <span className="text-sm text-gray-500">Expert Trader</span>
            </div>
            <p className="mt-2 text-gray-600 dark:text-gray-400 text-sm line-clamp-2">{mentor.bio}</p>
          </div>
        </div>
        
        <div className="mt-4 flex items-center">
          <Tag className="h-4 w-4 text-cyan-500 mr-2" />
          <span className="font-medium mr-2">${mentor.hourlyRate}/hour</span>
          <span className="text-gray-500 text-sm">{formatString(mentor.specialization)}</span>
        </div>
        
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="flex items-center">
            <Award className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm">{formatString(mentor.experienceLevel)}</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm">{mentor.experience} years</span>
          </div>
          <div className="flex items-center">
            <Globe className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm">{mentor.languages || "English"}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm">{mentor.location || "Worldwide"}</span>
          </div>
        </div>
        
        <div className="mt-6 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <Button 
            onClick={() => navigate(`/mentors/${mentor.id}`)}
            variant="outline" 
            className="w-full sm:w-auto"
          >
            <Info className="h-4 w-4 mr-2" />
            View Details
          </Button>
          
          <Dialog open={showBookingForm} onOpenChange={setShowBookingForm}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700 w-full sm:w-auto">
                <Calendar className="h-4 w-4 mr-2" />
                Book Session
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Book a Session</DialogTitle>
                <DialogDescription>
                  Schedule a one-on-one mentoring session with {mentor.name}.
                </DialogDescription>
              </DialogHeader>
              <BookingForm mentorId={mentor.id} onClose={() => setShowBookingForm(false)} />
            </DialogContent>
          </Dialog>
          
          <Button variant="outline" className="w-full sm:w-auto">
            <MessageCircle className="h-4 w-4 mr-2" />
            Message
          </Button>
        </div>
      </div>
    </Card>
  );
};