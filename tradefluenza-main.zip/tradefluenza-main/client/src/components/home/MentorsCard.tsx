import { Link } from "wouter";
import { ArrowRight, GraduationCap } from "lucide-react";

export const MentorsCard = () => {
  return (
    <Link href="/mentors" className="group">
      <div className="relative h-full overflow-hidden rounded-xl">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-50 to-sky-100 dark:from-cyan-950/40 dark:to-sky-900/30 transition-all duration-500 group-hover:scale-[1.05] group-hover:blur-[1px]"></div>
        
        {/* Card content with enhanced glassmorphism effect */}
        <div className="relative p-8 rounded-xl backdrop-blur-sm border border-cyan-200/60 dark:border-cyan-800/30 bg-white/50 dark:bg-gray-900/50 h-full flex flex-col">
          {/* Top colored bar */}
          <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-cyan-400 to-sky-600"></div>
          
          {/* Badge in top corner */}
          <div className="absolute top-4 right-4">
            <span className="inline-flex items-center rounded-full bg-cyan-50 dark:bg-cyan-900/30 px-2.5 py-0.5 text-xs font-medium text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800/50">
              Verified
            </span>
          </div>
          
          {/* Icon with pulse effect */}
          <div className="relative mb-6">
            <div className="absolute inset-0 rounded-full bg-cyan-500/20 blur-xl animate-pulse"></div>
            <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-cyan-500 to-sky-600 flex items-center justify-center text-white shadow-lg transform transition-transform group-hover:rotate-3 group-hover:scale-110">
              <GraduationCap className="h-10 w-10" />
            </div>
          </div>
          
          <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 group-hover:text-cyan-600 dark:group-hover:text-cyan-400">Mentors</h3>
          <p className="text-gray-600 dark:text-gray-300 mb-6">Book sessions with verified trading mentors and access personalized coaching from industry experts</p>
          
          {/* Stats section */}
          <div className="grid grid-cols-2 gap-2 mb-6">
            <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
              <p className="text-sm text-gray-500 dark:text-gray-400">Mentors</p>
              <p className="text-xl font-bold text-cyan-600 dark:text-cyan-400">30+</p>
            </div>
            <div className="bg-white/60 dark:bg-gray-800/30 rounded-lg p-2 text-center">
              <p className="text-sm text-gray-500 dark:text-gray-400">Reviews</p>
              <p className="text-xl font-bold text-cyan-600 dark:text-cyan-400">450+</p>
            </div>
          </div>
          
          <div className="flex items-center justify-center mt-auto p-3 rounded-lg bg-gradient-to-r from-cyan-500 to-sky-600 text-white font-medium group-hover:shadow-lg transition-all duration-300">
            <span>Find a Mentor</span>
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </div>
        </div>
      </div>
    </Link>
  );
};

export default MentorsCard;