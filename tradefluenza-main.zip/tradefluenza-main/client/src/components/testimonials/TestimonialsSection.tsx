import React from 'react';

// Create a simplified placeholder component for now
export const prefetchTestimonials = () => {
  console.log('Testimonials prefetch disabled for debugging');
  return Promise.resolve();
};

const TestimonialsSection = () => {
  return (
    <section className="p-8 my-8 text-center bg-gray-100 dark:bg-gray-800 rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Testimonials Section</h2>
      <p>Temporarily simplified for debugging</p>
    </section>
  );
};

export default TestimonialsSection;