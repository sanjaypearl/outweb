import { useState, useEffect } from "react";
import { X, Gift, Check } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

// Form schema
const freeAccountFormSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  phoneNumber: z
    .string()
    .min(10, { message: "Phone number must be at least 10 digits" })
    .regex(/^\+?[0-9\s\-()]+$/, { 
      message: "Please enter a valid phone number" 
    }),
});

type FreeAccountFormValues = z.infer<typeof freeAccountFormSchema>;

interface FreeAccountPopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function FreeAccountPopup({ 
  open, 
  onOpenChange
}: FreeAccountPopupProps) {
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Reset submission state when popup opens
  useEffect(() => {
    if (open) {
      setIsSubmitted(false);
    }
  }, [open]);

  // Create form
  const form = useForm<FreeAccountFormValues>({
    resolver: zodResolver(freeAccountFormSchema),
    defaultValues: {
      email: "",
      phoneNumber: "",
    },
  });

  // API mutation
  const mutation = useMutation({
    mutationFn: async (data: FreeAccountFormValues) => {
      const response = await apiRequest(
        "POST", 
        "/api/promotions/free-account-entry", 
        data
      );
      return await response.json();
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: "Success!",
        description: "Your entry has been submitted. Good luck!",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: FreeAccountFormValues) {
    mutation.mutate(data);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold gradient-text flex items-center gap-2">
            <Gift className="h-5 w-5" />
            Win a $10K Free Account
          </DialogTitle>
          <DialogDescription>
            Enter your details below for a chance to win a fully funded $10,000 trading account
          </DialogDescription>
        </DialogHeader>
        
        <div className="absolute top-4 right-4">
          <Button
            variant="ghost"
            className="h-6 w-6 p-0 rounded-full"
            onClick={() => onOpenChange(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {isSubmitted ? (
          <div className="py-6 px-2 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-full gradient-primary flex items-center justify-center">
              <Check className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold">Thank You!</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Your entry has been successfully submitted. We'll contact you if you're selected as the winner!
            </p>
            <Button
              className="w-full gradient-primary text-white"
              onClick={() => onOpenChange(false)}
            >
              Close
            </Button>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="your@email.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input placeholder="+1 123 456 7890" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full gradient-primary text-white"
                  disabled={mutation.isPending}
                >
                  {mutation.isPending ? "Submitting..." : "Enter Giveaway"}
                </Button>
              </div>
              
              <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                By submitting, you agree to receive promotional emails. You can unsubscribe at any time.
              </p>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}