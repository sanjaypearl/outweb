import { useState, useEffect } from "react";
import FreeAccountPopup from "./free-account-popup";

export default function PopupManager() {
  const [showPopup, setShowPopup] = useState(false);
  
  useEffect(() => {
    // Check if the popup has been shown in this session
    const hasShownPopup = sessionStorage.getItem("hasShownFreeAccountPopup");
    
    if (!hasShownPopup) {
      // Set a timeout to show the popup after 20 seconds (20000ms)
      const timer = setTimeout(() => {
        setShowPopup(true);
        // Mark that we've shown the popup in this session
        sessionStorage.setItem("hasShownFreeAccountPopup", "true");
      }, 20000);
      
      return () => clearTimeout(timer);
    }
  }, []);
  
  return (
    <FreeAccountPopup 
      open={showPopup} 
      onOpenChange={setShowPopup} 
    />
  );
}