import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Gift } from "lucide-react";
import FreeAccountPopup from "./free-account-popup";

export default function WinButton() {
  const [showPopup, setShowPopup] = useState(false);
  
  return (
    <>
      <Button 
        className="gradient-primary text-white font-bold relative overflow-hidden group"
        onClick={() => setShowPopup(true)}
      >
        <span className="absolute inset-0 bg-white/10 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
        <Gift className="w-4 h-4 mr-2" />
        Win $10K Free Account
      </Button>
      
      <FreeAccountPopup 
        open={showPopup} 
        onOpenChange={setShowPopup} 
      />
    </>
  );
}