import React, { useState, useEffect, useRef } from 'react';

interface CountUpAnimationProps {
  start?: number;
  end: number;
  duration?: number;
  className?: string;
  formatter?: (value: number) => string;
}

export function CountUpAnimation({
  start = 0,
  end,
  duration = 2,
  className = '',
  formatter = (value) => value.toString(),
}: CountUpAnimationProps) {
  const [count, setCount] = useState(start);
  const countRef = useRef<number>(start);
  const startTimeRef = useRef<number | null>(null);
  const frameIdRef = useRef<number | null>(null);
  const lastUpdateTimeRef = useRef<number>(Date.now());
  const incrementedValueRef = useRef<number>(end);

  useEffect(() => {
    // Reset when end changes
    countRef.current = start;
    startTimeRef.current = null;
    incrementedValueRef.current = end;
    lastUpdateTimeRef.current = Date.now();

    const animate = (timestamp: number) => {
      if (startTimeRef.current === null) {
        startTimeRef.current = timestamp;
      }

      const elapsed = timestamp - startTimeRef.current;
      const progress = Math.min(elapsed / (duration * 1000), 1);
      
      // Easing function: cubic-bezier(0.25, 0.1, 0.25, 1.0)
      const easedProgress = progress < 0.5
        ? 4 * progress * progress * progress
        : 1 - Math.pow(-2 * progress + 2, 3) / 2;
      
      const currentCount = Math.round(start + (end - start) * easedProgress);
      
      if (currentCount !== countRef.current) {
        countRef.current = currentCount;
        setCount(currentCount);
      }

      if (progress < 1) {
        frameIdRef.current = requestAnimationFrame(animate);
      }
    };

    frameIdRef.current = requestAnimationFrame(animate);

    // Increase by exactly 3 in 30 minutes
    // 30 minutes = 1800 seconds
    // 3 increments in 1800 seconds = 1 increment per 600 seconds (10 minutes)
    
    // Production setting: exactly 3 increments over 30 minutes
    const INCREMENT_INTERVAL_MS = 10 * 60 * 1000; // 10 minutes
    
    // Incremental updates
    const checkAndIncrement = () => {
      const now = Date.now();
      const elapsed = now - lastUpdateTimeRef.current;
      
      if (elapsed >= INCREMENT_INTERVAL_MS) {
        // Increment by 1
        incrementedValueRef.current += 1;
        countRef.current = incrementedValueRef.current;
        setCount(countRef.current);
        
        // Reset timer
        lastUpdateTimeRef.current = now;
        
        // Schedule next increment
        setTimeout(checkAndIncrement, INCREMENT_INTERVAL_MS);
      } else {
        // Check again shortly
        setTimeout(checkAndIncrement, 5000); // Check every 5 seconds
      }
    };
    
    // Start the increment check cycle
    const timer = setTimeout(checkAndIncrement, INCREMENT_INTERVAL_MS);

    return () => {
      if (frameIdRef.current) {
        cancelAnimationFrame(frameIdRef.current);
      }
      clearTimeout(timer);
    };
  }, [start, end, duration]);

  return <span className={className}>{formatter(count)}</span>;
}

export default CountUpAnimation;