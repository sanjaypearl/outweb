import { useState } from "react";
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  value: number;
  maxStars?: number;
  size?: number;
  onChange?: (value: number) => void;
  readOnly?: boolean;
  className?: string;
}

export function StarRating({
  value,
  maxStars = 5,
  onChange,
  readOnly = false,
  size = 20,
  className,
}: StarRatingProps) {
  const [hoverValue, setHoverValue] = useState<number | null>(null);
  
  // Create an array from 1 to maxStars
  const stars = Array.from({ length: maxStars }, (_, i) => i + 1);
  
  // Calculate the current display value (either hover value or actual value)
  const currentValue = hoverValue !== null ? hoverValue : value;
  
  // Handle mouse enter on a star
  const handleMouseEnter = (starValue: number) => {
    if (readOnly) return;
    setHoverValue(starValue);
  };
  
  // Handle mouse leave on the star container
  const handleMouseLeave = () => {
    if (readOnly) return;
    setHoverValue(null);
  };
  
  // Handle click on a star
  const handleClick = (starValue: number) => {
    if (readOnly) return;
    onChange?.(starValue);
  };
  
  return (
    <div 
      className={cn("flex items-center", className)}
      onMouseLeave={handleMouseLeave}
    >
      {stars.map((starValue) => (
        <Star
          key={starValue}
          size={size}
          className={cn(
            "transition-all cursor-pointer",
            readOnly ? "cursor-default" : "cursor-pointer",
            currentValue >= starValue
              ? "text-yellow-400 fill-yellow-400"
              : "text-muted stroke-muted-foreground",
            !readOnly && "hover:scale-110",
            "mr-0.5"
          )}
          onMouseEnter={() => handleMouseEnter(starValue)}
          onClick={() => handleClick(starValue)}
        />
      ))}
    </div>
  );
}