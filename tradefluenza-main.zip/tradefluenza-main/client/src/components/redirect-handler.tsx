import { useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { PropFirm } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

type RedirectType = 'propFirm' | 'broker';

export function RedirectHandler({ type }: { type: RedirectType }) {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id || '0');
  const [, setLocation] = useLocation();

  // Query for the entity data to get its URL
  const {
    data: entity,
    isLoading,
    isError,
  } = useQuery<PropFirm>({
    queryKey: [`/api/${type === 'propFirm' ? 'prop-firms' : 'brokers'}/${id}`],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!id,
  });

  // Effect to redirect when data is loaded
  useEffect(() => {
    if (entity?.websiteUrl) {
      // Track the external redirect
      try {
        import('@/lib/analytics').then(analytics => {
          analytics.trackBuyNowClick(entity.name, 0);
        }).catch(err => console.error('Failed to load analytics', err));
      } catch (error) {
        console.error('Error tracking event:', error);
      }
      
      // Redirect to the entity's website
      window.location.href = entity.websiteUrl;
    }
  }, [entity]);

  // If loading, show loading state
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <h2 className="text-xl font-semibold mb-2">Redirecting to Website</h2>
        <p className="text-gray-600 mb-4">Please wait while we redirect you...</p>
      </div>
    );
  }

  // If there's an error or no URL
  if (isError || !entity?.websiteUrl) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <h2 className="text-xl font-semibold mb-2">Unable to Redirect</h2>
        <p className="text-gray-600 mb-6">We couldn't find the website URL for this {type === 'propFirm' ? 'prop firm' : 'broker'}.</p>
        <Button onClick={() => setLocation(`/${type === 'propFirm' ? 'prop-firms' : 'brokers'}`)}>
          Go Back to {type === 'propFirm' ? 'Prop Firms' : 'Brokers'}
        </Button>
      </div>
    );
  }

  // Default view while waiting for redirect
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh]">
      <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
      <h2 className="text-xl font-semibold mb-2">Redirecting to {entity.name}</h2>
      <p className="text-gray-600 mb-4">If you are not redirected automatically, click the button below.</p>
      <Button
        onClick={() => window.location.href = entity.websiteUrl || '#'}
        className="gradient-primary text-white font-semibold"
      >
        Continue to Website
      </Button>
    </div>
  );
}