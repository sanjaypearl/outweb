import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Save, RefreshCw, TrendingUp, Award, Clock, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from '@/components/ui/skeleton';

interface PurchaseStats {
  id: number;
  totalPurchases: number;
  thisMonth: number;
  thisWeek: number;
  today: number;
  lastUpdated: Date;
}

export function PurchaseStatsManager() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch current stats
  const { data: stats, isLoading, error } = useQuery<PurchaseStats>({
    queryKey: ['/api/stats/purchases'],
  });
  
  // Form state
  const [formValues, setFormValues] = useState({
    totalPurchases: 0,
    thisMonth: 0,
    thisWeek: 0,
    today: 0
  });
  
  // Update form values when stats load
  useEffect(() => {
    if (stats) {
      setFormValues({
        totalPurchases: stats.totalPurchases,
        thisMonth: stats.thisMonth,
        thisWeek: stats.thisWeek,
        today: stats.today
      });
    }
  }, [stats]);
  
  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: parseInt(value) || 0
    });
  };
  
  // Update stats mutation
  const updateStatsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/admin/stats/purchases', formValues);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Statistics updated',
        description: 'Purchase counter statistics have been updated successfully.',
      });
      
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/stats/purchases'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update statistics',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Only show for authenticated users
  if (!user) return null;
  
  // Get formatted last updated time
  const getLastUpdatedText = () => {
    if (!stats?.lastUpdated) return 'Never updated';
    const date = new Date(stats.lastUpdated);
    return `Last updated: ${date.toLocaleDateString()} at ${date.toLocaleTimeString()}`;
  };
  
  return (
    <Card className="w-full max-w-lg mx-auto bg-background/80 backdrop-blur-sm border border-purple-500/20 shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium bg-gradient-to-r from-emerald-400 to-teal-600 bg-clip-text text-transparent">
          Purchase Counter Manager
        </CardTitle>
        <CardDescription>
          Update the purchase statistics displayed on the homepage
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 p-2 shadow-md">
                <Users className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1">
                <label htmlFor="totalPurchases" className="block text-sm font-medium mb-1">
                  Total Purchases
                </label>
                <Input
                  id="totalPurchases"
                  name="totalPurchases"
                  type="number"
                  min="0"
                  value={formValues.totalPurchases}
                  onChange={handleChange}
                  className="border-emerald-200 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 p-2 shadow-md">
                <TrendingUp className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1">
                <label htmlFor="thisMonth" className="block text-sm font-medium mb-1">
                  This Month
                </label>
                <Input
                  id="thisMonth"
                  name="thisMonth"
                  type="number"
                  min="0"
                  value={formValues.thisMonth}
                  onChange={handleChange}
                  className="border-emerald-200 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 p-2 shadow-md">
                <Clock className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1">
                <label htmlFor="thisWeek" className="block text-sm font-medium mb-1">
                  This Week
                </label>
                <Input
                  id="thisWeek"
                  name="thisWeek"
                  type="number"
                  min="0"
                  value={formValues.thisWeek}
                  onChange={handleChange}
                  className="border-emerald-200 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 p-2 shadow-md">
                <Award className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1">
                <label htmlFor="today" className="block text-sm font-medium mb-1">
                  Today
                </label>
                <Input
                  id="today"
                  name="today"
                  type="number"
                  min="0"
                  value={formValues.today}
                  onChange={handleChange}
                  className="border-emerald-200 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-4 text-xs text-muted-foreground text-right">
          {getLastUpdatedText()}
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          onClick={() => updateStatsMutation.mutate()}
          disabled={updateStatsMutation.isPending || isLoading}
          className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
        >
          {updateStatsMutation.isPending ? (
            <span className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 animate-spin" /> Updating...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Save className="h-4 w-4" /> Update Statistics
            </span>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}