import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface DiscountManagerProps {
  propFirmId: number;
  currentDiscount: number;
  propFirmName: string;
}

export function DiscountManager({ propFirmId, currentDiscount, propFirmName }: DiscountManagerProps) {
  const [discountPercentage, setDiscountPercentage] = useState(currentDiscount || 0);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const updateDiscountMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        "PATCH", 
        `/api/prop-firms/${propFirmId}/discount`, 
        { discountPercentage }
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Discount updated",
        description: `Successfully updated discount for ${propFirmName} to ${discountPercentage}%`,
        variant: "success",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/prop-firms/${propFirmId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/prop-firms'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update discount",
        description: error.message || "An error occurred while updating the discount percentage",
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateDiscountMutation.mutate();
  };
  
  return (
    <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 mt-4">
      <h3 className="text-md font-medium mb-3">Manage Discount</h3>
      
      <form onSubmit={handleSubmit} className="flex items-end gap-3">
        <div>
          <label htmlFor="discount-percentage" className="block text-sm font-medium text-gray-700 mb-1">
            Discount Percentage
          </label>
          <Input
            id="discount-percentage"
            type="number"
            min="0"
            max="100"
            value={discountPercentage}
            onChange={(e) => setDiscountPercentage(Number(e.target.value))}
            className="w-24"
          />
        </div>
        
        <Button 
          type="submit" 
          disabled={updateDiscountMutation.isPending || discountPercentage === currentDiscount}
          className="ml-3"
        >
          {updateDiscountMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Updating...
            </>
          ) : (
            "Update"
          )}
        </Button>
      </form>
    </div>
  );
}