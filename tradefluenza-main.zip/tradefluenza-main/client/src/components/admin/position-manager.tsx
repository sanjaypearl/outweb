import React, { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { ChevronUp, ChevronDown, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface PositionManagerProps {
  itemId: number;
  itemName: string;
  currentPosition: number | null;
  type: 'propFirm' | 'broker';
}

export function PositionManager({ itemId, itemName, currentPosition, type }: PositionManagerProps) {
  const { user } = useAuth();
  const [position, setPosition] = useState<number>(currentPosition || 999);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const endpoint = type === 'propFirm' 
    ? `/api/prop-firms/${itemId}/position` 
    : `/api/brokers/${itemId}/position`;
  
  const updatePositionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('PATCH', endpoint, { position });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Position updated',
        description: `${itemName}'s position has been updated to ${position}`,
      });
      
      // Invalidate queries to refresh the data
      if (type === 'propFirm') {
        queryClient.invalidateQueries({ queryKey: ['/api/prop-firms'] });
      } else {
        queryClient.invalidateQueries({ queryKey: ['/api/brokers'] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update position',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Only show for authenticated users
  if (!user) return null;
  
  return (
    <Card className="w-full max-w-md mx-auto bg-background/80 backdrop-blur-sm border border-purple-500/20 shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium bg-gradient-to-r from-purple-400 to-indigo-600 bg-clip-text text-transparent">Position Manager</CardTitle>
        <CardDescription>Update display position for {itemName}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setPosition(prev => Math.max(1, prev - 1))}
            className="h-8 w-8"
          >
            <ChevronUp className="h-4 w-4" />
          </Button>
          <Input
            type="number"
            min="1"
            value={position}
            onChange={(e) => setPosition(parseInt(e.target.value) || 1)}
            className="w-20 text-center"
          />
          <Button
            variant="outline"
            size="icon"
            onClick={() => setPosition(prev => prev + 1)}
            className="h-8 w-8"
          >
            <ChevronDown className="h-4 w-4" />
          </Button>
          <span className="ml-2 text-sm text-muted-foreground">
            Lower numbers appear first
          </span>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={() => updatePositionMutation.mutate()}
          disabled={updatePositionMutation.isPending}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
        >
          {updatePositionMutation.isPending ? (
            <span className="flex items-center gap-2">
              Saving... <span className="animate-spin">⏳</span>
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Save className="h-4 w-4" /> Save Position
            </span>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}