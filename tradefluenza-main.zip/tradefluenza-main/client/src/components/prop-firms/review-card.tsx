import React from "react";
import { formatDistanceToNow } from "date-fns";
import { User } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import StarRating from "./star-rating";
import { Separator } from "@/components/ui/separator";
import type { Review } from "@shared/schema";

interface ReviewCardProps {
  review: Review;
}

export default function ReviewCard({ review }: ReviewCardProps) {
  const { 
    title,
    content,
    rating,
    datePosted,
    isVerified,
    pros,
    cons,
    experience,
    tradingPeriod
  } = review;

  // Format the date
  const formattedDate = datePosted 
    ? formatDistanceToNow(new Date(datePosted), { addSuffix: true })
    : "Recently";
  
  // Get user initials for avatar
  const userInitials = "TF"; // Default for now, would need to fetch actual user data
  
  return (
    <Card className="overflow-hidden border border-gray-200">
      <CardHeader className="bg-gray-50 py-3 px-4 flex flex-row items-center gap-3">
        <Avatar className="h-10 w-10">
          <AvatarFallback className="bg-primary text-white">
            {userInitials}
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-col">
          <div className="flex flex-wrap items-center gap-2">
            <StarRating rating={Number(rating)} size="sm" />
            {isVerified && (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Verified Trader
              </Badge>
            )}
          </div>
          <p className="text-sm text-gray-500">
            {formattedDate}
          </p>
        </div>
      </CardHeader>
      
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-gray-700 mb-4">{content}</p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          {pros && pros.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-green-600 mb-2">Pros</h4>
              <ul className="text-sm space-y-1">
                {pros.map((pro, idx) => (
                  <li key={idx} className="flex items-start">
                    <span className="text-green-500 mr-2">+</span>
                    <span>{pro}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {cons && cons.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-red-600 mb-2">Cons</h4>
              <ul className="text-sm space-y-1">
                {cons.map((con, idx) => (
                  <li key={idx} className="flex items-start">
                    <span className="text-red-500 mr-2">-</span>
                    <span>{con}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
        
        {(experience || tradingPeriod) && (
          <>
            <Separator className="my-3" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-600">
              {experience && (
                <div>
                  <span className="font-medium">Experience Level:</span> {experience}
                </div>
              )}
              
              {tradingPeriod && (
                <div>
                  <span className="font-medium">Trading Period:</span> {tradingPeriod}
                </div>
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}