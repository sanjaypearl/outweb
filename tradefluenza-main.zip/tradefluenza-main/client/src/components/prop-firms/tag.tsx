import { cn } from "@/lib/utils";

// Props interface for the Tag component
export interface TagProps extends React.HTMLAttributes<HTMLDivElement> {
  text: string;
  size?: 'default' | 'sm' | 'lg';
  variant?: string;
}

// Size variations
const SIZE_STYLES: Record<string, string> = {
  'default': "h-6 px-3",
  'sm': "h-5 px-2.5 text-[10px]",
  'lg': "h-7 px-4 text-sm"
};

export default function Tag({ 
  className, 
  variant, 
  size = 'default',
  text,
  ...props 
}: TagProps) {
  // Base styles that apply to all tags
  const baseStyles = "inline-flex items-center justify-center rounded-full px-2.5 py-0.5 text-xs font-semibold shadow-sm transition-colors";
  
  // Get the correct size style
  const sizeStyle = SIZE_STYLES[size] || SIZE_STYLES.default;
  
  // Get color style based on the tag text or use default gradient
  let colorStyle = "bg-gradient-to-r from-gray-500 to-gray-600 text-white"; // default
  
  // Determine color style based on tag text
  switch (text) {
    case "Most Loved":
      colorStyle = "bg-gradient-to-r from-red-500 to-pink-500 text-white";
      break;
    case "Best Value":
      colorStyle = "bg-gradient-to-r from-green-500 to-emerald-500 text-white";
      break;
    case "Growing":
      colorStyle = "bg-gradient-to-r from-emerald-500 to-teal-500 text-white";
      break;
    case "Popular":
      colorStyle = "bg-gradient-to-r from-amber-500 to-yellow-500 text-white";
      break;
    case "New":
      colorStyle = "bg-gradient-to-r from-blue-500 to-cyan-500 text-white";
      break;
    case "Top Rated":
      colorStyle = "bg-gradient-to-r from-purple-500 to-violet-500 text-white";
      break;
  }
  
  // Combine all styles
  const combinedStyles = `${baseStyles} ${sizeStyle} ${colorStyle}`;
  
  return (
    <div 
      className={cn(combinedStyles, className)}
      {...props}
    >
      {text}
    </div>
  );
}