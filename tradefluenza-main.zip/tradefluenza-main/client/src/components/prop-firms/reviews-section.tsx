import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ReviewCard from "./review-card";
import StarRating from "./star-rating";
import ReviewForm from "./review-form";
import { Skeleton } from "@/components/ui/skeleton";
import { getQueryFn } from "@/lib/queryClient";
import type { PropFirm, Review } from "@shared/schema";

interface ReviewsSectionProps {
  propFirm: PropFirm;
}

export default function ReviewsSection({ propFirm }: ReviewsSectionProps) {
  // Fetch reviews for this prop firm
  const {
    data: reviews,
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: ['/api/prop-firms', propFirm.id, 'reviews'],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });
  
  // Add console logging to see what's happening
  React.useEffect(() => {
    console.log("Reviews data:", reviews);
    console.log("Is loading:", isLoading);
    console.log("Is error:", isError);
    // Refetch on component mount
    refetch();
  }, [reviews, isLoading, isError, refetch]);

  // Fetch average rating
  const {
    data: ratingData,
    isLoading: isRatingLoading,
  } = useQuery({
    queryKey: ['/api/prop-firms', propFirm.id, 'rating'],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const averageRating = ratingData?.averageRating || 0;
  const reviewCount = reviews?.length || 0;
  
  return (
    <section className="mt-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-4">Trader Reviews</h2>
        
        <div className="flex items-center gap-4">
          {isRatingLoading ? (
            <Skeleton className="h-8 w-32" />
          ) : (
            <div className="flex items-center">
              <StarRating 
                rating={averageRating} 
                size="lg" 
                showValue={true}
                className="mb-1" 
              />
              <span className="ml-2 text-gray-600">
                ({reviewCount} {reviewCount === 1 ? 'review' : 'reviews'})
              </span>
            </div>
          )}
        </div>
      </div>
      
      <Tabs defaultValue="read">
        <TabsList className="mb-6">
          <TabsTrigger value="read">Read Reviews</TabsTrigger>
          <TabsTrigger value="write">Write a Review</TabsTrigger>
        </TabsList>
        
        <TabsContent value="read">
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-40 w-full" />
              <Skeleton className="h-40 w-full" />
            </div>
          ) : isError ? (
            <div className="text-center py-8">
              <p className="text-red-500">
                There was an error loading reviews. Please try again later.
              </p>
            </div>
          ) : reviews?.length > 0 ? (
            <div className="space-y-4">
              {reviews.map((review: Review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 border rounded-lg bg-gray-50">
              <p className="text-gray-500">
                No reviews yet. Be the first to review {propFirm.name}!
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="write">
          <ReviewForm propFirmId={propFirm.id} />
        </TabsContent>
      </Tabs>
    </section>
  );
}