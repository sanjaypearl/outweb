import { Button } from "@/components/ui/button";

interface AccountSizeSelectorProps {
  accountSizes: number[];
  currentSize: number;
  onChange: (size: number) => void;
}

export default function AccountSizeSelector({ 
  accountSizes,
  currentSize,
  onChange
}: AccountSizeSelectorProps) {
  // Ensure we have at least some account sizes to show
  const sizes = accountSizes.length > 0 
    ? accountSizes 
    : [2500, 5000, 10000, 20000, 25000, 50000, 100000, 200000, 300000];
  
  return (
    <div className="hidden">
      {/* Account size selector has been removed per request, but keeping the functionality */}
      <div className="flex flex-wrap gap-3">
        {sizes.map((size) => (
          <button
            key={size}
            onClick={() => onChange(size)}
            className="hidden"
          >
            <span>${size >= 1000 ? (size / 1000).toLocaleString() : (size / 1000).toFixed(1)}K</span>
          </button>
        ))}
      </div>
    </div>
  );
}
