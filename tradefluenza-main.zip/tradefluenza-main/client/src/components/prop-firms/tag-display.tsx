import { Badge } from "@/components/ui/badge";
import { Tag } from "lucide-react";

interface TagDisplayProps {
  tags: string[];
  className?: string;
}

export default function TagDisplay({ tags = [], className = "" }: TagDisplayProps) {
  if (!tags || tags.length === 0) {
    return null;
  }
  
  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      {tags.map((tag, index) => (
        <Badge 
          key={index} 
          variant="secondary" 
          className="bg-primary/10 text-primary hover:bg-primary/20"
        >
          <Tag className="w-3 h-3 mr-1" /> {tag}
        </Badge>
      ))}
    </div>
  );
}