import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Link } from "wouter";
import { PropFirm } from "@shared/schema";
import StarRating from "./star-rating";
import Tag from "./tag";
import { useState } from "react";
import { Copy, CheckCircle2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface ComparisonCardProps {
  firm: PropFirm;
}

export default function ComparisonCard({ firm }: ComparisonCardProps) {
  // State for coupon code copy
  const [hasCopied, setHasCopied] = useState(false);
  const couponCode = "TFL";
  
  // Function to copy coupon code
  const copyToClipboard = () => {
    navigator.clipboard.writeText(couponCode).then(() => {
      setHasCopied(true);
      setTimeout(() => setHasCopied(false), 2000);
    });
  };
  
  // Fetch the rating data
  const { data: ratingData } = useQuery<{propFirmId: number, averageRating: number}>({
    queryKey: [`/api/prop-firms/${firm.id}/rating`],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!firm.id, // Only run the query if we have a firm ID
  });
  
  // Function to get program type badge color
  const getProgramTypeColor = (type: string) => {
    switch (type) {
      case "One-Phase": return "bg-gradient-to-r from-green-400 to-green-600 text-white";
      case "Two-Phase": return "bg-gradient-to-r from-blue-400 to-blue-600 text-white";
      case "Three-Phase": return "bg-gradient-to-r from-purple-400 to-purple-600 text-white";
      case "Rapid": return "bg-gradient-to-r from-purple-400 to-pink-500 text-white";
      case "Express": return "bg-gradient-to-r from-orange-400 to-orange-600 text-white";
      case "Instant Funding": return "bg-gradient-to-r from-pink-400 to-pink-600 text-white";
      default: return "bg-gradient-to-r from-gray-400 to-gray-600 text-white";
    }
  };
  
  // Get the average rating
  const averageRating = ratingData ? Number(ratingData.averageRating) : 0;
  
  const getAccountSizes = () => {
    if (!firm.accountSizes || !Array.isArray(firm.accountSizes)) return "N/A";
    return firm.accountSizes.map(size => 
      size >= 1000 ? `$${(size/1000)}K` : `$${size}`
    ).join(", ");
  };
  
  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:translate-y-[-2px]">
      {/* Card header with gradient stripe */}
      <div className="h-2 bg-gradient-to-r from-primary via-blue-500 to-purple-600"></div>
      
      {/* Card content */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center">
            <div className="flex-shrink-0 h-14 w-14 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg border border-gray-200 shadow-sm flex items-center justify-center overflow-hidden">
              {firm.logoUrl ? (
                <img 
                  className="h-12 w-12 object-contain" 
                  src={firm.logoUrl} 
                  alt={`${firm.name} Logo`} 
                />
              ) : (
                <span className="text-xl font-bold text-gray-600">
                  {firm.name.charAt(0)}
                </span>
              )}
            </div>
            <div className="ml-4">
              <Link href={`/prop-firms/${firm.id}`} className="block">
                <div className="text-xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 text-transparent bg-clip-text hover:from-primary hover:to-blue-700 transition-colors cursor-pointer">
                  {firm.name}
                </div>
              </Link>
              <div className="flex items-center mt-1">
                {averageRating > 0 ? (
                  <StarRating rating={averageRating} size="sm" />
                ) : (
                  <span className="text-sm text-gray-500 italic">No ratings yet</span>
                )}
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {firm.tags && Array.isArray(firm.tags) && firm.tags.length > 0 ? (
                  firm.tags.map((tag, index) => (
                    <Tag key={index} text={tag} size="sm" className="relative z-10 shadow" />
                  ))
                ) : (
                  // Default tag: if established within the last 2 years, mark as "New"
                  firm.established && parseInt(firm.established) >= 2023 && 
                  <Tag text="New" size="sm" className="relative z-10 shadow" />
                )}
              </div>
              <div className="text-sm text-gray-500 mt-2">
                {firm.established ? `Established ${firm.established}` : ''}
              </div>
            </div>
          </div>
          <span className={`px-3 py-1 text-sm font-medium ${getProgramTypeColor(firm.programType)} rounded-full shadow-sm`}>
            {firm.programType}
          </span>
        </div>
        
        {/* Coupon Code */}
        <div className="mb-3 bg-gradient-to-r from-primary/10 to-blue-500/10 rounded-lg p-3 border border-blue-100">
          <div className="text-xs text-gray-500 uppercase font-medium">Coupon Code</div>
          <div className="mt-2 flex items-center justify-between">
            <div className="rounded-md bg-white/70 border border-blue-200 px-3 py-1.5 shadow-sm">
              <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-600">{couponCode}</span>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={copyToClipboard}
                    className="text-gray-500 hover:text-primary transition-colors focus:outline-none"
                    aria-label="Copy coupon code"
                  >
                    {hasCopied ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Copy className="h-5 w-5" />
                    )}
                  </button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{hasCopied ? "Copied!" : "Copy code"}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        {/* Account sizes */}
        <div className="mb-5 bg-gray-50 rounded-lg p-3 border border-gray-100">
          <div className="text-xs text-gray-500 uppercase font-medium">Account Sizes</div>
          <div className="font-medium text-gray-800">{getAccountSizes()}</div>
        </div>
        
        {/* Trading parameters */}
        <div className="grid grid-cols-2 gap-5 mb-6">
          <div className="bg-gradient-to-br from-primary/5 to-blue-500/5 rounded-lg p-3">
            <div className="text-xs text-gray-500 uppercase font-medium">Profit Targets</div>
            <div className="mt-1 font-medium text-gray-900 whitespace-pre-line">
              {Array.isArray(firm.profitTargets) 
                ? firm.profitTargets.map((target) => `${target}%`).join(", ")
                : "N/A"
              }
            </div>
          </div>
          <div className="bg-gradient-to-br from-green-500/5 to-emerald-500/5 rounded-lg p-3">
            <div className="text-xs text-gray-500 uppercase font-medium">Profit Split</div>
            <div className="mt-1 font-bold text-lg text-emerald-600">{firm.profitSplit}%</div>
          </div>
          <div className="bg-gradient-to-br from-red-500/5 to-orange-500/5 rounded-lg p-3">
            <div className="text-xs text-gray-500 uppercase font-medium">Loss Limits</div>
            <div className="mt-1 text-sm">
              <span className="font-medium text-red-600">Daily: {firm.dailyLoss}%</span>
              <span className="mx-2">|</span>
              <span className="font-medium text-red-700">Max: {firm.maxLoss}%</span>
            </div>
          </div>
          <div className="bg-gradient-to-br from-purple-500/5 to-fuchsia-500/5 rounded-lg p-3">
            <div className="text-xs text-gray-500 uppercase font-medium">Payout Frequency</div>
            <div className="mt-1 font-medium text-purple-700">{firm.payoutFrequency || "N/A"}</div>
          </div>
        </div>
        
        {/* Price and CTA */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <div>
            <div className="text-sm text-gray-500 mb-1">Starting at</div>
            <div className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-700 text-transparent bg-clip-text">
              ${firm.pricing?.find(p => p.accountSize === firm.accountSizes?.[0])?.price || "N/A"}
            </div>
          </div>
          <Link href={`/prop-firms/${firm.id}`}>
            <Button className="bg-gradient-to-r from-primary to-blue-700 hover:from-primary/90 hover:to-blue-800 font-semibold text-white px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all transform hover:scale-105">
              Details
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
