import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

// Extend this with your custom validation
const reviewSchema = z.object({
  propFirmId: z.number(),
  userId: z.number().default(1), // Would come from auth in a real app
  rating: z.coerce.number().min(1).max(5),
  title: z.string().min(5, "Title must be at least 5 characters").max(100, "Title must not exceed 100 characters"),
  content: z.string().min(10, "Review must be at least 10 characters"),
  pros: z.array(z.string()).optional(),
  cons: z.array(z.string()).optional(),
  experience: z.string().optional(),
  tradingPeriod: z.string().optional(),
});

type ReviewFormData = z.infer<typeof reviewSchema>;

interface ReviewFormProps {
  propFirmId: number;
}

export default function ReviewForm({ propFirmId }: ReviewFormProps) {
  const queryClient = useQueryClient();
  const [prosInputs, setProsInputs] = React.useState<string[]>(['']);
  const [consInputs, setConsInputs] = React.useState<string[]>(['']);
  
  // Initialize the form
  const form = useForm<ReviewFormData>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      propFirmId,
      userId: 1, // Would be set from auth context
      rating: 5,
      title: "",
      content: "",
      pros: [],
      cons: [],
      experience: "",
      tradingPeriod: "",
    },
  });
  
  // Submit mutation
  const { mutate, isPending } = useMutation({
    mutationFn: (data: ReviewFormData) => {
      console.log("Submitting review data:", data);
      return apiRequest('POST', '/api/reviews', data);
    },
    onSuccess: (response) => {
      console.log("Review submission success:", response);
      
      // Invalidate queries to refetch data using correct query keys
      queryClient.invalidateQueries({ queryKey: [`/api/prop-firms/${propFirmId}/reviews`] });
      queryClient.invalidateQueries({ queryKey: [`/api/prop-firms/${propFirmId}/rating`] });
      
      // Directly force refetch the reviews
      queryClient.refetchQueries({ queryKey: [`/api/prop-firms/${propFirmId}/reviews`] });
      queryClient.refetchQueries({ queryKey: [`/api/prop-firms/${propFirmId}/rating`] });
      
      // Show success message
      toast({
        title: "Review submitted",
        description: "Thank you for sharing your experience!",
      });
      
      // Reset the form
      form.reset();
      setProsInputs(['']);
      setConsInputs(['']);
    },
    onError: (error) => {
      console.error("Review submission error:", error);
      toast({
        variant: "destructive",
        title: "Failed to submit review",
        description: error.message || "Please try again later",
      });
    }
  });

  // Handle form submission
  function onSubmit(data: ReviewFormData) {
    // Filter out empty pros and cons
    const filteredPros = prosInputs.filter(pro => pro.trim() !== '');
    const filteredCons = consInputs.filter(con => con.trim() !== '');
    
    // Update the data before submission
    data.pros = filteredPros.length > 0 ? filteredPros : undefined;
    data.cons = filteredCons.length > 0 ? filteredCons : undefined;
    
    mutate(data);
  }
  
  // Handle adding and updating pros/cons
  const handleProChange = (index: number, value: string) => {
    const newPros = [...prosInputs];
    newPros[index] = value;
    setProsInputs(newPros);
    
    // Add a new empty input if last one is being filled
    if (index === newPros.length - 1 && value.trim() !== '') {
      setProsInputs([...newPros, '']);
    }
  };
  
  const handleConChange = (index: number, value: string) => {
    const newCons = [...consInputs];
    newCons[index] = value;
    setConsInputs(newCons);
    
    // Add a new empty input if last one is being filled
    if (index === newCons.length - 1 && value.trim() !== '') {
      setConsInputs([...newCons, '']);
    }
  };
  
  return (
    <div className="bg-white p-6 rounded-lg border">
      <h3 className="text-xl font-semibold mb-4">Share Your Experience</h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Rating */}
          <FormField
            control={form.control}
            name="rating"
            render={({ field }) => (
              <FormItem className="space-y-1">
                <FormLabel>Rating</FormLabel>
                <FormControl>
                  <RadioGroup
                    defaultValue={field.value.toString()}
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    className="flex space-x-4"
                  >
                    {[1, 2, 3, 4, 5].map((value) => (
                      <FormItem key={value} className="flex items-center space-x-1">
                        <FormControl>
                          <RadioGroupItem value={value.toString()} />
                        </FormControl>
                        <FormLabel className="font-normal cursor-pointer">
                          {value}
                        </FormLabel>
                      </FormItem>
                    ))}
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {/* Title */}
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Review Title</FormLabel>
                <FormControl>
                  <Input placeholder="Summarize your experience" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {/* Content */}
          <FormField
            control={form.control}
            name="content"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Your Review</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Share details of your experience with this prop firm"
                    rows={4}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Separator />
          
          {/* Pros & Cons */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            {/* Pros */}
            <div>
              <h4 className="text-sm font-medium mb-2">Pros (Optional)</h4>
              {prosInputs.map((pro, index) => (
                <Input
                  key={`pro-${index}`}
                  className="mb-2"
                  placeholder={`Pro ${index + 1}`}
                  value={pro}
                  onChange={(e) => handleProChange(index, e.target.value)}
                />
              ))}
            </div>
            
            {/* Cons */}
            <div>
              <h4 className="text-sm font-medium mb-2">Cons (Optional)</h4>
              {consInputs.map((con, index) => (
                <Input
                  key={`con-${index}`}
                  className="mb-2"
                  placeholder={`Con ${index + 1}`}
                  value={con}
                  onChange={(e) => handleConChange(index, e.target.value)}
                />
              ))}
            </div>
          </div>
          
          <Separator />
          
          {/* Additional Info */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <FormField
              control={form.control}
              name="experience"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Experience Level (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Beginner, Intermediate, Expert" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="tradingPeriod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Trading Period (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., 3 months, 1 year" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full sm:w-auto"
            disabled={isPending}
          >
            {isPending ? "Submitting..." : "Submit Review"}
          </Button>
        </form>
      </Form>
    </div>
  );
}