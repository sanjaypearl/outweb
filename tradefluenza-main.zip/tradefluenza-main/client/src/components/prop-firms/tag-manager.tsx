import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { propFirmTags } from "@shared/schema";
import Tag from "./tag";
import { Input } from "@/components/ui/input";
import { PlusCircle, X, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TagManagerProps {
  propFirmId: number;
  currentTags: string[];
  className?: string;
}

export default function TagManager({ 
  propFirmId, 
  currentTags = [], 
  className = ""
}: TagManagerProps) {
  const [tags, setTags] = useState<string[]>(currentTags);
  const [isEditing, setIsEditing] = useState(false);
  const [newTag, setNewTag] = useState("");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Mutation for updating tags
  const { mutate: updateTags, isPending } = useMutation({
    mutationFn: async (tags: string[]) => {
      const response = await fetch(
        `/api/prop-firms/${propFirmId}/tags`, 
        { 
          method: "PATCH", 
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tags }) 
        }
      );
      if (!response.ok) {
        throw new Error('Failed to update tags');
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch the prop firm data
      queryClient.invalidateQueries({ queryKey: [`/api/prop-firms/${propFirmId}`] });
      
      toast({
        title: "Tags updated",
        description: "The prop firm tags have been updated successfully.",
        variant: "default",
      });
      
      setIsEditing(false);
    },
    onError: (error) => {
      console.error("Error updating tags:", error);
      toast({
        title: "Failed to update tags",
        description: "There was an error updating the prop firm tags.",
        variant: "destructive",
      });
    },
  });
  
  // Handle adding a new tag
  const handleAddTag = () => {
    if (!newTag.trim()) return;
    
    // Convert to title case for consistency
    const formattedTag = newTag.trim().replace(/\w\S*/g, (txt) => {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
    
    // Don't add if already exists
    if (tags.includes(formattedTag)) {
      setNewTag("");
      return;
    }
    
    setTags([...tags, formattedTag]);
    setNewTag("");
  };
  
  // Handle removing a tag
  const handleRemoveTag = (index: number) => {
    const newTags = [...tags];
    newTags.splice(index, 1);
    setTags(newTags);
  };
  
  // Handle saving the tags
  const handleSave = () => {
    updateTags(tags);
  };
  
  // Handle canceling the edit
  const handleCancel = () => {
    setTags(currentTags);
    setIsEditing(false);
    setNewTag("");
  };
  
  // Handle selecting a predefined tag
  const handleSelectTag = (tag: string) => {
    if (tags.includes(tag)) return;
    setTags([...tags, tag]);
  };
  
  return (
    <div className={`${className}`}>
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-sm font-medium text-gray-700">Tags</h3>
        {!isEditing ? (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setIsEditing(true)}
            className="h-8 px-2 text-xs"
          >
            Edit Tags
          </Button>
        ) : (
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleCancel}
              className="h-8 px-2 text-xs"
              disabled={isPending}
            >
              Cancel
            </Button>
            <Button 
              variant="default" 
              size="sm" 
              onClick={handleSave}
              className="h-8 px-3 text-xs"
              disabled={isPending}
            >
              {isPending ? "Saving..." : "Save"}
            </Button>
          </div>
        )}
      </div>
      
      {/* Display tags */}
      <div className="flex flex-wrap gap-2 mb-4">
        {tags.length > 0 ? (
          tags.map((tag, index) => (
            <div key={index} className="flex items-center">
              <Tag text={tag} />
              {isEditing && (
                <button 
                  className="ml-1 text-gray-400 hover:text-red-500 transition-colors"
                  onClick={() => handleRemoveTag(index)}
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
          ))
        ) : (
          <p className="text-sm text-gray-500 italic">No tags added yet</p>
        )}
      </div>
      
      {/* Tag editor */}
      {isEditing && (
        <div className="space-y-3 bg-gray-50 p-3 rounded-lg border border-gray-200">
          <div className="flex gap-2">
            <Input
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              placeholder="Add a custom tag..."
              className="h-8 text-sm"
              onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={handleAddTag}
              disabled={!newTag.trim()}
              className="h-8"
            >
              <PlusCircle className="h-4 w-4 mr-1" />
              Add
            </Button>
          </div>
          
          <div>
            <p className="text-xs font-medium text-gray-500 mb-2">Suggested Tags:</p>
            <div className="flex flex-wrap gap-2">
              {propFirmTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleSelectTag(tag)}
                  disabled={tags.includes(tag)}
                  className={`px-2 py-1 rounded-full text-xs border transition-colors ${
                    tags.includes(tag)
                      ? "bg-primary/10 text-primary border-primary/20 cursor-not-allowed"
                      : "border-gray-200 hover:border-primary/50 hover:bg-primary/5"
                  }`}
                >
                  {tags.includes(tag) && <Check className="inline h-3 w-3 mr-1" />}
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}