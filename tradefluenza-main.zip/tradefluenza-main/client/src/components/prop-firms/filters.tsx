import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { programTypes, payoutFrequencies, sortFields, sortDirections } from "@shared/schema";
import { useState, useEffect } from "react";

interface FiltersProps {
  programType: string | undefined;
  profitSplit: string | undefined;
  payoutFrequency: string | undefined;
  priceRange: [number, number] | undefined;
  sortBy: string;
  onChange: (
    type: "programType" | "profitSplit" | "payoutFrequency" | "priceRange" | "sort", 
    value: string | undefined | [number, number]
  ) => void;
}

export default function Filters({
  programType,
  profitSplit,
  payoutFrequency,
  priceRange,
  sortBy,
  onChange
}: FiltersProps) {
  const profitSplitOptions = ["50+", "70+", "80+", "90+"];
  
  // Define min/max price values for slider
  const MIN_PRICE = 50;
  const MAX_PRICE = 1500;
  const DEFAULT_PRICE_RANGE: [number, number] = [MIN_PRICE, MAX_PRICE];
  
  // Local state for price slider
  const [sliderValue, setSliderValue] = useState<[number, number]>(priceRange || DEFAULT_PRICE_RANGE);
  const [displayPriceRange, setDisplayPriceRange] = useState<[number, number]>(priceRange || DEFAULT_PRICE_RANGE);
  
  // Format price for display
  const formatPrice = (price: number): string => {
    return price >= 1000 ? `$${price/1000}K` : `$${price}`;
  };
  
  // Handle slider change with debounce
  const handlePriceChange = (value: number[]) => {
    const newRange = value as [number, number];
    setSliderValue(newRange);
    setDisplayPriceRange(newRange);
    
    // Debounce the actual filter change to avoid too many requests
    const timer = setTimeout(() => {
      // Only filter if the range is not the default full range
      if (newRange[0] > MIN_PRICE || newRange[1] < MAX_PRICE) {
        onChange("priceRange", newRange);
      } else {
        // If it's the full range, treat it as no filter
        onChange("priceRange", undefined);
      }
    }, 300);
    
    return () => clearTimeout(timer);
  };
  
  const handleProgramTypeChange = (value: string) => {
    onChange("programType", value === "all" ? undefined : value);
  };
  
  const handleProfitSplitChange = (value: string) => {
    onChange("profitSplit", value === "all" ? undefined : value);
  };
  
  const handlePayoutFrequencyChange = (value: string) => {
    onChange("payoutFrequency", value === "all" ? undefined : value);
  };
  
  const handleSortChange = (value: string) => {
    onChange("sort", value);
  };
  
  // Create sort options combining field and direction
  const sortOptions = [
    { value: "price-asc", label: "Price: Low to High", field: "price", direction: "asc" },
    { value: "price-desc", label: "Price: High to Low", field: "price", direction: "desc" },
    { value: "profitSplit-desc", label: "Profit Split: High to Low", field: "profitSplit", direction: "desc" },
    { value: "name-asc", label: "Name: A to Z", field: "name", direction: "asc" }
  ];
  
  return (
    <div className="futuristic-card p-6 mb-8 bg-gradient-to-r from-white via-gray-50 to-white">
      <h2 className="text-xl font-semibold mb-4 text-gray-700">Filter & Sort</h2>
      
      {/* Price Range Filter */}
      <div className="mb-6 bg-gradient-to-r from-indigo-50 to-purple-50 p-4 rounded-lg border border-indigo-100 shadow-sm">
        <div className="flex justify-between items-center mb-2">
          <label className="text-sm font-medium text-gray-700">Price Range</label>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 bg-white px-2 py-1 rounded-md shadow-sm border border-gray-200">
              {formatPrice(displayPriceRange[0])}
            </span>
            <span className="text-xs text-gray-500">to</span>
            <span className="text-xs text-gray-500 bg-white px-2 py-1 rounded-md shadow-sm border border-gray-200">
              {formatPrice(displayPriceRange[1])}
            </span>
          </div>
        </div>
        
        <div className="pt-3 px-2">
          <Slider
            defaultValue={sliderValue}
            value={sliderValue}
            min={MIN_PRICE}
            max={MAX_PRICE}
            step={50}
            onValueChange={handlePriceChange}
            className="cursor-pointer"
          />
        </div>
        
        <div className="flex justify-between mt-1">
          <span className="text-xs text-gray-400">{formatPrice(MIN_PRICE)}</span>
          <span className="text-xs text-gray-400">{formatPrice(MAX_PRICE)}</span>
        </div>
      </div>
      
      <div className="flex flex-col lg:flex-row justify-between gap-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full lg:w-auto">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-500">Program Type</label>
            <Select value={programType || "all"} onValueChange={handleProgramTypeChange}>
              <SelectTrigger className="border border-gray-200 hover:border-primary/40 transition-colors rounded-xl shadow-sm">
                <SelectValue placeholder="Program Type" />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                <SelectItem value="all">All Program Types</SelectItem>
                {programTypes.map((type) => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-500">Profit Split</label>
            <Select value={profitSplit || "all"} onValueChange={handleProfitSplitChange}>
              <SelectTrigger className="border border-gray-200 hover:border-primary/40 transition-colors rounded-xl shadow-sm">
                <SelectValue placeholder="Profit Split" />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                <SelectItem value="all">All Profit Splits</SelectItem>
                {profitSplitOptions.map((split) => (
                  <SelectItem key={split} value={split}>{split}%</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-500">Payout Frequency</label>
            <Select value={payoutFrequency || "all"} onValueChange={handlePayoutFrequencyChange}>
              <SelectTrigger className="border border-gray-200 hover:border-primary/40 transition-colors rounded-xl shadow-sm">
                <SelectValue placeholder="Payout Frequency" />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                <SelectItem value="all">All Frequencies</SelectItem>
                {payoutFrequencies.map((frequency) => (
                  <SelectItem key={frequency} value={frequency}>{frequency}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="space-y-2 w-full lg:w-auto">
            <label className="text-sm font-medium text-gray-500">Sort Results</label>
            <Select value={sortBy} onValueChange={handleSortChange}>
              <SelectTrigger className="border border-gray-200 hover:border-primary/40 transition-colors rounded-xl shadow-sm w-full">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}
