import React from 'react';
import { ArrowRight, Globe, Clock } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface TradingFirmProps {
  firm: {
    id: number;
    name: string;
    websiteUrl: string;
    logoUrl: string;
    couponCode: string | null;
    rank: string;
    reviewCount: number | null;
    country: string;
    yearsInOperation: number;
    assets: string[];
    platforms: string[];
    maxAllocations: number;
    promo: string | null;
    promoDiscount: number;
    favoriteCount: number | null;
    position: number | null;
  };
}

const TradingFirmCard: React.FC<TradingFirmProps> = ({ firm }) => {
  const { toast } = useToast();
  return (
    <div 
      className="bg-gradient-to-b from-indigo-800 to-purple-900 rounded-xl overflow-hidden shadow-lg border border-indigo-600/40 hover:border-indigo-500/70 transition-all duration-300"
    >
      {/* Firm Header */}
      <div className="p-4 flex items-center space-x-3 border-b border-indigo-700/50">
        {firm.logoUrl ? (
          <div className="h-14 w-14 flex items-center justify-center bg-purple-600 rounded-lg shadow-lg">
            <img 
              src={firm.logoUrl} 
              alt={firm.name} 
              className="h-8 w-8 object-contain"
            />
          </div>
        ) : (
          <div className="h-14 w-14 flex items-center justify-center bg-purple-600 rounded-lg shadow-lg">
            <span className="text-2xl font-bold text-white">{firm.name.charAt(0)}</span>
          </div>
        )}
        <div className="flex flex-col">
          <div className="font-semibold text-white text-lg">{firm.name}</div>
          <div className="flex items-center mt-1">
            <div className="w-2 h-2 rounded-full bg-blue-300 mr-2"></div>
            <span className="text-xs text-blue-200">Est. {firm.yearsInOperation}</span>
          </div>
        </div>
      </div>

      {/* Firm Details */}
      <div className="p-4">
        {/* Rating & Reviews */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <span className="text-white font-semibold mr-2 text-base">{firm.rank}</span>
            <div className="flex">
              {Array.from({ length: Math.floor(Number(firm.rank)) }).map((_, i) => (
                <svg 
                  key={i}
                  className="h-4 w-4 text-yellow-300 fill-current" 
                  viewBox="0 0 24 24"
                >
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
              ))}
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-indigo-700 text-white text-xs font-medium">
            {firm.reviewCount || 0} reviews
          </span>
        </div>

        {/* Location & Max Allocation */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div>
            <div className="text-xs text-blue-200 font-medium mb-1">Country</div>
            <div className="text-white flex items-center">
              <Globe className="h-4 w-4 text-blue-300 mr-1" />
              {firm.country}
            </div>
          </div>
          <div>
            <div className="text-xs text-blue-200 font-medium mb-1">Max Allocation</div>
            <div className="text-white font-medium">${(firm.maxAllocations).toLocaleString()}</div>
          </div>
        </div>

        {/* Assets & Platforms */}
        <div className="mb-3">
          <div className="text-xs text-blue-200 font-medium mb-1">Assets</div>
          <div className="flex flex-wrap gap-1 mb-2">
            {firm.assets && firm.assets.map((asset, index) => (
              <span 
                key={index} 
                className="bg-indigo-700 text-white px-2 py-1 rounded-md text-xs font-medium"
              >
                {asset}
              </span>
            ))}
          </div>
          <div className="text-xs text-blue-200 font-medium mb-1">Platforms</div>
          <div className="flex flex-wrap gap-1">
            {firm.platforms && firm.platforms.map((platform, index) => (
              <span 
                key={index} 
                className="bg-purple-700 text-white px-2 py-1 rounded-md text-xs font-medium"
              >
                {platform}
              </span>
            ))}
          </div>
        </div>
      </div>
      
      {/* Card Footer with Promo & Action */}
      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-indigo-800 to-purple-800 border-t border-indigo-600/50">
        {firm.promoDiscount ? (
          <div className="flex items-center">
            <div 
              className="rounded-lg overflow-hidden shadow-lg flex h-10 cursor-pointer group transition-all duration-200"
              onClick={() => {
                if (firm.couponCode) {
                  navigator.clipboard.writeText(firm.couponCode);
                  toast({
                    title: "Code copied!",
                    description: `${firm.couponCode} has been copied to clipboard`,
                    variant: "default",
                  });
                }
              }}
              title="Click to copy code"
            >
              <div className="bg-purple-600 h-full flex items-center justify-center px-3">
                <div className="text-white font-bold text-sm">{firm.promoDiscount}% OFF</div>
              </div>
              <div className="bg-black h-full flex items-center justify-center px-3 group-hover:bg-gray-900 transition-colors">
                <div className="text-white text-xs font-semibold flex items-center">
                  {firm.couponCode || 'CODE'}
                  <svg className="h-3 w-3 ml-1 text-white opacity-70 group-hover:opacity-100" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        ) : firm.promo ? (
          <div className="rounded-lg bg-gradient-to-r from-blue-700 to-indigo-700 text-white py-2 px-3 text-xs font-medium flex items-center justify-center border border-blue-500/50">
            {firm.promo}
          </div>
        ) : (
          <div className="text-blue-200 text-xs">No Promotion</div>
        )}
        
        <a 
          href={firm.websiteUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className="h-8 py-1 px-3 rounded-md bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium text-sm flex items-center justify-center whitespace-nowrap transition-all duration-200 shadow-md hover:shadow-xl"
        >
          Visit
          <ArrowRight className="ml-1 h-3.5 w-3.5 flex-shrink-0" />
        </a>
      </div>
    </div>
  );
};

export default TradingFirmCard;