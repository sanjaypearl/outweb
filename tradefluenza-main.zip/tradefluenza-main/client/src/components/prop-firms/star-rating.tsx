import React from "react";
import { Star, StarHalf } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  rating: number;
  size?: "sm" | "md" | "lg";
  showValue?: boolean;
  className?: string;
}

export default function StarRating({ 
  rating, 
  size = "md", 
  showValue = false, 
  className 
}: StarRatingProps) {
  // Ensure rating is a number and convert to nearest half-star value
  const numericRating = typeof rating === 'number' ? rating : 0;
  const roundedRating = Math.round(numericRating * 2) / 2;
  
  // Size settings
  const sizeMap = {
    sm: { star: 16, text: 'text-xs' },
    md: { star: 20, text: 'text-sm' },
    lg: { star: 24, text: 'text-base' }
  };
  
  const { star: starSize, text: textSize } = sizeMap[size];
  
  // Generate stars
  const stars = [];
  const totalStars = 5;
  
  for (let i = 1; i <= totalStars; i++) {
    if (i <= roundedRating) {
      // Full star
      stars.push(
        <Star 
          key={i} 
          className="fill-yellow-400 text-yellow-400" 
          size={starSize} 
        />
      );
    } else if (i - 0.5 === roundedRating) {
      // Half star
      stars.push(
        <StarHalf 
          key={i} 
          className="fill-yellow-400 text-yellow-400" 
          size={starSize} 
        />
      );
    } else {
      // Empty star
      stars.push(
        <Star 
          key={i} 
          className="text-gray-300" 
          size={starSize} 
        />
      );
    }
  }

  return (
    <div className={cn("flex items-center", className)}>
      <div className="flex">
        {stars}
      </div>
      {showValue && (
        <span className={cn("ml-1 font-medium", textSize)}>
          {numericRating.toFixed(1)}
        </span>
      )}
    </div>
  );
}