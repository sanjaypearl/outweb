import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, Copy, CheckCircle2, Award } from "lucide-react";
import { PropFirm } from "@shared/schema";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Link } from "wouter";

interface ComparisonTableProps {
  propFirms: PropFirm[];
}

export default function ComparisonTable({ propFirms }: ComparisonTableProps) {
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [copiedFirmId, setCopiedFirmId] = useState<number | null>(null);
  
  // Function to copy coupon code
  const copyToClipboard = (firmId: number, couponCode: string, firmName?: string) => {
    navigator.clipboard.writeText(couponCode).then(() => {
      setCopiedFirmId(firmId);
      setTimeout(() => setCopiedFirmId(null), 2000);
      
      // Track event in Google Analytics
      try {
        // Use dynamic import to avoid compile-time dependency
        import('@/lib/analytics').then(analytics => {
          analytics.trackCouponCopy(couponCode, firmName || `Firm ID ${firmId}`);
        }).catch(err => {
          console.error('Failed to load analytics', err);
        });
      } catch (error) {
        console.error('Error tracking coupon copy:', error);
      }
    });
  };
  
  // Function to determine discount percentage from the database
  const getDiscountPercentage = (firm: any): number => {
    // Use the discount percentage directly from the database
    // Fall back to a default of 15% if it's not available
    return firm.discountPercentage || 15;
  };
  
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };
  
  const renderSortIcon = (field: string) => {
    if (sortField !== field) {
      return <ArrowUpDown className="ml-1 h-4 w-4 text-white" />;
    }
    
    return sortDirection === "asc" ? (
      <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
      </svg>
    ) : (
      <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
      </svg>
    );
  };
  
  // Function to get program type badge color
  const getProgramTypeColor = (type: string) => {
    switch (type) {
      case "One-Phase": return "bg-gradient-to-r from-green-400 to-green-600 text-white";
      case "Two-Phase": return "bg-gradient-to-r from-blue-400 to-blue-600 text-white";
      case "Three-Phase": return "bg-gradient-to-r from-purple-400 to-purple-600 text-white";
      case "Rapid": return "bg-gradient-to-r from-purple-400 to-pink-500 text-white";
      case "Express": return "bg-gradient-to-r from-orange-400 to-orange-600 text-white";
      case "Instant Funding": return "bg-gradient-to-r from-pink-400 to-pink-600 text-white";
      default: return "bg-gradient-to-r from-gray-400 to-gray-600 text-white";
    }
  };
  
  return (
    <div className="mb-12 rounded-2xl shadow-xl overflow-hidden transform transition-all duration-300 hover:shadow-2xl">
      <div className="relative bg-gradient-to-r from-indigo-800 via-purple-800 to-indigo-900 p-8 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.2)_0,_transparent_2px)] bg-[length:12px_12px]"></div>
        <div className="absolute -left-20 -top-20 w-40 h-40 rounded-full bg-purple-500/20 blur-3xl"></div>
        <div className="absolute -right-20 -bottom-20 w-40 h-40 rounded-full bg-indigo-500/20 blur-3xl"></div>
        
        <div className="relative z-10 text-center">
          <div className="inline-flex items-center justify-center mb-3 bg-white/10 backdrop-blur-sm px-4 py-1.5 rounded-full">
            <Award className="mr-2 h-5 w-5 text-yellow-300" /> 
            <span className="text-white/90 text-sm font-semibold">Expert Selection</span>
          </div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-white via-gray-100 to-gray-200 text-transparent bg-clip-text">
            Top-Rated Prop Trading Firms
          </h2>
          <p className="text-indigo-100 mt-2 max-w-2xl mx-auto">
            Compare features, pricing, and find the perfect prop firm for your trading style
          </p>
        </div>
      </div>
      
      <div className="overflow-x-auto w-full">
        <table className="comparison-table w-full table-fixed border-collapse">
          <thead className="sticky top-0">
            <tr className="bg-gradient-to-r from-indigo-700 via-purple-700 to-indigo-700 border-b border-indigo-800">
              <th scope="col" className="px-4 py-3 text-center w-[16%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex items-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("name")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white">FIRM NAME</span>
                  <div className="ml-1 p-1 rounded bg-white/10">{renderSortIcon("name")}</div>
                </button>
              </th>
              <th scope="col" className="px-2 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex flex-col items-center justify-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("accountSizes")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">ACC.</span>
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">SIZE</span>
                  <div className="mt-1 p-1 rounded bg-white/10">{renderSortIcon("accountSizes")}</div>
                </button>
              </th>
              <th scope="col" className="px-2 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex flex-col items-center justify-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("programType")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">PROGRAM</span>
                  <div className="mt-1 p-1 rounded bg-white/10">{renderSortIcon("programType")}</div>
                </button>
              </th>
              <th scope="col" className="px-2 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex flex-col items-center justify-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("profitTargets")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">TARGETS</span>
                  <div className="mt-1 p-1 rounded bg-white/10">{renderSortIcon("profitTargets")}</div>
                </button>
              </th>
              <th scope="col" className="px-2 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex flex-col items-center justify-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("dailyLoss")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">DAILY</span>
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">LOSS</span>
                  <div className="mt-1 p-1 rounded bg-white/10">{renderSortIcon("dailyLoss")}</div>
                </button>
              </th>
              <th scope="col" className="px-2 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex flex-col items-center justify-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("maxLoss")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">MAX</span>
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">LOSS</span>
                  <div className="mt-1 p-1 rounded bg-white/10">{renderSortIcon("maxLoss")}</div>
                </button>
              </th>
              <th scope="col" className="px-2 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex flex-col items-center justify-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("profitSplit")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">PROFIT</span>
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">SPLIT</span>
                  <div className="mt-1 p-1 rounded bg-white/10">{renderSortIcon("profitSplit")}</div>
                </button>
              </th>
              <th scope="col" className="px-2 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex flex-col items-center justify-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("payoutFrequency")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">PAYOUT</span>
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">FREQU</span>
                  <span className="text-xs uppercase tracking-wider font-bold text-white text-center">ENT</span>
                  <div className="mt-1 p-1 rounded bg-white/10">{renderSortIcon("payoutFrequency")}</div>
                </button>
              </th>
              <th scope="col" className="px-3 py-3 text-center w-[8%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex items-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("price")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white">PRICE</span>
                  <div className="ml-1 p-1 rounded bg-white/10">{renderSortIcon("price")}</div>
                </button>
              </th>
              <th scope="col" className="px-3 py-3 text-center w-[10%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <button 
                  className="flex items-center font-medium focus:outline-none relative z-10"
                  onClick={() => handleSort("couponCode")}
                >
                  <span className="text-xs uppercase tracking-wider font-bold text-white">COUPON CODE</span>
                  <div className="ml-1 p-1 rounded bg-white/10">{renderSortIcon("couponCode")}</div>
                </button>
              </th>
              <th scope="col" className="px-3 py-3 text-center w-[10%] relative group">
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <span className="text-xs uppercase tracking-wider font-bold text-white relative z-10">ACTIONS</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {propFirms.map((firm, index) => (
              <tr 
                key={firm.id}
                className="hover:bg-indigo-50/40 transition-colors duration-150 relative group"
              >
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Link to={`/prop-firms/${firm.id}`} className="flex-shrink-0 h-12 w-12 bg-white rounded-xl flex items-center justify-center shadow-md border border-indigo-100 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                      {firm.logoUrl ? (
                        <img 
                          className="h-10 w-10 object-contain" 
                          src={firm.logoUrl} 
                          alt={`${firm.name} Logo`} 
                        />
                      ) : (
                        <div className="h-full w-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                          <span className="text-lg font-bold text-white">
                            {firm.name.charAt(0)}
                          </span>
                        </div>
                      )}
                    </Link>
                    <div className="ml-4">
                      <Link to={`/prop-firms/${firm.id}`} className="text-sm font-bold text-gray-900 mb-0.5 hover:text-indigo-600 transition-colors cursor-pointer">{firm.name}</Link>
                      <div className="text-xs text-gray-500 flex items-center">
                        {firm.established && (
                          <>
                            <span className="inline-block w-1.5 h-1.5 rounded-full bg-indigo-400 mr-1.5"></span>
                            <span>Est. {firm.established}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  {Array.isArray(firm.accountSizes) && firm.accountSizes.length > 0 ? (
                    <div className="flex flex-col gap-1">
                      {firm.accountSizes.map((size, i) => (
                        <div key={i} className="text-sm font-medium text-gray-800 flex items-center justify-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-400 mr-1.5"></span>
                          ${size.toLocaleString()}
                        </div>
                      )).slice(0, 3)}
                      {firm.accountSizes.length > 3 && (
                        <div className="text-xs text-gray-500 mt-1">+{firm.accountSizes.length - 3} more</div>
                      )}
                    </div>
                  ) : (
                    <div className="text-sm font-medium text-gray-800">N/A</div>
                  )}
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  <span className={`inline-flex px-2.5 py-1 text-xs font-medium ${getProgramTypeColor(firm.programType)} rounded-full shadow-sm`}>
                    {firm.programType}
                  </span>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  {Array.isArray(firm.profitTargets) 
                    ? firm.profitTargets.map((target, i) => (
                        <div key={i} className="text-sm font-medium text-gray-800 flex items-center justify-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mr-1.5"></span>
                          {target}%
                        </div>
                      ))
                    : <div className="text-sm font-medium text-gray-800 flex items-center justify-center">N/A</div>
                  }
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  <div className="text-sm font-medium text-gray-800 flex items-center justify-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mr-1.5"></span>
                    {firm.dailyLoss}%
                  </div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  <div className="text-sm font-medium text-gray-800 flex items-center justify-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400 mr-1.5"></span>
                    {firm.maxLoss}%
                  </div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  <div className="text-sm font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text flex items-center justify-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-400 mr-1.5"></span>
                    {firm.profitSplit}%
                  </div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  <div className="text-sm font-medium text-gray-800">{firm.payoutFrequency}</div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  <div className="text-lg font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text">
                    ${firm.pricing?.find(p => p.accountSize === firm.accountSizes?.[0])?.price || "N/A"}
                  </div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center">
                  <div className="flex flex-col items-center justify-center">
                    {/* Single coupon badge - pill shaped with gradient background */}
                    <div className="relative">
                      {/* Pill shaped container */}
                      <div className="rounded-2xl overflow-hidden" style={{ filter: "drop-shadow(0px 2px 4px rgba(0,0,0,0.15))" }}>
                        {/* Top section with discount % */}
                        <div className="px-4 py-1 text-center relative overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-fuchsia-600 bg-size-200 animate-gradient-slow"></div>
                          <span className="text-white font-bold text-base relative z-10">
                            {getDiscountPercentage(firm)}% OFF
                          </span>
                        </div>
                        
                        {/* Bottom section with coupon code */}
                        <div className="bg-black px-3 py-1 text-center flex items-center justify-center">
                          <span className="text-white font-bold mr-1">{firm.couponCode || "TFL"}</span>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <button
                                  onClick={() => copyToClipboard(firm.id, firm.couponCode || "TFL", firm.name)}
                                  className="text-white hover:text-purple-100 transition-colors focus:outline-none"
                                  aria-label="Copy coupon code"
                                >
                                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-gray-300">
                                    <rect x="8" y="8" width="12" height="12" rx="2" stroke="currentColor" strokeWidth="2" />
                                    <path d="M16 8V6C16 4.89543 15.1046 4 14 4H6C4.89543 4 4 4.89543 4 6V14C4 15.1046 4.89543 16 6 16H8" stroke="currentColor" strokeWidth="2" />
                                  </svg>
                                </button>
                              </TooltipTrigger>
                              <TooltipContent className="bg-gray-800 text-white border-0 px-3 py-1.5 rounded-lg">
                                <p>{copiedFirmId === firm.id ? "Copied!" : "Copy code"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>
                    </div>
                    
                    {/* Explainer text */}
                    <div className="text-xs text-gray-500 mt-1.5">
                      Use code for discount
                    </div>
                  </div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-sm font-medium text-center">
                  <a href={firm.websiteUrl || "#"} target="_blank" rel="noopener noreferrer">
                    <button className="relative px-4 py-2 rounded-xl font-semibold text-white shadow-lg overflow-hidden group-hover:scale-105 transition-transform duration-200">
                      <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 bg-size-200 animate-gradient-slow"></div>
                      <span className="relative flex items-center justify-center">
                        Buy Now
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                      </span>
                    </button>
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
