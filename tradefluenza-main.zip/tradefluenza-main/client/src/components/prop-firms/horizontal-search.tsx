import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Search, Loader2 } from "lucide-react";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";

// Define types for filter options
interface FilterOptions {
  programTypes: string[];
  profitTargets: number[];
  dailyLosses: number[];
  maxLosses: number[];
  profitSplits: number[];
  payoutFrequencies: string[];
}

interface HorizontalSearchProps {
  defaultProgramType?: string;
  defaultProfitTarget?: number;
  defaultDailyLoss?: number; 
  defaultMaxLoss?: number;
  defaultProfitSplit?: number;
  accountSize: number;
}

// Format filter option with appropriate suffix
const formatFilterText = (value: string, type: string): string => {
  if (value === "any") return "Any";
  
  if (type === "target" || type === "loss") {
    return `${value}% or lower`;
  }
  
  if (type === "split") {
    return `${value}% or higher`;
  }
  
  return value;
};

export default function HorizontalSearch({
  defaultProgramType = "any",
  defaultProfitTarget,
  defaultDailyLoss,
  defaultMaxLoss,
  defaultProfitSplit,
  accountSize = 0,
}: HorizontalSearchProps) {
  // Navigation
  const [, setLocation] = useLocation();
  
  // Filter states
  const [programType, setProgramType] = useState(defaultProgramType);
  const [profitTarget, setProfitTarget] = useState(defaultProfitTarget?.toString() || "any");
  const [dailyLoss, setDailyLoss] = useState(defaultDailyLoss?.toString() || "any");
  const [maxLoss, setMaxLoss] = useState(defaultMaxLoss?.toString() || "any");
  const [profitSplit, setProfitSplit] = useState(defaultProfitSplit?.toString() || "any");
  
  // Fetch filter options
  const { data: filterOptions, isLoading } = useQuery<FilterOptions>({
    queryKey: ['/api/prop-firms/filter-options'],
  });
  
  // Update filter states when defaults change
  useEffect(() => {
    setProgramType(defaultProgramType || "any");
    setProfitTarget(defaultProfitTarget?.toString() || "any");
    setDailyLoss(defaultDailyLoss?.toString() || "any");
    setMaxLoss(defaultMaxLoss?.toString() || "any");
    setProfitSplit(defaultProfitSplit?.toString() || "any");
  }, [defaultProgramType, defaultProfitTarget, defaultDailyLoss, defaultMaxLoss, defaultProfitSplit]);
  
  // Apply filters and navigate to results
  const applyFilters = () => {
    const params = new URLSearchParams();
    
    // Always include account size
    params.set("accountSize", accountSize.toString());
    
    // Only add non-"any" filters
    if (programType !== "any") params.set("programType", programType);
    if (profitTarget !== "any") params.set("profitTarget", profitTarget);
    if (dailyLoss !== "any") params.set("dailyLoss", dailyLoss);
    if (maxLoss !== "any") params.set("maxLoss", maxLoss);
    if (profitSplit !== "any") params.set("profitSplit", profitSplit);
    
    // Navigate to the filtered results
    setLocation(`/prop-firms?${params.toString()}`);
  };
  
  // Loading state
  if (isLoading) {
    return (
      <div className="w-full bg-white rounded-xl shadow-md border border-gray-100 p-6 mb-8 flex justify-center items-center">
        <Loader2 className="h-6 w-6 animate-spin text-indigo-600 mr-3" />
        <span className="text-gray-500">Loading filter options...</span>
      </div>
    );
  }
  
  return (
    <div className="relative w-full bg-gradient-to-br from-white to-indigo-50/30 rounded-2xl shadow-xl border border-indigo-100/60 p-6 mb-10 overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-blue-500"></div>
      <div className="absolute -right-24 -top-24 w-48 h-48 rounded-full bg-gradient-to-br from-indigo-200/20 to-purple-300/20 blur-3xl"></div>
      <div className="absolute -left-24 -bottom-24 w-48 h-48 rounded-full bg-gradient-to-tr from-purple-300/20 to-indigo-200/20 blur-3xl"></div>
      
      {/* Header */}
      <div className="mb-6 flex items-center">
        <div className="p-2 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 shadow-lg mr-4">
          <Search className="h-5 w-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 text-transparent bg-clip-text">Advanced Search</h3>
          <p className="text-sm text-gray-500">Filter prop firms to find the perfect match for your trading style</p>
        </div>
      </div>
      
      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 relative z-10">
        {/* Program Type */}
        <div className="space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-indigo-700 flex items-center">
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mr-1.5"></div>
            Program Type
          </div>
          <Select
            value={programType}
            onValueChange={(value) => {
              setProgramType(value);
              setTimeout(applyFilters, 100);
            }}
          >
            <SelectTrigger className="h-11 rounded-xl bg-white/80 backdrop-blur-sm border border-indigo-100 hover:border-indigo-300 shadow-sm">
              <SelectValue placeholder="Any Type" />
            </SelectTrigger>
            <SelectContent 
              position="popper" 
              align="start" 
              sideOffset={5}
              className="z-50 max-h-[300px]"
            >
              <SelectItem value="any">Any Type</SelectItem>
              {filterOptions?.programTypes?.map((type) => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Profit Target */}
        <div className="space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-purple-700 flex items-center">
            <div className="w-1.5 h-1.5 rounded-full bg-purple-600 mr-1.5"></div>
            Profit Target
          </div>
          <Select 
            value={profitTarget}
            onValueChange={(value) => {
              setProfitTarget(value);
              setTimeout(applyFilters, 100);
            }}
          >
            <SelectTrigger className="h-11 rounded-xl bg-white/80 backdrop-blur-sm border border-purple-100 hover:border-purple-300 shadow-sm">
              <SelectValue placeholder="Any Target" />
            </SelectTrigger>
            <SelectContent 
              position="popper" 
              align="start" 
              sideOffset={5}
              className="z-50 max-h-[300px]"
            >
              <SelectItem value="any">Any Target</SelectItem>
              {filterOptions?.profitTargets?.map((target) => (
                <SelectItem key={target} value={target.toString()}>
                  {formatFilterText(target.toString(), "target")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Daily Loss */}
        <div className="space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-blue-700 flex items-center">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-1.5"></div>
            Daily Loss
          </div>
          <Select 
            value={dailyLoss}
            onValueChange={(value) => {
              setDailyLoss(value);
              setTimeout(applyFilters, 100);
            }}
          >
            <SelectTrigger className="h-11 rounded-xl bg-white/80 backdrop-blur-sm border border-blue-100 hover:border-blue-300 shadow-sm">
              <SelectValue placeholder="Any Limit" />
            </SelectTrigger>
            <SelectContent 
              position="popper" 
              align="start" 
              sideOffset={5}
              className="z-50 max-h-[300px]"
            >
              <SelectItem value="any">Any Limit</SelectItem>
              {filterOptions?.dailyLosses?.map((limit) => (
                <SelectItem key={limit} value={limit.toString()}>
                  {formatFilterText(limit.toString(), "loss")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Max Loss */}
        <div className="space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-red-700 flex items-center">
            <div className="w-1.5 h-1.5 rounded-full bg-red-600 mr-1.5"></div>
            Max Loss
          </div>
          <Select 
            value={maxLoss}
            onValueChange={(value) => {
              setMaxLoss(value);
              setTimeout(applyFilters, 100);
            }}
          >
            <SelectTrigger className="h-11 rounded-xl bg-white/80 backdrop-blur-sm border border-red-100 hover:border-red-300 shadow-sm">
              <SelectValue placeholder="Any Limit" />
            </SelectTrigger>
            <SelectContent 
              position="popper" 
              align="start" 
              sideOffset={5}
              className="z-50 max-h-[300px]"
            >
              <SelectItem value="any">Any Limit</SelectItem>
              {filterOptions?.maxLosses?.map((limit) => (
                <SelectItem key={limit} value={limit.toString()}>
                  {formatFilterText(limit.toString(), "loss")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Profit Split */}
        <div className="space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-teal-700 flex items-center">
            <div className="w-1.5 h-1.5 rounded-full bg-teal-600 mr-1.5"></div>
            Profit Split
          </div>
          <Select 
            value={profitSplit}
            onValueChange={(value) => {
              setProfitSplit(value);
              setTimeout(applyFilters, 100);
            }}
          >
            <SelectTrigger className="h-11 rounded-xl bg-white/80 backdrop-blur-sm border border-teal-100 hover:border-teal-300 shadow-sm">
              <SelectValue placeholder="Any Split" />
            </SelectTrigger>
            <SelectContent 
              position="popper" 
              align="start" 
              sideOffset={5}
              className="z-50 max-h-[300px]"
            >
              <SelectItem value="any">Any Split</SelectItem>
              {filterOptions?.profitSplits?.map((split) => (
                <SelectItem key={split} value={split.toString()}>
                  {formatFilterText(split.toString(), "split")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Search Button */}
        <div className="lg:col-span-1 flex items-end">
          <Button 
            onClick={applyFilters}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 text-white 
                    hover:from-indigo-700 hover:via-purple-700 hover:to-indigo-700 
                    shadow-lg hover:shadow-xl hover:shadow-indigo-500/20
                    transition-all duration-300 transform hover:scale-[1.02]
                    border-0 font-semibold"
          >
            <div className="bg-white/20 p-1 rounded-md mr-2">
              <Search className="h-4 w-4 text-white" />
            </div>
            Search Firms
          </Button>
        </div>
      </div>
    </div>
  );
}