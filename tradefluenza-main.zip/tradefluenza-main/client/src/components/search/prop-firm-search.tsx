import { useState, useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { Search, Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { PropFirm } from "@shared/schema";

// Define the search form schema
const searchSchema = z.object({
  programType: z.string().optional(),
  accountSize: z.number().optional(),
  profitTarget: z.number().optional(),
  dailyLoss: z.number().optional(),
  maxLoss: z.number().optional(),
  profitSplit: z.number().optional(),
});

type SearchFormValues = z.infer<typeof searchSchema>;

export default function PropFirmSearch() {
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [searchResults, setSearchResults] = useState<PropFirm[]>([]);
  const [searchUrl, setSearchUrl] = useState<string>('/prop-firms');

  // Fetch all prop firms
  const { data: propFirms = [] } = useQuery<PropFirm[]>({
    queryKey: ['/api/prop-firms'],
  });

  // Fetch available account sizes
  const { data: accountSizes = [] } = useQuery<number[]>({
    queryKey: ['/api/prop-firms/account-sizes'],
  });

  // Get available program types from prop firms
  const programTypes = Array.from(
    new Set(propFirms.map(firm => firm.programType))
  ).filter(Boolean);

  // Define form with default values
  const form = useForm<SearchFormValues>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      programType: undefined,
      accountSize: undefined,
      profitTarget: undefined,
      dailyLoss: undefined,
      maxLoss: undefined,
      profitSplit: undefined,
    },
  });

  // Watch form values for filtering
  const formValues = form.watch();

  // Filter prop firms based on form values
  useEffect(() => {
    if (!propFirms.length) return;

    let results = [...propFirms];

    // Filter by program type
    if (formValues.programType && formValues.programType !== "any") {
      results = results.filter(firm => 
        firm.programType === formValues.programType
      );
    }

    // Filter by account size
    if (formValues.accountSize && typeof formValues.accountSize === 'number') {
      results = results.filter(firm => 
        firm.accountSizes.includes(formValues.accountSize!)
      );
    }

    // Filter by profit target (matching or lower)
    if (formValues.profitTarget) {
      results = results.filter(firm => {
        if (!firm.profitTargets || !firm.profitTargets.length) return false;
        return Math.min(...firm.profitTargets) <= formValues.profitTarget!;
      });
    }

    // Filter by daily loss (matching or higher)
    if (formValues.dailyLoss) {
      results = results.filter(firm => 
        firm.dailyLoss >= formValues.dailyLoss!
      );
    }

    // Filter by max loss (matching or higher)
    if (formValues.maxLoss) {
      results = results.filter(firm => 
        firm.maxLoss >= formValues.maxLoss!
      );
    }

    // Filter by profit split (matching or higher)
    if (formValues.profitSplit) {
      results = results.filter(firm => 
        firm.profitSplit >= formValues.profitSplit!
      );
    }

    setSearchResults(results);
  }, [formValues, propFirms]);

  // Reset all form fields
  const resetFilters = () => {
    form.reset({
      programType: undefined,
      accountSize: undefined,
      profitTarget: undefined,
      dailyLoss: undefined,
      maxLoss: undefined,
      profitSplit: undefined,
    });
  };

  // Create URL for prop firms page with filters as query params - memoized to prevent infinite loop
  const buildSearchUrl = useCallback((values: SearchFormValues) => {
    // Build query params
    const params = new URLSearchParams();
    
    if (values.programType && values.programType !== 'any') {
      params.set('programType', values.programType);
    }
    
    if (values.accountSize && typeof values.accountSize === 'number') {
      params.set('accountSize', values.accountSize.toString());
    }
    
    if (values.profitTarget) {
      params.set('profitTarget', values.profitTarget.toString());
    }
    
    if (values.dailyLoss) {
      params.set('dailyLoss', values.dailyLoss.toString());
    }
    
    if (values.maxLoss) {
      params.set('maxLoss', values.maxLoss.toString());
    }
    
    if (values.profitSplit) {
      params.set('profitSplit', values.profitSplit.toString());
    }
    
    // Return URL with params - empty params returns base URL
    const paramsString = params.toString();
    return paramsString ? `/prop-firms?${paramsString}` : '/prop-firms';
  }, []);

  // Update the search URL whenever form values change
  useEffect(() => {
    // Build the URL once and store it, preventing the infinite update loop
    const url = buildSearchUrl(formValues);
    setSearchUrl(url);
    // Remove searchUrl from the deps array to prevent infinite loop
  }, [formValues, buildSearchUrl]);

  // Count active filters (excluding "any" values)
  const activeFilterCount = Object.entries(formValues).filter(([key, value]) => {
    if (!value) return false;
    if (key === 'programType' && value === 'any') return false;
    return true;
  }).length;

  return (
    <div className="w-full max-w-3xl mx-auto mb-8 px-4">
      <Form {...form}>
        {/* Horizontal dropdowns */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
          {/* Program Type */}
          <FormField
              control={form.control}
              name="programType"
              render={({ field }) => (
                <FormItem className="space-y-1">
                  <FormLabel className="text-xs text-gray-500">Program Type</FormLabel>
                  <Select
                    value={field.value || "any"}
                    onValueChange={field.onChange}
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Any Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Type</SelectItem>
                      {programTypes.map(type => (
                        <SelectItem key={type} value={type || "unknown"}>
                          {type || "Unknown"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            {/* Account Size */}
            <FormField
              control={form.control}
              name="accountSize"
              render={({ field }) => (
                <FormItem className="space-y-1">
                  <FormLabel className="text-xs text-gray-500">Account Size</FormLabel>
                  <Select
                    value={field.value?.toString() || "any"}
                    onValueChange={(value) => 
                      field.onChange(value && value !== "any" ? parseInt(value) : undefined)
                    }
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Any Size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Size</SelectItem>
                      {accountSizes.sort((a, b) => a - b).map(size => (
                        <SelectItem key={size} value={size.toString()}>
                          ${size.toLocaleString()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            {/* Profit Target */}
            <FormField
              control={form.control}
              name="profitTarget"
              render={({ field }) => (
                <FormItem className="space-y-1">
                  <FormLabel className="text-xs text-gray-500">
                    Target Profit {field.value ? `(${field.value}%)` : ""}
                  </FormLabel>
                  <Select
                    value={field.value?.toString() || "any"}
                    onValueChange={(value) => 
                      field.onChange(value && value !== "any" ? parseInt(value) : undefined)
                    }
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Any Target" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Target</SelectItem>
                      {[3, 5, 8, 10, 12, 15].map(percent => (
                        <SelectItem key={percent} value={percent.toString()}>
                          {percent}% or Lower
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            {/* Daily Loss */}
            <FormField
              control={form.control}
              name="dailyLoss"
              render={({ field }) => (
                <FormItem className="space-y-1">
                  <FormLabel className="text-xs text-gray-500">
                    Daily Loss {field.value ? `(${field.value}%)` : ""}
                  </FormLabel>
                  <Select
                    value={field.value?.toString() || "any"}
                    onValueChange={(value) => 
                      field.onChange(value && value !== "any" ? parseInt(value) : undefined)
                    }
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Any Limit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Limit</SelectItem>
                      {[2, 4, 5, 8, 10].map(percent => (
                        <SelectItem key={percent} value={percent.toString()}>
                          {percent}% or Higher
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            {/* Max Loss */}
            <FormField
              control={form.control}
              name="maxLoss"
              render={({ field }) => (
                <FormItem className="space-y-1">
                  <FormLabel className="text-xs text-gray-500">
                    Max Loss {field.value ? `(${field.value}%)` : ""}
                  </FormLabel>
                  <Select
                    value={field.value?.toString() || "any"}
                    onValueChange={(value) => 
                      field.onChange(value && value !== "any" ? parseInt(value) : undefined)
                    }
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Any Limit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Limit</SelectItem>
                      {[4, 6, 8, 10, 12, 15].map(percent => (
                        <SelectItem key={percent} value={percent.toString()}>
                          {percent}% or Higher
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            {/* Profit Split */}
            <FormField
              control={form.control}
              name="profitSplit"
              render={({ field }) => (
                <FormItem className="space-y-1">
                  <FormLabel className="text-xs text-gray-500">
                    Profit Split {field.value ? `(${field.value}%)` : ""}
                  </FormLabel>
                  <Select
                    value={field.value?.toString() || "any"}
                    onValueChange={(value) => 
                      field.onChange(value && value !== "any" ? parseInt(value) : undefined)
                    }
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Any Split" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Split</SelectItem>
                      {[50, 60, 70, 80, 90, 100].map(percent => (
                        <SelectItem key={percent} value={percent.toString()}>
                          {percent}% or Higher
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
          </div>

        {/* Actions row */}
        <div className="flex justify-between items-center mt-2">
            {/* Active filter badges */}
            <div className="flex flex-wrap gap-2">
              {activeFilterCount > 0 ? (
                <>
                  {formValues.programType && formValues.programType !== 'any' && (
                    <Badge variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                      Program: {formValues.programType}
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-5 w-5 p-0 hover:bg-gray-200 rounded-full"
                        onClick={() => form.setValue('programType', undefined)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  )}
                  
                  {formValues.accountSize && (
                    <Badge variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                      Account: ${formValues.accountSize.toLocaleString()}
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-5 w-5 p-0 hover:bg-gray-200 rounded-full"
                        onClick={() => form.setValue('accountSize', undefined)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  )}
                  
                  {formValues.profitTarget && (
                    <Badge variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                      Target: {formValues.profitTarget}%
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-5 w-5 p-0 hover:bg-gray-200 rounded-full"
                        onClick={() => form.setValue('profitTarget', undefined)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  )}
                  
                  {formValues.dailyLoss && (
                    <Badge variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                      Daily: {formValues.dailyLoss}%
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-5 w-5 p-0 hover:bg-gray-200 rounded-full"
                        onClick={() => form.setValue('dailyLoss', undefined)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  )}
                  
                  {formValues.maxLoss && (
                    <Badge variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                      Max Loss: {formValues.maxLoss}%
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-5 w-5 p-0 hover:bg-gray-200 rounded-full"
                        onClick={() => form.setValue('maxLoss', undefined)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  )}
                  
                  {formValues.profitSplit && (
                    <Badge variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                      Split: {formValues.profitSplit}%
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-5 w-5 p-0 hover:bg-gray-200 rounded-full"
                        onClick={() => form.setValue('profitSplit', undefined)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  )}
                </>
              ) : (
                <span className="text-sm text-gray-500">No filters selected</span>
              )}
            </div>
            
            {/* Search and reset buttons */}
            <div className="flex items-center gap-2">
              {activeFilterCount > 0 && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={resetFilters}
                  type="button"
                >
                  <X className="mr-2 h-4 w-4" />
                  Reset
                </Button>
              )}
              
              <Link href={searchUrl}>
                <Button 
                  className="gradient-bg text-white"
                  size="sm"
                >
                  <Search className="mr-2 h-4 w-4" />
                  Find Prop Firms ({searchResults.length})
                </Button>
              </Link>
            </div>
          </div>
      </Form>
    </div>
  );
}