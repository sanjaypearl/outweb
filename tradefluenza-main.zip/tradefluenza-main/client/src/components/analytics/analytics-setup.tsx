import { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { trackEvent } from '@/lib/analytics';

export default function AnalyticsSetup() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("configuration");
  const [testEventName, setTestEventName] = useState("");

  const handleTestEvent = () => {
    if (!testEventName.trim()) {
      toast({
        title: "Error",
        description: "Please enter an event name",
        variant: "destructive"
      });
      return;
    }

    if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
      window.gtag('event', testEventName, {
        event_category: 'test',
        event_label: 'Admin panel test',
        value: Date.now()
      });
      
      toast({
        title: "Event sent!",
        description: `Test event "${testEventName}" has been sent to Google Analytics`,
      });
      
      setTestEventName("");
    } else {
      toast({
        title: "Error",
        description: "Google Analytics is not available",
        variant: "destructive"
      });
    }
  };

  const trackExampleEvent = (eventType: string) => {
    try {
      // Track an example event
      trackEvent(eventType, 'admin_test', 'Admin panel test', Date.now());
      
      toast({
        title: "Event sent!",
        description: `"${eventType}" event has been sent to Google Analytics`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send event",
        variant: "destructive"
      });
    }
  };

  const analyticsStatusText = typeof window !== 'undefined' && typeof window.gtag === 'function'
    ? "✅ Google Analytics is properly configured and working"
    : "❌ Google Analytics is not available or not properly configured";

  const analyticsStatusClass = typeof window !== 'undefined' && typeof window.gtag === 'function'
    ? "text-green-500 font-medium"
    : "text-red-500 font-medium";

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Analytics Management</CardTitle>
        <CardDescription>Manage and test Google Analytics configuration</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="font-semibold mb-2">Analytics Status</h3>
          <p className={analyticsStatusClass}>{analyticsStatusText}</p>
          <p className="text-sm text-gray-500 mt-2">
            Tracking ID: <code className="bg-gray-100 px-1 py-0.5 rounded">G-FCTC2LSV40</code>
          </p>
        </div>

        <Tabs defaultValue="configuration" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="configuration">Configuration</TabsTrigger>
            <TabsTrigger value="test">Test Events</TabsTrigger>
            <TabsTrigger value="report">Reports</TabsTrigger>
          </TabsList>
          
          <TabsContent value="configuration">
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Setup Instructions</h3>
                <p className="text-sm text-gray-500">
                  Google Analytics is already configured with the tracking ID <code>G-FCTC2LSV40</code>.
                  The tracking script is loaded in index.html.
                </p>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Implementation Details</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Component</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Base Tracking</TableCell>
                      <TableCell>✅ Implemented</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Page Views</TableCell>
                      <TableCell>✅ Auto-tracking via useAnalytics hook</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Buy Now Clicks</TableCell>
                      <TableCell>✅ Implemented</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Coupon Copies</TableCell>
                      <TableCell>✅ Implemented</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Filter Usage</TableCell>
                      <TableCell>✅ Implemented</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="test">
            <div className="space-y-4 py-4">
              <div className="grid gap-4">
                <div className="grid grid-cols-4 gap-4">
                  <div className="col-span-3">
                    <Label htmlFor="testEvent">Custom Event Name</Label>
                    <Input 
                      id="testEvent" 
                      placeholder="Enter test event name" 
                      value={testEventName}
                      onChange={(e) => setTestEventName(e.target.value)}
                    />
                  </div>
                  <div className="flex items-end">
                    <Button 
                      className="w-full" 
                      onClick={handleTestEvent}
                    >
                      Send Test Event
                    </Button>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Common Events</h3>
                <p className="text-sm text-gray-500 mb-4">Click to send test events for common interactions</p>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <Button 
                    variant="outline" 
                    onClick={() => trackExampleEvent('test_page_view')}
                  >
                    Page View
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => trackExampleEvent('test_buy_now_click')}
                  >
                    Buy Now Click
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => trackExampleEvent('test_coupon_copy')}
                  >
                    Coupon Copy
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => trackExampleEvent('test_filter_apply')}
                  >
                    Filter Apply
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => trackExampleEvent('test_review_submit')}
                  >
                    Review Submit
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => trackExampleEvent('test_sign_up')}
                  >
                    Sign Up
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="report">
            <div className="py-4 space-y-4">
              <div className="rounded-lg border p-4">
                <h3 className="font-medium mb-2">Analytics Reports</h3>
                <p className="text-sm text-gray-500 mb-4">
                  To view detailed analytics reports, please visit the Google Analytics dashboard.
                </p>
                <Button 
                  variant="outline" 
                  onClick={() => window.open('https://analytics.google.com/', '_blank')}
                >
                  Open Google Analytics
                </Button>
              </div>
              
              <div className="rounded-lg border p-4">
                <h3 className="font-medium mb-2">Quick Tips</h3>
                <ul className="list-disc list-inside text-sm text-gray-500 space-y-1">
                  <li>Check Real-Time reports to see immediate event tracking</li>
                  <li>Review Behavior flow to understand user navigation patterns</li>
                  <li>Set up custom dashboards for key metrics monitoring</li>
                  <li>Create conversion goals to track important user actions</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={() => window.location.href = '/admin'}>
          Back to Admin
        </Button>
        <Button onClick={() => setActiveTab(activeTab === "configuration" ? "test" : activeTab === "test" ? "report" : "configuration")}>
          Next Tab
        </Button>
      </CardFooter>
    </Card>
  );
}