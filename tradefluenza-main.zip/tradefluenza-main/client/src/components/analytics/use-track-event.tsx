import { useCallback } from 'react';
import { event } from '@/lib/analytics';

// Define the event categories for better organization
export const EventCategory = {
  ENGAGEMENT: 'engagement',
  PURCHASE: 'purchase',
  USER: 'user',
  NAVIGATION: 'navigation',
  CONTENT: 'content',
  FILTER: 'filter',
  SEARCH: 'search',
} as const;

// Hook to track events in the application
export function useTrackEvent() {
  const trackEvent = useCallback((
    action: string,
    category: typeof EventCategory[keyof typeof EventCategory],
    label?: string,
    value?: number,
  ) => {
    event({
      action,
      category,
      label,
      value,
    });
  }, []);

  return trackEvent;
}

// Predefined event trackers for common actions
export function useCommonTrackers() {
  const trackEvent = useTrackEvent();
  
  const trackPropFirmView = useCallback((propFirmName: string) => {
    trackEvent('view_prop_firm', EventCategory.CONTENT, propFirmName);
  }, [trackEvent]);
  
  const trackBrokerView = useCallback((brokerName: string) => {
    trackEvent('view_broker', EventCategory.CONTENT, brokerName);
  }, [trackEvent]);
  
  const trackBuyNowClick = useCallback((propFirmName: string, accountSize: number) => {
    trackEvent('buy_now_click', EventCategory.PURCHASE, propFirmName, accountSize);
  }, [trackEvent]);
  
  const trackCouponCopy = useCallback((couponCode: string, propFirmName: string) => {
    trackEvent('copy_coupon', EventCategory.ENGAGEMENT, `${couponCode} - ${propFirmName}`);
  }, [trackEvent]);
  
  const trackFilter = useCallback((filterType: string, filterValue: string) => {
    trackEvent('apply_filter', EventCategory.FILTER, `${filterType}: ${filterValue}`);
  }, [trackEvent]);
  
  const trackSearch = useCallback((searchTerm: string, resultsCount: number) => {
    trackEvent('search', EventCategory.SEARCH, searchTerm, resultsCount);
  }, [trackEvent]);
  
  const trackLogin = useCallback(() => {
    trackEvent('login', EventCategory.USER);
  }, [trackEvent]);
  
  const trackSignup = useCallback(() => {
    trackEvent('signup', EventCategory.USER);
  }, [trackEvent]);
  
  return {
    trackPropFirmView,
    trackBrokerView,
    trackBuyNowClick,
    trackCouponCopy,
    trackFilter,
    trackSearch,
    trackLogin,
    trackSignup,
  };
}