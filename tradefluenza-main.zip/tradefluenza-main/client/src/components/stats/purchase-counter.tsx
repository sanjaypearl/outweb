import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Users, Clock, TrendingUp, Award } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface PurchaseStats {
  totalPurchases: number;
  thisMonth: number;
  thisWeek: number;
  today: number;
  bySize: {
    small: number;
    medium: number;
    large: number;
  };
}

export default function PurchaseCounter() {
  const [animatedTotal, setAnimatedTotal] = useState(0);
  
  // Fetch purchase statistics
  const { data: stats, isLoading, error } = useQuery<PurchaseStats>({
    queryKey: ['/api/stats/purchases'],
  });
  
  // Animate counter
  useEffect(() => {
    if (stats) {
      const interval = 1500; // 1.5 seconds
      const steps = 30;
      const increment = Math.ceil(stats.totalPurchases / steps);
      let current = 0;
      
      const timer = setInterval(() => {
        current += increment;
        if (current >= stats.totalPurchases) {
          setAnimatedTotal(stats.totalPurchases);
          clearInterval(timer);
        } else {
          setAnimatedTotal(current);
        }
      }, interval / steps);
      
      return () => clearInterval(timer);
    }
  }, [stats]);
  
  if (error) {
    return null; // Hide the component if there's an error
  }
  
  return (
    <div className="relative overflow-hidden p-1 rounded-lg">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/20 via-teal-500/20 to-blue-500/20 z-0 blur-sm"></div>
      
      <div className="relative z-10 rounded-lg border border-emerald-600/30 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 backdrop-blur-sm p-4 shadow-xl">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center">
            <div className="rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 p-2 mr-4 shadow-lg">
              <Users className="h-6 w-6 text-white" />
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-emerald-900 dark:text-emerald-300">Traders Trust Us</h3>
              <div className="flex items-baseline">
                {isLoading ? (
                  <Skeleton className="h-10 w-32" />
                ) : (
                  <div className="text-3xl font-bold text-emerald-700 dark:text-emerald-500">
                    {animatedTotal.toLocaleString()}
                  </div>
                )}
                <span className="ml-2 text-sm font-medium text-emerald-600 dark:text-emerald-400">
                  traders purchased
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center md:justify-end gap-3 md:gap-6">
            <div className="stat-item">
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 text-emerald-600 mr-1.5" />
                <span className="text-xs uppercase font-medium text-gray-600 dark:text-gray-400">This Month</span>
              </div>
              {isLoading ? (
                <Skeleton className="h-6 w-16 mt-1" />
              ) : (
                <div className="text-lg font-bold text-gray-800 dark:text-gray-200">{stats?.thisMonth.toLocaleString()}</div>
              )}
            </div>
            
            <div className="stat-item">
              <div className="flex items-center">
                <Clock className="h-4 w-4 text-emerald-600 mr-1.5" />
                <span className="text-xs uppercase font-medium text-gray-600 dark:text-gray-400">This Week</span>
              </div>
              {isLoading ? (
                <Skeleton className="h-6 w-16 mt-1" />
              ) : (
                <div className="text-lg font-bold text-gray-800 dark:text-gray-200">{stats?.thisWeek.toLocaleString()}</div>
              )}
            </div>
            
            <div className="stat-item">
              <div className="flex items-center">
                <Award className="h-4 w-4 text-emerald-600 mr-1.5" />
                <span className="text-xs uppercase font-medium text-gray-600 dark:text-gray-400">Today</span>
              </div>
              {isLoading ? (
                <Skeleton className="h-6 w-16 mt-1" />
              ) : (
                <div className="text-lg font-bold text-gray-800 dark:text-gray-200">{stats?.today.toLocaleString()}</div>
              )}
            </div>
          </div>
        </div>
        
        {/* Live indicator */}
        <div className="absolute top-4 right-4 flex items-center">
          <div className="h-2 w-2 rounded-full bg-emerald-500 mr-1.5 animate-pulse"></div>
          <span className="text-xs text-emerald-700 dark:text-emerald-400 font-medium">LIVE</span>
        </div>
      </div>
    </div>
  );
}