import { useState, useCallback, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, CheckCircle2, Mail, Phone, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// Define the form schema
const promotionFormSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  phoneNumber: z.string().min(5, "Please enter a valid phone number"),
});

type PromotionFormData = z.infer<typeof promotionFormSchema>;

interface BlueberryPromoPopupProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function BlueberryPromoPopup({ 
  isOpen, 
  onOpenChange 
}: BlueberryPromoPopupProps) {
  const [submissionStatus, setSubmissionStatus] = useState<"idle" | "success" | "error">("idle");
  const [couponCode, setCouponCode] = useState("");
  const { toast } = useToast();
  
  // Reset form when reopened
  const handleOpenChange = useCallback((open: boolean) => {
    if (!open) {
      // If closing the dialog, run the callback
      onOpenChange(false);
      
      // Reset submission status after dialog is closed
      setTimeout(() => {
        setSubmissionStatus("idle");
      }, 300);
      
      // No longer reopening the popup automatically
      // This is handled by the usePromotionPopup hook using localStorage
    } else {
      onOpenChange(true);
    }
  }, [onOpenChange]);
  
  const form = useForm<PromotionFormData>({
    resolver: zodResolver(promotionFormSchema),
    defaultValues: {
      email: "",
      phoneNumber: ""
    }
  });

  const promotionMutation = useMutation({
    mutationFn: async (data: PromotionFormData) => {
      const payload = {
        ...data,
        promotionType: "blueberry_bogo"
      };
      
      const response = await apiRequest("POST", "/api/promotions/entry", payload);
      return await response.json();
    },
    onSuccess: (data) => {
      setSubmissionStatus("success");
      // No longer using coupon code from response
      toast({
        title: "Success!",
        description: "Your details have been submitted successfully.",
        variant: "default"
      });
      
      // Reset form
      form.reset();
      
      // Track event in Google Analytics
      if (typeof window !== 'undefined' && window.gtag) {
        window.gtag('event', 'promotion_signup', {
          event_category: 'conversions',
          event_label: 'Blueberry BOGO Promotion',
        });
      }
    },
    onError: (error: Error) => {
      setSubmissionStatus("error");
      toast({
        title: "Submission failed",
        description: error.message || "Please try again later.",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: PromotionFormData) => {
    promotionMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md overflow-hidden border-0 p-0">
        {/* Background inspired by the shared promo image */}
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-yellow-400 via-yellow-500 to-orange-500"></div>
        <div className="absolute inset-0 -z-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJzdW5idXJzdCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSI+PHBhdGggZD0iTTAgMCBMMTAwMCAxMDAwIE0xMDAwIDAgTDAgMTAwMCBNNTAwIDAgTDUwMCAxMDAwIE0wIDUwMCBMMTAwMCA1MDAiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIgc3Ryb2tlLXdpZHRoPSIxLjUiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjc3VuYnVyc3QpIi8+PC9zdmc+')]"></div>
        
        <div className="p-6 relative z-10">
          {submissionStatus === "success" ? (
            <div className="flex flex-col items-center justify-center py-8 px-2 relative z-10 bg-white/80 rounded-xl shadow-xl">
              <div className="rounded-full bg-gradient-to-r from-green-400 to-green-500 p-4 mb-5 shadow-lg">
                <CheckCircle2 className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-black mb-3 text-center">Thank You!</h3>
              <p className="text-gray-700 text-center mb-3 font-medium">
                You've been entered in the giveaway! Winners will be notified by email.
              </p>
              
              <Button 
                variant="outline" 
                onClick={() => handleOpenChange(false)}
                className="mt-4 border-gray-300 hover:bg-gray-100"
              >
                Close
              </Button>
            </div>
          ) : (
            <>
              <div className="mb-6 bg-black py-3 px-6 rounded-md shadow-lg transform -rotate-2 relative mx-auto max-w-[260px]">
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center transform rotate-12 shadow-md">
                  <Sparkles className="h-5 w-5 text-black" />
                </div>
                <div className="absolute -top-2 -left-2 w-8 h-8 bg-red-600 rounded-full flex items-center justify-center transform -rotate-12 shadow-md">
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <h2 className="text-center font-black text-3xl text-white mb-1">WIN 10K</h2>
                <h2 className="text-center font-black text-3xl text-white mb-1">ACCOUNT</h2>
                <h2 className="text-center font-black text-3xl text-white">FROM TRADEFLUENZA!</h2>
              </div>
              
              <div className="bg-white/90 rounded-xl p-5 shadow-xl mb-4">
                <h3 className="text-lg font-bold text-center mb-1">Limited Time Giveaway</h3>
                <p className="text-gray-700 text-center text-sm mb-4">
                  Enter your details below for a chance to win a $10,000 Tradefluenza funded trading account!
                </p>
                
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                      <Input 
                        id="email"
                        type="email"
                        placeholder="Your Email"
                        {...form.register("email")}
                        className={cn(
                          "pl-10 bg-white border-gray-300 focus:border-yellow-500 focus:ring-yellow-500/30",
                          form.formState.errors.email ? "border-red-500" : ""
                        )}
                      />
                    </div>
                    {form.formState.errors.email && (
                      <p className="text-red-500 text-xs mt-1">{form.formState.errors.email.message}</p>
                    )}
                  </div>
                  
                  <div>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                      <Input 
                        id="phoneNumber"
                        type="tel"
                        placeholder="Your Phone Number"
                        {...form.register("phoneNumber")}
                        className={cn(
                          "pl-10 bg-white border-gray-300 focus:border-yellow-500 focus:ring-yellow-500/30",
                          form.formState.errors.phoneNumber ? "border-red-500" : ""
                        )}
                      />
                    </div>
                    {form.formState.errors.phoneNumber && (
                      <p className="text-red-500 text-xs mt-1">{form.formState.errors.phoneNumber.message}</p>
                    )}
                  </div>
                  
                  <div className="pt-2 flex flex-col gap-2">
                    <Button 
                      type="submit" 
                      disabled={promotionMutation.isPending}
                      className="w-full bg-black hover:bg-gray-800 text-white font-bold py-2 shadow-lg"
                    >
                      {promotionMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        "Enter Giveaway"
                      )}
                    </Button>
                    
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => handleOpenChange(false)}
                      disabled={promotionMutation.isPending}
                      className="w-full border-gray-300 hover:bg-gray-100 text-gray-700"
                    >
                      No Thanks
                    </Button>
                  </div>
                </form>
              </div>
              
              <p className="text-xs text-center text-white drop-shadow-md">
                *Offer valid for a limited time. Terms and conditions apply.
              </p>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}