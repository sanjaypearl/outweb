// Image optimization script using Sharp
// We can use this script to optimize large image assets
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const ASSETS_DIR = path.join(process.cwd(), 'client/src/assets');
const OUTPUT_DIR = path.join(process.cwd(), 'client/src/assets/optimized');

// Create output directory if it doesn't exist
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

// Get all image files from assets directory
const imageFiles = fs.readdirSync(ASSETS_DIR).filter(file => {
  const ext = path.extname(file).toLowerCase();
  return ['.jpg', '.jpeg', '.png'].includes(ext);
});

console.log(`Found ${imageFiles.length} images to optimize`);

// Process each image
async function optimizeImages() {
  for (const file of imageFiles) {
    const inputPath = path.join(ASSETS_DIR, file);
    const fileExt = path.extname(file);
    const fileName = path.basename(file, fileExt);
    const outputPath = path.join(OUTPUT_DIR, `${fileName}${fileExt}`);
    
    // Skip if file is already in the optimized directory
    if (inputPath.includes('optimized')) continue;
    
    const stats = fs.statSync(inputPath);
    const fileSizeInKB = stats.size / 1024;
    
    console.log(`Processing: ${file} (${fileSizeInKB.toFixed(2)} KB)`);
    
    try {
      // Optimize the image - resize large images to max 1200px width
      // and set quality to 80% for good balance of quality and size
      await sharp(inputPath)
        .resize({ width: 1200, height: 1200, fit: 'inside', withoutEnlargement: true })
        .webp({ quality: 80 })
        .toFile(path.join(OUTPUT_DIR, `${fileName}.webp`));
      
      console.log(`✅ Optimized: ${fileName}.webp`);
    } catch (error) {
      console.error(`❌ Error optimizing ${file}:`, error);
    }
  }
}

optimizeImages().then(() => {
  console.log('Image optimization complete!');
});