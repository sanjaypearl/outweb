import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { parse } from 'csv-parse/sync';

// ES Module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
import { db } from '../server/db';
import { propFirms } from '../shared/schema';
import { eq, sql } from 'drizzle-orm';

// Function to parse price string to number (handling currencies)
function parsePrice(priceStr: string): number {
  // Remove currency symbols and commas, then convert to number
  return Number(priceStr.replace(/[$€£,]/g, ''));
}

// Function to parse percentage string to number
function parsePercentage(percentStr: string): number {
  if (percentStr === '-') return 0;
  return Number(percentStr.replace('%', ''));
}

// Function to convert program type string to proper format
function formatProgramType(program: string): string {
  const steps = program.match(/(\d+)/);
  if (!steps) return 'One-Phase';
  
  switch (steps[0]) {
    case '1': return 'One-Phase';
    case '2': return 'Two-Phase';
    case '3': return 'Three-Phase';
    default: return 'Two-Phase';
  }
}

// Parse profit targets into array of numbers
function parseProfitTargets(targetStr: string): number[] {
  if (targetStr === '-') return [0];
  
  return targetStr.split('/').map(target => 
    parsePercentage(target.trim())
  );
}

// Main import function
async function importPropFirms() {
  try {
    // Read CSV file
    const csvPath = path.resolve(__dirname, '../attached_assets/Challenge Data - Sheet1.csv');
    const csvData = fs.readFileSync(csvPath, 'utf8');
    
    // Parse CSV
    const records = parse(csvData, {
      columns: true,
      skip_empty_lines: true
    });
    
    console.log(`Found ${records.length} records to import`);
    
    // Process and insert data
    for (const record of records) {
      const accountSize = parseInt(record['Acc. Size'].replace('K', '000'));
      const programType = formatProgramType(record['Program']);
      const profitTargets = parseProfitTargets(record['Profit Target']);
      const dailyLoss = parsePercentage(record['Daily Loss']);
      const maxLoss = parsePercentage(record['Max Loss']);
      const profitSplit = parsePercentage(record['Profit Split']);
      const price = parsePrice(record['Price']);
      
      // Generate data for required fields that aren't in the CSV
      const firm = {
        name: record['Prop Firm'],
        established: '2020', // Default since not in CSV
        headquarters: 'Unknown', // Default since not in CSV
        websiteUrl: `https://${record['Prop Firm'].toLowerCase().replace(/\s+/g, '')}.com`,
        logoUrl: `/logos/${record['Prop Firm'].toLowerCase().replace(/\s+/g, '-')}.svg`,
        description: `${record['Prop Firm']} offers traders a ${programType.toLowerCase()} prop trading experience with ${profitSplit}% profit splits and multiple account tiers.`,
        accountSizes: [accountSize],
        programType,
        profitTargets,
        dailyLoss,
        maxLoss,
        profitSplit,
        payoutFrequency: record['Payout Frequency'],
        loyaltyProgram: parseInt(record['Loyalty Pts']) > 0,
        pricing: [{ accountSize, price }],
        refundPolicy: "Contact for refund policy details.",
        tradingPlatforms: ["MT4", "MT5"],
        instrumentsAllowed: ["Forex", "Indices", "Commodities"],
        minimumTradingDays: 5,
        timeToFunded: record['Payout Frequency'],
        scaling: {
          available: true,
          terms: "Contact for scaling details"
        },
        pros: [
          `${profitSplit}% profit split`,
          "Multiple account sizes",
          "Professional trading platform"
        ],
        cons: [
          "Limited educational resources",
          "Specific trading rules may apply",
          "Contact customer support for details"
        ]
      };
      
      // Check if firm already exists with this name and account size
      const existingFirms = await db.select().from(propFirms)
        .where(eq(propFirms.name, firm.name));
      
      if (existingFirms.length > 0) {
        // Firm exists, check if this account size exists
        const existingFirm = existingFirms[0];
        
        // Check if this account size is already in the accountSizes array
        if (!existingFirm.accountSizes.includes(accountSize)) {
          // Add this account size and pricing
          const updatedAccountSizes = [...existingFirm.accountSizes, accountSize];
          const updatedPricing = [...existingFirm.pricing, { accountSize, price }];
          
          // Update the firm
          await db.update(propFirms)
            .set({
              accountSizes: updatedAccountSizes,
              pricing: updatedPricing
            })
            .where(eq(propFirms.id, existingFirm.id));
            
          console.log(`Updated ${firm.name} with new account size ${accountSize}`);
        } else {
          console.log(`Skipping duplicate entry for ${firm.name} with account size ${accountSize}`);
        }
      } else {
        // New firm, insert it
        await db.insert(propFirms).values(firm);
        console.log(`Inserted new firm: ${firm.name}`);
      }
    }
    
    console.log('Import completed successfully');
  } catch (error) {
    console.error('Error importing data:', error);
  }
}

// Run the import
importPropFirms()
  .then(() => process.exit(0))
  .catch(error => {
    console.error('Unexpected error:', error);
    process.exit(1);
  });