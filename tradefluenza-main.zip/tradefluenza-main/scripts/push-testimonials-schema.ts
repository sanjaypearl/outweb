import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { migrate } from 'drizzle-orm/neon-serverless/migrator';
import * as schema from "../shared/schema";
import ws from 'ws';

// Configure neon to use the ws package for WebSocket connections
neonConfig.webSocketConstructor = ws;

// The script should be run from the project root with:
// npm run db:push:testimonials
// Ensure your DATABASE_URL is properly set in the environment or .env file

async function pushTestimonialsSchema() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable not set');
  }

  console.log('Connecting to database...');
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const db = drizzle(pool, { schema });

  try {
    console.log('Pushing testimonials schema to database...');
    
    // Create the testimonials table if it doesn't exist
    await db.execute(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        profile_image_url TEXT NOT NULL,
        trader_type TEXT NOT NULL,
        rating NUMERIC(2,1) NOT NULL,
        testimonial_text TEXT NOT NULL,
        trading_since TEXT NOT NULL,
        badge_label TEXT NOT NULL,
        badge_color TEXT NOT NULL,
        featured BOOLEAN DEFAULT FALSE,
        display_order INTEGER DEFAULT 999,
        date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
      );
    `);

    console.log('✅ Successfully pushed testimonials schema to database');

    // Add initial testimonials data
    console.log('Adding initial testimonials data...');
    
    await db.execute(`
      INSERT INTO testimonials (name, profile_image_url, trader_type, rating, testimonial_text, trading_since, badge_label, badge_color, featured, display_order)
      VALUES 
        ('Ravi Verma', '/attached_assets/ravi_verma.jpeg', 'Forex & Indices Trader', 5.0, 'The prop firm comparison tool saved me hundreds of dollars by helping me find the perfect firm for my trading style. I''m now consistently profitable with a $50K account!', '2021', 'Verified Trader', 'indigo', TRUE, 1),
        ('Rishav Negi', '/attached_assets/rishav_Negi.jpeg', 'Crypto Trader', 5.0, 'The social platform has been a game-changer for my trading journey. Learning from other traders and sharing my own insights has improved my strategy dramatically.', '2022', 'Community Leader', 'purple', TRUE, 2),
        ('Bobby Arya', '/attached_assets/Bobby_Arya.jpeg', 'Swing Trader', 5.0, 'The broker comparison tools helped me find a regulated broker with tight spreads. The trading events have been incredibly educational - I''ve learned so much!', '2020', 'Event Attendee', 'emerald', TRUE, 3)
      ON CONFLICT (id) DO NOTHING;
    `);

    console.log('✅ Successfully added initial testimonials data');

  } catch (error) {
    console.error('Error pushing testimonials schema:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

pushTestimonialsSchema().catch(err => {
  console.error('Failed to push testimonials schema:', err);
  process.exit(1);
});