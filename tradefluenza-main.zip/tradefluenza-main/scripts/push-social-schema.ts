import { drizzle } from "drizzle-orm/neon-serverless";
import { migrate } from "drizzle-orm/neon-serverless/migrator";
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from "ws";
import * as schema from "../shared/schema";

neonConfig.webSocketConstructor = ws;

// Push the schema changes to the database
async function pushSocialSchema() {
  console.log("Pushing social platform schema to database...");
  
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL must be set");
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const db = drizzle(pool, { schema });
  
  try {
    console.log("Adding new columns to users table...");
    await pool.query(`
      ALTER TABLE users 
      ADD COLUMN IF NOT EXISTS email TEXT UNIQUE,
      ADD COLUMN IF NOT EXISTS display_name TEXT,
      ADD COLUMN IF NOT EXISTS bio TEXT,
      ADD COLUMN IF NOT EXISTS avatar_url TEXT,
      ADD COLUMN IF NOT EXISTS cover_image_url TEXT,
      ADD COLUMN IF NOT EXISTS trading_experience TEXT,
      ADD COLUMN IF NOT EXISTS account_created TIMESTAMP DEFAULT NOW() NOT NULL,
      ADD COLUMN IF NOT EXISTS last_active TIMESTAMP DEFAULT NOW() NOT NULL,
      ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'trader',
      ADD COLUMN IF NOT EXISTS trading_style TEXT,
      ADD COLUMN IF NOT EXISTS favorite_markets TEXT[],
      ADD COLUMN IF NOT EXISTS preferred_timeframes TEXT[],
      ADD COLUMN IF NOT EXISTS location TEXT,
      ADD COLUMN IF NOT EXISTS website TEXT
    `);
    
    console.log("Creating social media tables...");
    await pool.query(`
      -- Create user_follows table
      CREATE TABLE IF NOT EXISTS user_follows (
        id SERIAL PRIMARY KEY,
        follower_id INTEGER NOT NULL REFERENCES users(id),
        following_id INTEGER NOT NULL REFERENCES users(id),
        date_followed TIMESTAMP DEFAULT NOW() NOT NULL
      );

      -- Create trade_posts table
      CREATE TABLE IF NOT EXISTS trade_posts (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        post_type TEXT NOT NULL,
        instrument TEXT,
        timeframe TEXT,
        direction TEXT,
        entry_price NUMERIC,
        target_price NUMERIC,
        stop_loss NUMERIC,
        risk_reward NUMERIC,
        result NUMERIC,
        image_urls TEXT[],
        tags TEXT[],
        date_posted TIMESTAMP DEFAULT NOW() NOT NULL,
        date_updated TIMESTAMP DEFAULT NOW() NOT NULL,
        is_public BOOLEAN DEFAULT TRUE NOT NULL,
        is_pinned BOOLEAN DEFAULT FALSE NOT NULL,
        is_archived BOOLEAN DEFAULT FALSE NOT NULL
      );

      -- Create post_comments table
      CREATE TABLE IF NOT EXISTS post_comments (
        id SERIAL PRIMARY KEY,
        post_id INTEGER NOT NULL REFERENCES trade_posts(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        content TEXT NOT NULL,
        date_posted TIMESTAMP DEFAULT NOW() NOT NULL,
        date_updated TIMESTAMP DEFAULT NOW() NOT NULL,
        parent_comment_id INTEGER REFERENCES post_comments(id)
      );

      -- Create post_likes table
      CREATE TABLE IF NOT EXISTS post_likes (
        id SERIAL PRIMARY KEY,
        post_id INTEGER NOT NULL REFERENCES trade_posts(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        date_liked TIMESTAMP DEFAULT NOW() NOT NULL
      );

      -- Create trading_floor table
      CREATE TABLE IF NOT EXISTS trading_floor (
        id SERIAL PRIMARY KEY,
        market_name TEXT NOT NULL UNIQUE,
        status TEXT NOT NULL DEFAULT 'normal',
        direction TEXT,
        activity_level INTEGER NOT NULL DEFAULT 50,
        important_news TEXT,
        last_updated TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);
    
    console.log("Schema push completed successfully.");
  } catch (error) {
    console.error("Error pushing schema:", error);
  } finally {
    await pool.end();
  }
}

pushSocialSchema().finally(() => process.exit(0));