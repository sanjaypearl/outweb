// ES Module script to import prop firm data
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { parse } from 'csv-parse/sync';
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

// ES Module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configure the Neon connection
neonConfig.webSocketConstructor = ws;

// Connect to the database
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Function to parse price string to number (handling currencies)
function parsePrice(priceStr) {
  if (!priceStr) return 0;
  // Remove currency symbols and commas, then convert to number
  return Number(priceStr.replace(/[$€£,]/g, ''));
}

// Function to parse percentage string to number
function parsePercentage(percentStr) {
  if (!percentStr || percentStr === '-') return 0;
  return Number(percentStr.replace('%', ''));
}

// Function to convert program type string to proper format
function formatProgramType(program) {
  if (!program) return 'One-Phase';
  const steps = program.match(/(\d+)/);
  if (!steps) return 'One-Phase';
  
  switch (steps[0]) {
    case '1': return 'One-Phase';
    case '2': return 'Two-Phase';
    case '3': return 'Three-Phase';
    default: return 'Two-Phase';
  }
}

// Parse profit targets into array of numbers
function parseProfitTargets(targetStr) {
  if (!targetStr || targetStr === '-') return [0];
  
  return targetStr.split('/').map(target => 
    parsePercentage(target.trim())
  );
}

// Main import function
async function importPropFirms() {
  try {
    // Read CSV file
    const csvPath = path.resolve(__dirname, '../attached_assets/Challenge Data - Sheet1.csv');
    const csvData = fs.readFileSync(csvPath, 'utf8');
    
    // Parse CSV
    const records = parse(csvData, {
      columns: true,
      skip_empty_lines: true
    });
    
    console.log(`Found ${records.length} records to import`);
    
    // Create prop_firms table if it doesn't exist
    await pool.query(`
      CREATE TABLE IF NOT EXISTS prop_firms (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        established TEXT NOT NULL,
        headquarters TEXT NOT NULL,
        website_url TEXT NOT NULL,
        logo_url TEXT NOT NULL,
        description TEXT NOT NULL,
        account_sizes INTEGER[] NOT NULL,
        program_type TEXT NOT NULL,
        profit_targets INTEGER[] NOT NULL,
        daily_loss INTEGER NOT NULL,
        max_loss INTEGER NOT NULL,
        profit_split INTEGER NOT NULL,
        payout_frequency TEXT NOT NULL,
        loyalty_program BOOLEAN NOT NULL,
        pricing JSONB NOT NULL,
        refund_policy TEXT NOT NULL,
        trading_platforms TEXT[] NOT NULL,
        instruments_allowed TEXT[] NOT NULL,
        minimum_trading_days INTEGER NOT NULL,
        time_to_funded TEXT NOT NULL,
        scaling JSONB NOT NULL,
        pros TEXT[] NOT NULL,
        cons TEXT[] NOT NULL,
        date_added TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);
    
    // Process and insert data
    for (const record of records) {
      const firmName = record['Prop Firm'];
      const accountSize = parseInt(record['Acc. Size'].replace('K', '000'));
      const programType = formatProgramType(record['Program']);
      const profitTargets = parseProfitTargets(record['Profit Target']);
      const dailyLoss = parsePercentage(record['Daily Loss']);
      const maxLoss = parsePercentage(record['Max Loss']);
      const profitSplit = parsePercentage(record['Profit Split']);
      const price = parsePrice(record['Price']);
      
      // Check if firm already exists
      const existingFirmResult = await pool.query(
        'SELECT * FROM prop_firms WHERE name = $1', 
        [firmName]
      );
      
      if (existingFirmResult.rows.length > 0) {
        const existingFirm = existingFirmResult.rows[0];
        
        // Check if this account size already exists in the array
        if (!existingFirm.account_sizes.includes(accountSize)) {
          // Add this account size and pricing
          const updatedAccountSizes = [...existingFirm.account_sizes, accountSize];
          const updatedPricing = [...existingFirm.pricing, { accountSize, price }];
          
          // Update the firm
          await pool.query(
            `UPDATE prop_firms 
             SET account_sizes = $1, pricing = $2
             WHERE id = $3`,
            [updatedAccountSizes, JSON.stringify(updatedPricing), existingFirm.id]
          );
          
          console.log(`Updated ${firmName} with new account size ${accountSize}`);
        } else {
          console.log(`Skipping duplicate entry for ${firmName} with account size ${accountSize}`);
        }
      } else {
        // Generate data for required fields that aren't in the CSV
        const firm = {
          name: firmName,
          established: '2020', // Default since not in CSV
          headquarters: 'Unknown', // Default since not in CSV
          websiteUrl: `https://${firmName.toLowerCase().replace(/\s+/g, '')}.com`,
          logoUrl: `/logos/${firmName.toLowerCase().replace(/\s+/g, '-')}.svg`,
          description: `${firmName} offers traders a ${programType.toLowerCase()} prop trading experience with ${profitSplit}% profit splits and multiple account tiers.`,
          accountSizes: [accountSize],
          programType,
          profitTargets,
          dailyLoss,
          maxLoss,
          profitSplit,
          payoutFrequency: record['Payout Frequency'],
          loyaltyProgram: parseInt(record['Loyalty Pts']) > 0,
          pricing: [{ accountSize, price }],
          refundPolicy: "Contact for refund policy details.",
          tradingPlatforms: ["MT4", "MT5"],
          instrumentsAllowed: ["Forex", "Indices", "Commodities"],
          minimumTradingDays: 5,
          timeToFunded: record['Payout Frequency'],
          scaling: {
            available: true,
            terms: "Contact for scaling details"
          },
          pros: [
            `${profitSplit}% profit split`,
            "Multiple account sizes",
            "Professional trading platform"
          ],
          cons: [
            "Limited educational resources",
            "Specific trading rules may apply",
            "Contact customer support for details"
          ]
        };
        
        // Insert the firm
        await pool.query(`
          INSERT INTO prop_firms (
            name, established, headquarters, website_url, logo_url, description,
            account_sizes, program_type, profit_targets, daily_loss, max_loss,
            profit_split, payout_frequency, loyalty_program, pricing,
            refund_policy, trading_platforms, instruments_allowed,
            minimum_trading_days, time_to_funded, scaling, pros, cons
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15,
            $16, $17, $18, $19, $20, $21, $22, $23
          )
        `, [
          firm.name, firm.established, firm.headquarters, firm.websiteUrl, 
          firm.logoUrl, firm.description, firm.accountSizes, firm.programType,
          firm.profitTargets, firm.dailyLoss, firm.maxLoss, firm.profitSplit,
          firm.payoutFrequency, firm.loyaltyProgram, JSON.stringify(firm.pricing),
          firm.refundPolicy, firm.tradingPlatforms, firm.instrumentsAllowed,
          firm.minimumTradingDays, firm.timeToFunded, JSON.stringify(firm.scaling),
          firm.pros, firm.cons
        ]);
        
        console.log(`Inserted new firm: ${firm.name}`);
      }
    }
    
    console.log('Import completed successfully');
  } catch (error) {
    console.error('Error importing data:', error);
  } finally {
    // Close the pool connection
    await pool.end();
  }
}

// Run the import
importPropFirms()
  .then(() => process.exit(0))
  .catch(error => {
    console.error('Unexpected error:', error);
    process.exit(1);
  });