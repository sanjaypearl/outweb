import { db } from "../server/db";
import { promotionEntries } from "../shared/schema";

async function pushPromotionsSchema() {
  console.log("Creating promotion_entries table...");
  
  try {
    // Push the schema to the database
    const createTable = await db.schema.createTable(promotionEntries).ifNotExists().execute();
    
    console.log("promotion_entries table created successfully!");
    
    // Exit with success
    process.exit(0);
  } catch (error) {
    console.error("Error creating promotion_entries table:", error);
    
    // Exit with error
    process.exit(1);
  }
}

// Run the function
pushPromotionsSchema();