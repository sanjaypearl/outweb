import { db } from '../server/db';
import { propFirms } from '../shared/schema';
import { eq } from 'drizzle-orm';

async function addAquaFunded() {
  try {
    // Check if AquaFunded already exists
    const existingFirms = await db.select().from(propFirms).where(eq(propFirms.name, 'AquaFunded'));
    
    if (existingFirms.length > 0) {
      console.log('AquaFunded already exists in the database');
      process.exit(0);
    }

    // Insert AquaFunded
    const [result] = await db.insert(propFirms).values({
      name: "AquaFunded",
      established: "2022",
      headquarters: "Unknown",
      websiteUrl: "https://aquafunded.com",
      logoUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREL01NC8B26ULUt08MQyvwCGpSSnEoYg9J7g&s",
      description: "AquaFunded offers traders a three-phase prop trading experience with 90% profit splits and multiple account tiers.",
      accountSizes: [25000, 10000],
      programType: "Three-Phase",
      profitTargets: [6, 6, 6],
      dailyLoss: 4,
      maxLoss: 8,
      profitSplit: 90,
      payoutFrequency: "14 Days",
      loyaltyProgram: true,
      pricing: [
        {
          price: 57,
          accountSize: 25000
        },
        {
          price: 3,
          accountSize: 10000
        }
      ],
      refundPolicy: "Contact for refund policy details.",
      tradingPlatforms: ["MT4", "MT5"],
      instrumentsAllowed: ["Forex", "Indices", "Commodities"],
      minimumTradingDays: 5,
      timeToFunded: "14 Days",
      scaling: {
        terms: "Contact for scaling details",
        available: true
      },
      pros: ["90% profit split", "Multiple account sizes", "Professional trading platform"],
      cons: ["Limited educational resources", "Specific trading rules may apply", "Contact customer support for details"],
      couponCode: "TFL",
      tags: ["Most Loved", "Best Value"],
      position: 2
    }).returning();

    console.log('Successfully added AquaFunded to the database', result);
  } catch (error) {
    console.error('Error adding AquaFunded:', error);
  } finally {
    process.exit(0);
  }
}

addAquaFunded();