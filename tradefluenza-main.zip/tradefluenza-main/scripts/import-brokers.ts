import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';
import { db } from '../server/db';
import { brokers } from '../shared/schema';
import { fileURLToPath } from 'url';

// Get the directory name in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface RawBrokerData {
  Broker: string;
  Country: string;
  'Years Active': string;
  Environment: string;
  Regulators: string;
  'Regulatory License Number': string;
  Score: string;
}

async function importBrokers() {
  try {
    console.log('Starting broker import process...');
    
    // Read the CSV file
    const csvFilePath = path.resolve(__dirname, '../attached_assets/broekr data - Sheet1.csv');
    const csvData = fs.readFileSync(csvFilePath, 'utf8');
    
    // Parse CSV data
    const records: RawBrokerData[] = parse(csvData, {
      columns: true,
      skip_empty_lines: true,
      from_line: 2, // Start from line 2 (skipping header)
    });
    
    console.log(`Found ${records.length} broker records`);
    
    // Process and clean the data
    const brokerData = [];
    
    for (let i = 0; i < records.length; i++) {
      const record = records[i];
      
      // Skip empty rows (rows with empty Broker field)
      if (!record.Broker) {
        continue;
      }
      
      // Process regulators field (split by comma and clean up)
      let regulatorsText = record.Regulators;
      if (regulatorsText.startsWith("Regulated in")) {
        // This is an additional information row, skip it
        continue;
      }
      
      // Extract regulator information
      const regulatorsList = regulatorsText.split(',')
        .map(item => item.trim())
        .filter(item => item.length > 0);
      
      // Create broker object
      const broker = {
        name: record.Broker,
        country: record.Country,
        yearsActive: record['Years Active'],
        environment: record.Environment,
        regulators: regulatorsList,
        regulatoryLicenseNumber: record['Regulatory License Number'] || null,
        score: parseFloat(record.Score) || 0,
        // Default values for optional fields
        logoUrl: `/brokers/${record.Broker.toLowerCase().replace(/\s+/g, '-')}.png`,
        websiteUrl: null,
        description: `${record.Broker} is a broker based in ${record.Country} that has been active for ${record['Years Active']}. It has a regulatory environment rating of ${record.Environment}.`,
        pros: [
          "Regulated by multiple authorities",
          "Strong security measures",
          "Competitive spreads"
        ],
        cons: [
          "Limited educational resources", 
          "Customer service can be slow at times"
        ],
        tags: []
      };
      
      // Add tags based on scores
      if (parseFloat(record.Score) >= 9.1) {
        broker.tags.push("Top Rated");
      }
      if (regulatorsList.length >= 2) {
        broker.tags.push("Most Regulated");
      }
      
      brokerData.push(broker);
    }
    
    console.log(`Processed ${brokerData.length} valid broker records`);
    
    // Insert into database
    const insertResult = await db.insert(brokers).values(brokerData).returning();
    
    console.log(`Successfully imported ${insertResult.length} brokers`);
    return insertResult;
    
  } catch (error) {
    console.error('Error importing brokers:', error);
    throw error;
  }
}

// Execute import function
importBrokers()
  .then(() => {
    console.log('Broker import complete');
    process.exit(0);
  })
  .catch(error => {
    console.error('Failed to import brokers:', error);
    process.exit(1);
  });