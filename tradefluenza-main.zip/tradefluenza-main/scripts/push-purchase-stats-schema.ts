import { db } from "../server/db";
import { sql } from "drizzle-orm";
import { insertPurchaseStatsSchema, purchaseStats } from "../shared/schema";

// Function to push the purchase stats schema to the database
async function pushPurchaseStatsSchema() {
  console.log("Starting purchase stats schema migration...");
  
  try {
    // Create purchase_stats table if it doesn't exist
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS purchase_stats (
        id SERIAL PRIMARY KEY,
        total_purchases INTEGER NOT NULL DEFAULT 0,
        this_month INTEGER NOT NULL DEFAULT 0,
        this_week INTEGER NOT NULL DEFAULT 0,
        today INTEGER NOT NULL DEFAULT 0,
        last_updated TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    
    console.log("Purchase stats table created successfully");
    
    // Check if any data exists in the table
    const existingStats = await db.select().from(purchaseStats);
    
    // If no data exists, insert initial stats
    if (existingStats.length === 0) {
      const initialData = {
        totalPurchases: 18427,
        thisMonth: 742,
        thisWeek: 187, 
        today: 34
      };
      
      try {
        await db.insert(purchaseStats).values(initialData);
        console.log("Initial purchase stats data inserted successfully");
      } catch (error) {
        console.error("Error inserting initial purchase stats data:", error);
      }
    } else {
      console.log("Purchase stats data already exists, skipping initialization");
    }
    
    console.log("Purchase stats schema migration completed successfully");
  } catch (error) {
    console.error("Error during purchase stats schema migration:", error);
    throw error;
  }
}

// Execute the migration
pushPurchaseStatsSchema()
  .then(() => {
    console.log("Schema migration completed successfully");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error during schema migration:", error);
    process.exit(1);
  });