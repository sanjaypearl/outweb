import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function updateTradingFirmsSchema() {
  console.log("Adding couponCode column to trading_firms table...");
  
  try {
    // Add the couponCode column if it doesn't exist
    await db.execute(sql`
      ALTER TABLE trading_firms
      ADD COLUMN IF NOT EXISTS coupon_code TEXT
    `);
    
    // Update existing records to set default coupon code
    await db.execute(sql`
      UPDATE trading_firms
      SET coupon_code = 'TFL'
      WHERE coupon_code IS NULL AND promo_discount IS NOT NULL
    `);
    
    console.log("Successfully updated trading_firms schema");
  } catch (error) {
    console.error("Error updating trading_firms schema:", error);
    throw error;
  }
}

updateTradingFirmsSchema().catch(console.error);