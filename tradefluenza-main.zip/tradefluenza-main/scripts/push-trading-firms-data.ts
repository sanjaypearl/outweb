import { db } from "../server/db";
import { tradingFirms } from "../shared/schema";

// This script inserts trading firms data into the database
async function pushTradingFirmsData() {
  console.log("Inserting trading firms data...");

  try {
    // Delete existing data first to avoid duplicates
    await db.delete(tradingFirms);
    
    // Sample trading firms data
    const firmsData = [
      {
        name: "Elite Capital Markets",
        rank: 1,
        reviewCount: 124,
        country: "United Kingdom",
        yearsInOperation: 7,
        assets: ["Forex", "Indices", "Commodities", "Stocks"],
        platforms: ["MT4", "MT5", "cTrader"],
        maxAllocations: 5000000,
        promo: "Free Trial",
        promoDiscount: 0,
        couponCode: null,
        logoUrl: "https://www.example.com/logos/elite-capital.png",
        websiteUrl: "https://www.elitecapitalmarkets.com",
        favoriteCount: 432,
        position: 1
      },
      {
        name: "GlobalX Trading",
        rank: 2,
        reviewCount: 96,
        country: "Singapore",
        yearsInOperation: 5,
        assets: ["Forex", "Crypto", "Commodities"],
        platforms: ["MT5", "Proprietary"],
        maxAllocations: 2500000,
        promo: "",
        promoDiscount: 15,
        couponCode: "TFL15",
        logoUrl: "https://www.example.com/logos/globalx.png",
        websiteUrl: "https://www.globalxtrading.com",
        favoriteCount: 387,
        position: 2
      },
      {
        name: "Quantum Finance",
        rank: 3,
        reviewCount: 78,
        country: "Switzerland",
        yearsInOperation: 10,
        assets: ["Forex", "Indices", "Bonds", "ETFs"],
        platforms: ["MT4", "MT5", "TradingView"],
        maxAllocations: 10000000,
        promo: "Premium Support",
        promoDiscount: 0,
        couponCode: null,
        logoUrl: "https://www.example.com/logos/quantum.png",
        websiteUrl: "https://www.quantumfinancepro.com",
        favoriteCount: 356,
        position: 3
      },
      {
        name: "FusionFX Capital",
        rank: 4,
        reviewCount: 62,
        country: "Australia",
        yearsInOperation: 4,
        assets: ["Forex", "Indices", "Commodities", "Crypto"],
        platforms: ["MT5", "cTrader"],
        maxAllocations: 1500000,
        promo: "",
        promoDiscount: 10,
        couponCode: "TFL10",
        logoUrl: "https://www.example.com/logos/fusionfx.png",
        websiteUrl: "https://www.fusionfxcapital.com",
        favoriteCount: 298,
        position: 4
      },
      {
        name: "Alpine Trading Group",
        rank: 5,
        reviewCount: 51,
        country: "Canada",
        yearsInOperation: 6,
        assets: ["Forex", "Commodities", "Equities"],
        platforms: ["MT4", "MT5"],
        maxAllocations: 2000000,
        promo: "Advanced Analytics",
        promoDiscount: 0,
        couponCode: null,
        logoUrl: "https://www.example.com/logos/alpine.png",
        websiteUrl: "https://www.alpinetradinggroup.com",
        favoriteCount: 276,
        position: 5
      },
      {
        name: "Meridian Capital",
        rank: 6,
        reviewCount: 45,
        country: "United States",
        yearsInOperation: 8,
        assets: ["Forex", "Futures", "Options"],
        platforms: ["Proprietary", "TradingView"],
        maxAllocations: 7500000,
        promo: "",
        promoDiscount: 5,
        couponCode: "TFL5",
        logoUrl: "https://www.example.com/logos/meridian.png",
        websiteUrl: "https://www.meridiancapital.com",
        favoriteCount: 245,
        position: 6
      },
      {
        name: "Nova Trading Solutions",
        rank: 7,
        reviewCount: 38,
        country: "Germany",
        yearsInOperation: 3,
        assets: ["Forex", "Indices", "Commodities"],
        platforms: ["MT5", "cTrader"],
        maxAllocations: 1000000,
        promo: "Fast Execution",
        promoDiscount: 0,
        couponCode: null,
        logoUrl: "https://www.example.com/logos/nova.png",
        websiteUrl: "https://www.novatradingsolutions.com",
        favoriteCount: 203,
        position: 7
      },
      {
        name: "Stellar Markets",
        rank: 8,
        reviewCount: 32,
        country: "Hong Kong",
        yearsInOperation: 5,
        assets: ["Forex", "Indices", "Crypto"],
        platforms: ["MT4", "MT5"],
        maxAllocations: 3000000,
        promo: "",
        promoDiscount: 20,
        couponCode: "TFL20",
        logoUrl: "https://www.example.com/logos/stellar.png",
        websiteUrl: "https://www.stellarmarkets.com",
        favoriteCount: 187,
        position: 8
      }
    ];
    
    // Insert each firm
    for (const firm of firmsData) {
      await db.insert(tradingFirms).values(firm);
    }
    
    console.log(`Successfully inserted ${firmsData.length} trading firms`);
  } catch (error) {
    console.error("Error inserting trading firms data:", error);
    throw error;
  }
}

// Run the function
pushTradingFirmsData()
  .then(() => {
    console.log("Trading firms data insertion completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed to insert trading firms data:", error);
    process.exit(1);
  });