import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import * as schema from "../shared/schema";
import ws from 'ws';

// Configure WebSocket for NeonDB
neonConfig.webSocketConstructor = ws;

// Ensure we have a database URL
if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set to push schema changes");
}

async function pushMentorsSchema() {
  console.log("🚀 Pushing mentors schema to database...");
  
  try {
    // Create a new pool and connection
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    const db = drizzle(pool, { schema });
    
    // Execute raw SQL to create tables
    // Create mentors table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS mentors (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        name TEXT NOT NULL,
        profile_image TEXT,
        bio TEXT NOT NULL,
        experience_years INTEGER NOT NULL,
        specialization mentor_specialization NOT NULL,
        experience_level experience_level NOT NULL,
        hourly_rate INTEGER NOT NULL,
        is_verified BOOLEAN DEFAULT FALSE,
        availability TEXT NOT NULL,
        languages TEXT NOT NULL,
        location TEXT,
        social_media TEXT,
        credentials TEXT,
        about TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Create mentor reviews table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS mentor_reviews (
        id SERIAL PRIMARY KEY,
        mentor_id INTEGER NOT NULL REFERENCES mentors(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        rating INTEGER NOT NULL,
        comment TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    // Create mentor sessions table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS mentor_sessions (
        id SERIAL PRIMARY KEY,
        mentor_id INTEGER NOT NULL REFERENCES mentors(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        date TIMESTAMP NOT NULL,
        duration INTEGER NOT NULL,
        price INTEGER NOT NULL,
        topic TEXT NOT NULL,
        notes TEXT,
        status session_status DEFAULT 'pending',
        payment_confirmed BOOLEAN DEFAULT FALSE,
        meeting_link TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    console.log("✅ Mentors schema successfully pushed to database!");
    
    // Close the pool
    await pool.end();
  } catch (error) {
    console.error("❌ Error pushing mentors schema to database:", error);
  }
}

// Create the enum types first
async function createEnumTypes() {
  console.log("Creating enum types...");
  
  try {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    
    // Create specialization enum
    await pool.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'mentor_specialization') THEN
          CREATE TYPE mentor_specialization AS ENUM (
            'forex', 'futures', 'stocks', 'crypto', 'options', 'algo_trading', 'risk_management', 'psychology'
          );
        END IF;
      END$$;
    `);
    
    // Create experience level enum
    await pool.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'experience_level') THEN
          CREATE TYPE experience_level AS ENUM (
            'beginner_friendly', 'intermediate', 'advanced', 'professional'
          );
        END IF;
      END$$;
    `);
    
    // Create session status enum
    await pool.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'session_status') THEN
          CREATE TYPE session_status AS ENUM (
            'pending', 'confirmed', 'completed', 'cancelled'
          );
        END IF;
      END$$;
    `);
    
    await pool.end();
    console.log("✅ Enum types created successfully!");
  } catch (error) {
    console.error("❌ Error creating enum types:", error);
    throw error;
  }
}

// Run the migration
async function run() {
  try {
    await createEnumTypes();
    await pushMentorsSchema();
    console.log("🎉 Database schema updated successfully!");
  } catch (error) {
    console.error("Failed to update database schema:", error);
    process.exit(1);
  }
}

run();