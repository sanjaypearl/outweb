import { db } from "../server/db";
import * as schema from "../shared/schema";

async function pushEventsSchema() {
  try {
    console.log("Creating events tables...");
    
    // Create the events table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS events (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        full_description TEXT NOT NULL,
        date TEXT NOT NULL,
        location TEXT NOT NULL,
        location_details TEXT,
        attendees TEXT,
        type TEXT NOT NULL,
        image_url TEXT,
        registration_url TEXT,
        speakers_list JSONB[],
        agenda JSONB[],
        is_premium BOOLEAN DEFAULT FALSE,
        price NUMERIC,
        max_attendees INTEGER,
        current_attendees INTEGER DEFAULT 0,
        date_created TIMESTAMP DEFAULT NOW() NOT NULL,
        date_updated TIMESTAMP DEFAULT NOW() NOT NULL,
        status TEXT DEFAULT 'Upcoming' NOT NULL,
        bg_class TEXT DEFAULT 'from-indigo-600 to-blue-600',
        featured BOOLEAN DEFAULT FALSE,
        organizer TEXT DEFAULT 'Tradefluenza'
      );
    `);
    
    // Create the event_registrations table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS event_registrations (
        id SERIAL PRIMARY KEY,
        event_id INTEGER NOT NULL REFERENCES events(id),
        user_id INTEGER REFERENCES users(id),
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone_number TEXT,
        registration_date TIMESTAMP DEFAULT NOW() NOT NULL,
        status TEXT DEFAULT 'Confirmed' NOT NULL,
        notes TEXT,
        payment_status TEXT,
        payment_amount NUMERIC,
        additional_info JSONB
      );
    `);
    
    console.log("Events tables created successfully!");
    
    // Insert sample data for events
    await db.execute(`
      INSERT INTO events (
        title, description, full_description, date, location, attendees, type, bg_class, featured
      ) VALUES 
      (
        'Tradefluenza Trading Meetup', 
        'Connect with fellow traders and prop firm representatives. Learn the latest strategies and network with industry experts.', 
        'Join us for an immersive two-day event focused on prop trading strategies, market analysis, and networking with industry experts. This event brings together traders of all experience levels to share insights, learn new techniques, and build valuable connections in the trading community.
        
        ### What to Expect
        
        - Expert presentations on market analysis and trading psychology
        - Panel discussions with successful prop traders
        - Hands-on workshops for various trading platforms
        - Networking sessions with prop firm representatives
        - Q&A opportunities with industry leaders
        
        ### Who Should Attend
        
        This event is perfect for both new and experienced traders looking to enhance their skills, connect with other professionals, and learn about the latest developments in prop trading.',
        'May 15-16, 2025',
        'New York City & Virtual',
        '500+ Traders',
        'Meetup',
        'from-indigo-600 to-blue-600',
        true
      ),
      (
        'Advanced Prop Trading Workshop', 
        'Deep dive into advanced trading techniques with our expert instructors. Hands-on sessions with real market scenarios.',
        'This intensive workshop is designed for traders who want to take their skills to the next level. Over the course of a full day, participants will engage in practical exercises, advanced strategy discussions, and real-time trading simulations led by professional traders with years of experience.
        
        ### Workshop Agenda
        
        - Advanced price action analysis techniques
        - Risk management for large account sizes
        - Order flow trading strategies
        - Market psychology and trading biases
        - Backtesting and strategy optimization
        
        ### Prerequisites
        
        Participants should have at least 6 months of active trading experience and familiarity with basic trading concepts. This workshop is focused on advanced techniques rather than trading fundamentals.',
        'June 8, 2025',
        'London',
        '200+ Traders',
        'Workshop',
        'from-purple-600 to-pink-600',
        true
      ),
      (
        'Trading Floor Virtual Tour', 
        'Get exclusive access to professional trading floors. See how institutional traders operate and learn their workflows.',
        'For the first time, we''re offering an exclusive virtual tour of multiple professional trading floors across the globe. This unique opportunity allows retail traders to see exactly how institutional trading operations function day-to-day, with detailed explanations of desk setups, trading technologies, and workflow processes.
        
        ### Virtual Tour Highlights
        
        - Live walkthrough of trading floors in New York, London, and Singapore
        - Overview of multi-screen desk setups and trading technologies
        - Q&A sessions with floor traders and technical staff
        - Demonstrations of proprietary trading tools and platforms
        - Insights into team communication and decision-making processes
        
        ### Technical Requirements
        
        Participants will need a stable internet connection capable of streaming video content and a device with audio capabilities. The tour will be hosted via a secure streaming platform with access instructions provided upon registration.',
        'July 2, 2025',
        'Online Exclusive',
        '1000+ Participants',
        'Virtual',
        'from-fuchsia-600 to-violet-600',
        true
      );
    `);
    
    console.log("Sample events data inserted successfully!");
    
  } catch (error) {
    console.error("Error creating events schema:", error);
  } finally {
    process.exit(0);
  }
}

pushEventsSchema();