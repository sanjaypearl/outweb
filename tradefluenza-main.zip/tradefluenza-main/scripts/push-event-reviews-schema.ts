import { db } from "../server/db";
import { eventReviews } from "../shared/schema";
import { sql } from "drizzle-orm";

async function pushEventReviewsSchema() {
  console.log("Starting event reviews schema migration...");

  try {
    // Create event_reviews table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "event_reviews" (
        "id" SERIAL PRIMARY KEY,
        "event_id" INTEGER NOT NULL REFERENCES "events"("id"),
        "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
        "rating" NUMERIC NOT NULL,
        "title" VARCHAR(100) NOT NULL,
        "content" TEXT NOT NULL,
        "highlights" TEXT[],
        "improvements" TEXT[],
        "date_posted" TIMESTAMP DEFAULT NOW() NOT NULL,
        "is_verified" BOOLEAN DEFAULT false,
        "would_recommend" BOOLEAN DEFAULT true
      );
    `);

    console.log("Event reviews table created successfully");
    
    // Manually test if we can insert a review
    try {
      await db.insert(eventReviews).values({
        eventId: 1, // Make sure this event ID exists
        userId: 1, // Make sure this user ID exists
        rating: 5,
        title: "Amazing trading workshop!",
        content: "This workshop provided incredible value and insights into trading strategies.",
        highlights: ["Great speakers", "Interactive sessions", "Networking opportunities"],
        improvements: ["Could be longer"],
        wouldRecommend: true
      });
      console.log("Test review inserted successfully");
    } catch (error) {
      console.log("Error inserting test review (this may be expected if IDs don't exist):", error);
    }

    console.log("Event reviews schema migration completed successfully");
  } catch (error) {
    console.error("Error during migration:", error);
    process.exit(1);
  }
}

pushEventReviewsSchema().catch(console.error);