import { db } from "../server/db";
import { tradingFirms } from "../shared/schema";
import { drizzle } from "drizzle-orm/neon-serverless";
import { neon } from "@neondatabase/serverless";
import { migrate } from "drizzle-orm/neon-http/migrator";

// This script creates the trading_firms table in the database
async function pushTradingFirmsSchema() {
  console.log("Creating trading_firms table...");

  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not defined");
  }

  const sql = neon(process.env.DATABASE_URL);
  const db = drizzle(sql);

  try {
    // Create trading_firms table
    await sql`
      CREATE TABLE IF NOT EXISTS trading_firms (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        rank INTEGER,
        review_count INTEGER,
        country TEXT,
        years_in_operation INTEGER,
        assets TEXT[],
        platforms TEXT[],
        max_allocations INTEGER,
        promo TEXT,
        promo_discount INTEGER,
        logo_url TEXT,
        website_url TEXT,
        favorite_count INTEGER,
        position INTEGER,
        date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;
    
    console.log("Successfully created trading_firms table");
  } catch (error) {
    console.error("Error creating trading_firms table:", error);
    throw error;
  }
}

// Run the function
pushTradingFirmsSchema()
  .then(() => {
    console.log("Trading firms schema creation completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed to create trading firms schema:", error);
    process.exit(1);
  });