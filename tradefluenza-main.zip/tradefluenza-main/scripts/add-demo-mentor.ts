import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import * as schema from "../shared/schema";
import ws from 'ws';
import { mentors, mentorReviews, users } from '../shared/schema';
import { eq } from 'drizzle-orm';

// Configure WebSocket for NeonDB
neonConfig.webSocketConstructor = ws;

// Ensure we have a database URL
if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set to add demo mentor");
}

async function addDemoMentor() {
  console.log("🚀 Adding demo mentor to database...");
  
  try {
    // Create a new pool and connection
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    const db = drizzle(pool, { schema });
    
    // Check if we have a demo user to associate with the mentor
    const demoUser = await db.select().from(users).where(eq(users.username, 'demo')).limit(1);
    
    let userId: number;
    
    if (demoUser.length === 0) {
      // Create a demo user if one doesn't exist
      console.log("Creating demo user...");
      const [user] = await db.insert(users).values({
        username: 'demo',
        password: 'hashed_password', // In a real app, this would be properly hashed
        email: 'demo@tradefluenza.com',
        name: 'Demo User',
        role: 'user',
      }).returning();
      
      userId = user.id;
    } else {
      userId = demoUser[0].id;
    }
    
    // Check if we already have a demo mentor
    const existingMentor = await db.select().from(mentors).where(eq(mentors.name, 'Alex Thompson')).limit(1);
    
    if (existingMentor.length > 0) {
      console.log("Demo mentor already exists!");
      return;
    }
    
    // Insert demo mentor
    const [mentor] = await db.insert(mentors).values({
      userId: userId,
      name: 'Alex Thompson',
      profileImage: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80',
      bio: 'Professional Forex and Futures trader with 8+ years of experience and a proven track record.',
      experience: 8, // 8 years
      specialization: 'forex',
      experienceLevel: 'professional',
      hourlyRate: 150, // $150 per hour
      isVerified: true,
      availability: JSON.stringify({
        monday: ['9:00-12:00', '13:00-17:00'],
        tuesday: ['9:00-12:00', '13:00-17:00'],
        wednesday: ['9:00-12:00', '13:00-17:00'],
        thursday: ['9:00-12:00', '13:00-17:00'],
        friday: ['9:00-12:00', '13:00-15:00'],
        saturday: [],
        sunday: []
      }),
      languages: 'English,Spanish',
      location: 'United States',
      socialMedia: JSON.stringify({
        twitter: 'https://twitter.com/alexthompson',
        linkedin: 'https://linkedin.com/in/alexthompson',
        instagram: 'https://instagram.com/alexthompsontrader'
      }),
      credentials: JSON.stringify({
        certifications: ['Certified Financial Analyst (CFA)', 'Professional Forex Trader'],
        education: ['MBA Finance, Harvard Business School']
      }),
      about: `
        I'm Viraj chaudhary  creattoe ar tradefluenxa com . Thompson, a professional Forex and Futures trader with over 8 years of experience in the financial markets. I specialize in technical analysis, price action trading, and risk management strategies.
        
        My trading journey began in 2015 when I left my corporate job to pursue trading full-time. After two challenging years of consistent losses and learning, I developed a reliable strategy that has allowed me to achieve consistent profitability.
        
        My teaching approach emphasizes building strong fundamentals, understanding market psychology, and developing personalized trading plans tailored to your lifestyle and risk tolerance. I believe that successful trading is 80% psychology and 20% strategy.
        
        As your mentor, I'll help you:
        - Develop a customized trading strategy
        - Master risk management techniques
        - Overcome psychological barriers
        - Build trading discipline
        - Analyze market conditions effectively
        
        Whether you're a beginner looking to start your trading journey or an experienced trader wanting to refine your strategy, I'm here to help you achieve your financial goals through trading.
      `
    }).returning();
    
    console.log(`Created mentor: ${mentor.name} (ID: ${mentor.id})`);
    
    // Add some sample reviews
    await db.insert(mentorReviews).values([
      {
        mentorId: mentor.id,
        userId: userId,
        rating: 5,
        comment: "Alex completely transformed my trading. His personalized approach and emphasis on psychology helped me overcome my biggest challenges. Highly recommended!"
      },
      {
        mentorId: mentor.id,
        userId: userId,
        rating: 5,
        comment: "One of the best investments I've made in my trading career. Alex's risk management strategies alone were worth every penny."
      },
      {
        mentorId: mentor.id,
        userId: userId,
        rating: 4,
        comment: "Great mentor with practical strategies. I appreciated his honest feedback and realistic approach to trading as a business."
      }
    ]);
    
    console.log("Added sample reviews for the mentor");
    
    console.log("✅ Demo mentor successfully added to database!");
    
    // Close the pool
    await pool.end();
  } catch (error) {
    console.error("❌ Error adding demo mentor to database:", error);
  }
}

// Run the function
addDemoMentor()
  .then(() => console.log("🎉 Demo data added successfully!"))
  .catch(error => console.error("Failed to add demo data:", error));