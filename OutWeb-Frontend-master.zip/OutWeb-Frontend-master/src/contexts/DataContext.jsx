import React, { createContext, useContext, useState } from "react";

const DataContext = createContext();

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
};

// Dummy form questions
const formQuestions = [
  {
    id: 1,
    section: "personal",
    question: "Full Name",
    type: "text",
    required: true,
  },
  {
    id: 2,
    section: "personal",
    question: "Email Address",
    type: "email",
    required: true,
  },
  {
    id: 3,
    section: "personal",
    question: "Phone Number",
    type: "tel",
    required: true,
  },
  {
    id: 4,
    section: "business",
    question: "Business Name",
    type: "text",
    required: true,
  },
  {
    id: 5,
    section: "business",
    question: "Business Registration Number",
    type: "text",
    required: true,
  },
  {
    id: 6,
    section: "business",
    question: "Business Type",
    type: "select",
    options: [
      "Tour Operator",
      "Hotel",
      "Restaurant",
      "Transport Service",
      "Other",
    ],
    required: true,
  },
  {
    id: 7,
    section: "finance",
    question: "Bank Name",
    type: "text",
    required: true,
  },
  {
    id: 8,
    section: "finance",
    question: "Account Number",
    type: "text",
    required: true,
  },
  {
    id: 9,
    section: "finance",
    question: "Routing Number",
    type: "text",
    required: true,
  },
  {
    id: 10,
    section: "establishment",
    question: "Physical Address",
    type: "textarea",
    required: true,
  },
  {
    id: 11,
    section: "establishment",
    question: "Years in Operation",
    type: "number",
    required: true,
  },
  {
    id: 12,
    section: "offerings",
    question: "Services Offered",
    type: "checkbox",
    options: [
      "Tours",
      "Accommodation",
      "Transportation",
      "Food & Beverage",
      "Activities",
    ],
    required: true,
  },
];

export const DataProvider = ({ children }) => {
  const [eois, setEois] = useState([]);
  const [users, setUsers] = useState([]);
  const [formSubmissions, setFormSubmissions] = useState([]);
  const [agreements, setAgreements] = useState([]);

  const submitEOI = (eoiData) => {
    const newEOI = {
      id: Date.now(),
      ...eoiData,
      status: "pending",
      createdAt: new Date().toISOString(),
    };
    setEois((prev) => [...prev, newEOI]);
    return newEOI;
  };

  const createUser = (userData) => {
    const newUser = {
      id: Date.now(),
      ...userData,
      createdAt: new Date().toISOString(),
      status: "active",
    };
    setUsers((prev) => [...prev, newUser]);
    return newUser;
  };

  const saveFormProgress = (userId, formId, responses) => {
    const submission = {
      id: Date.now(),
      userId,
      formId,
      responses,
      status: "draft",
      lastSaved: new Date().toISOString(),
    };

    setFormSubmissions((prev) => {
      const existing = prev.findIndex(
        (s) => s.userId === userId && s.formId === formId
      );
      if (existing >= 0) {
        const updated = [...prev];
        updated[existing] = { ...updated[existing], ...submission };
        return updated;
      }
      return [...prev, submission];
    });

    return submission;
  };

  const submitForm = (submissionId) => {
    setFormSubmissions((prev) =>
      prev.map((s) =>
        s.id === submissionId
          ? { ...s, status: "submitted", submittedAt: new Date().toISOString() }
          : s
      )
    );

    // Create agreement
    const submission = formSubmissions.find((s) => s.id === submissionId);
    if (submission) {
      const agreement = {
        id: Date.now(),
        userId: submission.userId,
        submissionId,
        status: "pending_signature",
        createdAt: new Date().toISOString(),
        docusignStatus: "sent",
      };
      setAgreements((prev) => [...prev, agreement]);
    }
  };

  const updateDocuSignStatus = (agreementId, status) => {
    setAgreements((prev) =>
      prev.map((a) =>
        a.id === agreementId
          ? {
              ...a,
              docusignStatus: status,
              updatedAt: new Date().toISOString(),
            }
          : a
      )
    );
  };

  const value = {
    formQuestions,
    eois,
    users,
    formSubmissions,
    agreements,
    submitEOI,
    createUser,
    saveFormProgress,
    submitForm,
    updateDocuSignStatus,
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};
