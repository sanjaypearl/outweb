import { createSlice } from "@reduxjs/toolkit";
import { loadProgressFromStorage } from "../Actions/formActions";

const defaultState = {
  currentSection: 0,

  partA: {
    A1: "",
    A2: "",
    A3: "",
    A4: "",
    A5: "",
    A6: "",
    A7: "",
    A8: "",
    A9: "",
    Q1: "",
    A10: "",
    A11: "",
    A12: "",
    A13: "",
    A14: "",
    A15: "",
    A16: "",
    A17: "",
    A18: "",
    A19: "",
  },
  partB: {
    Q2: "1", // "1" | "2" | "3"
    establishments: [
      {
        tradingName: "",
        address: "",
        description: "",
        diffWebsite: "No",
        businessUrl: "",
        businessActivity: "",
        otherActivity: "",
        bookingUrl: "",
        phone: "",
        email: "",
      },
      {
        tradingName: "",
        address: "",
        description: "",
        diffWebsite: "No",
        businessUrl: "",
        businessActivity: "",
        otherActivity: "",
        bookingUrl: "",
        phone: "",
        email: "",
      },
      {
        tradingName: "",
        address: "",
        description: "",
        diffWebsite: "No",
        businessUrl: "",
        businessActivity: "",
        otherActivity: "",
        bookingUrl: "",
        phone: "",
        email: "",
      },
    ],
  },
  partC: {
    experiences: [
      {
        add: "No",
        C1: "",
        C2: "",
        C3: "",
        C4: "",
        C5: "",
        C6: "",
        C7: "",
        C8: "No",
        C9: "",
        C10: "",
        C11: "",
      },
      {
        add: "No",
        C12: "",
        C13: "",
        C14: "",
        C15: "",
        C16: "",
        C17: "",
        C18: "",
        C19: "No",
        C20: "",
        C21: "",
        C22: "",
      },
      {
        add: "No",
        C23: "",
        C24: "",
        C25: "",
        C26: "",
        C27: "",
        C28: "",
        C29: "",
        C30: "No",
        C31: "",
        C32: "",
        C33: "",
      },
    ],
  },
  partD: {
    establishments: [
      { accept: "No", D1: "", D2: "" },
      { accept: "No", D3: "", D4: "" },
      { accept: "No", D5: "", D6: "" },
    ],
  },
  partE: {
    Q13: "No",
    activities: [
      {
        enabled: false,
        E1: "",
        E2: "",
        E3: "",
        E4: "",
        E5: "",
        E6: "",
        E7: "",
        E8: "",
        E9: "",
        E10: "",
        E11: "",
      },
      {
        enabled: false,
        E12: "",
        E13: "",
        E14: "",
        E15: "",
        E16: "",
        E17: "",
        E18: "",
        E19: "",
        E20: "",
        E21: "",
        E22: "",
      },
      {
        enabled: false,
        E23: "",
        E22b: "",
        E23b: "",
        E24: "",
        E25: "",
        E26: "",
        E27: "",
        E28: "",
        E29: "",
        E30: "",
        E31: "",
      },
    ],
  },
};

const persisted = loadProgressFromStorage();
const initialState = persisted || defaultState;

const formSlice = createSlice({
  name: "form",
  initialState,
  reducers: {
    setCurrentSection(state, action) {
      state.currentSection = action.payload;
    },

    updatePartA(state, action) {
      Object.assign(state.partA, action.payload);
    },

    setNumberOfEstablishments(state, action) {
      state.partB.Q2 = String(action.payload);
    },
    updateEstablishment(state, action) {
      const { index, changes } = action.payload; // 0..2
      Object.assign(state.partB.establishments[index], changes);
    },

    updateExperience(state, action) {
      const { index, changes } = action.payload; // 0..2
      Object.assign(state.partC.experiences[index], changes);
    },

    updateTastingCredit(state, action) {
      const { index, changes } = action.payload; // 0..2
      Object.assign(state.partD.establishments[index], changes);
    },

    setActivitiesEnabled(state, action) {
      state.partE.Q13 = action.payload ? "Yes" : "No";
    },
    updateActivity(state, action) {
      const { index, changes } = action.payload; // 0..2
      Object.assign(state.partE.activities[index], changes);
    },

    resetForm() {
      return defaultState;
    },
  },
});

export const {
  setCurrentSection,
  updatePartA,
  setNumberOfEstablishments,
  updateEstablishment,
  updateExperience,
  updateTastingCredit,
  setActivitiesEnabled,
  updateActivity,
  resetForm,
} = formSlice.actions;

export default formSlice.reducer;
