import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";

// 🔹 Import your reducers (example: auth, user)
import authReducer from "./Slices/authSlice";
import formReducer from "./Slices/formSlice";

const persistConfig = {
  key: "OUT_WEB",
  version: 1,
  storage,
};

const rootReducer = combineReducers({
  auth: authReducer,
  form: formReducer,
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ["persist/PERSIST", "persist/REHYDRATE"],
      },
    }),
});

const persistor = persistStore(store);

export { store, persistor };
