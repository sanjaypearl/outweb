import { createAsyncThunk } from "@reduxjs/toolkit";
import { axiosInstance } from "../../constant/axiosinstance";

// export const loginUser = createAsyncThunk(
//   "auth/login",
//   async ({ username, password }, { rejectWithValue }) => {
//     try {
//       const { data } = await axiosInstance.post(
//         "/auth",
//         {
//           username,
//           password,
//         },
//         { withCredentials: true }
//       ); // ⬅️ to handle cookies

//       if (!data.success) {
//         return rejectWithValue(data.message || "Login failed");
//       }

//       return data.data; // success response
//     } catch (error) {
//       return rejectWithValue(
//         error.response?.data?.message || "Something went wrong"
//       );
//     }
//   }
// );

export const loginUser = createAsyncThunk(
  "auth/login",
  async ({ username, password }, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post(
        "/auth",
        { username, password },
        { withCredentials: true }
      );

      if (!data.success) {
        return rejectWithValue(data.message || "Login failed");
      }

      return {
        user: data.data, // 👈 normalize
        token: data.token || null, // only if backend sends a token
      };
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const fetchUsers = createAsyncThunk(
  "users/fetchUsers",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get("/users"); // <-- adjust API route
      return data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch users"
      );
    }
  }
);

export const createUser = createAsyncThunk(
  "users/createUser",
  async (userData, { rejectWithValue }) => {
    console.log("userfata", userData);
    try {
      const { data } = await axiosInstance.post("/users", userData, {
        withCredentials: true,
      }); // <-- Adjust API route
      return data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to create user"
      );
    }
  }
);

export const deleteUser = createAsyncThunk(
  "users/deleteUser",
  async (username, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.delete("/users", {
        data: { username },
      });

      return { username, message: data.message };
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to delete user"
      );
    }
  }
);
