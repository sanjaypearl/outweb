import { createAsyncThunk } from "@reduxjs/toolkit";
import { axiosInstance } from "../../constant/axiosinstance";

export const createForm = createAsyncThunk(
  "forms/createForm",
  async (formData, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post("/v1/form", formData, {
        withCredentials: true,
      });

      if (!data.success) {
        return rejectWithValue(data.message || "Failed to create form");
      }

      return data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getAllForms = createAsyncThunk(
  "forms/getAllForms",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get("/v1/form", {
        withCredentials: true,
      });
      return data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch forms"
      );
    }
  }
);

export const assignFormToUsers = createAsyncThunk(
  "forms/assignFormToUsers",
  async ({ formId, userId }, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post(
        "/v1/form/assign",
        { formId, userId },
        { withCredentials: true }
      );

      if (data?.success || data?.message?.toLowerCase().includes("success")) {
        return {
          success: true,
          message: data.message || "Form assigned successfully",
          data: data.data || null,
        };
      }

      return rejectWithValue({
        success: false,
        message: data?.message || "Failed to assign form",
      });
    } catch (error) {
      return rejectWithValue({
        success: false,
        message: error.response?.data?.message || "Something went wrong",
      });
    }
  }
);

export const getDocuSignEnvelopes = createAsyncThunk(
  "docusign/getDocuSignEnvelopes",
  async (queryParams = {}, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get("/v1/form/envelopes", {
        params: queryParams,        // Pass query params here
        withCredentials: true,
      });

      if (data?.envelopes) {
        return {
          success: true,
          message: data.message || "Envelopes fetched successfully",
          data: data.envelopes,
        };
      }

      return rejectWithValue({
        success: false,
        message: data?.message || "Failed to fetch envelopes",
      });
    } catch (error) {
      return rejectWithValue({
        success: false,
        message: error.response?.data?.message || "Something went wrong",
      });
    }
  }
);

export const getDocuSignDocument = createAsyncThunk(
  "docusign/getDocuSignDocument",
  async ({ envelopeId, documentId }, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get(
        `/v1/form/documents/${envelopeId}/${documentId}`,
        { withCredentials: true }
      );

      if (data) {
        return {
          success: true,
          message: data.message || "Document fetched successfully",
          data: data, // or data.document depending on API response structure
        };
      }

      return rejectWithValue({
        success: false,
        message: data?.message || "Failed to fetch document",
      });
    } catch (error) {
      return rejectWithValue({
        success: false,
        message: error.response?.data?.message || "Something went wrong",
      });
    }
  }
);

export const getAssignedForms = createAsyncThunk(
  "forms/getAssignedForms",
  async (userId, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get(`/v1/form/${userId}`, {
        withCredentials: true,
      });
      return data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch assigned forms"
      );
    }
  }
);

export const submitFormResponse = createAsyncThunk(
  "forms/submitFormResponse",
  async (responseData, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post(
        "/v1/form/submitresponse",
        responseData,
        {
          withCredentials: true,
        }
      );

      if (!data.success) {
        return rejectWithValue(data.message || "Failed to submit form");
      }

      return data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const fetchUsers = createAsyncThunk(
  "users/fetchUsers",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get("/users", {
        withCredentials: true,
      });
      return data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch users"
      );
    }
  }
);

export const loadProgressFromStorage = (formId) => {
  try {
    const raw = localStorage.getItem(`form_progress_${formId}`);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    console.warn("[form] Failed to load:", e);
    return null;
  }
};

export const saveProgressToStorage = (formId, responses) => {
  try {
    localStorage.setItem(`form_progress_${formId}`, JSON.stringify(responses));
  } catch (e) {
    console.warn("[form] Failed to persist:", e);
  }
};
