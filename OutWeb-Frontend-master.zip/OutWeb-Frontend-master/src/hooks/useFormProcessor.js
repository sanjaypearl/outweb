"use client";

import { useState, useEffect } from "react";
import { processExcelFormData } from "../utils/formConfigProcessor";

/**
 * Custom hook to process form data and generate constants
 * @param {Array} formsData - Array of forms from API
 * @returns {Object} - Processed form data and utilities
 */
export const useFormProcessor = (formsData) => {
  const [processedData, setProcessedData] = useState(null);
  const [constants, setConstants] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!formsData || !Array.isArray(formsData)) {
      setProcessedData(null);
      setConstants({});
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const processed = processExcelFormData(formsData);

      if (processed) {
        setProcessedData(processed);
        setConstants(processed.constants || {});

        // Debug logs
        console.log("✅ Generated Form Constants:", processed.constants);
        console.log("📄 Constants File Content:", processed.constantsFileContent);
        console.log("🗂️ Processed Forms:", processed.forms);
      }
    } catch (err) {
      console.error("❌ Error processing form data:", err);
      setError(err.message || "Failed to process form data");
    } finally {
      setLoading(false);
    }
  }, [formsData]);

  // ---------- Constant helpers ----------
  const getBookingMethods = () =>
    constants.bookingMethodOptions || ["Phone", "Email", "Rezdy"];

  const getTastingCreditMax = () =>
    constants.tastingCreditMaxOptions || ["10", "15", "20"];

  const getYesNo = () => constants.yesNo || ["Yes", "No"];

  const getBusinessActivities = () =>
    constants.businessActivityOptions || [
      "Winery",
      "Brewery",
      "Restaurant",
      "Primary Producer",
      "Bakery",
      "Other",
    ];

  return {
    processedData,
    constants,
    loading,
    error,
    // Specific getters
    bookingMethods: getBookingMethods(),
    tastingCreditMax: getTastingCreditMax(),
    yesNo: getYesNo(),
    businessActivities: getBusinessActivities(),
    // Generic utils
    getConstant: (name) => constants?.[name] || [],
    hasConstant: (name) => Boolean(constants?.[name]),
  };
};

export const countFields = (formData) => {
  let count = 0;

  if (!formData?.fields?.parts) return 0;

  formData.fields.parts.forEach((part) => {
    console.log("part is",part)
    if (Array.isArray(part.fields)) {
      count += part.fields.length;
    }

    if (Array.isArray(part.subParts)) {
      part.subParts.forEach((sub) => {
        if (Array.isArray(sub.fields)) {
          count += sub.fields.length;
        }
      });
    }
  });
  console.log("total is ",count)
  return count;
};

