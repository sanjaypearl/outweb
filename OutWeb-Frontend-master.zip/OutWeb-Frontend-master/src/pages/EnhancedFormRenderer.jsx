
import React, { useState, useEffect } from "react";
import toast from "react-hot-toast";

const EnhancedFormRenderer = ({ formData, onSubmit, onSave, isSubmitting }) => {
  const [formValues, setFormValues] = useState({});
  const [errors, setErrors] = useState({});

  // Initialize form values from localStorage or default to null
  useEffect(() => {
    const savedProgress = localStorage.getItem(`form_progress_${formData.id}`);
    if (savedProgress) {
      setFormValues(JSON.parse(savedProgress));
    }
  }, [formData.id]);

  // Handle input changes for fields
  const handleInputChange = (ref, value) => {
    setFormValues((prev) => ({
      ...prev,
      [ref]: value,
    }));
    // Clear error for the field when user starts typing
    setErrors((prev) => ({
      ...prev,
      [ref]: "",
    }));
  };

  // Validate form before submission
  const validateForm = () => {
    const newErrors = {};
    formData.fields.parts.forEach((part) => {
      // Validate top-level part fields
      part.fields.forEach((field) => {
        if (!formValues[field.ref] && field.type !== "radio") {
          newErrors[field.ref] = `${field.label} is required`;
        }
        // Validate conditional fields
        if (field.conditions && formValues[field.ref]) {
          field.conditions.forEach((condition) => {
            if (
              formValues[field.ref] === condition.conditionOption &&
              !formValues[condition.ref]
            ) {
              newErrors[condition.ref] = `${condition.label} is required`;
            }
          });
        }
      });
      // Validate subPart fields
      part.subParts?.forEach((subPart) => {
        subPart.fields.forEach((field) => {
          if (!formValues[field.ref] && field.type !== "radio") {
            newErrors[field.ref] = `${field.label} is required`;
          }
          // Validate conditional fields
          if (field.conditions && formValues[field.ref]) {
            field.conditions.forEach((condition) => {
              if (
                formValues[field.ref] === condition.conditionOption &&
                !formValues[condition.ref]
              ) {
                newErrors[condition.ref] = `${condition.label} is required`;
              }
            });
          }
        });
      });
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      // Build structured JSON
      const submission = {
        termsAndConditions: formData.fields.termsAndConditions || "",
        parts: formData.fields.parts.map((part) => ({
          partName: part.partName,
          termsAndConditions: part.termsAndConditions || "",
          fields: part.fields.map((field) => ({
            name: field.label,
            value: formValues[field.ref] || "",
            ref: field.ref,
          })),
          subParts:
            part.subParts?.map((subPart) => ({
              subPartName: subPart.subPartName,
              termsAndConditions: subPart.termsAndConditions || "",
              fields: subPart.fields.map((field) => ({
                name: field.label,
                value: formValues[field.ref] || "",
                ref: field.ref,
              })),
            })) || [],
        })),
      };

      onSubmit(submission);
    } else {
      toast.error("Please fill out all required fields.");
    }
  };

  // Handle form save
  const handleSave = () => {
    localStorage.setItem(
      `form_progress_${formData.id}`,
      JSON.stringify(formValues)
    );
    onSave(formValues);
    toast.success("Progress saved!");
  };

  // Render a single field
  const renderField = (field) => {
    switch (field.type) {
      case "text":
        return (
          <div key={field.ref} className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {field.label}
            </label>
            <input
              type="text"
              value={formValues[field.ref] || ""}
              onChange={(e) => handleInputChange(field.ref, e.target.value)}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                errors[field.ref] ? "border-red-500" : "border-gray-300"
              }`}
              disabled={isSubmitting}
            />
            {errors[field.ref] && (
              <p className="text-red-500 text-xs mt-1">{errors[field.ref]}</p>
            )}
          </div>
        );
      case "radio":
        return (
          <div key={field.ref} className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {field.label}
            </label>
            <div className="flex space-x-4">
              {field.options.map((option) => (
                <label key={option} className="flex items-center">
                  <input
                    type="radio"
                    name={field.ref}
                    value={option}
                    checked={formValues[field.ref] === option}
                    onChange={(e) =>
                      handleInputChange(field.ref, e.target.value)
                    }
                    className="mr-2 focus:ring-indigo-500"
                    disabled={isSubmitting}
                  />
                  {option}
                </label>
              ))}
            </div>
            {errors[field.ref] && (
              <p className="text-red-500 text-xs mt-1">{errors[field.ref]}</p>
            )}
            {/* Render conditional fields */}
            {field.conditions && formValues[field.ref] && (
              <div className="ml-6 mt-2">
                {field.conditions
                  .filter(
                    (condition) =>
                      condition.conditionOption === formValues[field.ref]
                  )
                  .map((condition) => (
                    <div key={condition.ref} className="mb-4">
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        {condition.label}
                      </label>
                      <input
                        type="text"
                        value={formValues[condition.ref] || ""}
                        onChange={(e) =>
                          handleInputChange(condition.ref, e.target.value)
                        }
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                          errors[condition.ref]
                            ? "border-red-500"
                            : "border-gray-300"
                        }`}
                        disabled={isSubmitting}
                      />
                      {errors[condition.ref] && (
                        <p className="text-red-500 text-xs mt-1">
                          {errors[condition.ref]}
                        </p>
                      )}
                    </div>
                  ))}
              </div>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2 className="text-xl font-bold text-gray-900 mb-4">{formData.name}</h2>
      {formData.fields.termsAndConditions && (
        <div className="mb-6 p-4 bg-gray-50 rounded-md">
          <h3 className="text-sm font-medium text-gray-700 mb-2">
            Form Terms and Conditions
          </h3>
          <div
            className="text-sm text-gray-600"
            dangerouslySetInnerHTML={{
              __html: formData.fields.termsAndConditions,
            }}
          />
        </div>
      )}
      {formData.fields.parts.map((part, partIndex) => (
        <div key={partIndex} className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            {part.partName}
          </h3>
          {part.termsAndConditions && (
            <div className="mb-4 p-4 bg-gray-50 rounded-md">
              <h4 className="text-sm font-medium text-gray-700 mb-2">
                Part Terms and Conditions
              </h4>
              <div
                className="text-sm text-gray-600"
                dangerouslySetInnerHTML={{ __html: part.termsAndConditions }}
              />
            </div>
          )}
          {part.fields.map((field) => renderField(field))}
          {part.subParts?.map((subPart, subPartIndex) => (
            <div key={subPartIndex} className="ml-4 mb-4">
              <h4 className="text-md font-medium text-gray-800 mb-2">
                {subPart.subPartName}
              </h4>
              {subPart.termsAndConditions && (
                <div className="mb-4 p-4 bg-gray-50 rounded-md">
                  <h5 className="text-sm font-medium text-gray-700 mb-2">
                    SubPart Terms and Conditions
                  </h5>
                  <div
                    className="text-sm text-gray-600"
                    dangerouslySetInnerHTML={{
                      __html: subPart.termsAndConditions,
                    }}
                  />
                </div>
              )}
              {subPart.fields.map((field) => renderField(field))}
            </div>
          ))}
        </div>
      ))}
      <div className="flex justify-end space-x-4">
        <button
          type="button"
          onClick={handleSave}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
          disabled={isSubmitting}
        >
          Save Progress
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
          disabled={isSubmitting}
        >
          {isSubmitting ? "Submitting..." : "Submit Form"}
        </button>
      </div>
    </form>
  );
};

export default EnhancedFormRenderer;
