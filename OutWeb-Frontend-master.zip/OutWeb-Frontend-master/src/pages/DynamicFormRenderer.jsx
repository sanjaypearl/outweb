import { useState, useEffect, useCallback } from "react";

const DynamicFormRenderer = ({ formData, onSubmit, onSave }) => {
  const [responses, setResponses] = useState({});
  const [visibleFields, setVisibleFields] = useState(new Set());

  const calculateFieldVisibility = useCallback(
    (field, currentResponses) => {
      if (!field.command || Object.keys(field.command).length === 0) {
        return true;
      }

      for (const controllerField of formData.fields) {
        if (
          controllerField.command &&
          Object.keys(controllerField.command).length > 0
        ) {
          const controllerValue = String(currentResponses[controllerField.ref]);
          if (
            controllerValue &&
            controllerField.command[controllerValue] &&
            controllerField.command[controllerValue].includes(field.ref)
          ) {
            return true;
          }
        }
      }

      return false;
    },
    [formData]
  );

  useEffect(() => {
    if (!formData?.fields) return;

    const initialResponses = {};
    const loadedProgress = localStorage.getItem(`form_progress_${formData.id}`);
    let previousResponses = {};

    if (loadedProgress) {
      try {
        previousResponses = JSON.parse(loadedProgress);
      } catch (e) {
        console.error("Failed to parse saved form progress:", e);
      }
    }

    formData.fields.forEach((field) => {
      initialResponses[field.ref] =
        previousResponses[field.ref] !== undefined
          ? previousResponses[field.ref]
          : field.value !== undefined
          ? field.value
          : "";
    });

    setResponses(initialResponses);

    const newVisibleFields = new Set();
    formData.fields.forEach((field) => {
      if (calculateFieldVisibility(field, initialResponses)) {
        newVisibleFields.add(field.ref);
      }
    });
    setVisibleFields(newVisibleFields);
  }, [formData, calculateFieldVisibility]);

  useEffect(() => {
    if (!formData?.fields || Object.keys(responses).length === 0) return;

    const newVisibleFields = new Set();
    formData.fields.forEach((field) => {
      if (calculateFieldVisibility(field, responses)) {
        newVisibleFields.add(field.ref);
      }
    });
    setVisibleFields(newVisibleFields);
  }, [responses, formData, calculateFieldVisibility]);

  const handleFieldChange = (fieldRef, value) => {
    setResponses((prevResponses) => ({
      ...prevResponses,
      [fieldRef]: value,
    }));
  };

  const renderField = (field) => {
    const value =
      responses[field.ref] !== undefined ? responses[field.ref] : "";

    const displayValue = field.type === "boolean" ? String(value) : value;

    switch (field.type) {
      case "text":
      case "email":
        return (
          <input
            type={field.type}
            value={displayValue}
            onChange={(e) => handleFieldChange(field.ref, e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder={`Enter ${field.label.toLowerCase()}`}
          />
        );

      case "textarea":
        return (
          <textarea
            value={displayValue}
            onChange={(e) => handleFieldChange(field.ref, e.target.value)}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder={`Enter ${field.label.toLowerCase()}`}
          />
        );

      case "select":
        return (
          <select
            value={displayValue}
            onChange={(e) => handleFieldChange(field.ref, e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">Select an option...</option>
            {field.options?.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        );

      case "radio":
        return (
          <div className="space-y-2">
            {field.options?.map((option) => (
              <label key={option} className="flex items-center">
                <input
                  type="radio"
                  name={field.ref}
                  value={option}
                  checked={displayValue === option}
                  onChange={(e) => handleFieldChange(field.ref, e.target.value)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">{option}</span>
              </label>
            ))}
          </div>
        );

      case "boolean":
        return (
          <div className="space-y-2">
            <label className="flex items-center">
              <input
                type="radio"
                name={field.ref}
                value="true"
                checked={displayValue === "true"}
                onChange={(e) => handleFieldChange(field.ref, e.target.value)}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
              />
              <span className="ml-2 text-sm text-gray-700">Yes</span>
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                name={field.ref}
                value="false"
                checked={displayValue === "false"}
                onChange={(e) => handleFieldChange(field.ref, e.target.value)}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
              />
              <span className="ml-2 text-sm text-gray-700">No</span>
            </label>
          </div>
        );

      case "number":
        return (
          <input
            type="number"
            value={displayValue}
            onChange={(e) => handleFieldChange(field.ref, e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder={`Enter ${field.label.toLowerCase()}`}
          />
        );

      case "date":
        return (
          <input
            type="date"
            value={displayValue}
            onChange={(e) => handleFieldChange(field.ref, e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        );

      default:
        return (
          <input
            type="text"
            value={displayValue}
            onChange={(e) => handleFieldChange(field.ref, e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder={`Enter ${field.label.toLowerCase()}`}
          />
        );
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const visibleResponses = {};
    Array.from(visibleFields).forEach((fieldRef) => {
      if (responses[fieldRef] !== undefined) {
        visibleResponses[fieldRef] = responses[fieldRef];
      }
    });

    onSubmit(visibleResponses);
  };

  const handleSaveProgress = () => {
    const visibleResponses = {};
    Array.from(visibleFields).forEach((fieldRef) => {
      if (responses[fieldRef] !== undefined) {
        visibleResponses[fieldRef] = responses[fieldRef];
      }
    });

    onSave(visibleResponses);
  };

  if (!formData?.fields || formData.fields.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No form fields defined.
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        {formData.name || "Form"}
      </h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        {formData.fields.map((field) => (
          <div
            key={field.ref}
            className={
              visibleFields.has(field.ref) ? "block space-y-2" : "hidden"
            }
          >
            <label className="block text-sm font-medium text-gray-700">
              {field.label}
              {field.type === "boolean" && (
                <span className="text-gray-500 ml-1">(Yes/No)</span>
              )}
            </label>
            {renderField(field)}
          </div>
        ))}

        <div className="flex justify-between pt-6">
          <button
            type="button"
            onClick={handleSaveProgress}
            className="px-4 py-2 text-indigo-600 bg-indigo-100 rounded hover:bg-indigo-200"
          >
            Save Progress
          </button>
          <button
            type="submit"
            className="px-6 py-2 text-white bg-indigo-600 rounded hover:bg-indigo-700"
          >
            Submit Form
          </button>
        </div>
      </form>
    </div>
  );
};

export default DynamicFormRenderer;
