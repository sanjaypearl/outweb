export const businessActivities = [
  "Winery",
  "Brewery",
  "Restaurant",
  "Primary Producer",
  "Bakery",
  "Other",
];

export const bookingMethods = ["Phone", "Email", "Rezdy"];

export const tastingCreditMax = ["10", "15", "20"];

export const yesNo = ["Yes", "No"];

// Tiny helper to show fields only when establishment count allows
export const estEnabled = (q2Value, index) => {
  const count = Number.parseInt(q2Value || "1", 10);
  return index < count;
};
