import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  createUser,
  deleteUser,
  fetchUsers,
} from "../feature/Actions/authAction";
import {
  getAllForms,
  createForm,
  assignFormToUsers,
  getDocuSignEnvelopes,
} from "../feature/Actions/formActions";
import DeleteModal from "../components/deleteModal";
import { logout } from "../feature/Slices/authSlice";
import toast from "react-hot-toast";
import FormBuilder from "./FormBuilder";
import FormAssignment from "./FormAssignment";

const AdminDashboard = () => {
  const { users } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState("users");
  const [showCreateUser, setShowCreateUser] = useState(false);
  const [showFormBuilder, setShowFormBuilder] = useState(false);
  const [showFormAssignment, setShowFormAssignment] = useState(false);
  const [forms, setForms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [envelopes, setEnvelopes] = useState([]);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [showPdfModal, setShowPdfModal] = useState(false);
  const [filters, setFilters] = useState({
    status: "",
    fromDate: "",
    toDate: "",
    search: "",
  });

  const [newUser, setNewUser] = useState({
    name: "",
    username: "",
    password: "",
  });
  const [selectedUser, setSelectedUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const eois = [
    {
      id: 1,
      name: "Alice",
      company: "Tech Corp",
      email: "alice@test.com",
      serviceType: "Consulting",
      status: "pending",
    },
    {
      id: 2,
      name: "Bob",
      company: "Biz Ltd",
      email: "bob@test.com",
      serviceType: "Software",
      status: "active",
    },
  ];

  const formSubmissions = [
    { id: 1, userId: "U1", status: "submitted", lastSaved: new Date() },
    { id: 2, userId: "U2", status: "draft", lastSaved: new Date() },
  ];

  const fetchForms = async () => {
    try {
      setLoading(true);
      const result = await dispatch(getAllForms());
      if (result.payload && result.payload.data) {
        setForms(result.payload.data);
      }
    } catch (error) {
      console.error("Error fetching forms:", error);
      toast.error("Failed to fetch forms");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateForm = async (formData) => {
    try {
      setLoading(true);
      const result = await dispatch(createForm(formData));

      if (result.payload && result.payload.success) {
        toast.success("Form created successfully!");
        setShowFormBuilder(false);
        fetchForms();
      } else {
        toast.error(result.payload?.message || "Failed to create form");
      }
    } catch (error) {
      console.error("Error creating form:", error);
      toast.error("Failed to create form");
    } finally {
      setLoading(false);
    }
  };

  const handleAssignForm = async (formId, userId) => {
    try {
      const result = await dispatch(assignFormToUsers({ formId, userId }));

      if (result.payload && result.payload.success) {
        toast.success("Form assigned successfully!");
        setShowFormAssignment(false);
      } else {
        throw new Error(result.payload?.message || "Failed to assign form");
      }
    } catch (error) {
      console.error("Error assigning form:", error);
      toast.error(error.message || "Failed to assign form");
      throw error;
    }
  };

  const handleDeleteForm = async (formId) => {
    if (!confirm("Are you sure you want to delete this form?")) return;

    try {
      const { axiosInstance } = await import("../constant/axiosinstance");
      const { data } = await axiosInstance.delete(`/forms/${formId}`, {
        withCredentials: true,
      });

      if (data.success) {
        toast.success("Form deleted successfully!");
        fetchForms();
      } else {
        toast.error("Failed to delete form");
      }
    } catch (error) {
      console.error("Error deleting form:", error);
      toast.error("Failed to delete form");
    }
  };

  const handleViewDocument = async (documentUrl) => {
    try {
      setLoading(true);
      const response = await fetch(documentUrl, {
        method: "GET",
        credentials: "include", // Include cookies for authentication
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setPdfUrl(url);
      setShowPdfModal(true);
    } catch (error) {
      console.error("Error fetching document:", error);
      toast.error("Failed to fetch document");
    } finally {
      setLoading(false);
    }
  };

  const fetchEnvelopes = async () => {
    try {
      setLoading(true);
      const queryParams = {};
      if (filters.status) queryParams.status = filters.status;
      if (filters.fromDate) queryParams.fromDate = filters.fromDate;
      if (filters.toDate) queryParams.toDate = filters.toDate;
      if (filters.search) queryParams.search = filters.search;

      const result = await dispatch(getDocuSignEnvelopes(queryParams));
      console.log("result is",result)
      if (result.payload && result.payload.data) {
        console.log("result is",result.payload.data)
        setEnvelopes(result.payload.data); // Use envelopes from response
      } else {
        toast.error(result.payload?.message || "Failed to fetch envelopes");
      }
    } catch (error) {
      console.error("Error fetching envelopes:", error);
      toast.error("Something went wrong while fetching envelopes");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    dispatch(fetchUsers());
    fetchForms();
    fetchEnvelopes();
  }, [dispatch]);

  useEffect(() => {
    if (activeTab === "agreements") {
      fetchEnvelopes();
    }
  }, [filters, activeTab]);

  const handleLogout = () => {
    dispatch(logout());
    toast.success("You have logged out successfully!");
    navigate("/login");
  };

  const handleCreateUser = (e) => {
    e.preventDefault();
    dispatch(createUser(newUser)).then((res) => {
      if (res.payload && res.payload.success) {
        dispatch(fetchUsers());
      }
    });
    setNewUser({ name: "", username: "", password: "" });
    setShowCreateUser(false);
  };

  const handleDelete = (username) => {
    setSelectedUser(username);
    setIsModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (selectedUser) {
      dispatch(deleteUser(selectedUser));
    }
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "1":
      case "pending":
      case "sent":
        return "bg-yellow-100 text-yellow-800";
      case "0":
      case "completed":
      case "active":
        return "bg-green-100 text-green-800";
      case "submitted":
        return "bg-blue-100 text-blue-800";
      case "draft":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <h1 className="text-2xl font-bold text-gray-900">
              Admin Dashboard
            </h1>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowCreateUser(true)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Create User
              </button>
              <button
                onClick={() => setShowFormBuilder(true)}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Create Form
              </button>
              <button
                onClick={() => setShowFormAssignment(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Assign Form
              </button>
              <button
                onClick={handleLogout}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white shadow rounded-lg">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8 px-6">
              {[
                { id: "eois", name: "EOIs", count: eois.length },
                { id: "users", name: "Users", count: users?.length || 0 },
                { id: "forms", name: "Forms", count: forms.length },
                {
                  id: "submissions",
                  name: "Submissions",
                  count: formSubmissions.length,
                },
                {
                  id: "agreements",
                  name: "Agreements",
                  count: envelopes?.length || 0,
                },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? "border-indigo-500 text-indigo-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {tab.name} ({tab.count})
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === "eois" && (
              <div className="overflow-x-auto">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  EOIs (Dummy Data)
                </h3>
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        Company
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        Service
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {eois.map((eoi) => (
                      <tr key={eoi.id}>
                        <td className="px-6 py-4">{eoi.name}</td>
                        <td className="px-6 py-4">{eoi.company}</td>
                        <td className="px-6 py-4">{eoi.email}</td>
                        <td className="px-6 py-4">{eoi.serviceType}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(
                              eoi.status
                            )}`}
                          >
                            {eoi.status.toUpperCase()}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === "users" && (
              <div className="overflow-x-auto">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Users
                </h3>
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50 text-center">
                    <tr>
                      <th className="px-6 py-3 text-xs font-medium text-gray-500 text-center">
                        Name
                      </th>
                      <th className="px-6 py-3 text-xs font-medium text-gray-500 text-center">
                        Email
                      </th>
                      <th className="px-6 py-3 text-xs font-medium text-gray-500 text-center">
                        Status
                      </th>
                      <th className="px-6 py-3 text-xs font-medium text-gray-500 text-center">
                        Created
                      </th>
                      <th className="px-6 py-3 text-xs font-medium text-gray-500 text-center">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200 text-center">
                    {users?.map((user) => (
                      <tr key={user.id}>
                        <td className="px-6 py-4">{user.name}</td>
                        <td className="px-6 py-4">{user.username}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              user.is_active == 1
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {user.is_active == 1 ? "ACTIVE" : "INACTIVE"}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(user.created_at).toLocaleDateString("en-GB", {
                            day: "2-digit",
                            month: "short",
                            year: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => handleDelete(user.username)}
                            className="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1 rounded-md"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === "forms" && (
              <div className="overflow-x-auto">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Forms Management
                </h3>
                {loading ? (
                  <div className="text-center py-4">Loading forms...</div>
                ) : forms.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <p>No forms created yet.</p>
                    <button
                      onClick={() => setShowFormBuilder(true)}
                      className="mt-2 text-indigo-600 hover:text-indigo-800"
                    >
                      Create your first form
                    </button>
                  </div>
                ) : (
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Form Name
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Fields Count
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Created
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {forms.map((form) => (
                        <tr key={form.id}>
                          <td className="px-6 py-4 font-medium text-gray-900">
                            {form.name || `Form ${form.id}`}
                          </td>
                          <td className="px-6 py-4 text-gray-500">
                            {JSON.parse(form.data || "[]").length} fields
                          </td>
                          <td className="px-6 py-4 text-gray-500">
                            {new Date(form.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 space-x-2">
                            <button
                              onClick={() => {
                                console.log("Preview form:", form);
                              }}
                              className="text-indigo-600 hover:text-indigo-800 text-sm"
                            >
                              Preview
                            </button>
                            <button
                              onClick={() => handleDeleteForm(form.id)}
                              className="text-red-600 hover:text-red-800 text-sm"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {activeTab === "submissions" && (
              <div className="overflow-x-auto">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Form Submissions (Dummy Data)
                </h3>
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        User ID
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                        Last Updated
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {formSubmissions.map((sub) => (
                      <tr key={sub.id}>
                        <td className="px-6 py-4">{sub.userId}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(
                              sub.status
                            )}`}
                          >
                            {sub.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          {new Date(sub.lastSaved).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === "agreements" && (
              <div className="overflow-x-auto">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Agreements (DocuSign)
                </h3>
                <div className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <select
                      name="status"
                      value={filters.status}
                      onChange={handleFilterChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    >
                      <option value="">All Statuses</option>
                      <option value="sent">Sent</option>
                      <option value="completed">Completed</option>
                      <option value="voided">Voided</option>
                      <option value="created">Created</option>
                      <option value="declined">Declined</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      From Date
                    </label>
                    <input
                      type="date"
                      name="fromDate"
                      value={filters.fromDate}
                      onChange={handleFilterChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      To Date
                    </label>
                    <input
                      type="date"
                      name="toDate"
                      value={filters.toDate}
                      onChange={handleFilterChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Search
                    </label>
                    <input
                      type="text"
                      name="search"
                      value={filters.search}
                      onChange={handleFilterChange}
                      placeholder="Search by email or name"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                </div>
                {loading ? (
                  <div className="text-center py-4">Loading agreements...</div>
                ) : envelopes?.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <p>No agreements found.</p>
                  </div>
                ) : (
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Envelope ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Created
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">
                          Documents
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {envelopes.map((envelope) => (
                        <tr key={envelope.envelopeId}>
                          <td className="px-6 py-4">{envelope.envelopeId}</td>
                          <td className="px-6 py-4">
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(
                                envelope.status
                              )}`}
                            >
                              {envelope.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            {new Date(envelope.sentDate).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 space-x-2">
                            {envelope.documents.length === 0 ? (
                              <span className="text-gray-500 text-sm">
                                No documents
                              </span>
                            ) : (
                              envelope.documents.map((doc) => (
                                <button
                                  key={doc.documentId}
                                  onClick={() => handleViewDocument(doc.url)}
                                  className="text-indigo-600 hover:text-indigo-800 text-sm block"
                                >
                                  {doc.name}
                                </button>
                              ))
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {showCreateUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white rounded-2xl shadow-xl p-8 w-[400px] relative">
            <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">
              Create New User
            </h3>
            <form onSubmit={handleCreateUser} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={newUser.name}
                  onChange={(e) =>
                    setNewUser({ ...newUser, name: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="Enter full name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  required
                  value={newUser.username}
                  onChange={(e) =>
                    setNewUser({ ...newUser, username: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="Enter email"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={newUser.password}
                  onChange={(e) =>
                    setNewUser({ ...newUser, password: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="Enter password"
                />
              </div>
              <div className="flex justify-end gap-3 pt-6">
                <button
                  type="button"
                  onClick={() => setShowCreateUser(false)}
                  className="px-5 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showFormBuilder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <FormBuilder
              onSave={handleCreateForm}
              onCancel={() => setShowFormBuilder(false)}
            />
          </div>
        </div>
      )}

      {showFormAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <FormAssignment
              forms={forms}
              users={users || []}
              onAssign={handleAssignForm}
              onCancel={() => setShowFormAssignment(false)}
            />
          </div>
        </div>
      )}

      {showPdfModal && pdfUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto relative">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-medium text-gray-900">View Document</h3>
              <button
                onClick={() => {
                  setShowPdfModal(false);
                  setPdfUrl(null);
                  URL.revokeObjectURL(pdfUrl); // Clean up Blob URL
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                Close
              </button>
            </div>
            <div className="p-4">
              <iframe
                src={pdfUrl}
                className="w-full h-[80vh]"
                title="DocuSign Document"
              />
            </div>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={handleConfirmDelete}
        itemName={selectedUser}
      />
    </div>
  );
};

export default AdminDashboard;