import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { logout } from "../feature/Slices/authSlice";
import { useData } from "../contexts/DataContext";
import {
  getAssignedForms,
  submitFormResponse,
} from "../feature/Actions/formActions";
import { useFormProcessor,countFields } from "../hooks/useFormProcessor";
import EnhancedFormRenderer from "./EnhancedFormRenderer";
import toast from "react-hot-toast";

const UserDashboard = () => {
  const { user } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { formSubmissions, agreements } = useData();

  const [assignedForms, setAssignedForms] = useState([]);

  const [selectedForm, setSelectedForm] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false); // New state for form submission loading

  console.log("selected form is", selectedForm);
  const {
    processedData,
    constants,
    bookingMethods,
    tastingCreditMax,
    yesNo,
    businessActivities,
    loading: processingLoading,
    error: processingError,
  } = useFormProcessor(assignedForms);

  const userSubmissions = user
    ? formSubmissions.filter((s) => s.userId === user.id)
    : [];
  const userAgreements = user
    ? agreements.filter((a) => a.userId === user.id)
    : [];

  const fetchAssignedForms = async () => {
    if (!user?.id) {
      navigate("/login");
      return;
    }

    try {
      setLoading(true);
      const result = await dispatch(getAssignedForms(user.id));

      if (result.payload && result.payload.forms) {
        setAssignedForms(result.payload.forms);
      }
    } catch (error) {
      console.error("Error fetching assigned forms:", error);
      toast.error("Failed to fetch assigned forms");
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = async (formId, responses) => {
    if (!user?.id) {
      toast.error("User not logged in.");
      navigate("/login");
      return;
    }

    try {
      setIsSubmitting(true); // Set submitting state
      const result = await dispatch(
        submitFormResponse({
          userId: user.id,
          formId: formId,
          responses: JSON.stringify(responses),
        })
      );

      if (result.payload && result.payload.success) {
        toast.success("Form submitted successfully!");
        setSelectedForm(null);
        setShowSuccessPopup(true);
        fetchAssignedForms();
      } else {
        toast.error(result.payload?.message || "Failed to submit form");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      toast.error("Failed to submit form");
    } finally {
      setIsSubmitting(false); // Reset submitting state
    }
  };

  const handleFormSave = async (formId, responses) => {
    localStorage.setItem(`form_progress_${formId}`, JSON.stringify(responses));
    toast.success("Progress saved!");
  };

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "draft":
        return "bg-yellow-100 text-yellow-800";
      case "submitted":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getDocuSignStatusColor = (status) => {
    switch (status) {
      case "sent":
        return "bg-blue-100 text-blue-800";
      case "signed":
        return "bg-green-100 text-green-800";
      case "declined":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  useEffect(() => {
    if (user) {
      fetchAssignedForms();
    } else {
      navigate("/login");
    }
  }, [user, navigate]);

  useEffect(() => {
    if (constants && Object.keys(constants).length > 0) {
      console.log("=== Generated Form Constants (User Dashboard) ===");
      console.log("bookingMethods:", bookingMethods);
      console.log("tastingCreditMax:", tastingCreditMax);
      console.log("yesNo:", yesNo);
      console.log("businessActivities:", businessActivities);
      console.log("All constants:", constants);
    }
  }, [constants, bookingMethods, tastingCreditMax, yesNo, businessActivities]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full animate-pulse"></div>
          <p className="text-gray-600">Loading user data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                User Dashboard
              </h1>
              <p className="text-gray-600">Welcome back, {user?.name}</p>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">{user?.company}</span>
              <button
                onClick={handleLogout}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {processingLoading && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-3"></div>
              <span className="text-blue-800">
                Processing form configurations...
              </span>
            </div>
          </div>
        )}

        {processingError && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-800">
              Error processing forms: {processingError}
            </p>
          </div>
        )}

        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Assigned Forms ({assignedForms.length})
          </h2>
          <div className="bg-white shadow rounded-lg overflow-hidden">
            {loading ? (
              <div className="p-6 text-center text-gray-500">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                Loading assigned forms...
              </div>
            ) : assignedForms.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                <svg
                  className="w-12 h-12 mx-auto mb-4 text-gray-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  ></path>
                </svg>
                <p>No forms assigned to you yet.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Form Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fields
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Assigned Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {assignedForms.map((form) => (
                      <tr key={form.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {form.name || `Form ${form.id}`}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {countFields(assignedForms)} fields
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              form.name?.toLowerCase().includes("supplier")
                                ? "bg-blue-100 text-blue-800"
                                : form.name?.toLowerCase().includes("sachin")
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {form.name?.toLowerCase().includes("supplier")
                              ? "Supplier Agreement"
                              : form.name?.toLowerCase().includes("sachin")
                              ? "Sachins Agreement"
                              : "Other"}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(form.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => setSelectedForm(form)}
                            className="text-indigo-600 hover:text-indigo-900 mr-4 font-medium"
                          >
                            Fill Form
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Quick Actions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              to="/dashboard"
              className="bg-indigo-600 hover:bg-indigo-700 text-white p-6 rounded-lg text-center transition duration-200"
            >
              <div className="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                  ></path>
                </svg>
              </div>
              <h3 className="font-semibold mb-1">Start New Form</h3>
              <p className="text-sm opacity-90">Begin a new form process</p>
            </Link>

            <div className="bg-white border-2 border-dashed border-gray-300 p-6 rounded-lg text-center">
              <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg
                  className="w-6 h-6 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  ></path>
                </svg>
              </div>
              <h3 className="font-semibold mb-1 text-gray-600">Need Help?</h3>
              <p className="text-sm text-gray-500">
                Contact support via WhatsApp
              </p>
            </div>

            <div className="bg-white border-2 border-dashed border-gray-300 p-6 rounded-lg text-center">
              <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg
                  className="w-6 h-6 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  ></path>
                </svg>
              </div>
              <h3 className="font-semibold mb-1 text-gray-600">
                View Templates
              </h3>
              <p className="text-sm text-gray-500">Browse available forms</p>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Your Submissions ({userSubmissions.length})
          </h2>
          <div className="bg-white shadow rounded-lg overflow-hidden">
            {userSubmissions.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                <svg
                  className="w-12 h-12 mx-auto mb-4 text-gray-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  ></path>
                </svg>
                <p>
                  No submissions yet. Start by filling out an assigned form.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Form Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Last Updated
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {userSubmissions.map((submission) => (
                      <tr key={submission.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          Submission for Form {submission.formId}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(
                              submission.status
                            )}`}
                          >
                            {submission.status.replace("_", " ").toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(submission.lastSaved).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {submission.status === "draft" ? (
                            <Link
                              to={`/form/${submission.formId}`}
                              className="text-indigo-600 hover:text-indigo-900 mr-4"
                            >
                              Continue
                            </Link>
                          ) : (
                            <Link
                              to={`/review/${submission.id}`}
                              className="text-indigo-600 hover:text-indigo-900 mr-4"
                            >
                              View
                            </Link>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Your Agreements ({userAgreements.length})
          </h2>
          <div className="bg-white shadow rounded-lg overflow-hidden">
            {userAgreements.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                <svg
                  className="w-12 h-12 mx-auto mb-4 text-gray-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  ></path>
                </svg>
                <p>
                  No agreements yet. Complete a form to generate your first
                  agreement.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Agreement Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        DocuSign Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {userAgreements.map((agreement) => (
                      <tr key={agreement.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          Supplier Agreement
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getDocuSignStatusColor(
                              agreement.docusignStatus
                            )}`}
                          >
                            {agreement.docusignStatus
                              .replace("_", " ")
                              .toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(agreement.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <Link
                            to={`/docusign/${agreement.id}`}
                            className="text-indigo-600 hover:text-indigo-900 mr-4"
                          >
                            View Status
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {selectedForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full max-h-[95vh] overflow-y-auto relative">
              <div className="p-4 border-b border-gray-200 flex justify-between items-center sticky top-0 bg-white z-10">
                <h3 className="text-lg font-medium text-gray-900">
                  {selectedForm.name || `Form ${selectedForm.id}`}
                </h3>
                <button
                  onClick={() => setSelectedForm(null)}
                  className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100"
                  disabled={isSubmitting}
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M6 18L18 6M6 6l12 12"
                    ></path>
                  </svg>
                </button>
              </div>
              <div className="p-4">
                {isSubmitting && (
                  <div className="absolute inset-0 bg-white/80 flex items-center justify-center z-20">
                    <div className="flex flex-col items-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mb-4"></div>
                      <p className="text-blue-800 text-sm font-medium">
                        Submitting form...
                      </p>
                    </div>
                  </div>
                )}
                <EnhancedFormRenderer
                  formData={selectedForm}
                  onSubmit={(responses) =>
                    handleFormSubmit(selectedForm.id, responses)
                  }
                  onSave={(responses) =>
                    handleFormSave(selectedForm.id, responses)
                  }
                  isSubmitting={isSubmitting} // Pass submitting state to EnhancedFormRenderer
                />
              </div>
            </div>
          </div>
        )}

        {showSuccessPopup && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
            <div className="bg-white rounded-2xl shadow-xl p-8 w-[400px] relative">
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                Submission Successful
              </h3>
              <p className="text-sm text-gray-700 mb-6">
                Tasting Trails will review all information submitted and will be
                in contact within the next 5 business days. If accepted, your
                information will form part of your Partner Agreement which will
                be sent to you electronically for digital signature. Thank you
                for your support and we look forward to working with you and
                your team.
              </p>
              <div className="flex justify-center">
                <button
                  onClick={() => setShowSuccessPopup(false)}
                  className="px-5 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition"
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserDashboard;
