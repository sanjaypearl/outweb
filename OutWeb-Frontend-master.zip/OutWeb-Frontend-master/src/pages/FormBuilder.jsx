import { useState } from "react";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";

const FormBuilder = ({ onSave, onCancel }) => {
  const [formName, setFormName] = useState("");
  const [termsAndConditions, setTermsAndConditions] = useState("");
  const [parts, setParts] = useState([]);
  const [currentPart, setCurrentPart] = useState("");
  const [currentSubPart, setCurrentSubPart] = useState("");
  const [selectedParentPartIndex, setSelectedParentPartIndex] = useState(null);
  const [currentField, setCurrentField] = useState({
    ref: "",
    label: "",
    type: "text",
    options: [],
    command: { type: "", value: "" },
    conditions: [],
  });
  const [previewValues, setPreviewValues] = useState({});

  const fieldTypes = [
    { value: "text", label: "Text Input" },
    { value: "textarea", label: "Text Area" },
    { value: "select", label: "Select Dropdown" },
    { value: "radio", label: "Radio Buttons" },
    { value: "boolean", label: "Yes/No Question" },
    { value: "number", label: "Number Input" },
    { value: "date", label: "Date Input" },
    { value: "email", label: "Email Input" },
    { value: "prompt", label: "Prompt/Instruction" },
  ];

  const addPart = () => {
    if (!currentPart.trim()) {
      alert("Please enter a part name");
      return;
    }
    setParts([...parts, { partName: currentPart.trim(), subParts: [], fields: [], termsAndConditions: "" }]);
    setCurrentPart("");
  };

  const addSubPart = () => {
    if (selectedParentPartIndex === null) {
      alert("Please select a parent part");
      return;
    }
    if (!currentSubPart.trim()) {
      alert("Please enter a sub-part name");
      return;
    }
    const updatedParts = [...parts];
    updatedParts[selectedParentPartIndex].subParts.push({
      subPartName: currentSubPart.trim(),
      fields: [],
      termsAndConditions: "",
    });
    setParts(updatedParts);
    setCurrentSubPart("");
  };

  const updatePartTerms = (partIndex, terms) => {
    const updatedParts = [...parts];
    updatedParts[partIndex].termsAndConditions = terms;
    setParts(updatedParts);
  };

  const updateSubPartTerms = (partIndex, subPartIndex, terms) => {
    const updatedParts = [...parts];
    updatedParts[partIndex].subParts[subPartIndex].termsAndConditions = terms;
    setParts(updatedParts);
  };

  const removePart = (partIndex) => {
    if (window.confirm("Are you sure you want to remove this part?")) {
      setParts(parts.filter((_, i) => i !== partIndex));
      setPreviewValues((prev) => {
        const newValues = { ...prev };
        Object.keys(newValues).forEach((key) => {
          if (key.startsWith(`${partIndex}-`)) delete newValues[key];
        });
        return newValues;
      });
    }
  };

  const removeSubPart = (partIndex, subPartIndex) => {
    if (window.confirm("Are you sure you want to remove this sub-part?")) {
      const updatedParts = [...parts];
      updatedParts[partIndex].subParts.splice(subPartIndex, 1);
      setParts(updatedParts);
      setPreviewValues((prev) => {
        const newValues = { ...prev };
        Object.keys(newValues).forEach((key) => {
          if (key.startsWith(`${partIndex}-${subPartIndex}-`)) delete newValues[key];
        });
        return newValues;
      });
    }
  };

  const addField = (partIndex, subPartIndex = null) => {
    if (currentField.type !== "prompt" && (!currentField.ref.trim() || !currentField.label.trim())) {
      alert("Please fill in both reference and label");
      return;
    }
    if (currentField.type === "prompt" && !currentField.label.trim()) {
      alert("Please fill in the content");
      return;
    }
    const updatedParts = [...parts];
    const targetFields = subPartIndex !== null 
      ? updatedParts[partIndex].subParts[subPartIndex].fields 
      : updatedParts[partIndex].fields;
    targetFields.push({
      ...currentField,
      ref: currentField.type === "prompt" ? "" : currentField.ref,
      value: null,
    });
    setParts(updatedParts);
    setCurrentField({
      ref: "",
      label: "",
      type: "text",
      options: [],
      command: { type: "", value: "" },
      conditions: [],
    });
  };

  const removeField = (partIndex, fieldIndex, subPartIndex = null) => {
    const updatedParts = [...parts];
    const targetFields = subPartIndex !== null 
      ? updatedParts[partIndex].subParts[subPartIndex].fields 
      : updatedParts[partIndex].fields;
    targetFields.splice(fieldIndex, 1);
    setParts(updatedParts);
    setPreviewValues((prev) => {
      const newValues = { ...prev };
      const key = subPartIndex !== null 
        ? `${partIndex}-${subPartIndex}-${fieldIndex}` 
        : `${partIndex}-${fieldIndex}`;
      delete newValues[key];
      return newValues;
    });
  };

  const addOption = () => {
    const option = prompt("Enter option value (e.g., Delhi, Noida, Mumbai):");
    if (option && option.trim() !== "") {
      setCurrentField({
        ...currentField,
        options: [...(currentField.options || []), option.trim()],
      });
    }
  };

  const addConditionalField = (option) => {
    const newField = {
      ref: "",
      label: "",
      type: "text",
      options: [],
      conditionOption: option,
    };
    const conditionalField = prompt(`Enter label for conditional field (e.g., 'Question for ${option}'):`);
    if (conditionalField && conditionalField.trim()) {
      newField.label = conditionalField.trim();
      newField.ref = prompt("Enter reference ID for this conditional field (e.g., B1):") || "";
      newField.type = prompt("Enter field type (text, number, etc.):") || "text";
      setCurrentField({
        ...currentField,
        conditions: [...(currentField.conditions || []), newField],
      });
    }
  };

  const handleCommandChange = (key, value) => {
    setCurrentField({
      ...currentField,
      command: {
        ...currentField.command,
        [key]: value,
      },
    });
  };

  const handlePreviewInput = (partIndex, fieldIndex, value, subPartIndex = null, customKey = null) => {
    const key = customKey || (subPartIndex !== null ? `${partIndex}-${subPartIndex}-${fieldIndex}` : `${partIndex}-${fieldIndex}`);
    setPreviewValues({
      ...previewValues,
      [key]: value,
    });
  };

  const handleSave = () => {
    if (!formName.trim()) {
      alert("Please enter a form name");
      return;
    }
    if (parts.length === 0) {
      alert("Please add at least one part");
      return;
    }
    const formData = {
      name: formName,
      termsAndConditions,
      parts,
    };
    onSave(formData);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Form submitted! Values:\n" + JSON.stringify(previewValues, null, 2));
  };

  const renderPreviewFields = (fields, partIndex, subPartIndex = null) => {
    return fields.map((field, fieldIndex) => {
      const key = subPartIndex !== null ? `${partIndex}-${subPartIndex}-${fieldIndex}` : `${partIndex}-${fieldIndex}`;
      return (
        <div key={fieldIndex} className="flex flex-col space-y-2">
          {field.type === "prompt" ? (
            <div className="text-sm text-gray-600" dangerouslySetInnerHTML={{ __html: field.label }} />
          ) : (
            <>
              <label className="text-sm font-medium text-gray-700">
                {field.ref}: {field.label}
                {field.command.type && (
                  <span className="text-xs italic text-gray-500 ml-2">
                    (Instruction: {field.command.type}: {field.command.value})
                  </span>
                )}
              </label>
              {["text", "email", "date"].includes(field.type) && (
                <input
                  type={field.type}
                  value={previewValues[key] || ""}
                  onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex)}
                  placeholder={field.type === "date" ? "YYYY-MM-DD" : field.label}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              )}
              {field.type === "textarea" && (
                <textarea
                  value={previewValues[key] || ""}
                  onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex)}
                  placeholder="Enter text (up to 1000 characters)"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 h-24 resize-none"
                />
              )}
              {field.type === "number" && (
                <input
                  type="number"
                  value={previewValues[key] || ""}
                  onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex)}
                  placeholder={field.options.length > 0 ? `Enter: ${field.options.join(", ")}` : "Enter a number"}
                  className="w-32 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              )}
              {field.type === "select" && (
                <div className="relative w-full">
                  <select
                    value={previewValues[key] || ""}
                    onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none"
                  >
                    <option value="">Select an option</option>
                    {field.options.map((option, idx) => (
                      <option key={idx} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                    <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
              )}
              {(field.type === "radio" || field.type === "boolean") && (
                <div className="space-y-2">
                  {(field.type === "boolean" ? ["Yes", "No"] : field.options).map((option, idx) => (
                    <label key={idx} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name={key}
                        value={option}
                        checked={previewValues[key] === option}
                        onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex)}
                        className="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500"
                      />
                      <span className="text-gray-600">{option}</span>
                    </label>
                  ))}
                </div>
              )}
              {(field.type === "radio" || field.type === "boolean") &&
                field.conditions?.length > 0 &&
                field.conditions
                  .filter((cond) => cond.conditionOption === previewValues[key])
                  .map((cond, condIndex) => {
                    const condKey = `${key}-cond-${condIndex}`;
                    return (
                      <div key={condIndex} className="ml-4 border-l-2 pl-4 border-indigo-200">
                        <label className="text-sm font-medium text-gray-700">
                          {cond.ref}: {cond.label}
                        </label>
                        {["text", "email", "date"].includes(cond.type) && (
                          <input
                            type={cond.type}
                            value={previewValues[condKey] || ""}
                            onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex, condKey)}
                            placeholder={cond.type === "date" ? "YYYY-MM-DD" : cond.label}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                        )}
                        {cond.type === "textarea" && (
                          <textarea
                            value={previewValues[condKey] || ""}
                            onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex, condKey)}
                            placeholder="Enter text (up to 1000 characters)"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 h-24 resize-none"
                          />
                        )}
                        {cond.type === "number" && (
                          <input
                            type="number"
                            value={previewValues[condKey] || ""}
                            onChange={(e) => handlePreviewInput(partIndex, fieldIndex, e.target.value, subPartIndex, condKey)}
                            placeholder="Enter a number"
                            className="w-32 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                        )}
                      </div>
                    );
                  })}
            </>
          )}
        </div>
      );
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg space-y-8">
      <h2 className="text-2xl font-bold mb-6">Create Tasting Trails Partner Form</h2>

      <div>
        <label className="block text-sm font-medium mb-2">Form Terms and Conditions</label>
        <CKEditor
          editor={ClassicEditor}
          data={termsAndConditions}
          onChange={(event, editor) => setTermsAndConditions(editor.getData())}
          config={{
            toolbar: [
              "heading",
              "|",
              "bold",
              "italic",
              "link",
              "bulletedList",
              "numberedList",
              "|",
              "undo",
              "redo",
            ],
          }}
        />
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Form Name</label>
          <input
            type="text"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="e.g., Tasting Trails Partner Form"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Main Part Name (e.g., A, B, C)</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={currentPart}
              onChange={(e) => setCurrentPart(e.target.value)}
              placeholder="e.g., Part A: General Details"
              className="flex-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              onClick={addPart}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
            >
              Add Main Part
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Sub-Part Name (e.g., B1, B2)</label>
          <div className="flex gap-2">
            <select
              value={selectedParentPartIndex ?? ""}
              onChange={(e) => setSelectedParentPartIndex(e.target.value ? Number(e.target.value) : null)}
              className="px-3 py-2 border rounded-md"
            >
              <option value="">Select Parent Part</option>
              {parts.map((part, idx) => (
                <option key={idx} value={idx}>
                  {part.partName}
                </option>
              ))}
            </select>
            <input
              type="text"
              value={currentSubPart}
              onChange={(e) => setCurrentSubPart(e.target.value)}
              placeholder="e.g., Sub-Part B1: Specific Details"
              className="flex-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              onClick={addSubPart}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
            >
              Add Sub-Part
            </button>
          </div>
        </div>

        {parts.map((part, partIndex) => (
          <div key={partIndex} className="mb-8 border rounded p-4 bg-gray-50">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">{part.partName}</h3>
              <button
                onClick={() => removePart(partIndex)}
                className="text-red-600 hover:text-red-800 px-3 py-1 rounded border border-red-600 hover:bg-red-100"
              >
                Remove Part
              </button>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Main Part Terms and Conditions</label>
              <CKEditor
                editor={ClassicEditor}
                data={part.termsAndConditions}
                onChange={(event, editor) => updatePartTerms(partIndex, editor.getData())}
                config={{
                  toolbar: [
                    "heading",
                    "|",
                    "bold",
                    "italic",
                    "link",
                    "bulletedList",
                    "numberedList",
                    "|",
                    "undo",
                    "redo",
                  ],
                }}
              />
            </div>

            <div className="mb-4 p-4 bg-white border rounded space-y-4">
              <h4 className="font-medium text-gray-900">Add Field to {part.partName}</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Reference (ID)</label>
                  <input
                    type="text"
                    value={currentField.ref}
                    onChange={(e) => setCurrentField({ ...currentField, ref: e.target.value })}
                    placeholder="e.g., A1, Q1"
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    disabled={currentField.type === "prompt"}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Label</label>
                  <input
                    type="text"
                    value={currentField.label}
                    onChange={(e) => setCurrentField({ ...currentField, label: e.target.value })}
                    placeholder={
                      currentField.type === "prompt"
                        ? "Enter prompt text"
                        : "Enter field label e.g., Your Name, Class"
                    }
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Type</label>
                <select
                  value={currentField.type}
                  onChange={(e) =>
                    setCurrentField({
                      ...currentField,
                      type: e.target.value,
                      options: [],
                      command: { type: "", value: "" },
                      conditions: [],
                      ref: e.target.value === "prompt" ? "" : currentField.ref,
                      label: "",
                    })
                  }
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {fieldTypes.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>
              {(currentField.type === "select" ||
                currentField.type === "radio" ||
                currentField.type === "boolean" ||
                currentField.type === "number") && (
                <div>
                  <label className="block text-sm font-medium mb-1">Options</label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {currentField.options.map((option, index) => (
                      <span key={index} className="bg-indigo-100 text-indigo-800 px-2 py-1 rounded text-sm">
                        {option}
                        <button
                          type="button"
                          onClick={() =>
                            setCurrentField({
                              ...currentField,
                              options: currentField.options.filter((_, i) => i !== index),
                              conditions: currentField.conditions.filter((cond) => cond.conditionOption !== option),
                            })
                          }
                          className="ml-1 text-indigo-600 hover:text-indigo-800"
                        >
                          ×
                        </button>
                        {(currentField.type === "radio" || currentField.type === "boolean") && (
                          <button
                            type="button"
                            onClick={() => addConditionalField(option)}
                            className="ml-2 text-green-600 hover:text-green-800"
                          >
                            + Cond
                          </button>
                        )}
                      </span>
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={addOption}
                    className="bg-indigo-600 text-white px-3 py-1 rounded text-sm hover:bg-indigo-700"
                  >
                    Add Option
                  </button>
                </div>
              )}
              {currentField.conditions.length > 0 && (
                <div>
                  <label className="block text-sm font-medium mb-1">Conditional Fields</label>
                  <div className="space-y-2">
                    {currentField.conditions.map((cond, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <span className="text-sm text-gray-700">
                          {cond.ref}: {cond.label} (If {cond.conditionOption}, Type: {cond.type})
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setCurrentField({
                              ...currentField,
                              conditions: currentField.conditions.filter((_, i) => i !== index),
                            })
                          }
                          className="text-red-600 hover:text-red-800"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div>
                <label className="block text-sm font-medium mb-1">Command Type (e.g., Condition before adding)</label>
                <input
                  type="text"
                  value={currentField.command.type}
                  onChange={(e) => handleCommandChange("type", e.target.value)}
                  placeholder="e.g., If yes, go to B1"
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-2"
                />
                <label className="block text-sm font-medium mb-1">Command Value</label>
                <input
                  type="text"
                  value={currentField.command.value}
                  onChange={(e) => handleCommandChange("value", e.target.value)}
                  placeholder="e.g., B1"
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <button
                type="button"
                onClick={() => addField(partIndex)}
                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
              >
                Add Field to Main Part
              </button>
            </div>

            <div className="mb-4">
              <h4 className="font-medium text-gray-900 mb-2">Fields in {part.partName}</h4>
              {part.fields.length === 0 ? (
                <p className="text-gray-500">No fields added yet</p>
              ) : (
                <div className="space-y-2">
                  {part.fields.map((field, fieldIndex) => (
                    <div key={fieldIndex} className="flex items-center justify-between p-3 border rounded bg-white">
                      <div>
                        {field.type !== "prompt" && (
                          <span className="font-medium text-gray-900">{field.ref}</span>
                        )}
                        {field.type !== "prompt" && (
                          <span className="mx-2 text-gray-400">-</span>
                        )}
                        <span className="text-gray-700">{field.label}</span>
                        <span className="ml-2 text-sm text-gray-500">({field.type})</span>
                        {field.command.type && (
                          <span className="ml-2 text-sm text-gray-500">
                            ({field.command.type}: {field.command.value})
                          </span>
                        )}
                        {field.conditions?.length > 0 && (
                          <div className="text-sm text-gray-500">
                            Conditions: {field.conditions.map((cond) => `${cond.ref}: ${cond.label} (If ${cond.conditionOption})`).join(", ")}
                          </div>
                        )}
                      </div>
                      <button
                        onClick={() => removeField(partIndex, fieldIndex)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {part.subParts.map((subPart, subPartIndex) => (
              <div key={subPartIndex} className="mb-4 pl-6 border-l-4 border-indigo-200">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-lg font-medium">{subPart.subPartName}</h4>
                  <button
                    onClick={() => removeSubPart(partIndex, subPartIndex)}
                    className="text-red-600 hover:text-red-800 px-3 py-1 rounded border border-red-600 hover:bg-red-100"
                  >
                    Remove Sub-Part
                  </button>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Sub-Part Terms and Conditions</label>
                  <CKEditor
                    editor={ClassicEditor}
                    data={subPart.termsAndConditions}
                    onChange={(event, editor) => updateSubPartTerms(partIndex, subPartIndex, editor.getData())}
                    config={{
                      toolbar: [
                        "heading",
                        "|",
                        "bold",
                        "italic",
                        "link",
                        "bulletedList",
                        "numberedList",
                        "|",
                        "undo",
                        "redo",
                      ],
                    }}
                  />
                </div>

                <div className="mb-4 p-4 bg-white border rounded space-y-4">
                  <h5 className="font-medium text-gray-900">Add Field to {subPart.subPartName}</h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Reference (ID)</label>
                      <input
                        type="text"
                        value={currentField.ref}
                        onChange={(e) => setCurrentField({ ...currentField, ref: e.target.value })}
                        placeholder="e.g., A1, Q1"
                        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        disabled={currentField.type === "prompt"}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Label</label>
                      <input
                        type="text"
                        value={currentField.label}
                        onChange={(e) => setCurrentField({ ...currentField, label: e.target.value })}
                        placeholder={
                          currentField.type === "prompt"
                            ? "Enter prompt text"
                            : "Enter field label e.g., Your Name, Class"
                        }
                        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <select
                      value={currentField.type}
                      onChange={(e) =>
                        setCurrentField({
                          ...currentField,
                          type: e.target.value,
                          options: [],
                          command: { type: "", value: "" },
                          conditions: [],
                          ref: e.target.value === "prompt" ? "" : currentField.ref,
                          label: "",
                        })
                      }
                      className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      {fieldTypes.map((type) => (
                        <option key={type.value} value={type.value}>
                          {type.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  {(currentField.type === "select" ||
                    currentField.type === "radio" ||
                    currentField.type === "boolean" ||
                    currentField.type === "number") && (
                    <div>
                      <label className="block text-sm font-medium mb-1">Options</label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {currentField.options.map((option, index) => (
                          <span key={index} className="bg-indigo-100 text-indigo-800 px-2 py-1 rounded text-sm">
                            {option}
                            <button
                              type="button"
                              onClick={() =>
                                setCurrentField({
                                  ...currentField,
                                  options: currentField.options.filter((_, i) => i !== index),
                                  conditions: currentField.conditions.filter((cond) => cond.conditionOption !== option),
                                })
                              }
                              className="ml-1 text-indigo-600 hover:text-indigo-800"
                            >
                              ×
                            </button>
                            {(currentField.type === "radio" || currentField.type === "boolean") && (
                              <button
                                type="button"
                                onClick={() => addConditionalField(option)}
                                className="ml-2 text-green-600 hover:text-green-800"
                              >
                                + Cond
                              </button>
                            )}
                          </span>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={addOption}
                        className="bg-indigo-600 text-white px-3 py-1 rounded text-sm hover:bg-indigo-700"
                      >
                        Add Option
                      </button>
                    </div>
                  )}
                  {currentField.conditions.length > 0 && (
                    <div>
                      <label className="block text-sm font-medium mb-1">Conditional Fields</label>
                      <div className="space-y-2">
                        {currentField.conditions.map((cond, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <span className="text-sm text-gray-700">
                              {cond.ref}: {cond.label} (If {cond.conditionOption}, Type: {cond.type})
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                setCurrentField({
                                  ...currentField,
                                  conditions: currentField.conditions.filter((_, i) => i !== index),
                                })
                              }
                              className="text-red-600 hover:text-red-800"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-medium mb-1">Command Type (e.g., Condition before adding)</label>
                    <input
                      type="text"
                      value={currentField.command.type}
                      onChange={(e) => handleCommandChange("type", e.target.value)}
                      placeholder="e.g., If yes, go to B1"
                      className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-2"
                    />
                    <label className="block text-sm font-medium mb-1">Command Value</label>
                    <input
                      type="text"
                      value={currentField.command.value}
                      onChange={(e) => handleCommandChange("value", e.target.value)}
                      placeholder="e.g., B1"
                      className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => addField(partIndex, subPartIndex)}
                    className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                  >
                    Add Field to Sub-Part
                  </button>
                </div>

                <div>
                  {subPart.fields.length === 0 ? (
                    <p className="text-gray-500">No fields added yet</p>
                  ) : (
                    <div className="space-y-2">
                      {subPart.fields.map((field, fieldIndex) => (
                        <div key={fieldIndex} className="flex items-center justify-between p-3 border rounded bg-white">
                          <div>
                            {field.type !== "prompt" && (
                              <span className="font-medium text-gray-900">{field.ref}</span>
                            )}
                            {field.type !== "prompt" && (
                              <span className="mx-2 text-gray-400">-</span>
                            )}
                            <span className="text-gray-700">{field.label}</span>
                            <span className="ml-2 text-sm text-gray-500">({field.type})</span>
                            {field.command.type && (
                              <span className="ml-2 text-sm text-gray-500">
                                ({field.command.type}: {field.command.value})
                              </span>
                            )}
                            {field.conditions?.length > 0 && (
                              <div className="text-sm text-gray-500">
                                Conditions: {field.conditions.map((cond) => `${cond.ref}: ${cond.label} (If ${cond.conditionOption})`).join(", ")}
                              </div>
                            )}
                          </div>
                          <button
                            onClick={() => removeField(partIndex, fieldIndex, subPartIndex)}
                            className="text-red-600 hover:text-red-800"
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ))}

        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-gray-700 bg-gray-200 rounded hover:bg-gray-300"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-2 text-white bg-indigo-600 rounded hover:bg-indigo-700"
          >
            Save Form
          </button>
        </div>
      </div>

      <div className="border-t pt-6 mt-6">
        <h3 className="text-xl font-bold mb-4">Interactive Form Preview</h3>
        <form onSubmit={handleSubmit} className="space-y-6 bg-gray-50 p-6 rounded-lg border">
          <h4 className="text-lg font-semibold text-indigo-600">{formName || "Tasting Trails Partner Form"}</h4>
          {termsAndConditions && (
            <div>
              <h5 className="text-sm font-medium text-gray-700 mb-2">Form Terms and Conditions</h5>
              <div className="text-sm text-gray-600 border p-4 rounded bg-white" dangerouslySetInnerHTML={{ __html: termsAndConditions }} />
            </div>
          )}
          {parts.length === 0 ? (
            <p className="text-gray-500">No parts added yet</p>
          ) : (
            parts.map((part, partIndex) => (
              <div key={partIndex} className="border rounded-lg p-4 bg-white shadow-sm">
                <h5 className="text-md font-medium mb-3 text-gray-800">{part.partName}</h5>
                {part.termsAndConditions && (
                  <div className="mb-4">
                    <h6 className="text-sm font-medium text-gray-700 mb-2">Main Part Terms and Conditions</h6>
                    <div className="text-sm text-gray-600 border p-4 rounded bg-white" dangerouslySetInnerHTML={{ __html: part.termsAndConditions }} />
                  </div>
                )}
                {part.fields.length > 0 && (
                  <div className="space-y-4 mb-4">
                    {renderPreviewFields(part.fields, partIndex)}
                  </div>
                )}
                {part.subParts.length > 0 ? (
                  part.subParts.map((subPart, subPartIndex) => (
                    <div key={subPartIndex} className="ml-4 border-l-2 pl-4 border-gray-300">
                      <h6 className="text-sm font-medium mb-2 text-gray-700">{subPart.subPartName}</h6>
                      {subPart.termsAndConditions && (
                        <div className="mb-4">
                          <h6 className="text-sm font-medium text-gray-700 mb-2">Sub-Part Terms and Conditions</h6>
                          <div className="text-sm text-gray-600 border p-4 rounded bg-white" dangerouslySetInnerHTML={{ __html: subPart.termsAndConditions }} />
                        </div>
                      )}
                      {subPart.fields.length === 0 ? (
                        <p className="text-gray-500 text-sm">No fields in this sub-part</p>
                      ) : (
                        <div className="space-y-4">
                          {renderPreviewFields(subPart.fields, partIndex, subPartIndex)}
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  !part.fields.length && <p className="text-gray-500 text-sm">No sub-parts or fields in this part</p>
                )}
              </div>
            ))
          )}
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
            >
              Submit Form
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FormBuilder;