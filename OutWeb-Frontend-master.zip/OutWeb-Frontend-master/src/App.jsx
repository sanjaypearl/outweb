import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { DataProvider } from "./contexts/DataContext";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import UserDashboard from "./pages/UserDashboard";
import AdminDashboard from "./pages/AdminDashboard";

import ChangePasswordPage from "./components/chnagePassword";
import { Toaster } from "react-hot-toast";

import { useSelector } from "react-redux";

function ProtectedRoute({ children, requiredRole }) {
  const user = useSelector((state) => state.auth.user);

  // 1️⃣ If user is not logged in → redirect to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // 2️⃣ If role is required but doesn't match → redirect based on actual role
  if (requiredRole && user.role !== requiredRole) {
    if (user.role === "ADMIN") return <Navigate to="/admin" replace />;
    if (user.role === "USER") return <Navigate to="/dashboard" replace />;
    return <Navigate to="/" replace />;
  }

  // 3️⃣ Otherwise → allow access
  return children;
}

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />

              {/* Protected routes */}
              <Route
                path="/change-password"
                element={
                  <ProtectedRoute requiredRole="USER">
                    <ChangePasswordPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute requiredRole="USER">
                    <UserDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin"
                element={
                  <ProtectedRoute requiredRole="ADMIN">
                    <AdminDashboard />
                  </ProtectedRoute>
                }
              />

              {/* catch-all route */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>

            <Toaster position="top-center" reverseOrder={false} />
          </div>
        </Router>
      </DataProvider>
    </AuthProvider>
  );
}

export default App;
