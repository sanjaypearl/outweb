/**
 * Recursively collects all fields from a form structure
 * @param {Object} formFields - The `fields` object of a form
 * @returns {Array} - Flattened list of all field objects
 */
const collectAllFields = (formFields) => {
  let collected = [];

  if (!formFields) return collected;

  // Top-level fields
  if (Array.isArray(formFields.fields)) {
    collected = collected.concat(formFields.fields);
  }

  // Parts
  if (Array.isArray(formFields.parts)) {
    formFields.parts.forEach((part) => {
      if (Array.isArray(part.fields)) {
        collected = collected.concat(part.fields);
      }

      if (Array.isArray(part.subParts)) {
        part.subParts.forEach((sub) => {
          if (Array.isArray(sub.fields)) {
            collected = collected.concat(sub.fields);
          }
        });
      }
    });
  }

  return collected;
};

/**
 * Generates a clean constant name from field ref/label
 */
const generateConstantName = (ref, label) => {
  const base = ref || label || "constant";
  return (
    base
      .toString()
      .replace(/\s+/g, "")
      .replace(/[^a-zA-Z0-9]/g, "")
      .replace(/^\d+/, "") + "Options"
  );
};

/**
 * Extracts unique options from form fields to generate constants
 */
export const generateFormConstants = (forms) => {
  const constants = {};

  forms.forEach((form) => {
    const allFields = collectAllFields(form.fields);

    allFields.forEach((field) => {
      if (field.options && field.options.length > 0) {
        const constantName = generateConstantName(field.ref, field.label);

        if (!constants[constantName]) {
          constants[constantName] = [...new Set(field.options)];
        }
      }

      // Handle boolean fields - always add Yes/No options
      if (field.type === "boolean") {
        constants.yesNo = ["Yes", "No"];
      }
    });
  });

  return constants;
};

/**
 * Processes form data to create a flow configuration
 */
export const processFormFlow = (formData) => {
  if (!formData || !formData.fields) return null;

  const allFields = collectAllFields(formData.fields);

  const flowConfig = {
    id: formData.id,
    name: formData.name,
    fields: {},
    flowMap: {},
    initialFields: [],
  };

  allFields.forEach((field) => {
    flowConfig.fields[field.ref] = {
      ...field,
      isVisible: false,
    };

    if (field.command && Object.keys(field.command).length > 0) {
      flowConfig.flowMap[field.ref] = field.command;
    }
  });

  const allTargetFields = new Set();
  Object.values(flowConfig.flowMap).forEach((commands) => {
    Object.values(commands).forEach((targets) => {
      if (Array.isArray(targets)) {
        targets.forEach((target) => allTargetFields.add(target));
      }
    });
  });

  flowConfig.initialFields = allFields
    .filter((field) => !allTargetFields.has(field.ref))
    .map((field) => field.ref);

  return flowConfig;
};

/**
 * Generates constants file content
 */
const generateConstantsFile = (constants) => {
  return Object.entries(constants)
    .map(([key, values]) => `export const ${key} = ${JSON.stringify(values)};`)
    .join("\n");
};

/**
 * Main processor function that handles Excel/API data
 */
export const processExcelFormData = (formsData) => {
  if (!Array.isArray(formsData)) return null;

  const constants = generateFormConstants(formsData);
  const processedForms = formsData.map((form) => processFormFlow(form));

  const supplierAgreement = processedForms.find(
    (form) => form && form.name?.toLowerCase().includes("supplier")
  );

  const sachinsAgreement = processedForms.find(
    (form) => form && form.name?.toLowerCase().includes("sachin")
  );

  return {
    constants,
    constantsFileContent: generateConstantsFile(constants),
    forms: {
      supplierAgreement,
      sachinsAgreement,
      all: processedForms.filter(Boolean),
    },
  };
};
