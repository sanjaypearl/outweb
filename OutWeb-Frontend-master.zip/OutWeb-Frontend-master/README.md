updates 9/9/25
